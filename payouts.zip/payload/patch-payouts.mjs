import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const SPEC = {
  "name": "payouts",
  "backup": ".backup-payouts",
  "prefixes": [
    "biz-pay__",
    "lc-paydone"
  ],
  "newFiles": [
    "supabase/functions/payouts/index.ts",
    "supabase/functions/payouts/providers.ts",
    "src/services/payouts.js",
    "src/components/business/PayoutsSection.jsx",
    "src/styles/business/payouts.css",
    "src/pages/app/PayoutsDone.jsx",
    "src/styles/app/payouts-done.css",
    "tests/suites/payouts.mjs"
  ],
  "replaceFiles": [],
  "patches": [
    {
      "file": "src/pages/business/SettingsPage.jsx",
      "find": "import { PushRow } from '../../components/common/PushSetup'\n",
      "replace": "import { PushRow } from '../../components/common/PushSetup'\nimport { PayoutsSection } from '../../components/business/PayoutsSection'\n"
    },
    {
      "file": "src/pages/business/SettingsPage.jsx",
      "find": "    const { notify } = useWorkspace()",
      "replace": "    const { notify, isOwner } = useWorkspace()"
    },
    {
      "file": "src/pages/business/SettingsPage.jsx",
      "find": "                <Section id=\"security\" title=\"Sign-in and security\">",
      "replace": "                {isOwner && <PayoutsSection notify={notify} />}\n\n                <Section id=\"security\" title=\"Sign-in and security\">"
    },
    {
      "file": "src/pages/business/SettingsPage.jsx",
      "find": "<p className=\"biz-page__sub\">Your account, sign-in and security.</p>",
      "replace": "<p className=\"biz-page__sub\">Your account, payouts, sign-in and security.</p>"
    },
    {
      "file": "src/BookingApp.jsx",
      "find": "const AppDownload = lazy(() => import('./pages/app/AppDownload'))\n",
      "replace": "const AppDownload = lazy(() => import('./pages/app/AppDownload'))\nconst PayoutsDone = lazy(() => import('./pages/app/PayoutsDone'))\n"
    },
    {
      "file": "src/BookingApp.jsx",
      "find": "                    <Route path=\"/app\" element={<AppDownload />} />",
      "replace": "                    <Route path=\"/app\" element={<AppDownload />} />\n                    <Route path=\"/payouts/done\" element={<PayoutsDone />} />"
    },
    {
      "file": "supabase/config.toml",
      "find": "[functions.notify]\nverify_jwt = false\n",
      "replace": "[functions.notify]\nverify_jwt = false\n\n[functions.payouts]\nverify_jwt = true\n"
    },
    {
      "file": "tests/harness/fakeSupabase.js",
      "find": "export const supabase = {\n  from: builder,",
      "replace": "// Payouts server function: ?payoutstate=not_started|pending|waiting|restricted|active|error|paystack|paystack-active\nconst PAYOUT_ROWS = {\n  not_started: { provider: 'stripe', status: 'not_started', details_due: [] },\n  pending: { provider: 'stripe', status: 'pending', details_due: ['individual.dob.day'] },\n  waiting: { provider: 'stripe', status: 'pending', details_due: [] },\n  restricted: { provider: 'stripe', status: 'restricted', details_due: ['external_account'] },\n  active: { provider: 'stripe', status: 'active', bank_name: 'Millennium BCP', account_last4: '6789', details_due: [] },\n  paystack: { provider: 'paystack', status: 'not_started', details_due: [] },\n  'paystack-active': { provider: 'paystack', status: 'active', bank_name: 'Access Bank', account_last4: '6789', details_due: [] },\n}\nconst failed = (message) => ({ data: null, error: { context: { json: async () => ({ error: message }) } } })\nconst payouts = (body) => {\n  const state = new URLSearchParams(window.location.search).get('payoutstate') || 'not_started'\n  if (state === 'error') return failed('Payouts are not switched on yet')\n  const row = { test: true, ...(PAYOUT_ROWS[state] || PAYOUT_ROWS.not_started) }\n  if (body.action === 'status') return { data: row, error: null }\n  if (body.action === 'start' || body.action === 'manage') return { data: { url: `/?path=${encodeURIComponent('/portal/settings')}&payouts=return&payoutstate=active` }, error: null }\n  if (body.action === 'banks') return { data: { banks: [{ code: '044', name: 'Access Bank' }, { code: '058', name: 'GTBank' }] }, error: null }\n  if (body.action === 'resolve') return body.account_number === '0123456789' ? { data: { account_name: 'ADEBAYO OLUWASEUN' }, error: null } : failed('We could not find that account. Check the number and the bank.')\n  if (body.action === 'connect') return { data: { ...PAYOUT_ROWS['paystack-active'], test: true, account_name: 'ADEBAYO OLUWASEUN' }, error: null }\n  return failed('Unknown action')\n}\n\nexport const supabase = {\n  functions: { invoke: async (name, { body } = {}) => { calls.push(['fn', name, body]); return name === 'payouts' ? payouts(body || {}) : { data: null, error: null } } },\n  from: builder,"
    },
    {
      "file": "tests/run.mjs",
      "find": "import pricing from './suites/pricing.mjs'\n",
      "replace": "import pricing from './suites/pricing.mjs'\nimport payouts from './suites/payouts.mjs'\n"
    },
    {
      "file": "tests/run.mjs",
      "find": "['pricing', pricing]] }",
      "replace": "['pricing', pricing], ['payouts', payouts]] }"
    }
  ],
  "retires": []
}

const here = path.dirname(fileURLToPath(import.meta.url))
const root = process.cwd()
const check = process.argv.includes('--check')
const problems = []
const plan = []

const abs = (rel) => path.join(root, ...rel.split('/'))
const source = (rel) => path.join(here, 'files', ...rel.split('/'))
const read = (p) => fs.readFileSync(p, 'utf8')
const eolOf = (text) => (text.includes('\r\n') ? '\r\n' : '\n')
const toEol = (text, eol) => text.replace(/\r\n/g, '\n').replace(/\n/g, eol)
const sha = (text) => crypto.createHash('sha256').update(text.replace(/\r\n/g, '\n')).digest('hex')
const count = (hay, needle) => (needle ? hay.split(needle).length - 1 : 0)

const pkg = JSON.parse(read(abs('package.json')))
if (pkg.name !== 'locappoint') {
    console.error('  [ABORT] This is not the locappoint repo.')
    process.exit(1)
}

for (const rel of SPEC.newFiles) {
    if (fs.existsSync(abs(rel))) problems.push(`${rel} already exists (patch already applied?)`)
    else if (!fs.existsSync(source(rel))) problems.push(`payload is missing ${rel}`)
    else plan.push(['NEW', rel])
}

for (const { file, sha: expected } of SPEC.replaceFiles) {
    if (!fs.existsSync(abs(file))) { problems.push(`${file} is missing`); continue }
    if (sha(read(abs(file))) !== expected) { problems.push(`${file} changed since this patch was built (or it is already applied)`); continue }
    plan.push(['REPLACE', file])
}

const srcFiles = () => {
    const out = []
    const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const full = path.join(dir, entry.name)
            if (entry.isDirectory()) { if (entry.name !== 'node_modules') walk(full) }
            else if (/\.(jsx?|css)$/.test(entry.name)) out.push(full)
        }
    }
    walk(abs('src'))
    return out
}

for (const prefix of SPEC.prefixes || []) {
    const owners = srcFiles().filter((full) => read(full).includes(prefix)).map((full) => path.relative(root, full))
    if (owners.length) problems.push(`class prefix ${prefix} is already used in ${owners.join(', ')}`)
}

const edits = new Map()
for (const p of SPEC.patches) {
    if (!fs.existsSync(abs(p.file))) { problems.push(`${p.file} is missing`); continue }
    if (!edits.has(p.file)) edits.set(p.file, read(abs(p.file)))
    const current = edits.get(p.file)
    const eol = eolOf(current)
    const find = toEol(p.find, eol)
    const hits = count(current, find)
    if (hits !== 1) { problems.push(`${p.file}: anchor matched ${hits} times, expected 1: ${JSON.stringify(p.find.slice(0, 60))}`); continue }
    edits.set(p.file, current.replace(find, () => toEol(p.replace, eol)))
}
for (const file of edits.keys()) plan.push(['EDIT', file])

for (const rel of SPEC.retires) {
    if (!fs.existsSync(abs(rel))) { problems.push(`${rel} is missing`); continue }
    const base = path.basename(rel)
    const stem = /\.(jsx?)$/.test(base) ? base.replace(/\.(jsx?)$/, '') : base
    const pattern = new RegExp(`[\\/'"]${stem.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\.jsx?)?['"]`)
    const planned = (full) => {
        const key = path.relative(root, full).split(path.sep).join('/')
        if (SPEC.replaceFiles.some((f) => f.file === key)) return read(source(key))
        return edits.has(key) ? edits.get(key) : read(full)
    }
    const users = srcFiles().filter((full) => full !== abs(rel) && pattern.test(planned(full))).map((full) => path.relative(root, full))
    if (users.length) problems.push(`${rel} is still imported by ${users.join(', ')}`)
    else plan.push(['RETIRE', rel])
}

if (problems.length) {
    console.error('  [ABORT] Nothing was written:')
    for (const p of problems) console.error(`    ${p}`)
    process.exit(1)
}

if (check) {
    for (const [kind, rel] of plan) console.log(`  [${kind}] ${rel}`)
    console.log('  Checks passed.')
    process.exit(0)
}

for (const [kind, rel] of plan) {
    const target = abs(rel)
    if (kind === 'NEW') {
        fs.mkdirSync(path.dirname(target), { recursive: true })
        fs.copyFileSync(source(rel), target)
    } else if (kind === 'REPLACE') {
        const eol = eolOf(read(target))
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, toEol(read(source(rel)), eol))
    } else if (kind === 'EDIT') {
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, edits.get(rel))
    } else if (kind === 'RETIRE') {
        fs.renameSync(target, target + '.mistake')
    }
    console.log(`  [${kind}] ${rel}`)
}
console.log('  Patch applied.')
