export type Row = {
    id: string
    kind: string
    channel: string
    recipient_email: string | null
    appointment_id: string | null
    payload: Record<string, unknown>
    attempts: number
}

export type Message = { from: string; to: string; subject: string; html: string; text: string }

export type Render = (row: Row) => Message | null
