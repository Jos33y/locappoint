// Booking emails. The panel is the day of the booking: its time in the gutter, the booking in the slot,
// a struck-through "was" row when it moved, and the address. Business emails lead with the client,
// client emails with the service.

import { layout } from '../layout.ts'
import { slot, was, where, type Slot } from '../blocks.ts'
import { SITE, FOOTER_TEXT, cutoffText, duration, esc, longDay, oneLine, plainText, priceText, relativeDay, shortDay } from '../format.ts'
import type { Message, Render, Row } from '../types.ts'

const ADDRESS = 'bookings@relay.locappoint.com'

type Booking = {
    title: string
    preheader: string
    h1: string
    sub: string
    day: string
    place: string
    was?: string
    slot: Slot
    where?: string
    small: string
}

const senderName = (value: string) => `"${value.replace(/["<>\\]/g, '').slice(0, 60)} via LocAppoint" <${ADDRESS}>`

const bookingFacts = (row: Row) => {
    const p = row.payload as Record<string, any>
    const date = String(p.date || '')
    const time = String(p.time || '')
    const bizRaw = oneLine(p.business_name) || 'the business'
    const clientRaw = oneLine(p.client_name) || 'A client'
    const serviceRaw = oneLine(p.service_name) || 'Booking'
    const price = priceText(p.price, p.country)
    const staff = oneLine(p.staff_name)
    const place = [oneLine(p.address), oneLine(p.city)].filter(Boolean)
    const contact = oneLine(p.business_whatsapp) || oneLine(p.business_phone)
    const movedFrom = p.moved_from ? String(p.moved_from) : ''
    return {
        p,
        date,
        time,
        tz: String(p.timezone || 'Europe/Lisbon'),
        bizRaw,
        clientRaw,
        serviceRaw,
        biz: esc(bizRaw),
        client: esc(clientRaw),
        service: esc(serviceRaw),
        short: `${shortDay(date)}, ${time}`,
        long: `${longDay(date)} at ${time}`,
        dayLabel: longDay(date),
        clientDetails: [duration(Number(p.duration_minutes) || 0), staff ? `with ${esc(staff)}` : '', price].filter(Boolean).join(' &middot; '),
        businessDetails: [esc(serviceRaw), duration(Number(p.duration_minutes) || 0), price, staff ? `with ${esc(staff)}` : ''].filter(Boolean).join(' &middot; '),
        where: place.length ? esc(place.join(', ')) : '',
        was: movedFrom ? `${shortDay(movedFrom)}, ${movedFrom.slice(11, 16)}` : '',
        contact: contact ? esc(contact) : '',
        cutoff: cutoffText(Number(p.cancel_cutoff_minutes) || 0),
        mine: `${SITE}/client/appointments?booking=${row.appointment_id}`,
        calendar: `${SITE}/portal/calendar?booking=${row.appointment_id}`,
        page: `${SITE}/${String(p.slug || '').replace(/[^a-z0-9-]/gi, '')}`,
    }
}

type Facts = ReturnType<typeof bookingFacts>

const bookingMessage = (row: Row, f: Facts, forClient: boolean, subject: string, o: Booking, lines: string[]): Message => ({
    from: forClient ? senderName(f.bizRaw) : `LocAppoint <${ADDRESS}>`,
    to: row.recipient_email!,
    subject,
    html: layout({
        title: o.title,
        preheader: o.preheader,
        h1: o.h1,
        sub: o.sub,
        day: o.day,
        place: o.place,
        rows: [o.was ? was(o.was) : '', slot(o.slot), o.where ? where(o.where) : ''],
        small: o.small,
    }),
    text: [
        plainText(o.h1),
        '',
        ...lines,
        '',
        ...(o.slot.button ? [`${o.slot.button.label}: ${o.slot.button.href}`, ''] : []),
        plainText(o.small),
        '',
        ...FOOTER_TEXT,
    ].join('\n'),
})

const clientSmall = (f: Facts, lead: string) =>
    `${lead}${f.contact ? ` Need to reach ${f.biz}? Message them on ${f.contact}.` : ''}`

const VIEW = (f: Facts) => ({ label: 'View booking', href: f.mine, width: 150 })
const CALENDAR = (f: Facts) => ({ label: 'Open calendar', href: f.calendar, width: 160 })
const BOOK_AGAIN = (f: Facts) => ({ label: 'Pick a new time', href: f.page, width: 170 })

const forClient = (row: Row) => row.payload.audience !== 'business'

export const BOOKING: Record<string, Render> = {
    booking_confirmed: (row) => {
        const f = bookingFacts(row)
        const o: Booking = {
            title: 'You are booked',
            preheader: `${f.service} at ${f.biz}, ${f.long}.`,
            h1: 'You&rsquo;re booked.',
            sub: `${f.biz} has you down for ${f.long}. Here is your day.`,
            day: f.dayLabel,
            place: f.biz,
            slot: { state: 'booked', time: f.time, title: f.service, sub: f.clientDetails, button: VIEW(f) },
            where: f.where,
            small: clientSmall(f, `Plans change. You can move or cancel it from your bookings ${f.cutoff}.`),
        }
        return bookingMessage(row, f, true, `Booked: ${f.serviceRaw} at ${f.bizRaw}, ${f.short}`, o,
            [`${f.serviceRaw} at ${f.bizRaw}`, `${f.long}`, plainText(f.clientDetails), f.where ? plainText(f.where) : ''].filter(Boolean))
    },

    booking_requested: (row) => {
        const f = bookingFacts(row)
        const o: Booking = {
            title: 'Request sent',
            preheader: `${f.biz} confirms bookings themselves. We will email you the moment they do.`,
            h1: 'Request sent.',
            sub: `${f.biz} confirms each booking themselves. We will email you the moment they do.`,
            day: f.dayLabel,
            place: f.biz,
            slot: { state: 'waiting', time: f.time, flag: `Waiting for ${f.biz}`, title: f.service, sub: f.clientDetails, button: VIEW(f) },
            where: f.where,
            small: clientSmall(f, 'The time is held for you while they decide.'),
        }
        return bookingMessage(row, f, true, `Request sent to ${f.bizRaw} for ${f.short}`, o,
            [`${f.serviceRaw} at ${f.bizRaw}`, f.long, `Waiting for ${f.bizRaw} to confirm.`])
    },

    booking_declined: (row) => {
        const f = bookingFacts(row)
        const o: Booking = {
            title: 'Not this time',
            preheader: `${f.biz} could not take your booking for ${f.short}. Other times are open.`,
            h1: 'Not this time.',
            sub: `${f.biz} could not take your booking for ${f.long}. Other times are open on their page.`,
            day: f.dayLabel,
            place: f.biz,
            slot: { state: 'cancelled', time: f.time, flag: 'Not accepted', title: f.service, sub: f.clientDetails, button: BOOK_AGAIN(f) },
            small: clientSmall(f, 'There is nothing else you need to do.'),
        }
        return bookingMessage(row, f, true, `${f.bizRaw} could not take your booking for ${f.short}`, o,
            [`${f.bizRaw} could not take your booking for ${f.long}.`, `Other times: ${f.page}`])
    },

    booking_cancelled: (row) => {
        const f = bookingFacts(row)
        if (forClient(row)) {
            const o: Booking = {
                title: 'Booking cancelled',
                preheader: `${f.biz} cancelled your booking for ${f.short}.`,
                h1: 'Booking cancelled.',
                sub: `${f.biz} cancelled your booking for ${f.long}. Sorry about that.`,
                day: f.dayLabel,
                place: f.biz,
                slot: { state: 'cancelled', time: f.time, flag: `Cancelled by ${f.biz}`, title: f.service, sub: f.clientDetails, button: BOOK_AGAIN(f) },
                small: clientSmall(f, 'There is nothing else you need to do.'),
            }
            return bookingMessage(row, f, true, `${f.bizRaw} cancelled your booking for ${f.short}`, o,
                [`${f.bizRaw} cancelled your booking for ${f.long}.`, `Pick a new time: ${f.page}`])
        }
        const o: Booking = {
            title: 'Booking cancelled',
            preheader: `${f.client} cancelled ${f.short}. The time is open again.`,
            h1: 'A slot opened up.',
            sub: `${f.client} cancelled ${f.service} for ${f.long}. The time is open for other clients again.`,
            day: f.dayLabel,
            place: f.biz,
            slot: { state: 'cancelled', time: f.time, flag: 'Cancelled by the client', title: f.client, sub: f.businessDetails, button: CALENDAR(f) },
            small: 'You do not need to do anything.',
        }
        return bookingMessage(row, f, false, `Cancelled: ${f.clientRaw}, ${f.short}`, o,
            [`${f.clientRaw} cancelled ${f.serviceRaw} for ${f.long}.`, 'The time is open again.'])
    },

    booking_moved: (row) => {
        const f = bookingFacts(row)
        if (forClient(row)) {
            const o: Booking = {
                title: 'New time',
                preheader: `${f.biz} moved your booking to ${f.long}.`,
                h1: 'New time.',
                sub: `${f.biz} moved your booking to ${f.long}.`,
                day: f.dayLabel,
                place: f.biz,
                was: f.was,
                slot: { state: 'booked', time: f.time, title: f.service, sub: f.clientDetails, button: VIEW(f) },
                where: f.where,
                small: clientSmall(f, `Does the new time not work? You can change or cancel it from your bookings ${f.cutoff}.`),
            }
            return bookingMessage(row, f, true, `New time: ${f.short} at ${f.bizRaw}`, o,
                [`${f.bizRaw} moved your booking.`, f.was ? `Was: ${f.was}` : '', `Now: ${f.long}`].filter(Boolean))
        }
        const o: Booking = {
            title: 'Booking moved',
            preheader: `${f.client} moved their booking to ${f.short}.`,
            h1: 'Booking moved.',
            sub: `${f.client} moved ${f.service} to ${f.long}.`,
            day: f.dayLabel,
            place: f.biz,
            was: f.was,
            slot: { state: 'booked', time: f.time, title: f.client, sub: f.businessDetails, button: CALENDAR(f) },
            small: 'It is already in your calendar. You do not need to do anything.',
        }
        return bookingMessage(row, f, false, `Moved: ${f.clientRaw} to ${f.short}`, o,
            [`${f.clientRaw} moved ${f.serviceRaw}.`, f.was ? `Was: ${f.was}` : '', `Now: ${f.long}`].filter(Boolean))
    },

    booking_reminder: (row) => {
        const f = bookingFacts(row)
        const when = relativeDay(f.date, f.tz)
        const o: Booking = {
            title: 'See you soon',
            preheader: `${f.service} at ${f.biz}, ${when} at ${f.time}.`,
            h1: when === 'tomorrow' ? 'See you tomorrow.' : when === 'today' ? 'See you today.' : 'See you soon.',
            sub: `${f.service} at ${f.biz}, ${when} at ${f.time}.`,
            day: f.dayLabel,
            place: f.biz,
            slot: { state: 'booked', time: f.time, title: f.service, sub: f.clientDetails, button: VIEW(f) },
            where: f.where,
            small: clientSmall(f, `Cannot make it? Cancel from your bookings ${f.cutoff}, so someone else can take the time.`),
        }
        const lead = when === 'tomorrow' ? 'Tomorrow' : when === 'today' ? 'Today' : shortDay(f.date)
        return bookingMessage(row, f, true, `${lead} at ${f.time}: ${f.serviceRaw} at ${f.bizRaw}`, o,
            [`${f.serviceRaw} at ${f.bizRaw}`, f.long, f.where ? plainText(f.where) : ''].filter(Boolean))
    },

    booking_new: (row) => {
        const f = bookingFacts(row)
        const o: Booking = {
            title: 'New booking',
            preheader: `${f.client} booked ${f.service} for ${f.long}.`,
            h1: 'New booking.',
            sub: `${f.client} booked ${f.service} for ${f.long}. It is confirmed and in your calendar.`,
            day: f.dayLabel,
            place: f.biz,
            slot: { state: 'booked', time: f.time, title: f.client, sub: f.businessDetails, button: CALENDAR(f) },
            small: f.p.client_phone ? `Their number is ${esc(f.p.client_phone)}, if you need to reach them.` : 'You do not need to do anything.',
        }
        return bookingMessage(row, f, false, `New booking: ${f.clientRaw}, ${f.short}`, o,
            [`${f.clientRaw} booked ${f.serviceRaw}.`, f.long, plainText(f.businessDetails)])
    },

    booking_request: (row) => {
        const f = bookingFacts(row)
        const moved = Boolean(f.was)
        const o: Booking = {
            title: 'Request to confirm',
            preheader: `${f.client} wants ${f.short}. Confirm or decline.`,
            h1: moved ? 'New time to confirm.' : 'New request.',
            sub: moved
                ? `${f.client} moved ${f.service} to ${f.long}. It needs your OK.`
                : `${f.client} wants ${f.service} on ${f.long}. The time is held until you answer.`,
            day: f.dayLabel,
            place: f.biz,
            was: f.was,
            slot: { state: 'waiting', time: f.time, flag: 'Waiting for you', title: f.client, sub: f.businessDetails, button: { label: 'Confirm or decline', href: f.calendar, width: 200 } },
            small: 'Answer soon. Clients book elsewhere when they wait too long. You can switch to automatic confirmation in Business page, Bookings.',
        }
        return bookingMessage(row, f, false, `${moved ? 'New time to confirm' : 'Request to confirm'}: ${f.clientRaw}, ${f.short}`, o,
            [moved ? `${f.clientRaw} moved ${f.serviceRaw} and it needs your OK.` : `${f.clientRaw} wants ${f.serviceRaw}.`, f.was ? `Was: ${f.was}` : '', f.long, `Confirm or decline: ${f.calendar}`].filter(Boolean))
    },
}
