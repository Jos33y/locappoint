import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const SPEC = {
  "name": "email-modules",
  "backup": ".backup-emailmods",
  "prefixes": [],
  "newFiles": [
    "supabase/functions/notify/layout.ts",
    "supabase/functions/notify/blocks.ts",
    "supabase/functions/notify/format.ts",
    "supabase/functions/notify/types.ts",
    "supabase/functions/notify/emails/index.ts",
    "supabase/functions/notify/emails/account.ts",
    "supabase/functions/notify/emails/booking.ts",
    "tests/suites/emails.mjs",
    "supabase/config.toml"
  ],
  "replaceFiles": [
    {
      "file": "supabase/functions/notify/index.ts",
      "sha": "ae4d644f61fc4a75936eb2fa2b1796e4bfea289622f7b5faf666178f26452b03"
    }
  ],
  "patches": [
    {
      "file": "tests/run.mjs",
      "find": "import settings from './suites/settings.mjs'\n",
      "replace": "import settings from './suites/settings.mjs'\nimport emails from './suites/emails.mjs'\n"
    },
    {
      "file": "tests/run.mjs",
      "find": "SUITES.all = [...SUITES.flows, ...SUITES.layout]\nSUITES.quick = [...SUITES.flows, ['layout, 4 key screens', layout]]",
      "replace": "SUITES.emails = [['emails', emails]]\nSUITES.all = [...SUITES.flows, ...SUITES.emails, ...SUITES.layout]\nSUITES.quick = [...SUITES.flows, ...SUITES.emails, ['layout, 4 key screens', layout]]"
    },
    {
      "file": "tests/run.mjs",
      "find": "console.log(`Unknown suite \"${target}\". Use quick, flows, layout or all.`)",
      "replace": "console.log(`Unknown suite \"${target}\". Use quick, flows, emails, layout or all.`)"
    },
    {
      "file": "tests/run.mjs",
      "find": "        await suite({ browser, url, check, only, cover: path.join(here, 'fixtures', 'cover.jpg') })",
      "replace": "        await suite({ browser, url, check, only, server, root: path.resolve(here, '..'), cover: path.join(here, 'fixtures', 'cover.jpg') })"
    },
    {
      "file": "package.json",
      "find": "    \"test:layout\": \"node tests/run.mjs layout\"",
      "replace": "    \"test:layout\": \"node tests/run.mjs layout\",\n    \"test:emails\": \"node tests/run.mjs emails\",\n    \"deploy:notify\": \"npx supabase functions deploy notify --use-api\""
    },
    {
      "file": "tests/README.md",
      "find": "| `npm run test:layout` |",
      "replace": "| `npm run test:emails` | Every email the notify function sends, with sample data: renders, escapes names, https links, WCAG AAA contrast, no text under 12px, no sideways scroll at 375 and 620px | about 20 seconds |\n| `npm run test:layout` |"
    },
    {
      "file": "tests/README.md",
      "find": "| `npm test` | Flows plus 4 key screens",
      "replace": "| `npm test` | Flows, emails, plus 4 key screens"
    }
  ],
  "retires": []
}

const here = path.dirname(fileURLToPath(import.meta.url))
const root = process.cwd()
const check = process.argv.includes('--check')
const problems = []
const plan = []

const abs = (rel) => path.join(root, ...rel.split('/'))
const source = (rel) => path.join(here, 'files', ...rel.split('/'))
const read = (p) => fs.readFileSync(p, 'utf8')
const eolOf = (text) => (text.includes('\r\n') ? '\r\n' : '\n')
const toEol = (text, eol) => text.replace(/\r\n/g, '\n').replace(/\n/g, eol)
const sha = (text) => crypto.createHash('sha256').update(text.replace(/\r\n/g, '\n')).digest('hex')
const count = (hay, needle) => (needle ? hay.split(needle).length - 1 : 0)

const pkg = JSON.parse(read(abs('package.json')))
if (pkg.name !== 'locappoint') {
    console.error('  [ABORT] This is not the locappoint repo.')
    process.exit(1)
}

for (const rel of SPEC.newFiles) {
    if (fs.existsSync(abs(rel))) problems.push(`${rel} already exists (patch already applied?)`)
    else if (!fs.existsSync(source(rel))) problems.push(`payload is missing ${rel}`)
    else plan.push(['NEW', rel])
}

for (const { file, sha: expected } of SPEC.replaceFiles) {
    if (!fs.existsSync(abs(file))) { problems.push(`${file} is missing`); continue }
    if (sha(read(abs(file))) !== expected) { problems.push(`${file} changed since this patch was built (or it is already applied)`); continue }
    plan.push(['REPLACE', file])
}

const srcFiles = () => {
    const out = []
    const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const full = path.join(dir, entry.name)
            if (entry.isDirectory()) { if (entry.name !== 'node_modules') walk(full) }
            else if (/\.(jsx?|css)$/.test(entry.name)) out.push(full)
        }
    }
    walk(abs('src'))
    return out
}

for (const prefix of SPEC.prefixes || []) {
    const owners = srcFiles().filter((full) => read(full).includes(prefix)).map((full) => path.relative(root, full))
    if (owners.length) problems.push(`class prefix ${prefix} is already used in ${owners.join(', ')}`)
}

const edits = new Map()
for (const p of SPEC.patches) {
    if (!fs.existsSync(abs(p.file))) { problems.push(`${p.file} is missing`); continue }
    if (!edits.has(p.file)) edits.set(p.file, read(abs(p.file)))
    const current = edits.get(p.file)
    const eol = eolOf(current)
    const find = toEol(p.find, eol)
    const hits = count(current, find)
    if (hits !== 1) { problems.push(`${p.file}: anchor matched ${hits} times, expected 1: ${JSON.stringify(p.find.slice(0, 60))}`); continue }
    edits.set(p.file, current.replace(find, () => toEol(p.replace, eol)))
}
for (const file of edits.keys()) plan.push(['EDIT', file])

for (const rel of SPEC.retires) {
    if (!fs.existsSync(abs(rel))) { problems.push(`${rel} is missing`); continue }
    const base = path.basename(rel)
    const stem = /\.(jsx?)$/.test(base) ? base.replace(/\.(jsx?)$/, '') : base
    const pattern = new RegExp(`[\\/'"]${stem.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\.jsx?)?['"]`)
    const planned = (full) => {
        const key = path.relative(root, full).split(path.sep).join('/')
        if (SPEC.replaceFiles.some((f) => f.file === key)) return read(source(key))
        return edits.has(key) ? edits.get(key) : read(full)
    }
    const users = srcFiles().filter((full) => full !== abs(rel) && pattern.test(planned(full))).map((full) => path.relative(root, full))
    if (users.length) problems.push(`${rel} is still imported by ${users.join(', ')}`)
    else plan.push(['RETIRE', rel])
}

if (problems.length) {
    console.error('  [ABORT] Nothing was written:')
    for (const p of problems) console.error(`    ${p}`)
    process.exit(1)
}

if (check) {
    for (const [kind, rel] of plan) console.log(`  [${kind}] ${rel}`)
    console.log('  Checks passed.')
    process.exit(0)
}

for (const [kind, rel] of plan) {
    const target = abs(rel)
    if (kind === 'NEW') {
        fs.mkdirSync(path.dirname(target), { recursive: true })
        fs.writeFileSync(target, read(source(rel)))
    } else if (kind === 'REPLACE') {
        const eol = eolOf(read(target))
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, toEol(read(source(rel)), eol))
    } else if (kind === 'EDIT') {
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, edits.get(rel))
    } else if (kind === 'RETIRE') {
        fs.renameSync(target, target + '.mistake')
    }
    console.log(`  [${kind}] ${rel}`)
}
console.log('  Patch applied.')
