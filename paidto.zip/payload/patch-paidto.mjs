import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const SPEC = {
  "name": "paidto",
  "backup": ".backup-paidto",
  "prefixes": [
    "biz-pay__paid"
  ],
  "newFiles": [],
  "replaceFiles": [],
  "patches": [
    {
      "file": "supabase/functions/payouts/index.ts",
      "find": "                const state = stripeState(account, Boolean(current.ready_at))\n                const bank = state.status === 'not_started' ? null : await stripeBank(current.account_ref)\n                const row = await save(business.id, {\n                    provider, ...state,\n                    bank_name: bank?.bank_name ?? current.bank_name ?? null,\n                    account_last4: bank?.account_last4 ?? current.account_last4 ?? null,\n",
      "replace": "                let state = stripeState(account, Boolean(current.ready_at))\n                const bank = await stripeBank(current.account_ref)\n                const bankName = bank.bank_name ?? current.bank_name ?? null\n                const last4 = bank.account_last4 ?? current.account_last4 ?? null\n                // Never say payouts are on until the owner can see which account the money goes to.\n                if (state.status === 'active' && !last4) state = { status: 'pending', details_due: [] }\n                const row = await save(business.id, {\n                    provider, ...state,\n                    bank_name: bankName,\n                    account_last4: last4,\n"
    },
    {
      "file": "src/pages/business/PaymentsPage.jsx",
      "find": "    if (p.status === 'active') return 'ready'",
      "replace": "    if (p.status === 'active') return p.account_last4 ? 'ready' : 'checking'"
    },
    {
      "file": "src/pages/business/PaymentsPage.jsx",
      "find": "    const bankSub = at === 'ready'\n        ? (payout.account_last4 ? `Account ending ${payout.account_last4}` : 'On file')\n        : COPY[at].bank",
      "replace": "    const bankSub = at === 'ready' ? 'Ready' : COPY[at].bank"
    },
    {
      "file": "src/pages/business/PaymentsPage.jsx",
      "find": "                <span className=\"biz-pay__stopname\">{at === 'ready' && payout.bank_name ? payout.bank_name : 'Your bank'}</span>",
      "replace": "                <span className=\"biz-pay__stopname\">Your bank</span>"
    },
    {
      "file": "src/pages/business/PaymentsPage.jsx",
      "find": "const Ready = () => (",
      "replace": "// The account the money goes to, as loud as the title: the owner checks it is theirs.\nconst PaidTo = ({ payout }) => (\n    <div className=\"biz-pay__paidto\">\n        <span className=\"biz-pay__paidicon\" aria-hidden=\"true\"><Landmark size={22} /></span>\n        <span className=\"biz-pay__paidtext\">\n            <span className=\"biz-pay__paidlabel\">Paid to</span>\n            <span className=\"biz-pay__paidbank\">{payout.bank_name || 'Your bank account'}</span>\n            <span className=\"biz-pay__paidnum\">Account ending <b>{payout.account_last4}</b></span>\n        </span>\n    </div>\n)\n\nconst Ready = () => ("
    },
    {
      "file": "src/pages/business/PaymentsPage.jsx",
      "find": "            : 'When clients pay on Locappoint, the money goes straight to this account.'",
      "replace": "            : 'Every payment from Locappoint goes to this account. If it is not yours, change it now.'"
    },
    {
      "file": "src/pages/business/PaymentsPage.jsx",
      "find": "        lede = 'When clients pay on Locappoint, the money goes straight to this account.'",
      "replace": "        lede = 'Every payment from Locappoint goes to this account. If it is not yours, change it on Stripe.'"
    },
    {
      "file": "src/pages/business/PaymentsPage.jsx",
      "find": "                    <p className=\"biz-pay__lede\">{lede}</p>\n                    <MoneyRoute",
      "replace": "                    <p className=\"biz-pay__lede\">{lede}</p>\n                    {at === 'ready' && !formOpen && <PaidTo payout={p} />}\n                    <MoneyRoute"
    },
    {
      "file": "src/styles/business/payouts.css",
      "find": "/* What to have at hand before Stripe's page",
      "replace": "/* Paid to: the bank the money goes to, big enough to check at a glance. */\n.biz-pay__paidto {\n    display: flex;\n    align-items: center;\n    gap: var(--space-4);\n    padding: var(--space-4) var(--space-5);\n    border-radius: var(--lc-r-lg);\n    background: var(--lc-raised);\n    box-shadow: inset 0 0 0 1px var(--lc-line-strong);\n}\n\n.biz-pay__paidicon {\n    display: grid;\n    place-items: center;\n    flex: none;\n    width: 48px;\n    height: 48px;\n    border-radius: var(--lc-r-md);\n    background: var(--lc-azure-button);\n    color: var(--lc-on-accent);\n}\n\n.biz-pay__paidtext {\n    display: flex;\n    flex-direction: column;\n    gap: 2px;\n    min-width: 0;\n}\n\n.biz-pay__paidlabel {\n    color: var(--lc-ink-3);\n    font-size: var(--lc-t-label);\n}\n\n.biz-pay__paidbank {\n    color: var(--lc-ink-1);\n    font-family: var(--lc-font-display);\n    font-size: var(--lc-t-heading);\n    font-weight: var(--font-weight-semibold);\n    line-height: var(--lc-lh-tight);\n    overflow-wrap: anywhere;\n}\n\n.biz-pay__paidnum {\n    color: var(--lc-ink-2);\n    font-size: var(--lc-t-body);\n}\n\n.biz-pay__paidnum b {\n    color: var(--lc-ink-1);\n    font-family: var(--lc-font-mono);\n    font-variant-numeric: tabular-nums;\n    font-weight: var(--font-weight-medium);\n    letter-spacing: 0.06em;\n}\n\n/* What to have at hand before Stripe's page"
    },
    {
      "file": "tests/suites/payouts.mjs",
      "find": "            bank: document.querySelector('.biz-pay__stop--bank')?.textContent || '',",
      "replace": "            bank: document.querySelector('.biz-pay__stop--bank')?.textContent || '',\n            paidTo: document.querySelector('.biz-pay__paidto')?.textContent || '',"
    },
    {
      "file": "tests/suites/payouts.mjs",
      "find": "check(/Millennium BCP/.test(v.bank) && /Account ending 6789/.test(v.bank), 'the bank stop shows the bank name and last four digits')",
      "replace": "check(/Paid to/.test(v.paidTo) && /Millennium BCP/.test(v.paidTo) && /Account ending 6789/.test(v.paidTo), 'ready shows which account the money goes to, bank name and last four digits')\n    check(await p.evaluate(() => { const t = document.querySelector('.biz-pay__paidto'); const r = document.querySelector('.biz-pay__route'); return t && r && (t.compareDocumentPosition(r) & Node.DOCUMENT_POSITION_FOLLOWING) }), 'the account comes before the route, right under the title')"
    },
    {
      "file": "tests/suites/payouts.mjs",
      "find": "check(v.title === 'Payouts are on' && /Access Bank/.test(v.bank) && /Account ending 6789/.test(v.bank) && v.buttons.includes('Change bank'), 'saved: the bank and last four digits show on the route')",
      "replace": "check(v.title === 'Payouts are on' && /Access Bank/.test(v.paidTo) && /Account ending 6789/.test(v.paidTo) && v.buttons.includes('Change bank'), 'saved: the bank name and last four digits show as Paid to')"
    },
    {
      "file": "tests/suites/payouts.mjs",
      "find": "    p = await open('pending')\n",
      "replace": "    p = await open('active-nobank')\n    v = await view(p)\n    check(v.title !== 'Payouts are on' && !v.paidTo && v.badge === 'Being checked', 'never \"on\" without a bank the owner can see')\n    await p.close()\n\n    p = await open('pending')\n"
    },
    {
      "file": "tests/harness/fakeSupabase.js",
      "find": "  active: { provider: 'stripe', status: 'active', bank_name: 'Millennium BCP', account_last4: '6789', details_due: [] },\n",
      "replace": "  active: { provider: 'stripe', status: 'active', bank_name: 'Millennium BCP', account_last4: '6789', details_due: [] },\n  'active-nobank': { provider: 'stripe', status: 'active', details_due: [] },\n"
    }
  ],
  "retires": []
}

const here = path.dirname(fileURLToPath(import.meta.url))
const root = process.cwd()
const check = process.argv.includes('--check')
const problems = []
const plan = []

const abs = (rel) => path.join(root, ...rel.split('/'))
const source = (rel) => path.join(here, 'files', ...rel.split('/'))
const read = (p) => fs.readFileSync(p, 'utf8')
const eolOf = (text) => (text.includes('\r\n') ? '\r\n' : '\n')
const toEol = (text, eol) => text.replace(/\r\n/g, '\n').replace(/\n/g, eol)
const sha = (text) => crypto.createHash('sha256').update(text.replace(/\r\n/g, '\n')).digest('hex')
const count = (hay, needle) => (needle ? hay.split(needle).length - 1 : 0)

const pkg = JSON.parse(read(abs('package.json')))
if (pkg.name !== 'locappoint') {
    console.error('  [ABORT] This is not the locappoint repo.')
    process.exit(1)
}

for (const rel of SPEC.newFiles) {
    if (fs.existsSync(abs(rel))) problems.push(`${rel} already exists (patch already applied?)`)
    else if (!fs.existsSync(source(rel))) problems.push(`payload is missing ${rel}`)
    else plan.push(['NEW', rel])
}

for (const { file, sha: expected } of SPEC.replaceFiles) {
    if (!fs.existsSync(abs(file))) { problems.push(`${file} is missing`); continue }
    if (sha(read(abs(file))) !== expected) { problems.push(`${file} changed since this patch was built (or it is already applied)`); continue }
    plan.push(['REPLACE', file])
}

const srcFiles = () => {
    const out = []
    const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const full = path.join(dir, entry.name)
            if (entry.isDirectory()) { if (entry.name !== 'node_modules') walk(full) }
            else if (/\.(jsx?|css)$/.test(entry.name)) out.push(full)
        }
    }
    walk(abs('src'))
    return out
}

for (const prefix of SPEC.prefixes || []) {
    const owners = srcFiles().filter((full) => read(full).includes(prefix)).map((full) => path.relative(root, full))
    if (owners.length) problems.push(`class prefix ${prefix} is already used in ${owners.join(', ')}`)
}

const edits = new Map()
for (const p of SPEC.patches) {
    if (!fs.existsSync(abs(p.file))) { problems.push(`${p.file} is missing`); continue }
    if (!edits.has(p.file)) edits.set(p.file, read(abs(p.file)))
    const current = edits.get(p.file)
    const eol = eolOf(current)
    const find = toEol(p.find, eol)
    const hits = count(current, find)
    if (hits !== 1) { problems.push(`${p.file}: anchor matched ${hits} times, expected 1: ${JSON.stringify(p.find.slice(0, 60))}`); continue }
    edits.set(p.file, current.replace(find, () => toEol(p.replace, eol)))
}
for (const file of edits.keys()) plan.push(['EDIT', file])

for (const rel of SPEC.retires) {
    if (!fs.existsSync(abs(rel))) { problems.push(`${rel} is missing`); continue }
    const base = path.basename(rel)
    const stem = /\.(jsx?)$/.test(base) ? base.replace(/\.(jsx?)$/, '') : base
    const pattern = new RegExp(`[\\/'"]${stem.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\.jsx?)?['"]`)
    const planned = (full) => {
        const key = path.relative(root, full).split(path.sep).join('/')
        if (SPEC.replaceFiles.some((f) => f.file === key)) return read(source(key))
        return edits.has(key) ? edits.get(key) : read(full)
    }
    const users = srcFiles().filter((full) => full !== abs(rel) && pattern.test(planned(full))).map((full) => path.relative(root, full))
    if (users.length) problems.push(`${rel} is still imported by ${users.join(', ')}`)
    else plan.push(['RETIRE', rel])
}

if (problems.length) {
    console.error('  [ABORT] Nothing was written:')
    for (const p of problems) console.error(`    ${p}`)
    process.exit(1)
}

if (check) {
    for (const [kind, rel] of plan) console.log(`  [${kind}] ${rel}`)
    console.log('  Checks passed.')
    process.exit(0)
}

for (const [kind, rel] of plan) {
    const target = abs(rel)
    if (kind === 'NEW') {
        fs.mkdirSync(path.dirname(target), { recursive: true })
        fs.copyFileSync(source(rel), target)
    } else if (kind === 'REPLACE') {
        const eol = eolOf(read(target))
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, toEol(read(source(rel)), eol))
    } else if (kind === 'EDIT') {
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, edits.get(rel))
    } else if (kind === 'RETIRE') {
        fs.renameSync(target, target + '.mistake')
    }
    console.log(`  [${kind}] ${rel}`)
}
console.log('  Patch applied.')
