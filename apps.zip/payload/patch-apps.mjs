import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const SPEC = {
  "name": "apps",
  "backup": ".backup-apps",
  "prefixes": [
    "lc-dl"
  ],
  "newFiles": [
    "android/.gitignore",
    "android/app/.gitignore",
    "android/app/build.gradle",
    "android/app/capacitor.build.gradle",
    "android/app/proguard-rules.pro",
    "android/app/src/androidTest/java/com/getcapacitor/myapp/ExampleInstrumentedTest.java",
    "android/app/src/main/AndroidManifest.xml",
    "android/app/src/main/java/com/locappoint/app/MainActivity.java",
    "android/app/src/main/res/drawable-land-hdpi/splash.png",
    "android/app/src/main/res/drawable-land-ldpi/splash.png",
    "android/app/src/main/res/drawable-land-mdpi/splash.png",
    "android/app/src/main/res/drawable-land-night-hdpi/splash.png",
    "android/app/src/main/res/drawable-land-night-ldpi/splash.png",
    "android/app/src/main/res/drawable-land-night-mdpi/splash.png",
    "android/app/src/main/res/drawable-land-night-xhdpi/splash.png",
    "android/app/src/main/res/drawable-land-night-xxhdpi/splash.png",
    "android/app/src/main/res/drawable-land-night-xxxhdpi/splash.png",
    "android/app/src/main/res/drawable-land-xhdpi/splash.png",
    "android/app/src/main/res/drawable-land-xxhdpi/splash.png",
    "android/app/src/main/res/drawable-land-xxxhdpi/splash.png",
    "android/app/src/main/res/drawable-night/splash.png",
    "android/app/src/main/res/drawable-port-hdpi/splash.png",
    "android/app/src/main/res/drawable-port-ldpi/splash.png",
    "android/app/src/main/res/drawable-port-mdpi/splash.png",
    "android/app/src/main/res/drawable-port-night-hdpi/splash.png",
    "android/app/src/main/res/drawable-port-night-ldpi/splash.png",
    "android/app/src/main/res/drawable-port-night-mdpi/splash.png",
    "android/app/src/main/res/drawable-port-night-xhdpi/splash.png",
    "android/app/src/main/res/drawable-port-night-xxhdpi/splash.png",
    "android/app/src/main/res/drawable-port-night-xxxhdpi/splash.png",
    "android/app/src/main/res/drawable-port-xhdpi/splash.png",
    "android/app/src/main/res/drawable-port-xxhdpi/splash.png",
    "android/app/src/main/res/drawable-port-xxxhdpi/splash.png",
    "android/app/src/main/res/drawable-v24/ic_launcher_foreground.xml",
    "android/app/src/main/res/drawable/ic_launcher_background.xml",
    "android/app/src/main/res/drawable/splash.png",
    "android/app/src/main/res/layout/activity_main.xml",
    "android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml",
    "android/app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml",
    "android/app/src/main/res/mipmap-hdpi/ic_launcher.png",
    "android/app/src/main/res/mipmap-hdpi/ic_launcher_background.png",
    "android/app/src/main/res/mipmap-hdpi/ic_launcher_foreground.png",
    "android/app/src/main/res/mipmap-hdpi/ic_launcher_round.png",
    "android/app/src/main/res/mipmap-ldpi/ic_launcher.png",
    "android/app/src/main/res/mipmap-ldpi/ic_launcher_background.png",
    "android/app/src/main/res/mipmap-ldpi/ic_launcher_foreground.png",
    "android/app/src/main/res/mipmap-ldpi/ic_launcher_round.png",
    "android/app/src/main/res/mipmap-mdpi/ic_launcher.png",
    "android/app/src/main/res/mipmap-mdpi/ic_launcher_background.png",
    "android/app/src/main/res/mipmap-mdpi/ic_launcher_foreground.png",
    "android/app/src/main/res/mipmap-mdpi/ic_launcher_round.png",
    "android/app/src/main/res/mipmap-xhdpi/ic_launcher.png",
    "android/app/src/main/res/mipmap-xhdpi/ic_launcher_background.png",
    "android/app/src/main/res/mipmap-xhdpi/ic_launcher_foreground.png",
    "android/app/src/main/res/mipmap-xhdpi/ic_launcher_round.png",
    "android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png",
    "android/app/src/main/res/mipmap-xxhdpi/ic_launcher_background.png",
    "android/app/src/main/res/mipmap-xxhdpi/ic_launcher_foreground.png",
    "android/app/src/main/res/mipmap-xxhdpi/ic_launcher_round.png",
    "android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png",
    "android/app/src/main/res/mipmap-xxxhdpi/ic_launcher_background.png",
    "android/app/src/main/res/mipmap-xxxhdpi/ic_launcher_foreground.png",
    "android/app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png",
    "android/app/src/main/res/values/ic_launcher_background.xml",
    "android/app/src/main/res/values/strings.xml",
    "android/app/src/main/res/values/styles.xml",
    "android/app/src/main/res/xml/file_paths.xml",
    "android/app/src/test/java/com/getcapacitor/myapp/ExampleUnitTest.java",
    "android/build.gradle",
    "android/capacitor.settings.gradle",
    "android/gradle.properties",
    "android/gradle/wrapper/gradle-wrapper.jar",
    "android/gradle/wrapper/gradle-wrapper.properties",
    "android/gradlew",
    "android/gradlew.bat",
    "android/settings.gradle",
    "android/variables.gradle",
    "assets/icon-background.png",
    "assets/icon-foreground.png",
    "assets/icon-only.png",
    "assets/splash-dark.png",
    "assets/splash.png",
    "capacitor.config.json",
    "codemagic.yaml",
    "ios/.gitignore",
    "ios/App/App.xcodeproj/project.pbxproj",
    "ios/App/App.xcodeproj/project.xcworkspace/xcshareddata/IDEWorkspaceChecks.plist",
    "ios/App/App/AppDelegate.swift",
    "ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png",
    "ios/App/App/Assets.xcassets/AppIcon.appiconset/Contents.json",
    "ios/App/App/Assets.xcassets/Contents.json",
    "ios/App/App/Assets.xcassets/Splash.imageset/Contents.json",
    "ios/App/App/Assets.xcassets/Splash.imageset/Default@1x~universal~anyany-dark.png",
    "ios/App/App/Assets.xcassets/Splash.imageset/Default@1x~universal~anyany.png",
    "ios/App/App/Assets.xcassets/Splash.imageset/Default@2x~universal~anyany-dark.png",
    "ios/App/App/Assets.xcassets/Splash.imageset/Default@2x~universal~anyany.png",
    "ios/App/App/Assets.xcassets/Splash.imageset/Default@3x~universal~anyany-dark.png",
    "ios/App/App/Assets.xcassets/Splash.imageset/Default@3x~universal~anyany.png",
    "ios/App/App/Assets.xcassets/Splash.imageset/splash-2732x2732-1.png",
    "ios/App/App/Assets.xcassets/Splash.imageset/splash-2732x2732-2.png",
    "ios/App/App/Assets.xcassets/Splash.imageset/splash-2732x2732.png",
    "ios/App/App/Base.lproj/LaunchScreen.storyboard",
    "ios/App/App/Base.lproj/Main.storyboard",
    "ios/App/App/Info.plist",
    "ios/App/App/SceneDelegate.swift",
    "ios/App/CapApp-SPM/.gitignore",
    "ios/App/CapApp-SPM/Package.swift",
    "ios/App/CapApp-SPM/README.md",
    "ios/App/CapApp-SPM/Sources/CapApp-SPM/CapApp-SPM.swift",
    "ios/debug.xcconfig",
    "src/pages/app/AppDownload.jsx",
    "src/services/native.js",
    "src/services/release.js",
    "src/styles/app/download.css",
    "supabase/migrations/apps.sql",
    "supabase/queries/apps-verify.sql",
    "tests/suites/apps.mjs"
  ],
  "replaceFiles": [],
  "patches": [
    {
      "file": "package-lock.json",
      "find": "      \"dependencies\": {\n        \"@fontsource/inter\": \"^5.3.0\",",
      "replace": "      \"dependencies\": {\n        \"@capacitor/android\": \"^8.5.2\",\n        \"@capacitor/app\": \"^8.1.1\",\n        \"@capacitor/browser\": \"^8.0.4\",\n        \"@capacitor/core\": \"^8.5.2\",\n        \"@capacitor/filesystem\": \"^8.1.3\",\n        \"@capacitor/ios\": \"^8.5.2\",\n        \"@capacitor/share\": \"^8.0.2\",\n        \"@capacitor/splash-screen\": \"^8.0.2\",\n        \"@fontsource/inter\": \"^5.3.0\","
    },
    {
      "file": "package-lock.json",
      "find": "      \"devDependencies\": {\n        \"@eslint/js\": \"^9.33.0\",",
      "replace": "      \"devDependencies\": {\n        \"@capacitor/cli\": \"^8.5.2\",\n        \"@eslint/js\": \"^9.33.0\","
    },
    {
      "file": "package-lock.json",
      "find": "        \"node\": \">=6.9.0\"\n      }\n    },\n    \"node_modules/@esbuild/aix-ppc64\": {",
      "replace": "        \"node\": \">=6.9.0\"\n      }\n    },\n    \"node_modules/@capacitor/android\": {\n      \"version\": \"8.5.2\",\n      \"resolved\": \"https://registry.npmjs.org/@capacitor/android/-/android-8.5.2.tgz\",\n      \"integrity\": \"sha512-rtiaz78egCcS+vs29wkWCL3C+RhazKMSygXcjutwWP8NmO6r5UBxOvGf3Wjz5+ahobyQ723tn9gCePwRwcNDZQ==\",\n      \"license\": \"MIT\",\n      \"peerDependencies\": {\n        \"@capacitor/core\": \"^8.5.0\"\n      }\n    },\n    \"node_modules/@capacitor/app\": {\n      \"version\": \"8.1.1\",\n      \"resolved\": \"https://registry.npmjs.org/@capacitor/app/-/app-8.1.1.tgz\",\n      \"integrity\": \"sha512-xM2ZTX5jK60tFtmjsmJv+Cdj1Qsb6NcavkqmdEnCPQBeya9oKhamZJxYOnQNj1ZvcJM7sWfG6BEtSLx42pisbA==\",\n      \"license\": \"MIT\",\n      \"peerDependencies\": {\n        \"@capacitor/core\": \">=8.0.0\"\n      }\n    },\n    \"node_modules/@capacitor/browser\": {\n      \"version\": \"8.0.4\",\n      \"resolved\": \"https://registry.npmjs.org/@capacitor/browser/-/browser-8.0.4.tgz\",\n      \"integrity\": \"sha512-ORZ4u/y+7aMuu6yVuk6SP529fUZyqcbnuHB1q5McpA3o2SYfVoi28iB8rsQjI2ad1qlKJd29ZUuGtspXLBDlWg==\",\n      \"license\": \"MIT\",\n      \"peerDependencies\": {\n        \"@capacitor/core\": \">=8.0.0\"\n      }\n    },\n    \"node_modules/@capacitor/cli\": {\n      \"version\": \"8.5.2\",\n      \"resolved\": \"https://registry.npmjs.org/@capacitor/cli/-/cli-8.5.2.tgz\",\n      \"integrity\": \"sha512-O2kpA5ZPJUAmliDCcmpMf8xnJwMezxlFPUrlyOAjbL3U9MFNY3l4ZpPI/UXwvyPmR8ETcVF9pFr+VdWq61rqTQ==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"@ionic/cli-framework-output\": \"^2.2.8\",\n        \"@ionic/utils-subprocess\": \"^3.0.1\",\n        \"@ionic/utils-terminal\": \"^2.3.5\",\n        \"commander\": \"^12.1.0\",\n        \"debug\": \"^4.4.0\",\n        \"env-paths\": \"^2.2.0\",\n        \"fs-extra\": \"^11.2.0\",\n        \"kleur\": \"^4.1.5\",\n        \"native-run\": \"^2.0.3\",\n        \"open\": \"^8.4.0\",\n        \"plist\": \"^3.1.0\",\n        \"prompts\": \"^2.4.2\",\n        \"rimraf\": \"^6.0.1\",\n        \"semver\": \"^7.6.3\",\n        \"tar\": \"^7.5.3\",\n        \"tslib\": \"^2.8.1\",\n        \"xcode\": \"^3.0.1\",\n        \"xml2js\": \"^0.6.2\"\n      },\n      \"bin\": {\n        \"cap\": \"bin/capacitor\",\n        \"capacitor\": \"bin/capacitor\"\n      },\n      \"engines\": {\n        \"node\": \">=22.0.0\"\n      }\n    },\n    \"node_modules/@capacitor/cli/node_modules/semver\": {\n      \"version\": \"7.8.5\",\n      \"resolved\": \"https://registry.npmjs.org/semver/-/semver-7.8.5.tgz\",\n      \"integrity\": \"sha512-Y7/KDsb8LjooZpwaqGyulO6DQlksgCncchHGk+sZIY4SBvUocMBEFH5Ur1fI4dV+Jvl0w6cjvucaIi40puRioA==\",\n      \"dev\": true,\n      \"license\": \"ISC\",\n      \"bin\": {\n        \"semver\": \"bin/semver.js\"\n      },\n      \"engines\": {\n        \"node\": \">=10\"\n      }\n    },\n    \"node_modules/@capacitor/core\": {\n      \"version\": \"8.5.2\",\n      \"resolved\": \"https://registry.npmjs.org/@capacitor/core/-/core-8.5.2.tgz\",\n      \"integrity\": \"sha512-agnQbGdhGw/KZFuLf7H9SY2o+oE7upkr/WPQsYaokXP6f9chaE8iVmbKkfN6SVl4w3pmz7oZ3Ur1hbkmy1hx+w==\",\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"tslib\": \"^2.1.0\"\n      }\n    },\n    \"node_modules/@capacitor/filesystem\": {\n      \"version\": \"8.1.3\",\n      \"resolved\": \"https://registry.npmjs.org/@capacitor/filesystem/-/filesystem-8.1.3.tgz\",\n      \"integrity\": \"sha512-GNBlRkaXEEb+6WP/YsDXr2zygyOHoieuye6viyd2ZkEdBwfseG41jxfarVxLWH0r0owhyNUbwJ/Qi8fubqr6wA==\",\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"@capacitor/synapse\": \"^1.0.4\"\n      },\n      \"peerDependencies\": {\n        \"@capacitor/core\": \">=8.0.0\"\n      }\n    },\n    \"node_modules/@capacitor/ios\": {\n      \"version\": \"8.5.2\",\n      \"resolved\": \"https://registry.npmjs.org/@capacitor/ios/-/ios-8.5.2.tgz\",\n      \"integrity\": \"sha512-eOT2S67AfTFG7KN0T3oxwAajrJz4rSye+ODfvChiwrk0F/+kWufFM1qU6cDjGJUOfwdAoeuEpZyWHSwZlu4GFg==\",\n      \"license\": \"MIT\",\n      \"peerDependencies\": {\n        \"@capacitor/core\": \"^8.5.0\"\n      }\n    },\n    \"node_modules/@capacitor/share\": {\n      \"version\": \"8.0.2\",\n      \"resolved\": \"https://registry.npmjs.org/@capacitor/share/-/share-8.0.2.tgz\",\n      \"integrity\": \"sha512-L2M4iBLTf/IaMmg+ruuriAoJyBzu1EgayWhgC5cX1HJGkA665g2ROz8c2Z5lfkT/XSLbAuG3bb7VlW3eGgUCNQ==\",\n      \"license\": \"MIT\",\n      \"peerDependencies\": {\n        \"@capacitor/core\": \">=8.0.0\"\n      }\n    },\n    \"node_modules/@capacitor/splash-screen\": {\n      \"version\": \"8.0.2\",\n      \"resolved\": \"https://registry.npmjs.org/@capacitor/splash-screen/-/splash-screen-8.0.2.tgz\",\n      \"integrity\": \"sha512-0C6rYScr13WfAE9nPl4ScOQynmjFv9NT3Th+RZkD4ezYHmER6mcl1/lDYsv7jg3Rj3FOvLrlTlmNkUrr83kZzQ==\",\n      \"license\": \"MIT\",\n      \"peerDependencies\": {\n        \"@capacitor/core\": \">=8.0.0\"\n      }\n    },\n    \"node_modules/@capacitor/synapse\": {\n      \"version\": \"1.0.4\",\n      \"resolved\": \"https://registry.npmjs.org/@capacitor/synapse/-/synapse-1.0.4.tgz\",\n      \"integrity\": \"sha512-/C1FUo8/OkKuAT4nCIu/34ny9siNHr9qtFezu4kxm6GY1wNFxrCFWjfYx5C1tUhVGz3fxBABegupkpjXvjCHrw==\",\n      \"license\": \"ISC\"\n    },\n    \"node_modules/@esbuild/aix-ppc64\": {"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/@jridgewell/gen-mapping\": {",
      "replace": "    },\n    \"node_modules/@ionic/cli-framework-output\": {\n      \"version\": \"2.2.8\",\n      \"resolved\": \"https://registry.npmjs.org/@ionic/cli-framework-output/-/cli-framework-output-2.2.8.tgz\",\n      \"integrity\": \"sha512-TshtaFQsovB4NWRBydbNFawql6yul7d5bMiW1WYYf17hd99V6xdDdk3vtF51bw6sLkxON3bDQpWsnUc9/hVo3g==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"@ionic/utils-terminal\": \"2.3.5\",\n        \"debug\": \"^4.0.0\",\n        \"tslib\": \"^2.0.1\"\n      },\n      \"engines\": {\n        \"node\": \">=16.0.0\"\n      }\n    },\n    \"node_modules/@ionic/utils-array\": {\n      \"version\": \"2.1.6\",\n      \"resolved\": \"https://registry.npmjs.org/@ionic/utils-array/-/utils-array-2.1.6.tgz\",\n      \"integrity\": \"sha512-0JZ1Zkp3wURnv8oq6Qt7fMPo5MpjbLoUoa9Bu2Q4PJuSDWM8H8gwF3dQO7VTeUj3/0o1IB1wGkFWZZYgUXZMUg==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"debug\": \"^4.0.0\",\n        \"tslib\": \"^2.0.1\"\n      },\n      \"engines\": {\n        \"node\": \">=16.0.0\"\n      }\n    },\n    \"node_modules/@ionic/utils-fs\": {\n      \"version\": \"3.1.7\",\n      \"resolved\": \"https://registry.npmjs.org/@ionic/utils-fs/-/utils-fs-3.1.7.tgz\",\n      \"integrity\": \"sha512-2EknRvMVfhnyhL1VhFkSLa5gOcycK91VnjfrTB0kbqkTFCOXyXgVLI5whzq7SLrgD9t1aqos3lMMQyVzaQ5gVA==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"@types/fs-extra\": \"^8.0.0\",\n        \"debug\": \"^4.0.0\",\n        \"fs-extra\": \"^9.0.0\",\n        \"tslib\": \"^2.0.1\"\n      },\n      \"engines\": {\n        \"node\": \">=16.0.0\"\n      }\n    },\n    \"node_modules/@ionic/utils-fs/node_modules/fs-extra\": {\n      \"version\": \"9.1.0\",\n      \"resolved\": \"https://registry.npmjs.org/fs-extra/-/fs-extra-9.1.0.tgz\",\n      \"integrity\": \"sha512-hcg3ZmepS30/7BSFqRvoo3DOMQu7IjqxO5nCDt+zM9XWjb33Wg7ziNT+Qvqbuc3+gWpzO02JubVyk2G4Zvo1OQ==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"at-least-node\": \"^1.0.0\",\n        \"graceful-fs\": \"^4.2.0\",\n        \"jsonfile\": \"^6.0.1\",\n        \"universalify\": \"^2.0.0\"\n      },\n      \"engines\": {\n        \"node\": \">=10\"\n      }\n    },\n    \"node_modules/@ionic/utils-object\": {\n      \"version\": \"2.1.6\",\n      \"resolved\": \"https://registry.npmjs.org/@ionic/utils-object/-/utils-object-2.1.6.tgz\",\n      \"integrity\": \"sha512-vCl7sl6JjBHFw99CuAqHljYJpcE88YaH2ZW4ELiC/Zwxl5tiwn4kbdP/gxi2OT3MQb1vOtgAmSNRtusvgxI8ww==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"debug\": \"^4.0.0\",\n        \"tslib\": \"^2.0.1\"\n      },\n      \"engines\": {\n        \"node\": \">=16.0.0\"\n      }\n    },\n    \"node_modules/@ionic/utils-process\": {\n      \"version\": \"2.1.12\",\n      \"resolved\": \"https://registry.npmjs.org/@ionic/utils-process/-/utils-process-2.1.12.tgz\",\n      \"integrity\": \"sha512-Jqkgyq7zBs/v/J3YvKtQQiIcxfJyplPgECMWgdO0E1fKrrH8EF0QGHNJ9mJCn6PYe2UtHNS8JJf5G21e09DfYg==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"@ionic/utils-object\": \"2.1.6\",\n        \"@ionic/utils-terminal\": \"2.3.5\",\n        \"debug\": \"^4.0.0\",\n        \"signal-exit\": \"^3.0.3\",\n        \"tree-kill\": \"^1.2.2\",\n        \"tslib\": \"^2.0.1\"\n      },\n      \"engines\": {\n        \"node\": \">=16.0.0\"\n      }\n    },\n    \"node_modules/@ionic/utils-stream\": {\n      \"version\": \"3.1.7\",\n      \"resolved\": \"https://registry.npmjs.org/@ionic/utils-stream/-/utils-stream-3.1.7.tgz\",\n      \"integrity\": \"sha512-eSELBE7NWNFIHTbTC2jiMvh1ABKGIpGdUIvARsNPMNQhxJB3wpwdiVnoBoTYp+5a6UUIww4Kpg7v6S7iTctH1w==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"debug\": \"^4.0.0\",\n        \"tslib\": \"^2.0.1\"\n      },\n      \"engines\": {\n        \"node\": \">=16.0.0\"\n      }\n    },\n    \"node_modules/@ionic/utils-subprocess\": {\n      \"version\": \"3.0.1\",\n      \"resolved\": \"https://registry.npmjs.org/@ionic/utils-subprocess/-/utils-subprocess-3.0.1.tgz\",\n      \"integrity\": \"sha512-cT4te3AQQPeIM9WCwIg8ohroJ8TjsYaMb2G4ZEgv9YzeDqHZ4JpeIKqG2SoaA3GmVQ3sOfhPM6Ox9sxphV/d1A==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"@ionic/utils-array\": \"2.1.6\",\n        \"@ionic/utils-fs\": \"3.1.7\",\n        \"@ionic/utils-process\": \"2.1.12\",\n        \"@ionic/utils-stream\": \"3.1.7\",\n        \"@ionic/utils-terminal\": \"2.3.5\",\n        \"cross-spawn\": \"^7.0.3\",\n        \"debug\": \"^4.0.0\",\n        \"tslib\": \"^2.0.1\"\n      },\n      \"engines\": {\n        \"node\": \">=16.0.0\"\n      }\n    },\n    \"node_modules/@ionic/utils-terminal\": {\n      \"version\": \"2.3.5\",\n      \"resolved\": \"https://registry.npmjs.org/@ionic/utils-terminal/-/utils-terminal-2.3.5.tgz\",\n      \"integrity\": \"sha512-3cKScz9Jx2/Pr9ijj1OzGlBDfcmx7OMVBt4+P1uRR0SSW4cm1/y3Mo4OY3lfkuaYifMNBW8Wz6lQHbs1bihr7A==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"@types/slice-ansi\": \"^4.0.0\",\n        \"debug\": \"^4.0.0\",\n        \"signal-exit\": \"^3.0.3\",\n        \"slice-ansi\": \"^4.0.0\",\n        \"string-width\": \"^4.1.0\",\n        \"strip-ansi\": \"^6.0.0\",\n        \"tslib\": \"^2.0.1\",\n        \"untildify\": \"^4.0.0\",\n        \"wrap-ansi\": \"^7.0.0\"\n      },\n      \"engines\": {\n        \"node\": \">=16.0.0\"\n      }\n    },\n    \"node_modules/@ionic/utils-terminal/node_modules/wrap-ansi\": {\n      \"version\": \"7.0.0\",\n      \"resolved\": \"https://registry.npmjs.org/wrap-ansi/-/wrap-ansi-7.0.0.tgz\",\n      \"integrity\": \"sha512-YVGIj2kamLSTxw6NsZjoBxfSwsn0ycdesmc4p+Q21c5zPuZ1pl+NfxVdxPtdHvmNVOQ6XSYG4AUtyt/Fi7D16Q==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"ansi-styles\": \"^4.0.0\",\n        \"string-width\": \"^4.1.0\",\n        \"strip-ansi\": \"^6.0.0\"\n      },\n      \"engines\": {\n        \"node\": \">=10\"\n      },\n      \"funding\": {\n        \"url\": \"https://github.com/chalk/wrap-ansi?sponsor=1\"\n      }\n    },\n    \"node_modules/@isaacs/fs-minipass\": {\n      \"version\": \"4.0.1\",\n      \"resolved\": \"https://registry.npmjs.org/@isaacs/fs-minipass/-/fs-minipass-4.0.1.tgz\",\n      \"integrity\": \"sha512-wgm9Ehl2jpeqP3zw/7mo3kRHFp5MEDhqAdwy1fTGkHAwnkGOVsgpvQhL8B5n1qlb01jV3n/bI0ZfZp5lWA1k4w==\",\n      \"dev\": true,\n      \"license\": \"ISC\",\n      \"dependencies\": {\n        \"minipass\": \"^7.0.4\"\n      },\n      \"engines\": {\n        \"node\": \">=18.0.0\"\n      }\n    },\n    \"node_modules/@jridgewell/gen-mapping\": {"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/@types/json-schema\": {",
      "replace": "    },\n    \"node_modules/@types/fs-extra\": {\n      \"version\": \"8.1.5\",\n      \"resolved\": \"https://registry.npmjs.org/@types/fs-extra/-/fs-extra-8.1.5.tgz\",\n      \"integrity\": \"sha512-0dzKcwO+S8s2kuF5Z9oUWatQJj5Uq/iqphEtE3GQJVRRYm/tD1LglU2UnXi2A8jLq5umkGouOXOR9y0n613ZwQ==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"@types/node\": \"*\"\n      }\n    },\n    \"node_modules/@types/json-schema\": {"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/@types/ws\": {",
      "replace": "    },\n    \"node_modules/@types/slice-ansi\": {\n      \"version\": \"4.0.0\",\n      \"resolved\": \"https://registry.npmjs.org/@types/slice-ansi/-/slice-ansi-4.0.0.tgz\",\n      \"integrity\": \"sha512-+OpjSaq85gvlZAYINyzKpLeiFkSC4EsC6IIiT6v6TLSU5k5U83fHGj9Lel8oKEXM0HqgrMVCjXPDPVICtxF7EQ==\",\n      \"dev\": true,\n      \"license\": \"MIT\"\n    },\n    \"node_modules/@types/ws\": {"
    },
    {
      "file": "package-lock.json",
      "find": "        \"vite\": \"^4.2.0 || ^5.0.0 || ^6.0.0 || ^7.0.0\"\n      }",
      "replace": "        \"vite\": \"^4.2.0 || ^5.0.0 || ^6.0.0 || ^7.0.0\"\n      }\n    },\n    \"node_modules/@xmldom/xmldom\": {\n      \"version\": \"0.9.12\",\n      \"resolved\": \"https://registry.npmjs.org/@xmldom/xmldom/-/xmldom-0.9.12.tgz\",\n      \"integrity\": \"sha512-5AXjrcMClTryPe9LgZrygpB1lj7s0S9E0+W+AHaVKAVyHanafK86iPSvG5xHVSp/jC+VH1UXu0TAEmY279xH7A==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"engines\": {\n        \"node\": \">=14.6\"\n      }"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/async-function\": {",
      "replace": "    },\n    \"node_modules/astral-regex\": {\n      \"version\": \"2.0.0\",\n      \"resolved\": \"https://registry.npmjs.org/astral-regex/-/astral-regex-2.0.0.tgz\",\n      \"integrity\": \"sha512-Z7tMw1ytTXt5jqMcOP+OQteU1VuNK9Y02uuJtKQ1Sv69jXQKKg5cibLwGJow8yzZP+eAc18EmLGPal0bp36rvQ==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"engines\": {\n        \"node\": \">=8\"\n      }\n    },\n    \"node_modules/async-function\": {"
    },
    {
      "file": "package-lock.json",
      "find": "      \"license\": \"MIT\",\n      \"engines\": {\n        \"node\": \">= 0.4\"\n      }\n    },\n    \"node_modules/available-typed-arrays\": {",
      "replace": "      \"license\": \"MIT\",\n      \"engines\": {\n        \"node\": \">= 0.4\"\n      }\n    },\n    \"node_modules/at-least-node\": {\n      \"version\": \"1.0.0\",\n      \"resolved\": \"https://registry.npmjs.org/at-least-node/-/at-least-node-1.0.0.tgz\",\n      \"integrity\": \"sha512-+q/t7Ekv1EDY2l6Gda6LLiX14rU9TV20Wa3ofeQmwPFZbOMo9DXrLbOjFaaclkXKWidIaopwAObQDqwWtGUjqg==\",\n      \"dev\": true,\n      \"license\": \"ISC\",\n      \"engines\": {\n        \"node\": \">= 4.0.0\"\n      }\n    },\n    \"node_modules/available-typed-arrays\": {"
    },
    {
      "file": "package-lock.json",
      "find": "      \"dev\": true,\n      \"license\": \"MIT\"\n    },\n    \"node_modules/brace-expansion\": {",
      "replace": "      \"dev\": true,\n      \"license\": \"MIT\"\n    },\n    \"node_modules/base64-js\": {\n      \"version\": \"1.5.1\",\n      \"resolved\": \"https://registry.npmjs.org/base64-js/-/base64-js-1.5.1.tgz\",\n      \"integrity\": \"sha512-AKpaYlHn8t4SVbOHCy+b5+KKgvR4vrsD8vbvrbiQJps7fKDTkjkDry6ji0rUJjC0kzbNePLwzxq8iypo41qeWA==\",\n      \"dev\": true,\n      \"funding\": [\n        {\n          \"type\": \"github\",\n          \"url\": \"https://github.com/sponsors/feross\"\n        },\n        {\n          \"type\": \"patreon\",\n          \"url\": \"https://www.patreon.com/feross\"\n        },\n        {\n          \"type\": \"consulting\",\n          \"url\": \"https://feross.org/support\"\n        }\n      ],\n      \"license\": \"MIT\"\n    },\n    \"node_modules/big-integer\": {\n      \"version\": \"1.6.52\",\n      \"resolved\": \"https://registry.npmjs.org/big-integer/-/big-integer-1.6.52.tgz\",\n      \"integrity\": \"sha512-QxD8cf2eVqJOOz63z6JIN9BzvVs/dlySa5HGSBH5xtR8dPteIRQnBxxKqkNTiT6jbDTF6jAfrd4oMcND9RGbQg==\",\n      \"dev\": true,\n      \"license\": \"Unlicense\",\n      \"engines\": {\n        \"node\": \">=0.6\"\n      }\n    },\n    \"node_modules/bplist-creator\": {\n      \"version\": \"0.1.0\",\n      \"resolved\": \"https://registry.npmjs.org/bplist-creator/-/bplist-creator-0.1.0.tgz\",\n      \"integrity\": \"sha512-sXaHZicyEEmY86WyueLTQesbeoH/mquvarJaQNbjuOQO+7gbFcDEWqKmcWA4cOTLzFlfgvkiVxolk1k5bBIpmg==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"stream-buffers\": \"2.2.x\"\n      }\n    },\n    \"node_modules/bplist-parser\": {\n      \"version\": \"0.3.2\",\n      \"resolved\": \"https://registry.npmjs.org/bplist-parser/-/bplist-parser-0.3.2.tgz\",\n      \"integrity\": \"sha512-apC2+fspHGI3mMKj+dGevkGo/tCqVB8jMb6i+OX+E29p0Iposz07fABkRIfVUPNd5A5VbuOz1bZbnmkKLYF+wQ==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"big-integer\": \"1.6.x\"\n      },\n      \"engines\": {\n        \"node\": \">= 5.10.0\"\n      }\n    },\n    \"node_modules/brace-expansion\": {"
    },
    {
      "file": "package-lock.json",
      "find": "        \"node\": \"^6 || ^7 || ^8 || ^9 || ^10 || ^11 || ^12 || >=13.7\"\n      }",
      "replace": "        \"node\": \"^6 || ^7 || ^8 || ^9 || ^10 || ^11 || ^12 || >=13.7\"\n      }\n    },\n    \"node_modules/buffer-crc32\": {\n      \"version\": \"0.2.13\",\n      \"resolved\": \"https://registry.npmjs.org/buffer-crc32/-/buffer-crc32-0.2.13.tgz\",\n      \"integrity\": \"sha512-VO9Ht/+p3SN7SKWqcrgEzjGbRSJYTx+Q1pTQC0wrWqHx0vpJraQ6GtHx8tvcg1rlK1byhU5gccxgOgj7B0TDkQ==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"engines\": {\n        \"node\": \"*\"\n      }"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/chromium-bidi\": {",
      "replace": "    },\n    \"node_modules/chownr\": {\n      \"version\": \"3.0.0\",\n      \"resolved\": \"https://registry.npmjs.org/chownr/-/chownr-3.0.0.tgz\",\n      \"integrity\": \"sha512-+IxzY9BZOQd/XuYPRmrvEVjF/nqj5kgT4kEq7VofrDoM1MxoRjEWkrCC3EtLi59TVawxTAn+orJwFQcrqEN1+g==\",\n      \"dev\": true,\n      \"license\": \"BlueOak-1.0.0\",\n      \"engines\": {\n        \"node\": \">=18\"\n      }\n    },\n    \"node_modules/chromium-bidi\": {"
    },
    {
      "file": "package-lock.json",
      "find": "      \"integrity\": \"sha512-dOy+3AuW3a2wNbZHIuMZpTcgjGuLU/uBL/ubcZF9OXbDo8ff4O8yVp5Bf0efS8uEoYo5q4Fx7dY9OgQGXgAsQA==\",\n      \"license\": \"MIT\"\n    },\n    \"node_modules/concat-map\": {",
      "replace": "      \"integrity\": \"sha512-dOy+3AuW3a2wNbZHIuMZpTcgjGuLU/uBL/ubcZF9OXbDo8ff4O8yVp5Bf0efS8uEoYo5q4Fx7dY9OgQGXgAsQA==\",\n      \"license\": \"MIT\"\n    },\n    \"node_modules/commander\": {\n      \"version\": \"12.1.0\",\n      \"resolved\": \"https://registry.npmjs.org/commander/-/commander-12.1.0.tgz\",\n      \"integrity\": \"sha512-Vw8qHK3bZM9y/P10u3Vib8o/DdkvA2OtPtZvD871QKjy74Wj1WSKFILMPRPSdUSx5RFK1arlJzEtA4PkFgnbuA==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"engines\": {\n        \"node\": \">=18\"\n      }\n    },\n    \"node_modules/concat-map\": {"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/define-properties\": {",
      "replace": "    },\n    \"node_modules/define-lazy-prop\": {\n      \"version\": \"2.0.0\",\n      \"resolved\": \"https://registry.npmjs.org/define-lazy-prop/-/define-lazy-prop-2.0.0.tgz\",\n      \"integrity\": \"sha512-Ds09qNh8yw3khSjiJjiUInaGX9xlqZDY7JVryGxdxV7NPeuqQfplOpQ66yJFZut3jLa5zOwkXw1g9EI2uKh4Og==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"engines\": {\n        \"node\": \">=8\"\n      }\n    },\n    \"node_modules/define-properties\": {"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/emoji-regex\": {",
      "replace": "    },\n    \"node_modules/elementtree\": {\n      \"version\": \"0.1.7\",\n      \"resolved\": \"https://registry.npmjs.org/elementtree/-/elementtree-0.1.7.tgz\",\n      \"integrity\": \"sha512-wkgGT6kugeQk/P6VZ/f4T+4HB41BVgNBq5CDIZVbQ02nvTVqAiVTbskxxu3eA/X96lMlfYOwnLQpN2v5E1zDEg==\",\n      \"dev\": true,\n      \"license\": \"Apache-2.0\",\n      \"dependencies\": {\n        \"sax\": \"1.1.4\"\n      },\n      \"engines\": {\n        \"node\": \">= 0.4.0\"\n      }\n    },\n    \"node_modules/emoji-regex\": {"
    },
    {
      "file": "package-lock.json",
      "find": "      \"integrity\": \"sha512-MSjYzcWNOA0ewAHpz0MxpYFvwg6yjy1NG3xteoqz644VCo/RPgnr1/GGt+ic3iJTzQ8Eu3TdM14SawnVUmGE6A==\",\n      \"license\": \"MIT\"\n    },\n    \"node_modules/es-abstract\": {",
      "replace": "      \"integrity\": \"sha512-MSjYzcWNOA0ewAHpz0MxpYFvwg6yjy1NG3xteoqz644VCo/RPgnr1/GGt+ic3iJTzQ8Eu3TdM14SawnVUmGE6A==\",\n      \"license\": \"MIT\"\n    },\n    \"node_modules/env-paths\": {\n      \"version\": \"2.2.1\",\n      \"resolved\": \"https://registry.npmjs.org/env-paths/-/env-paths-2.2.1.tgz\",\n      \"integrity\": \"sha512-+h1lkLKhZMTYjog1VEpJNG7NZJWcuc2DDk/qsqSTRRCOXiLjeQ1d1/udrUGhqMxUgAlwKNZ0cf2uqan5GLuS2A==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"engines\": {\n        \"node\": \">=6\"\n      }\n    },\n    \"node_modules/es-abstract\": {"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/fdir\": {",
      "replace": "    },\n    \"node_modules/fd-slicer\": {\n      \"version\": \"1.1.0\",\n      \"resolved\": \"https://registry.npmjs.org/fd-slicer/-/fd-slicer-1.1.0.tgz\",\n      \"integrity\": \"sha512-cE1qsB/VwyQozZ+q1dGxR8LBYNZeofhEdUNGSMbQD3Gw2lAzX9Zb3uIU6Ebc/Fmyjo9AWWfnn0AUCHqtevs/8g==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"pend\": \"~1.2.0\"\n      }\n    },\n    \"node_modules/fdir\": {"
    },
    {
      "file": "package-lock.json",
      "find": "        \"react-dom\": {\n          \"optional\": true\n        }\n      }\n    },\n    \"node_modules/fsevents\": {",
      "replace": "        \"react-dom\": {\n          \"optional\": true\n        }\n      }\n    },\n    \"node_modules/fs-extra\": {\n      \"version\": \"11.4.1\",\n      \"resolved\": \"https://registry.npmjs.org/fs-extra/-/fs-extra-11.4.1.tgz\",\n      \"integrity\": \"sha512-KYAb4c9BJQI6QqGKthV68OHe0badztdXJWKo0WtBA9IuCFPTKvE5ZdUBglP833aMjhaSPNO4A5j/EkzZtGlKjA==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"graceful-fs\": \"^4.2.0\",\n        \"jsonfile\": \"^6.0.1\",\n        \"universalify\": \"^2.0.0\"\n      },\n      \"engines\": {\n        \"node\": \">=14.14\"\n      }\n    },\n    \"node_modules/fsevents\": {"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/glob-parent\": {",
      "replace": "    },\n    \"node_modules/glob\": {\n      \"version\": \"13.0.6\",\n      \"resolved\": \"https://registry.npmjs.org/glob/-/glob-13.0.6.tgz\",\n      \"integrity\": \"sha512-Wjlyrolmm8uDpm/ogGyXZXb1Z+Ca2B8NbJwqBVg0axK9GbBeoS7yGV6vjXnYdGm6X53iehEuxxbyiKp8QmN4Vw==\",\n      \"dev\": true,\n      \"license\": \"BlueOak-1.0.0\",\n      \"dependencies\": {\n        \"minimatch\": \"^10.2.2\",\n        \"minipass\": \"^7.1.3\",\n        \"path-scurry\": \"^2.0.2\"\n      },\n      \"engines\": {\n        \"node\": \"18 || 20 || >=22\"\n      },\n      \"funding\": {\n        \"url\": \"https://github.com/sponsors/isaacs\"\n      }\n    },\n    \"node_modules/glob-parent\": {"
    },
    {
      "file": "package-lock.json",
      "find": "      },\n      \"engines\": {\n        \"node\": \">=10.13.0\"\n      }\n    },\n    \"node_modules/globals\": {",
      "replace": "      },\n      \"engines\": {\n        \"node\": \">=10.13.0\"\n      }\n    },\n    \"node_modules/glob/node_modules/balanced-match\": {\n      \"version\": \"4.0.4\",\n      \"resolved\": \"https://registry.npmjs.org/balanced-match/-/balanced-match-4.0.4.tgz\",\n      \"integrity\": \"sha512-BLrgEcRTwX2o6gGxGOCNyMvGSp35YofuYzw9h1IMTRmKqttAZZVU67bdb9Pr2vUHA8+j3i2tJfjO6C6+4myGTA==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"engines\": {\n        \"node\": \"18 || 20 || >=22\"\n      }\n    },\n    \"node_modules/glob/node_modules/brace-expansion\": {\n      \"version\": \"5.0.12\",\n      \"resolved\": \"https://registry.npmjs.org/brace-expansion/-/brace-expansion-5.0.12.tgz\",\n      \"integrity\": \"sha512-YovQ3rzhaLMIrDjNDMkNS01tea93qhEhG5xy8f6+R0l+dw3Ki+5sCoIoI942iuLZTHWogWktgwVDhU09iNEimQ==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"balanced-match\": \"^4.0.2\"\n      },\n      \"engines\": {\n        \"node\": \"20 || >=22\"\n      }\n    },\n    \"node_modules/glob/node_modules/minimatch\": {\n      \"version\": \"10.2.6\",\n      \"resolved\": \"https://registry.npmjs.org/minimatch/-/minimatch-10.2.6.tgz\",\n      \"integrity\": \"sha512-vpLQEs+VLCr1nU0BXS07maYoFwlDAH0gngQuuttxIwutDFEMHq2blX+8vpgxDdK3J1PwjCJiep77OitTZ4Ll1A==\",\n      \"dev\": true,\n      \"license\": \"BlueOak-1.0.0\",\n      \"dependencies\": {\n        \"brace-expansion\": \"^5.0.8\"\n      },\n      \"engines\": {\n        \"node\": \"18 || 20 || >=22\"\n      },\n      \"funding\": {\n        \"url\": \"https://github.com/sponsors/isaacs\"\n      }\n    },\n    \"node_modules/globals\": {"
    },
    {
      "file": "package-lock.json",
      "find": "        \"url\": \"https://github.com/sponsors/ljharb\"\n      }\n    },\n    \"node_modules/has-bigints\": {",
      "replace": "        \"url\": \"https://github.com/sponsors/ljharb\"\n      }\n    },\n    \"node_modules/graceful-fs\": {\n      \"version\": \"4.2.11\",\n      \"resolved\": \"https://registry.npmjs.org/graceful-fs/-/graceful-fs-4.2.11.tgz\",\n      \"integrity\": \"sha512-RbJ5/jmFcNNCcDV5o9eTnBLJ/HszWV0P73bc+Ff4nS/rJj+YaS6IGyiOL0VoBYX+l1Wrl3k63h/KrH+nhJ0XvQ==\",\n      \"dev\": true,\n      \"license\": \"ISC\"\n    },\n    \"node_modules/has-bigints\": {"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/internal-slot\": {",
      "replace": "    },\n    \"node_modules/inherits\": {\n      \"version\": \"2.0.4\",\n      \"resolved\": \"https://registry.npmjs.org/inherits/-/inherits-2.0.4.tgz\",\n      \"integrity\": \"sha512-k/vGaX4/Yla3WzyMCvTQOXYeIHvqOKtnqBduzTHpzpQZzAskKMhZ2K+EnBiSM9zGSoIFeMpXKxa4dYeZIQqewQ==\",\n      \"dev\": true,\n      \"license\": \"ISC\"\n    },\n    \"node_modules/ini\": {\n      \"version\": \"4.1.3\",\n      \"resolved\": \"https://registry.npmjs.org/ini/-/ini-4.1.3.tgz\",\n      \"integrity\": \"sha512-X7rqawQBvfdjS10YU1y1YVreA3SsLrW9dX2CewP2EbBJM4ypVNLDkO5y04gejPwKIY9lR+7r9gn3rFPt/kmWFg==\",\n      \"dev\": true,\n      \"license\": \"ISC\",\n      \"engines\": {\n        \"node\": \"^14.17.0 || ^16.13.0 || >=18.0.0\"\n      }\n    },\n    \"node_modules/internal-slot\": {"
    },
    {
      "file": "package-lock.json",
      "find": "      },\n      \"funding\": {\n        \"url\": \"https://github.com/sponsors/ljharb\"\n      }\n    },\n    \"node_modules/is-extglob\": {",
      "replace": "      },\n      \"funding\": {\n        \"url\": \"https://github.com/sponsors/ljharb\"\n      }\n    },\n    \"node_modules/is-docker\": {\n      \"version\": \"2.2.1\",\n      \"resolved\": \"https://registry.npmjs.org/is-docker/-/is-docker-2.2.1.tgz\",\n      \"integrity\": \"sha512-F+i2BKsFrH66iaUFc0woD8sLy8getkwTwtOBjvs56Cx4CgJDeKQeqfz8wAYiSb8JOprWhHH5p77PbmYCvvUuXQ==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"bin\": {\n        \"is-docker\": \"cli.js\"\n      },\n      \"engines\": {\n        \"node\": \">=8\"\n      },\n      \"funding\": {\n        \"url\": \"https://github.com/sponsors/sindresorhus\"\n      }\n    },\n    \"node_modules/is-extglob\": {"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/isarray\": {",
      "replace": "    },\n    \"node_modules/is-wsl\": {\n      \"version\": \"2.2.0\",\n      \"resolved\": \"https://registry.npmjs.org/is-wsl/-/is-wsl-2.2.0.tgz\",\n      \"integrity\": \"sha512-fKzAra0rGJUUBwGBgNkHZuToZcn+TtXHpeCgmkMJMMYx1sQDYaCSyjJBSCa2nH1DGm7s3n1oBnohoVTBaN7Lww==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"is-docker\": \"^2.0.0\"\n      },\n      \"engines\": {\n        \"node\": \">=8\"\n      }\n    },\n    \"node_modules/isarray\": {"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/keyv\": {",
      "replace": "    },\n    \"node_modules/jsonfile\": {\n      \"version\": \"6.2.1\",\n      \"resolved\": \"https://registry.npmjs.org/jsonfile/-/jsonfile-6.2.1.tgz\",\n      \"integrity\": \"sha512-zwOTdL3rFQ/lRdBnntKVOX6k5cKJwEc1HdilT71BWEu7J41gXIB2MRp+vxduPSwZJPWBxEzv4yH1wYLJGUHX4Q==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"universalify\": \"^2.0.0\"\n      },\n      \"optionalDependencies\": {\n        \"graceful-fs\": \"^4.1.6\"\n      }\n    },\n    \"node_modules/keyv\": {"
    },
    {
      "file": "package-lock.json",
      "find": "        \"json-buffer\": \"3.0.1\"\n      }",
      "replace": "        \"json-buffer\": \"3.0.1\"\n      }\n    },\n    \"node_modules/kleur\": {\n      \"version\": \"4.1.5\",\n      \"resolved\": \"https://registry.npmjs.org/kleur/-/kleur-4.1.5.tgz\",\n      \"integrity\": \"sha512-o+NO+8WrRiQEE4/7nwRJhN1HWpVmJm511pBHUxPLtp0BUISzlBplORYSmTclCnJvQq2tKu/sgl3xVpkc7ZWuQQ==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"engines\": {\n        \"node\": \">=6\"\n      }"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/mitt\": {",
      "replace": "    },\n    \"node_modules/minipass\": {\n      \"version\": \"7.1.3\",\n      \"resolved\": \"https://registry.npmjs.org/minipass/-/minipass-7.1.3.tgz\",\n      \"integrity\": \"sha512-tEBHqDnIoM/1rXME1zgka9g6Q2lcoCkxHLuc7ODJ5BxbP5d4c2Z5cGgtXAku59200Cx7diuHTOYfSBD8n6mm8A==\",\n      \"dev\": true,\n      \"license\": \"BlueOak-1.0.0\",\n      \"engines\": {\n        \"node\": \">=16 || 14 >=14.17\"\n      }\n    },\n    \"node_modules/minizlib\": {\n      \"version\": \"3.1.0\",\n      \"resolved\": \"https://registry.npmjs.org/minizlib/-/minizlib-3.1.0.tgz\",\n      \"integrity\": \"sha512-KZxYo1BUkWD2TVFLr0MQoM8vUUigWD3LlD83a/75BqC+4qE0Hb1Vo5v1FgcfaNXvfXzr+5EhQ6ing/CaBijTlw==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"minipass\": \"^7.1.2\"\n      },\n      \"engines\": {\n        \"node\": \">= 18\"\n      }\n    },\n    \"node_modules/mitt\": {"
    },
    {
      "file": "package-lock.json",
      "find": "        \"node\": \"^10 || ^12 || ^13.7 || ^14 || >=15.0.1\"\n      }",
      "replace": "        \"node\": \"^10 || ^12 || ^13.7 || ^14 || >=15.0.1\"\n      }\n    },\n    \"node_modules/native-run\": {\n      \"version\": \"2.0.3\",\n      \"resolved\": \"https://registry.npmjs.org/native-run/-/native-run-2.0.3.tgz\",\n      \"integrity\": \"sha512-U1PllBuzW5d1gfan+88L+Hky2eZx+9gv3Pf6rNBxKbORxi7boHzqiA6QFGSnqMem4j0A9tZ08NMIs5+0m/VS1Q==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"@ionic/utils-fs\": \"^3.1.7\",\n        \"@ionic/utils-terminal\": \"^2.3.4\",\n        \"bplist-parser\": \"^0.3.2\",\n        \"debug\": \"^4.3.4\",\n        \"elementtree\": \"^0.1.7\",\n        \"ini\": \"^4.1.1\",\n        \"plist\": \"^3.1.0\",\n        \"split2\": \"^4.2.0\",\n        \"through2\": \"^4.0.2\",\n        \"tslib\": \"^2.6.2\",\n        \"yauzl\": \"^2.10.0\"\n      },\n      \"bin\": {\n        \"native-run\": \"bin/native-run\"\n      },\n      \"engines\": {\n        \"node\": \">=16.0.0\"\n      }"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/optionator\": {",
      "replace": "    },\n    \"node_modules/open\": {\n      \"version\": \"8.4.2\",\n      \"resolved\": \"https://registry.npmjs.org/open/-/open-8.4.2.tgz\",\n      \"integrity\": \"sha512-7x81NCL719oNbsq/3mh+hVrAWmFuEYUqrq/Iw3kUzH8ReypT9QQ0BLoJS7/G9k6N81XjW4qHWtjWwe/9eLy1EQ==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"define-lazy-prop\": \"^2.0.0\",\n        \"is-docker\": \"^2.1.1\",\n        \"is-wsl\": \"^2.2.0\"\n      },\n      \"engines\": {\n        \"node\": \">=12\"\n      },\n      \"funding\": {\n        \"url\": \"https://github.com/sponsors/sindresorhus\"\n      }\n    },\n    \"node_modules/optionator\": {"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/parent-module\": {",
      "replace": "    },\n    \"node_modules/package-json-from-dist\": {\n      \"version\": \"1.0.1\",\n      \"resolved\": \"https://registry.npmjs.org/package-json-from-dist/-/package-json-from-dist-1.0.1.tgz\",\n      \"integrity\": \"sha512-UEZIS3/by4OC8vL3P2dTXRETpebLI2NiI5vIrjaD/5UtrkFX/tNbwjTSRAGC/+7CAo2pIcBaRgWmcBBHcsaCIw==\",\n      \"dev\": true,\n      \"license\": \"BlueOak-1.0.0\"\n    },\n    \"node_modules/parent-module\": {"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/picocolors\": {",
      "replace": "    },\n    \"node_modules/path-scurry\": {\n      \"version\": \"2.0.2\",\n      \"resolved\": \"https://registry.npmjs.org/path-scurry/-/path-scurry-2.0.2.tgz\",\n      \"integrity\": \"sha512-3O/iVVsJAPsOnpwWIeD+d6z/7PmqApyQePUtCndjatj/9I5LylHvt5qluFaBT3I5h3r1ejfR056c+FCv+NnNXg==\",\n      \"dev\": true,\n      \"license\": \"BlueOak-1.0.0\",\n      \"dependencies\": {\n        \"lru-cache\": \"^11.0.0\",\n        \"minipass\": \"^7.1.2\"\n      },\n      \"engines\": {\n        \"node\": \"18 || 20 || >=22\"\n      },\n      \"funding\": {\n        \"url\": \"https://github.com/sponsors/isaacs\"\n      }\n    },\n    \"node_modules/path-scurry/node_modules/lru-cache\": {\n      \"version\": \"11.5.3\",\n      \"resolved\": \"https://registry.npmjs.org/lru-cache/-/lru-cache-11.5.3.tgz\",\n      \"integrity\": \"sha512-U4N8FgzmWxc8k1VH8Kr6lQg18U7Fjvby6wXHVRX/ZZ7IwWbRMgrRbP0Wrb5q5NVinryp4SQampHKdvtecItxUg==\",\n      \"dev\": true,\n      \"license\": \"BlueOak-1.0.0\",\n      \"engines\": {\n        \"node\": \"20 || >=22\"\n      }\n    },\n    \"node_modules/pend\": {\n      \"version\": \"1.2.0\",\n      \"resolved\": \"https://registry.npmjs.org/pend/-/pend-1.2.0.tgz\",\n      \"integrity\": \"sha512-F3asv42UuXchdzt+xXqfW1OGlVBe+mxa2mqI0pg5yAHZPvFmY3Y6drSf/GQ1A86WgWEN9Kzh/WrgKa6iGcHXLg==\",\n      \"dev\": true,\n      \"license\": \"MIT\"\n    },\n    \"node_modules/picocolors\": {"
    },
    {
      "file": "package-lock.json",
      "find": "        \"url\": \"https://github.com/sponsors/jonschlinkert\"\n      }",
      "replace": "        \"url\": \"https://github.com/sponsors/jonschlinkert\"\n      }\n    },\n    \"node_modules/plist\": {\n      \"version\": \"3.1.1\",\n      \"resolved\": \"https://registry.npmjs.org/plist/-/plist-3.1.1.tgz\",\n      \"integrity\": \"sha512-ZIfcLJC+7E7FBFnDxm9MPmt7D+DidyQ26lewieO75AdhA2ayMtsJSES0iWzqJQbcVRSrTufQoy0DR94xHue0oA==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"@xmldom/xmldom\": \"^0.9.10\",\n        \"base64-js\": \"^1.5.1\",\n        \"xmlbuilder\": \"^15.1.1\"\n      },\n      \"engines\": {\n        \"node\": \">=10.4.0\"\n      }"
    },
    {
      "file": "package-lock.json",
      "find": "      \"license\": \"MIT\",\n      \"engines\": {\n        \"node\": \">= 0.8.0\"\n      }\n    },\n    \"node_modules/punycode\": {",
      "replace": "      \"license\": \"MIT\",\n      \"engines\": {\n        \"node\": \">= 0.8.0\"\n      }\n    },\n    \"node_modules/prompts\": {\n      \"version\": \"2.4.2\",\n      \"resolved\": \"https://registry.npmjs.org/prompts/-/prompts-2.4.2.tgz\",\n      \"integrity\": \"sha512-NxNv/kLguCA7p3jE8oL2aEBsrJWgAakBpgmgK6lpPWV+WuOmY6r2/zbAVnP+T8bQlA0nzHXSJSJW0Hq7ylaD2Q==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"kleur\": \"^3.0.3\",\n        \"sisteransi\": \"^1.0.5\"\n      },\n      \"engines\": {\n        \"node\": \">= 6\"\n      }\n    },\n    \"node_modules/prompts/node_modules/kleur\": {\n      \"version\": \"3.0.3\",\n      \"resolved\": \"https://registry.npmjs.org/kleur/-/kleur-3.0.3.tgz\",\n      \"integrity\": \"sha512-eTIzlVOSUR+JxdDFepEYcBMtZ9Qqdef+rnzWdRZuMbOywu5tO2w2N7rqjoANZ5k9vywhL6Br1VRjUIgTQx4E8w==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"engines\": {\n        \"node\": \">=6\"\n      }\n    },\n    \"node_modules/punycode\": {"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/reflect.getprototypeof\": {",
      "replace": "    },\n    \"node_modules/readable-stream\": {\n      \"version\": \"3.6.2\",\n      \"resolved\": \"https://registry.npmjs.org/readable-stream/-/readable-stream-3.6.2.tgz\",\n      \"integrity\": \"sha512-9u/sniCrY3D5WdsERHzHE4G2YCXqoG5FTHUiCC4SIbr6XcLZBY05ya9EKjYek9O5xOAwjGq+1JdGBAS7Q9ScoA==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"inherits\": \"^2.0.3\",\n        \"string_decoder\": \"^1.1.1\",\n        \"util-deprecate\": \"^1.0.1\"\n      },\n      \"engines\": {\n        \"node\": \">= 6\"\n      }\n    },\n    \"node_modules/reflect.getprototypeof\": {"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/rollup\": {",
      "replace": "    },\n    \"node_modules/rimraf\": {\n      \"version\": \"6.1.3\",\n      \"resolved\": \"https://registry.npmjs.org/rimraf/-/rimraf-6.1.3.tgz\",\n      \"integrity\": \"sha512-LKg+Cr2ZF61fkcaK1UdkH2yEBBKnYjTyWzTJT6KNPcSPaiT7HSdhtMXQuN5wkTX0Xu72KQ1l8S42rlmexS2hSA==\",\n      \"dev\": true,\n      \"license\": \"BlueOak-1.0.0\",\n      \"dependencies\": {\n        \"glob\": \"^13.0.3\",\n        \"package-json-from-dist\": \"^1.0.1\"\n      },\n      \"bin\": {\n        \"rimraf\": \"dist/esm/bin.mjs\"\n      },\n      \"engines\": {\n        \"node\": \"20 || >=22\"\n      },\n      \"funding\": {\n        \"url\": \"https://github.com/sponsors/isaacs\"\n      }\n    },\n    \"node_modules/rollup\": {"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/safe-push-apply\": {",
      "replace": "    },\n    \"node_modules/safe-buffer\": {\n      \"version\": \"5.2.1\",\n      \"resolved\": \"https://registry.npmjs.org/safe-buffer/-/safe-buffer-5.2.1.tgz\",\n      \"integrity\": \"sha512-rp3So07KcdmmKbGvgaNxQSJr7bGVSVk5S9Eq1F+ppbRo70+YeaDxkw5Dd8NPN+GD6bjnYm2VuPuCXmpuYvmCXQ==\",\n      \"dev\": true,\n      \"funding\": [\n        {\n          \"type\": \"github\",\n          \"url\": \"https://github.com/sponsors/feross\"\n        },\n        {\n          \"type\": \"patreon\",\n          \"url\": \"https://www.patreon.com/feross\"\n        },\n        {\n          \"type\": \"consulting\",\n          \"url\": \"https://feross.org/support\"\n        }\n      ],\n      \"license\": \"MIT\"\n    },\n    \"node_modules/safe-push-apply\": {"
    },
    {
      "file": "package-lock.json",
      "find": "        \"url\": \"https://github.com/sponsors/ljharb\"\n      }\n    },\n    \"node_modules/scheduler\": {",
      "replace": "        \"url\": \"https://github.com/sponsors/ljharb\"\n      }\n    },\n    \"node_modules/sax\": {\n      \"version\": \"1.1.4\",\n      \"resolved\": \"https://registry.npmjs.org/sax/-/sax-1.1.4.tgz\",\n      \"integrity\": \"sha512-5f3k2PbGGp+YtKJjOItpg3P99IMD84E4HOvcfleTb5joCHNXYLsR9yWFPOYGgaeMPDubQILTCMdsFb2OMeOjtg==\",\n      \"dev\": true,\n      \"license\": \"ISC\"\n    },\n    \"node_modules/scheduler\": {"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/source-map-js\": {",
      "replace": "    },\n    \"node_modules/signal-exit\": {\n      \"version\": \"3.0.7\",\n      \"resolved\": \"https://registry.npmjs.org/signal-exit/-/signal-exit-3.0.7.tgz\",\n      \"integrity\": \"sha512-wnD2ZE+l+SPC/uoS0vXeE9L1+0wuaMqKlfz9AMUo38JsyLSBWSFcHR1Rri62LZc12vLr1gb3jl7iwQhgwpAbGQ==\",\n      \"dev\": true,\n      \"license\": \"ISC\"\n    },\n    \"node_modules/simple-plist\": {\n      \"version\": \"1.3.1\",\n      \"resolved\": \"https://registry.npmjs.org/simple-plist/-/simple-plist-1.3.1.tgz\",\n      \"integrity\": \"sha512-iMSw5i0XseMnrhtIzRb7XpQEXepa9xhWxGUojHBL43SIpQuDQkh3Wpy67ZbDzZVr6EKxvwVChnVpdl8hEVLDiw==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"bplist-creator\": \"0.1.0\",\n        \"bplist-parser\": \"0.3.1\",\n        \"plist\": \"^3.0.5\"\n      }\n    },\n    \"node_modules/simple-plist/node_modules/bplist-parser\": {\n      \"version\": \"0.3.1\",\n      \"resolved\": \"https://registry.npmjs.org/bplist-parser/-/bplist-parser-0.3.1.tgz\",\n      \"integrity\": \"sha512-PyJxiNtA5T2PlLIeBot4lbp7rj4OadzjnMZD/G5zuBNt8ei/yCU7+wW0h2bag9vr8c+/WuRWmSxbqAl9hL1rBA==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"big-integer\": \"1.6.x\"\n      },\n      \"engines\": {\n        \"node\": \">= 5.10.0\"\n      }\n    },\n    \"node_modules/sisteransi\": {\n      \"version\": \"1.0.5\",\n      \"resolved\": \"https://registry.npmjs.org/sisteransi/-/sisteransi-1.0.5.tgz\",\n      \"integrity\": \"sha512-bLGGlR1QxBcynn2d5YmDX4MGjlZvy2MRBDRNHLJ8VI6l6+9FUiyTFNJ0IveOSP0bcXgVDPRcfGqA0pjaqUpfVg==\",\n      \"dev\": true,\n      \"license\": \"MIT\"\n    },\n    \"node_modules/slice-ansi\": {\n      \"version\": \"4.0.0\",\n      \"resolved\": \"https://registry.npmjs.org/slice-ansi/-/slice-ansi-4.0.0.tgz\",\n      \"integrity\": \"sha512-qMCMfhY040cVHT43K9BFygqYbUPFZKHOg7K73mtTWJRb8pyP3fzf4Ixd5SzdEJQ6MRUg/WBnOLxghZtKKurENQ==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"ansi-styles\": \"^4.0.0\",\n        \"astral-regex\": \"^2.0.0\",\n        \"is-fullwidth-code-point\": \"^3.0.0\"\n      },\n      \"engines\": {\n        \"node\": \">=10\"\n      },\n      \"funding\": {\n        \"url\": \"https://github.com/chalk/slice-ansi?sponsor=1\"\n      }\n    },\n    \"node_modules/source-map-js\": {"
    },
    {
      "file": "package-lock.json",
      "find": "      \"license\": \"BSD-3-Clause\",\n      \"engines\": {\n        \"node\": \">=0.10.0\"\n      }\n    },\n    \"node_modules/stop-iteration-iterator\": {",
      "replace": "      \"license\": \"BSD-3-Clause\",\n      \"engines\": {\n        \"node\": \">=0.10.0\"\n      }\n    },\n    \"node_modules/split2\": {\n      \"version\": \"4.2.0\",\n      \"resolved\": \"https://registry.npmjs.org/split2/-/split2-4.2.0.tgz\",\n      \"integrity\": \"sha512-UcjcJOWknrNkF6PLX83qcHM6KHgVKNkV62Y8a5uYDVv9ydGQVwAHMKqHdJje1VTWpljG0WYpCDhrCdAOYH4TWg==\",\n      \"dev\": true,\n      \"license\": \"ISC\",\n      \"engines\": {\n        \"node\": \">= 10.x\"\n      }\n    },\n    \"node_modules/stop-iteration-iterator\": {"
    },
    {
      "file": "package-lock.json",
      "find": "      },\n      \"engines\": {\n        \"node\": \">= 0.4\"\n      }\n    },\n    \"node_modules/string-width\": {",
      "replace": "      },\n      \"engines\": {\n        \"node\": \">= 0.4\"\n      }\n    },\n    \"node_modules/stream-buffers\": {\n      \"version\": \"2.2.0\",\n      \"resolved\": \"https://registry.npmjs.org/stream-buffers/-/stream-buffers-2.2.0.tgz\",\n      \"integrity\": \"sha512-uyQK/mx5QjHun80FLJTfaWE7JtwfRMKBLkMne6udYOmvH0CawotVa7TfgYHzAnpphn4+TweIx1QKMnRIbipmUg==\",\n      \"dev\": true,\n      \"license\": \"Unlicense\",\n      \"engines\": {\n        \"node\": \">= 0.10.0\"\n      }\n    },\n    \"node_modules/string_decoder\": {\n      \"version\": \"1.3.0\",\n      \"resolved\": \"https://registry.npmjs.org/string_decoder/-/string_decoder-1.3.0.tgz\",\n      \"integrity\": \"sha512-hkRX8U1WjJFd8LsDJ2yQ/wWWxaopEsABU1XfkM8A+j0+85JAGppt16cr1Whg6KIbb4okU6Mql6BOj+uup/wKeA==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"safe-buffer\": \"~5.2.0\"\n      }\n    },\n    \"node_modules/string-width\": {"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/tinyglobby\": {",
      "replace": "    },\n    \"node_modules/tar\": {\n      \"version\": \"7.5.22\",\n      \"resolved\": \"https://registry.npmjs.org/tar/-/tar-7.5.22.tgz\",\n      \"integrity\": \"sha512-MFO/QzvtAOmJbkhOaCTvbGcFN9L9b+JunIsDwaKljSOdcLMea3NJ1k9Usz/rjdfSXTq4dfzfeS7W4p4YOAAHeA==\",\n      \"dev\": true,\n      \"license\": \"BlueOak-1.0.0\",\n      \"dependencies\": {\n        \"@isaacs/fs-minipass\": \"^4.0.0\",\n        \"chownr\": \"^3.0.0\",\n        \"minipass\": \"^7.1.2\",\n        \"minizlib\": \"^3.1.0\",\n        \"yallist\": \"^5.0.0\"\n      },\n      \"engines\": {\n        \"node\": \">=18\"\n      }\n    },\n    \"node_modules/tar/node_modules/yallist\": {\n      \"version\": \"5.0.0\",\n      \"resolved\": \"https://registry.npmjs.org/yallist/-/yallist-5.0.0.tgz\",\n      \"integrity\": \"sha512-YgvUTfwqyc7UXVMrB+SImsVYSmTS8X/tSrtdNZMImM+n7+QTriRXyXim0mBrTXNeqzVF0KWGgHPeiyViFFrNDw==\",\n      \"dev\": true,\n      \"license\": \"BlueOak-1.0.0\",\n      \"engines\": {\n        \"node\": \">=18\"\n      }\n    },\n    \"node_modules/through2\": {\n      \"version\": \"4.0.2\",\n      \"resolved\": \"https://registry.npmjs.org/through2/-/through2-4.0.2.tgz\",\n      \"integrity\": \"sha512-iOqSav00cVxEEICeD7TjLB1sueEL+81Wpzp2bY17uZjZN0pWZPuo4suZ/61VujxmqSGFfgOcNuTZ85QJwNZQpw==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"readable-stream\": \"3\"\n      }\n    },\n    \"node_modules/tinyglobby\": {"
    },
    {
      "file": "package-lock.json",
      "find": "        \"url\": \"https://github.com/sponsors/SuperchupuDev\"\n      }",
      "replace": "        \"url\": \"https://github.com/sponsors/SuperchupuDev\"\n      }\n    },\n    \"node_modules/tree-kill\": {\n      \"version\": \"1.2.2\",\n      \"resolved\": \"https://registry.npmjs.org/tree-kill/-/tree-kill-1.2.2.tgz\",\n      \"integrity\": \"sha512-L0Orpi8qGpRG//Nd+H90vFB+3iHnue1zSSGmNOOCh1GLJ7rUKVwV2HvijphGQS2UmhUZewS9VgvxYIdgr+fG1A==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"bin\": {\n        \"tree-kill\": \"cli.js\"\n      }"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/update-browserslist-db\": {",
      "replace": "    },\n    \"node_modules/universalify\": {\n      \"version\": \"2.0.1\",\n      \"resolved\": \"https://registry.npmjs.org/universalify/-/universalify-2.0.1.tgz\",\n      \"integrity\": \"sha512-gptHNQghINnc/vTGIk0SOFGFNXw7JVrlRUtConJRlvaw6DuX0wO5Jeko9sWrMBhh+PsYAZ7oXAiOnf/UKogyiw==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"engines\": {\n        \"node\": \">= 10.0.0\"\n      }\n    },\n    \"node_modules/untildify\": {\n      \"version\": \"4.0.0\",\n      \"resolved\": \"https://registry.npmjs.org/untildify/-/untildify-4.0.0.tgz\",\n      \"integrity\": \"sha512-KK8xQ1mkzZeg9inewmFVDNkg3l5LUhoq9kN6iWYB/CC9YMG8HA+c1Q8HwDe6dEX7kErrEVNVBO3fWsVq5iDgtw==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"engines\": {\n        \"node\": \">=8\"\n      }\n    },\n    \"node_modules/update-browserslist-db\": {"
    },
    {
      "file": "package-lock.json",
      "find": "        \"react\": \"^16.8.0 || ^17.0.0 || ^18.0.0 || ^19.0.0\"\n      }",
      "replace": "        \"react\": \"^16.8.0 || ^17.0.0 || ^18.0.0 || ^19.0.0\"\n      }\n    },\n    \"node_modules/util-deprecate\": {\n      \"version\": \"1.0.2\",\n      \"resolved\": \"https://registry.npmjs.org/util-deprecate/-/util-deprecate-1.0.2.tgz\",\n      \"integrity\": \"sha512-EPD5q1uXyFxJpCrLnCc1nHnq3gOa6DZBocAIiI2TaSCA7VCJ1UJDMagCzIkXNsUYfD1daK//LTEQ8xiIbrHtcw==\",\n      \"dev\": true,\n      \"license\": \"MIT\"\n    },\n    \"node_modules/uuid\": {\n      \"version\": \"7.0.3\",\n      \"resolved\": \"https://registry.npmjs.org/uuid/-/uuid-7.0.3.tgz\",\n      \"integrity\": \"sha512-DPSke0pXhTZgoF/d+WSt2QaKMCFSfx7QegxEWT+JOuHF5aWrKEn0G+ztjuJg/gG8/ItK+rbPCD/yNv8yyih6Cg==\",\n      \"deprecated\": \"uuid@10 and below is no longer supported.  For ESM codebases, update to uuid@latest.  For CommonJS codebases, use uuid@11 (but be aware this version will likely be deprecated in 2028).\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"bin\": {\n        \"uuid\": \"dist/bin/uuid\"\n      }"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/y18n\": {",
      "replace": "    },\n    \"node_modules/xcode\": {\n      \"version\": \"3.0.1\",\n      \"resolved\": \"https://registry.npmjs.org/xcode/-/xcode-3.0.1.tgz\",\n      \"integrity\": \"sha512-kCz5k7J7XbJtjABOvkc5lJmkiDh8VhjVCGNiqdKCscmVpdVUpEAyXv1xmCLkQJ5dsHqx3IPO4XW+NTDhU/fatA==\",\n      \"dev\": true,\n      \"license\": \"Apache-2.0\",\n      \"dependencies\": {\n        \"simple-plist\": \"^1.1.0\",\n        \"uuid\": \"^7.0.3\"\n      },\n      \"engines\": {\n        \"node\": \">=10.0.0\"\n      }\n    },\n    \"node_modules/xml2js\": {\n      \"version\": \"0.6.2\",\n      \"resolved\": \"https://registry.npmjs.org/xml2js/-/xml2js-0.6.2.tgz\",\n      \"integrity\": \"sha512-T4rieHaC1EXcES0Kxxj4JWgaUQHDk+qwHcYOCFHfiwKz7tOVPLq7Hjq9dM1WCMhylqMEfP7hMcOIChvotiZegA==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"sax\": \">=0.6.0\",\n        \"xmlbuilder\": \"~11.0.0\"\n      },\n      \"engines\": {\n        \"node\": \">=4.0.0\"\n      }\n    },\n    \"node_modules/xml2js/node_modules/xmlbuilder\": {\n      \"version\": \"11.0.1\",\n      \"resolved\": \"https://registry.npmjs.org/xmlbuilder/-/xmlbuilder-11.0.1.tgz\",\n      \"integrity\": \"sha512-fDlsI/kFEx7gLvbecc0/ohLG50fugQp8ryHzMTuW9vSa1GJ0XYWKnhsUx7oie3G98+r56aTQIUB4kht42R3JvA==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"engines\": {\n        \"node\": \">=4.0\"\n      }\n    },\n    \"node_modules/xmlbuilder\": {\n      \"version\": \"15.1.1\",\n      \"resolved\": \"https://registry.npmjs.org/xmlbuilder/-/xmlbuilder-15.1.1.tgz\",\n      \"integrity\": \"sha512-yMqGBqtXyeN1e3TGYvgNgDVZ3j84W4cwkOXQswghol6APgZWaff9lnbvN7MHYJOiXsvGPXtjTYJEiC9J2wv9Eg==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"engines\": {\n        \"node\": \">=8.0\"\n      }\n    },\n    \"node_modules/y18n\": {"
    },
    {
      "file": "package-lock.json",
      "find": "    },\n    \"node_modules/yocto-queue\": {",
      "replace": "    },\n    \"node_modules/yauzl\": {\n      \"version\": \"2.10.0\",\n      \"resolved\": \"https://registry.npmjs.org/yauzl/-/yauzl-2.10.0.tgz\",\n      \"integrity\": \"sha512-p4a9I6X6nu6IhoGmBqAcbJy1mlC4j27vEPZX9F4L4/vZT3Lyq1VkFHw/V/PUcB9Buo+DG3iHkT0x3Qya58zc3g==\",\n      \"dev\": true,\n      \"license\": \"MIT\",\n      \"dependencies\": {\n        \"buffer-crc32\": \"~0.2.3\",\n        \"fd-slicer\": \"~1.1.0\"\n      }\n    },\n    \"node_modules/yocto-queue\": {"
    },
    {
      "file": "package.json",
      "find": "  \"dependencies\": {\n    \"@fontsource/inter\": \"^5.3.0\",",
      "replace": "  \"dependencies\": {\n    \"@capacitor/android\": \"^8.5.2\",\n    \"@capacitor/app\": \"^8.1.1\",\n    \"@capacitor/browser\": \"^8.0.4\",\n    \"@capacitor/core\": \"^8.5.2\",\n    \"@capacitor/filesystem\": \"^8.1.3\",\n    \"@capacitor/ios\": \"^8.5.2\",\n    \"@capacitor/share\": \"^8.0.2\",\n    \"@capacitor/splash-screen\": \"^8.0.2\",\n    \"@fontsource/inter\": \"^5.3.0\","
    },
    {
      "file": "package.json",
      "find": "  \"devDependencies\": {\n    \"@eslint/js\": \"^9.33.0\",",
      "replace": "  \"devDependencies\": {\n    \"@capacitor/cli\": \"^8.5.2\",\n    \"@eslint/js\": \"^9.33.0\","
    },
    {
      "file": "src/App.jsx",
      "find": "import { installErrorHandlers } from './services/errors'\n",
      "replace": "import { installErrorHandlers } from './services/errors'\nimport { startNative } from './services/native'\n"
    },
    {
      "file": "src/App.jsx",
      "find": "\n// app. is reserved for the future download page, so it forwards to the apex for now.\nfunction redirectToApex() {",
      "replace": "\n// www. forwards to the apex; app. lands on the download page at /app.\nfunction redirectToApex() {"
    },
    {
      "file": "src/App.jsx",
      "find": "    const { pathname, search, hash } = window.location\n    window.location.replace(`https://${APEX}${pathname}${search}${hash}`)\n    return true",
      "replace": "    const { pathname, search, hash } = window.location\n    const path = host === `app.${APEX}` && pathname === '/' ? '/app' : pathname\n    window.location.replace(`https://${APEX}${path}${search}${hash}`)\n    return true"
    },
    {
      "file": "src/App.jsx",
      "find": "        }\n    }, [])",
      "replace": "        }\n        startNative()\n    }, [])"
    },
    {
      "file": "src/BookingApp.jsx",
      "find": "import { RouteBoundary } from './components/common/ErrorBoundary'\n",
      "replace": "import { RouteBoundary } from './components/common/ErrorBoundary'\nimport { isNative } from './services/native'\n"
    },
    {
      "file": "src/BookingApp.jsx",
      "find": "const Join = lazy(() => import('./pages/app/Join'))\nconst Invite = lazy(() => import('./pages/business/Invite'))",
      "replace": "const Join = lazy(() => import('./pages/app/Join'))\nconst AppDownload = lazy(() => import('./pages/app/AppDownload'))\nconst Invite = lazy(() => import('./pages/business/Invite'))"
    },
    {
      "file": "src/BookingApp.jsx",
      "find": "                <Routes>\n                    <Route path=\"/\" element={<AppHome />} />\n                    <Route path=\"/about\" element={<Navigate to=\"/\" replace />} />",
      "replace": "                <Routes>\n                    {/* The apps skip the website's front page and open on the person's own home. */}\n                    <Route path=\"/\" element={isNative() ? <Navigate to=\"/me\" replace /> : <AppHome />} />\n                    <Route path=\"/about\" element={<Navigate to=\"/\" replace />} />"
    },
    {
      "file": "src/BookingApp.jsx",
      "find": "                    <Route path=\"/waitlist\" element={<WaitlistRedirect />} />\n",
      "replace": "                    <Route path=\"/waitlist\" element={<WaitlistRedirect />} />\n                    <Route path=\"/app\" element={<AppDownload />} />\n"
    },
    {
      "file": "src/components/business/PosterSheet.jsx",
      "find": "import { downloadPoster } from './posterImage'\nimport '../../styles/business/poster.css'",
      "replace": "import { downloadPoster } from './posterImage'\nimport { isNative } from '../../services/native'\nimport '../../styles/business/poster.css'"
    },
    {
      "file": "src/components/business/PosterSheet.jsx",
      "find": "                    <div className=\"lc-poster-sheet__acts\">\n                        <Button icon={Printer} onClick={() => window.print()}>Print</Button>\n                        <Button variant=\"secondary\" icon={Download} loading={saving} onClick={savePoster}>Download poster</Button>\n                    </div>",
      "replace": "                    <div className=\"lc-poster-sheet__acts\">\n                        {/* The apps cannot print a page; the saved image prints from the share sheet instead. */}\n                        {!isNative() && <Button icon={Printer} onClick={() => window.print()}>Print</Button>}\n                        <Button variant={isNative() ? 'primary' : 'secondary'} icon={Download} loading={saving} onClick={savePoster}>{isNative() ? 'Save or print the poster' : 'Download poster'}</Button>\n                    </div>"
    },
    {
      "file": "src/components/business/ShareLink.jsx",
      "find": "import { useState } from 'react'\nimport { Check, Copy, MessageCircle } from 'lucide-react'\nimport { pageUrl, publicHost } from '../../services/links'\n",
      "replace": "import { useState } from 'react'\nimport { Check, Copy, MessageCircle, Share2 } from 'lucide-react'\nimport { pageUrl, publicHost } from '../../services/links'\nimport { isNative, shareLink } from '../../services/native'\n"
    },
    {
      "file": "src/components/business/ShareLink.jsx",
      "find": "                </a>\n            </div>",
      "replace": "                </a>\n                {isNative() && (\n                    <button type=\"button\" className=\"btn btn--secondary\" onClick={() => shareLink({ title: business.business_name, text: `Book with ${business.business_name}`, url: link }).catch(() => {})}>\n                        <Share2 size={16} aria-hidden=\"true\" /> More\n                    </button>\n                )}\n            </div>"
    },
    {
      "file": "src/components/business/posterImage.js",
      "find": "import QRCode from 'qrcode'\n",
      "replace": "import QRCode from 'qrcode'\nimport { saveFile } from '../../services/native'\n"
    },
    {
      "file": "src/components/business/posterImage.js",
      "find": "    const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/png'))\n    const url = URL.createObjectURL(blob)\n    const a = document.createElement('a')\n    a.download = filename\n    a.href = url\n    a.click()\n    setTimeout(() => URL.revokeObjectURL(url), 30000)\n}",
      "replace": "    const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/png'))\n    await saveFile(blob, filename)\n}"
    },
    {
      "file": "src/components/client/EmailSheet.jsx",
      "find": "import { supabase } from '../../config/supabase'\nimport '../../styles/business/settings-page.css'",
      "replace": "import { supabase } from '../../config/supabase'\nimport { appOrigin } from '../../services/native'\nimport '../../styles/business/settings-page.css'"
    },
    {
      "file": "src/components/client/EmailSheet.jsx",
      "find": "        try {\n            const { error: updateError } = await supabase.auth.updateUser({ email: clean }, { emailRedirectTo: `${window.location.origin}/auth/confirm` })\n            if (updateError) throw updateError",
      "replace": "        try {\n            const { error: updateError } = await supabase.auth.updateUser({ email: clean }, { emailRedirectTo: `${appOrigin()}/auth/confirm` })\n            if (updateError) throw updateError"
    },
    {
      "file": "src/components/common/Appfooter.jsx",
      "find": "                            <li><Link to=\"/portal\">Business dashboard</Link></li>\n                        </ul>",
      "replace": "                            <li><Link to=\"/portal\">Business dashboard</Link></li>\n                            <li><Link to=\"/app\">Get the app</Link></li>\n                        </ul>"
    },
    {
      "file": "src/components/ui/QrCode.jsx",
      "find": "import QRCode from 'qrcode'\nimport '../../styles/ui-kit.css'",
      "replace": "import QRCode from 'qrcode'\nimport { saveFile } from '../../services/native'\nimport '../../styles/ui-kit.css'"
    },
    {
      "file": "src/components/ui/QrCode.jsx",
      "find": "    }\n    const link = document.createElement('a')\n    link.download = filename\n    link.href = canvas.toDataURL('image/png')\n    link.click()\n}",
      "replace": "    }\n    canvas.toBlob((blob) => { if (blob) saveFile(blob, filename) }, 'image/png')\n}"
    },
    {
      "file": "src/contexts/AuthContext.jsx",
      "find": "import { AuthContext } from '../context_definition/AuthContextDefinition'\n",
      "replace": "import { AuthContext } from '../context_definition/AuthContextDefinition'\nimport { appOrigin, isNative, nativeOAuth } from '../services/native'\n"
    },
    {
      "file": "src/contexts/AuthContext.jsx",
      "find": "                    },\n                    emailRedirectTo: `${window.location.origin}/auth?verified=true${userData.next ? `&next=${encodeURIComponent(userData.next)}` : ''}`\n                }",
      "replace": "                    },\n                    emailRedirectTo: `${appOrigin()}/auth?verified=true${userData.next ? `&next=${encodeURIComponent(userData.next)}` : ''}`\n                }"
    },
    {
      "file": "src/contexts/AuthContext.jsx",
      "find": "    const signInWithGoogle = async () => {\n        try {\n            const { data, error } = await supabase.auth.signInWithOAuth({\n                provider: 'google',",
      "replace": "    const signInWithGoogle = async () => {\n        try {\n            if (isNative()) return { data: await nativeOAuth(supabase, 'google'), error: null }\n            const { data, error } = await supabase.auth.signInWithOAuth({\n                provider: 'google',"
    },
    {
      "file": "src/contexts/AuthContext.jsx",
      "find": "    const signInWithApple = async () => {\n        try {\n            const { data, error } = await supabase.auth.signInWithOAuth({\n                provider: 'apple',",
      "replace": "    const signInWithApple = async () => {\n        try {\n            if (isNative()) return { data: await nativeOAuth(supabase, 'apple'), error: null }\n            const { data, error } = await supabase.auth.signInWithOAuth({\n                provider: 'apple',"
    },
    {
      "file": "src/contexts/AuthContext.jsx",
      "find": "            const { data, error } = await supabase.auth.resetPasswordForEmail(email, {\n                redirectTo: `${window.location.origin}/reset-password`,\n            })",
      "replace": "            const { data, error } = await supabase.auth.resetPasswordForEmail(email, {\n                redirectTo: `${appOrigin()}/reset-password`,\n            })"
    },
    {
      "file": "src/pages/business/Setup.jsx",
      "find": "import { useSlugStatus } from '../../hooks/useSlugStatus'\nimport '../../styles/business/setup.css'",
      "replace": "import { useSlugStatus } from '../../hooks/useSlugStatus'\nimport { isNative, shareLink } from '../../services/native'\nimport '../../styles/business/setup.css'"
    },
    {
      "file": "src/pages/business/Setup.jsx",
      "find": "    const percent = useCountUp(strength.percent)\n    const canShare = typeof navigator !== 'undefined' && typeof navigator.share === 'function'\n    const nudge = !business.logo_url ? 'logo' : !business.banner_url ? 'cover' : null",
      "replace": "    const percent = useCountUp(strength.percent)\n    const canShare = isNative() || (typeof navigator !== 'undefined' && typeof navigator.share === 'function')\n    const nudge = !business.logo_url ? 'logo' : !business.banner_url ? 'cover' : null"
    },
    {
      "file": "src/pages/business/Setup.jsx",
      "find": "    const share = async () => {\n        try { await navigator.share({ title: business.business_name, text: `Book with ${business.business_name}`, url: link }) } catch { /* noop */ }\n    }",
      "replace": "    const share = async () => {\n        try { await shareLink({ title: business.business_name, text: `Book with ${business.business_name}`, url: link }) } catch { /* noop */ }\n    }"
    },
    {
      "file": "src/services/calendar.js",
      "find": "// Add a booking to a calendar: a Google Calendar link and an .ics file for Apple, Outlook and others.",
      "replace": "import { saveFile } from './native'\n// Add a booking to a calendar: a Google Calendar link and an .ics file for Apple, Outlook and others."
    },
    {
      "file": "src/services/calendar.js",
      "find": "const stamp = (d) => `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}00Z`\nconst escapeIcs = (value) => String(value).replace(/\\\\/g, '\\\\\\\\').replace(/;/g, '\\;').replace(/,/g, '\\\\,').replace(/\\r?\\n/g, '\\\\n')\n",
      "replace": "const stamp = (d) => `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}00Z`\nconst escapeIcs = (value) => String(value).replace(/\\\\/g, '\\\\\\\\').replace(/;/g, '\\\\;').replace(/,/g, '\\\\,').replace(/\\r?\\n/g, '\\\\n')\n"
    },
    {
      "file": "src/services/calendar.js",
      "find": "\nexport const downloadIcs = (e) => {\n    const url = URL.createObjectURL(new Blob([icsText(e)], { type: 'text/calendar;charset=utf-8' }))\n    const link = document.createElement('a')\n    link.href = url\n    link.download = 'booking.ics'\n    document.body.appendChild(link)\n    link.click()\n    link.remove()\n    setTimeout(() => URL.revokeObjectURL(url), 1000)\n}\n",
      "replace": "\nexport const downloadIcs = (e) => saveFile(new Blob([icsText(e)], { type: 'text/calendar;charset=utf-8' }), 'booking.ics')\n"
    },
    {
      "file": "src/services/links.js",
      "find": "const configured = (import.meta.env.VITE_PUBLIC_URL || '').trim().replace(/\\/+$/, '')\n\nexport const publicOrigin = () => configured || window.location.origin\n",
      "replace": "import { isNative, WEB_ORIGIN } from './native'\n\nconst configured = (import.meta.env.VITE_PUBLIC_URL || '').trim().replace(/\\/+$/, '')\n\n// Inside the apps the page origin is local, so links people share always use the website.\nexport const publicOrigin = () => configured || (isNative() ? WEB_ORIGIN : window.location.origin)\n"
    },
    {
      "file": "tests/harness/main.jsx",
      "find": "import ErrorsTab from '@src/pages/admin/tabs/ErrorsTab'\nimport { installErrorHandlers } from '@src/services/errors'",
      "replace": "import ErrorsTab from '@src/pages/admin/tabs/ErrorsTab'\nimport AppDownload from '@src/pages/app/AppDownload'\nimport { installErrorHandlers } from '@src/services/errors'"
    },
    {
      "file": "tests/harness/main.jsx",
      "find": "window.__locaReportInDev = true\nwindow.__QRCode = QRCode",
      "replace": "window.__locaReportInDev = true\n// ?native=1 behaves like the phone apps; ?release=none or ?release=1 fakes the Android download note.\nif (params.get('native') === '1') window.__locaNative = true\nif (params.has('release')) window.__locaRelease = params.get('release') === 'none' ? null : { version: '1.0.7', file: 'locappoint-1.0.7.apk', size: 6291456 }\nwindow.__QRCode = QRCode"
    },
    {
      "file": "tests/harness/main.jsx",
      "find": "        <Route path=\"/team/:token\" element={<TeamJoin />} />\n        <Route path=\"/admin-errors\" element={<div className=\"admin\"><ErrorsTab formatDate={fmtDate} formatTime={fmtTime} /></div>} />",
      "replace": "        <Route path=\"/team/:token\" element={<TeamJoin />} />\n        <Route path=\"/app\" element={<AppDownload />} />\n        <Route path=\"/admin-errors\" element={<div className=\"admin\"><ErrorsTab formatDate={fmtDate} formatTime={fmtTime} /></div>} />"
    },
    {
      "file": "tests/run.mjs",
      "find": "import hardening from './suites/hardening.mjs'\n\nconst here = path.dirname(fileURLToPath(import.meta.url))\nconst [target = 'quick', filter] = process.argv.slice(2)\nconst SUITES = { layout: [['layout', layout]], flows: [['shell', shell], ['business page', businessPage], ['services and hours', servicesHours], ['settings', settings], ['notifications', notifications], ['insights', insights], ['rebooking', rebook], ['reviews', reviews], ['business audit', audit], ['overview', overview], ['client home', clientHome], ['referrals', referrals], ['clients', clients], ['team', team], ['time', time], ['addons', addons], ['money', money], ['hardening', hardening]] }\nSUITES.emails = [['emails', emails]]",
      "replace": "import hardening from './suites/hardening.mjs'\nimport apps from './suites/apps.mjs'\n\nconst here = path.dirname(fileURLToPath(import.meta.url))\nconst [target = 'quick', filter] = process.argv.slice(2)\nconst SUITES = { layout: [['layout', layout]], flows: [['shell', shell], ['business page', businessPage], ['services and hours', servicesHours], ['settings', settings], ['notifications', notifications], ['insights', insights], ['rebooking', rebook], ['reviews', reviews], ['business audit', audit], ['overview', overview], ['client home', clientHome], ['referrals', referrals], ['clients', clients], ['team', team], ['time', time], ['addons', addons], ['money', money], ['hardening', hardening], ['apps', apps]] }\nSUITES.emails = [['emails', emails]]"
    }
  ],
  "retires": []
}

const here = path.dirname(fileURLToPath(import.meta.url))
const root = process.cwd()
const check = process.argv.includes('--check')
const problems = []
const plan = []

const abs = (rel) => path.join(root, ...rel.split('/'))
const source = (rel) => path.join(here, 'files', ...rel.split('/'))
const read = (p) => fs.readFileSync(p, 'utf8')
const eolOf = (text) => (text.includes('\r\n') ? '\r\n' : '\n')
const toEol = (text, eol) => text.replace(/\r\n/g, '\n').replace(/\n/g, eol)
const sha = (text) => crypto.createHash('sha256').update(text.replace(/\r\n/g, '\n')).digest('hex')
const count = (hay, needle) => (needle ? hay.split(needle).length - 1 : 0)

const pkg = JSON.parse(read(abs('package.json')))
if (pkg.name !== 'locappoint') {
    console.error('  [ABORT] This is not the locappoint repo.')
    process.exit(1)
}

for (const rel of SPEC.newFiles) {
    if (fs.existsSync(abs(rel))) problems.push(`${rel} already exists (patch already applied?)`)
    else if (!fs.existsSync(source(rel))) problems.push(`payload is missing ${rel}`)
    else plan.push(['NEW', rel])
}

for (const { file, sha: expected } of SPEC.replaceFiles) {
    if (!fs.existsSync(abs(file))) { problems.push(`${file} is missing`); continue }
    if (sha(read(abs(file))) !== expected) { problems.push(`${file} changed since this patch was built (or it is already applied)`); continue }
    plan.push(['REPLACE', file])
}

const srcFiles = () => {
    const out = []
    const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const full = path.join(dir, entry.name)
            if (entry.isDirectory()) { if (entry.name !== 'node_modules') walk(full) }
            else if (/\.(jsx?|css)$/.test(entry.name)) out.push(full)
        }
    }
    walk(abs('src'))
    return out
}

for (const prefix of SPEC.prefixes || []) {
    const owners = srcFiles().filter((full) => read(full).includes(prefix)).map((full) => path.relative(root, full))
    if (owners.length) problems.push(`class prefix ${prefix} is already used in ${owners.join(', ')}`)
}

const edits = new Map()
for (const p of SPEC.patches) {
    if (!fs.existsSync(abs(p.file))) { problems.push(`${p.file} is missing`); continue }
    if (!edits.has(p.file)) edits.set(p.file, read(abs(p.file)))
    const current = edits.get(p.file)
    const eol = eolOf(current)
    const find = toEol(p.find, eol)
    const hits = count(current, find)
    if (hits !== 1) { problems.push(`${p.file}: anchor matched ${hits} times, expected 1: ${JSON.stringify(p.find.slice(0, 60))}`); continue }
    edits.set(p.file, current.replace(find, () => toEol(p.replace, eol)))
}
for (const file of edits.keys()) plan.push(['EDIT', file])

for (const rel of SPEC.retires) {
    if (!fs.existsSync(abs(rel))) { problems.push(`${rel} is missing`); continue }
    const base = path.basename(rel)
    const stem = /\.(jsx?)$/.test(base) ? base.replace(/\.(jsx?)$/, '') : base
    const pattern = new RegExp(`[\\/'"]${stem.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\.jsx?)?['"]`)
    const planned = (full) => {
        const key = path.relative(root, full).split(path.sep).join('/')
        if (SPEC.replaceFiles.some((f) => f.file === key)) return read(source(key))
        return edits.has(key) ? edits.get(key) : read(full)
    }
    const users = srcFiles().filter((full) => full !== abs(rel) && pattern.test(planned(full))).map((full) => path.relative(root, full))
    if (users.length) problems.push(`${rel} is still imported by ${users.join(', ')}`)
    else plan.push(['RETIRE', rel])
}

if (problems.length) {
    console.error('  [ABORT] Nothing was written:')
    for (const p of problems) console.error(`    ${p}`)
    process.exit(1)
}

if (check) {
    for (const [kind, rel] of plan) console.log(`  [${kind}] ${rel}`)
    console.log('  Checks passed.')
    process.exit(0)
}

for (const [kind, rel] of plan) {
    const target = abs(rel)
    if (kind === 'NEW') {
        fs.mkdirSync(path.dirname(target), { recursive: true })
        fs.copyFileSync(source(rel), target)
    } else if (kind === 'REPLACE') {
        const eol = eolOf(read(target))
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, toEol(read(source(rel)), eol))
    } else if (kind === 'EDIT') {
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, edits.get(rel))
    } else if (kind === 'RETIRE') {
        fs.renameSync(target, target + '.mistake')
    }
    console.log(`  [${kind}] ${rel}`)
}
console.log('  Patch applied.')
