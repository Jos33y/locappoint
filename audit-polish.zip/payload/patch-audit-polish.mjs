import fs from 'fs'
import path from 'path'

const REPO = process.cwd()

const NEW_FILES = [
    { path: 'src/components/business/CommandPalette.jsx', content: `import { useEffect, useMemo, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { useNavigate } from 'react-router-dom'
import { Search, Settings } from 'lucide-react'
import { NAV_FOOT, NAV_ITEMS } from './nav'
import '../../styles/business/palette.css'

const PAGES = [...NAV_ITEMS, ...NAV_FOOT, { to: '/portal/settings', label: 'Settings', icon: Settings }]

const CommandPalette = ({ open, onClose, actions }) => {
    const navigate = useNavigate()
    const [query, setQuery] = useState('')
    const [active, setActive] = useState(0)
    const inputRef = useRef(null)
    const listRef = useRef(null)

    useEffect(() => {
        if (!open) return
        setQuery('')
        setActive(0)
    }, [open])

    const groups = useMemo(() => {
        const q = query.trim().toLowerCase()
        const match = (item) => !q || item.label.toLowerCase().includes(q) || item.keywords?.some((k) => k.includes(q))
        return [
            { label: 'Actions', items: actions.filter(match) },
            { label: 'Go to', items: PAGES.filter(match) },
        ].filter((g) => g.items.length)
    }, [query, actions])

    const flat = groups.flatMap((g) => g.items)

    useEffect(() => { setActive(0) }, [query])

    useEffect(() => {
        listRef.current?.querySelector('[aria-selected="true"]')?.scrollIntoView({ block: 'nearest' })
    }, [active])

    if (!open) return null

    const run = (item) => {
        onClose()
        if (item.run) item.run()
        else navigate(item.to)
    }

    const onKeyDown = (event) => {
        if (event.key === 'Escape') { event.preventDefault(); onClose() }
        if (event.key === 'ArrowDown') { event.preventDefault(); setActive((i) => Math.min(flat.length - 1, i + 1)) }
        if (event.key === 'ArrowUp') { event.preventDefault(); setActive((i) => Math.max(0, i - 1)) }
        if (event.key === 'Enter' && flat[active]) { event.preventDefault(); run(flat[active]) }
    }

    let index = -1
    return createPortal(
        <div className="lc-cmd" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose() }}>
            <div className="lc-cmd__panel" role="dialog" aria-modal="true" aria-label="Jump to a page or action" onKeyDown={onKeyDown}>
                <div className="lc-cmd__search">
                    <Search size={18} aria-hidden="true" />
                    <input
                        ref={inputRef}
                        autoFocus
                        className="lc-cmd__input"
                        value={query}
                        onChange={(event) => setQuery(event.target.value)}
                        placeholder="Jump to a page or action"
                        aria-label="Jump to a page or action"
                        role="combobox"
                        aria-expanded="true"
                        aria-controls="lc-cmd-list"
                        aria-activedescendant={flat[active] ? \`lc-cmd-\${active}\` : undefined}
                        autoComplete="off"
                        spellCheck="false"
                    />
                    <kbd className="lc-cmd__esc">Esc</kbd>
                </div>
                <div ref={listRef} id="lc-cmd-list" className="lc-cmd__list" role="listbox" aria-label="Results">
                    {flat.length === 0 && <p className="lc-cmd__empty">Nothing matches "{query}".</p>}
                    {groups.map((group) => (
                        <div key={group.label} role="group" aria-label={group.label}>
                            <p className="lc-cmd__group">{group.label}</p>
                            {group.items.map((item) => {
                                index += 1
                                const i = index
                                const Icon = item.icon
                                return (
                                    <div
                                        key={\`\${group.label}-\${item.label}\`}
                                        id={\`lc-cmd-\${i}\`}
                                        role="option"
                                        aria-selected={i === active}
                                        className={\`lc-cmd__item\${i === active ? ' is-active' : ''}\`}
                                        onMouseMove={() => setActive(i)}
                                        onClick={() => run(item)}
                                    >
                                        {Icon && <Icon size={17} aria-hidden="true" />}
                                        <span className="lc-cmd__label">{item.label}</span>
                                        {item.planned && <span className="biz-soon">Soon</span>}
                                    </div>
                                )
                            })}
                        </div>
                    ))}
                </div>
                <p className="lc-cmd__foot">Searching clients and bookings arrives with Clients.</p>
            </div>
        </div>,
        document.body
    )
}

export default CommandPalette
` },
    { path: 'src/styles/business/palette.css', content: `.lc-cmd {
    position: fixed;
    inset: 0;
    z-index: calc(var(--z-modal) + 10);
    display: flex;
    justify-content: center;
    align-items: flex-start;
    padding: 12vh var(--space-4) var(--space-4);
    background: rgba(5, 6, 8, 0.6);
    backdrop-filter: blur(6px);
    -webkit-backdrop-filter: blur(6px);
    animation: lc-fade var(--lc-base) var(--lc-ease);
}

.lc-cmd__panel {
    display: flex;
    flex-direction: column;
    width: min(580px, 100%);
    max-height: 70vh;
    overflow: hidden;
    border-radius: var(--lc-r-xl);
    background: var(--lc-overlay);
    box-shadow: var(--lc-shadow-overlay);
    animation: lc-arrive var(--lc-base) var(--lc-ease);
}

.lc-cmd__search {
    display: flex;
    align-items: center;
    gap: var(--space-3);
    padding: 0 var(--space-5);
    border-bottom: 1px solid var(--lc-line);
    color: var(--lc-ink-3);
}

.lc-cmd__input {
    flex: 1;
    min-width: 0;
    height: 56px;
    border: 0;
    background: none;
    color: var(--lc-ink-1);
    font-family: var(--lc-font-body);
    font-size: 16px;
    outline: none;
}

.lc-cmd__input::placeholder {
    color: var(--lc-ink-3);
}

.lc-cmd__esc {
    padding: 2px 6px;
    border-radius: 6px;
    background: var(--lc-raised);
    color: var(--lc-ink-3);
    font-family: var(--lc-font-mono);
    font-size: 11px;
}

.lc-cmd__list {
    flex: 1;
    overflow-y: auto;
    padding: var(--space-2);
}

.lc-cmd__group {
    margin: var(--space-2) var(--space-3) var(--space-1);
    color: var(--lc-ink-3);
    font-size: 12px;
    font-weight: var(--font-weight-medium);
}

.lc-cmd__item {
    display: flex;
    align-items: center;
    gap: var(--space-3);
    min-height: 42px;
    padding: 0 var(--space-3);
    border-radius: var(--lc-r-sm);
    color: var(--lc-ink-2);
    font-size: 14px;
    cursor: pointer;
}

.lc-cmd__item svg {
    flex: none;
    color: var(--lc-ink-3);
}

.lc-cmd__item.is-active {
    background: var(--lc-raised-hover);
    color: var(--lc-ink-1);
}

.lc-cmd__item.is-active svg {
    color: var(--azure);
}

.lc-cmd__label {
    flex: 1;
}

.lc-cmd__empty {
    margin: 0;
    padding: var(--space-6) var(--space-3);
    color: var(--lc-ink-3);
    text-align: center;
}

.lc-cmd__foot {
    margin: 0;
    padding: var(--space-3) var(--space-5);
    border-top: 1px solid var(--lc-line);
    color: var(--lc-ink-3);
    font-size: 12px;
}

@media (prefers-reduced-motion: reduce) {
    .lc-cmd,
    .lc-cmd__panel {
        animation: none;
    }
}
` },
]

const PATCHES = [
    {
        file: 'src/styles/foundation.css',
        edits: [
            { desc: "Panel tone for the sidebar, one step above the canvas", find: `    --lc-well: #050608;
`, replace: `    --lc-well: #050608;
    --lc-panel: #0E1118;
` },
        ],
    },
    {
        file: 'src/styles/business/shell.css',
        edits: [
            { desc: "Sidebar on its own panel tone", find: `        background: var(--lc-well);
        border-right: 1px solid var(--lc-line);`, replace: `        background: var(--lc-panel);
        border-right: 1px solid var(--lc-line);` },
            { desc: "Group labels at readable contrast", find: `.biz-navgroup__label {
    margin: 0 0 var(--space-1);
    padding: 0 var(--space-3);
    color: var(--lc-ink-4);`, replace: `.biz-navgroup__label {
    margin: 0 0 var(--space-1);
    padding: 0 var(--space-3);
    color: var(--lc-ink-3);` },
            { desc: "Clock, day note, inline text button, autofill", find: `.biz-startrow.active .biz-startrow__pct {
    color: var(--lc-ink-1);
}
`, replace: `.biz-startrow.active .biz-startrow__pct {
    color: var(--lc-ink-1);
}

.biz-clock {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    color: var(--lc-ink-2);
    font-size: 14px;
}

.biz-clock svg {
    color: var(--lc-ink-3);
}

.biz-clock__time {
    color: var(--lc-ink-1);
    font-weight: var(--font-weight-medium);
}

.biz-clock__zone {
    color: var(--lc-ink-3);
}

.biz-note {
    margin: 0;
    padding: 10px 12px;
    border-radius: var(--lc-r-md);
    background: var(--lc-info-tint);
    color: var(--lc-ink-1);
    font-size: 13px;
    line-height: var(--lc-lh-body);
}

.biz-textbtn--inline {
    display: inline;
    padding: 0;
}

.biz-input:-webkit-autofill,
.biz-input:-webkit-autofill:hover,
.biz-input:-webkit-autofill:focus {
    -webkit-text-fill-color: var(--lc-ink-1);
    -webkit-box-shadow: inset 0 0 0 1px var(--lc-line-strong), inset 0 0 0 100px var(--lc-well);
    caret-color: var(--lc-ink-1);
    transition: background-color 9999s;
}
` },
        ],
    },
    {
        file: 'src/styles/ui.css',
        edits: [
            { desc: "Card headers line up with the rows in compact cards", find: `.ui-card__foot {
`, replace: `.ui-card--pad-sm > .ui-card__head {
    padding: var(--space-2) var(--space-4) 0;
}

.ui-input:-webkit-autofill,
.ui-input:-webkit-autofill:hover,
.ui-input:-webkit-autofill:focus {
    -webkit-text-fill-color: var(--lc-ink-1);
    -webkit-box-shadow: inset 0 0 0 1px var(--lc-line-strong), inset 0 0 0 100px var(--lc-well);
    caret-color: var(--lc-ink-1);
    transition: background-color 9999s;
}

.ui-card__foot {
` },
        ],
    },
    {
        file: 'src/pages/business/GettingStarted.jsx',
        edits: [
            { desc: "Chevron only where the row links somewhere", find: `                        chevron={!step.done}
`, replace: `                        chevron={Boolean(step.to) && !step.done}
` },
        ],
    },
    {
        file: 'src/components/business/BusinessShell.jsx',
        edits: [
            { desc: "Clock icon", find: `import { ArrowLeftRight, Bell, ChevronRight, CirclePlay, LogOut, Menu, Plus, Search, Settings, Share2 } from 'lucide-react'`, replace: `import { ArrowLeftRight, Bell, ChevronRight, CirclePlay, Clock, LogOut, Menu, Plus, Search, Settings, Share2 } from 'lucide-react'` },
            { desc: "Title no longer repeated in the top bar", find: `import { NAV_FOOT, NAV_GROUPS, NAV_ITEMS, titleFor } from './nav'`, replace: `import { NAV_FOOT, NAV_GROUPS, NAV_ITEMS } from './nav'` },
            { desc: "Command bar", find: `import Tour from './Tour'
`, replace: `import Tour from './Tour'
import CommandPalette from './CommandPalette'
` },
            { desc: "Business clock and platform key hint", find: `const ambientTone =`, replace: `const IS_MAC = typeof navigator !== 'undefined' && /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent)

const TopClock = ({ timeZone = 'Europe/Lisbon' }) => {
    const [now, setNow] = useState(() => new Date())
    useEffect(() => {
        const timer = setInterval(() => setNow(new Date()), 30000)
        return () => clearInterval(timer)
    }, [])
    const time = new Intl.DateTimeFormat('en-GB', { timeZone, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(now)
    const day = new Intl.DateTimeFormat('en-GB', { timeZone, weekday: 'long' }).format(now)
    const city = timeZone.split('/').pop().replace(/_/g, ' ')
    return (
        <span className="biz-clock">
            <Clock size={15} aria-hidden="true" />
            <span>{day}</span>
            <span className="biz-clock__time biz-num">{time}</span>
            <span className="biz-clock__zone">{city} time</span>
        </span>
    )
}

const ambientTone =` },
            { desc: "Command bar state", find: `    const [tourOpen, setTourOpen] = useState(false)
`, replace: `    const [tourOpen, setTourOpen] = useState(false)
    const [cmdOpen, setCmdOpen] = useState(false)
` },
            { desc: "Command bar actions and shortcut", find: `    }, [workspace, user?.id, reloadWorkspace, bookingsVersion, refreshBookings, openNewBooking, openBooking, openTour, notify])
`, replace: `    }, [workspace, user?.id, reloadWorkspace, bookingsVersion, refreshBookings, openNewBooking, openBooking, openTour, notify])

    const paletteActions = useMemo(() => [
        { label: 'New booking', icon: Plus, run: () => openNewBooking(), keywords: ['add', 'book', 'walk-in', 'phone call'] },
        { label: 'Share your booking link', icon: Share2, run: () => setShareOpen(true), keywords: ['link', 'whatsapp', 'copy'] },
        { label: 'Replay the tour', icon: CirclePlay, run: openTour, keywords: ['help', 'guide', 'how'] },
        { label: 'Switch to Booking', icon: ArrowLeftRight, to: '/client', keywords: ['client', 'book as a client'] },
    ], [openNewBooking, openTour])

    useEffect(() => {
        const onKey = (event) => {
            if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
                event.preventDefault()
                setCmdOpen((open) => !open)
            }
        }
        document.addEventListener('keydown', onKey)
        return () => document.removeEventListener('keydown', onKey)
    }, [])
` },
            { desc: "No page title variable", find: `    const title = titleFor(location.pathname)
`, replace: `` },
            { desc: "Top bar shows the business's local time", find: `                    <span className="biz-topbar__title">{title}</span>
`, replace: `                    <span className="biz-topbar__title"><TopClock timeZone={value?.business?.timezone} /></span>
` },
            { desc: "Search opens the command bar", find: `                    <button type="button" className="biz-search" onClick={() => notify('Search arrives with Clients')}>
                        <Search size={16} aria-hidden="true" />
                        <span>Search clients and bookings</span>
                        <kbd>Ctrl K</kbd>`, replace: `                    <button type="button" className="biz-search" onClick={() => setCmdOpen(true)} aria-keyshortcuts={IS_MAC ? 'Meta+K' : 'Control+K'}>
                        <Search size={16} aria-hidden="true" />
                        <span>Search or jump to</span>
                        <kbd>{IS_MAC ? '⌘K' : 'Ctrl K'}</kbd>` },
            { desc: "Render the command bar", find: `                    <Tour open={tourOpen} onClose={closeTour} />
`, replace: `                    <Tour open={tourOpen} onClose={closeTour} />
                    <CommandPalette open={cmdOpen} onClose={() => setCmdOpen(false)} actions={paletteActions} />
` },
        ],
    },
    {
        file: 'src/components/business/NewBookingSheet.jsx',
        edits: [
            { desc: "useRef for the one-time jump", find: `import { useEffect, useMemo, useState } from 'react'`, replace: `import { useEffect, useMemo, useRef, useState } from 'react'` },
            { desc: "Day note state", find: `    const [error, setError] = useState('')
`, replace: `    const [error, setError] = useState('')
    const [dayNote, setDayNote] = useState('')
    const autoJumped = useRef(false)
` },
            { desc: "Find the next day with free time", find: `    const strip = useMemo(() => Array.from({ length: STRIP_DAYS }, (_, i) => addDays(today, i)), [today])
`, replace: `    const strip = useMemo(() => Array.from({ length: STRIP_DAYS }, (_, i) => addDays(today, i)), [today])

    const findNextFree = async (fromKey, serviceId, staffId) => {
        for (const dateKey of strip.filter((d) => d > fromKey)) {
            const rows = await getSlots({ businessId: business.id, serviceId, date: dateKey, staffId })
            if (rows.length) return dateKey
        }
        return null
    }
` },
            { desc: "Reset the note on open", find: `        setOtherTime(false)
        setError('')
    }, [open, prefill,`, replace: `        setOtherTime(false)
        setError('')
        setDayNote('')
        autoJumped.current = false
    }, [open, prefill,` },
            { desc: "Nothing free today: jump to the next free day, once", find: `                setSlots(rows)
                setForm((current) => {`, replace: `                setSlots(rows)
                if (!rows.length && !prefill?.date && !autoJumped.current && form.date === today) {
                    autoJumped.current = true
                    findNextFree(today, form.serviceId, form.staffId).then((next) => {
                        if (!next) return
                        setForm((current) => ({ ...current, date: next, time: '' }))
                        setDayNote(\`Nothing free today, so here is \${formatDay(next, { weekday: 'long', day: 'numeric', month: 'long' })}, your next free day.\`)
                    })
                }
                setForm((current) => {` },
            { desc: "Manual jump", find: `    const set = (field, value) => setForm((current) => ({ ...current, [field]: value }))
`, replace: `    const set = (field, value) => setForm((current) => ({ ...current, [field]: value }))

    const jumpToNextFree = async () => {
        const next = await findNextFree(form.date, form.serviceId, form.staffId)
        if (!next) {
            setDayNote('No free times in the next two weeks. Use a time outside opening hours.')
            return
        }
        setOtherDate(false)
        setForm((current) => ({ ...current, date: next, time: '' }))
        setDayNote(\`Next free day: \${formatDay(next, { weekday: 'long', day: 'numeric', month: 'long' })}.\`)
    }
` },
            { desc: "Picking a day clears the note", find: `                                    onClick={() => setForm((current) => ({ ...current, date: dateKey, time: '' }))}`, replace: `                                    onClick={() => { setDayNote(''); setForm((current) => ({ ...current, date: dateKey, time: '' })) }}` },
            { desc: "Show the note", find: `                        {otherDate ? 'Show the next two weeks' : 'Another date'}
                    </button>
`, replace: `                        {otherDate ? 'Show the next two weeks' : 'Another date'}
                    </button>
                    {dayNote && <p className="biz-note" role="status">{dayNote}</p>}
` },
            { desc: "Empty day offers the next free day", find: `                        <p className="biz-hint">No free times in opening hours on this day.</p>
`, replace: `                        <p className="biz-hint">
                            No free times in opening hours on this day.{' '}
                            <button type="button" className="biz-textbtn biz-textbtn--inline" onClick={jumpToNextFree}>Find the next free day</button>
                        </p>
` },
            { desc: "No autofill of your own phone on a client booking", find: `type="tel" inputMode="tel" value={form.phone} onChange={update('phone')} autoComplete="off"`, replace: `type="tel" inputMode="tel" value={form.phone} onChange={update('phone')} autoComplete="client-phone"` },
            { desc: "No autofill of your own email on a client booking", find: `type="email" value={form.email} onChange={update('email')} autoComplete="off"`, replace: `type="email" value={form.email} onChange={update('email')} autoComplete="client-email"` },
        ],
    },
]

const RETIRES = []

let failed = false

for (const nf of NEW_FILES) {
    const full = path.join(REPO, nf.path)
    if (fs.existsSync(full)) { console.error(`[FAIL] Already exists: ${nf.path}`); failed = true }
    if (!fs.existsSync(path.dirname(full))) { console.error(`[FAIL] Parent dir missing: ${nf.path}`); failed = true }
}

const fileChanges = new Map()
for (const group of PATCHES) {
    const fullPath = path.join(REPO, group.file)
    if (!fs.existsSync(fullPath)) { console.error(`[FAIL] Missing: ${group.file}`); failed = true; continue }
    let content = fs.readFileSync(fullPath, 'utf8')
    const original = content
    const crlf = (content.match(/\r\n/g) || []).length
    const lf = (content.match(/\n/g) || []).length - crlf
    const eol = crlf > lf ? '\r\n' : '\n'
    let ok = true
    for (const edit of group.edits) {
        // Anchors accept CRLF or LF; replacements follow the file's dominant ending.
        const pattern = edit.find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\n/g, '\\r?\\n')
        const matches = (content.match(new RegExp(pattern, 'g')) || []).length
        if (matches !== 1) {
            console.error(`[FAIL] ${group.file}: ${matches} matches for "${edit.desc}" (expected 1)`)
            failed = true; ok = false; break
        }
        const replace = edit.replace.replace(/\n/g, eol)
        content = content.replace(new RegExp(pattern), () => replace)
    }
    if (ok) fileChanges.set(fullPath, { original, modified: content, edits: group.edits })
}

const retirePaths = []
for (const rel of RETIRES) {
    const full = path.join(REPO, rel)
    if (!fs.existsSync(full)) { console.error(`[FAIL] Retire target missing: ${rel}`); failed = true; continue }
    if (fs.existsSync(`${full}.mistake`)) { console.error(`[FAIL] Already retired: ${rel}.mistake`); failed = true; continue }
    retirePaths.push({ full, rel })
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const nf of NEW_FILES) {
    fs.writeFileSync(path.join(REPO, nf.path), nf.content)
    console.log(`[NEW] ${nf.path}`)
}
for (const [fullPath, change] of fileChanges) {
    fs.writeFileSync(`${fullPath}.backup`, change.original)
    fs.writeFileSync(fullPath, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, fullPath)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}
for (const { full, rel } of retirePaths) {
    fs.renameSync(full, `${full}.mistake`)
    console.log(`[RETIRE] ${rel} -> .mistake`)
}

console.log('\n[DONE]')
