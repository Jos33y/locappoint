$ErrorActionPreference = 'Stop'

Write-Host ""
Write-Host "  Locappoint - Audit polish: sidebar tone, command bar, clock, next free day" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path 'package.json')) { Write-Host "  [ABORT] No package.json. Run from repo root." -ForegroundColor Red; exit 1 }
$pkg = Get-Content 'package.json' -Raw | ConvertFrom-Json
if ($pkg.name -ne 'locappoint') { Write-Host "  [ABORT] Wrong package: $($pkg.name)" -ForegroundColor Red; exit 1 }
try { $null = & node --version } catch { Write-Host "  [ABORT] Node.js not found." -ForegroundColor Red; exit 1 }

Write-Host "  Applies on top of sidebar-help (already installed)." -ForegroundColor Magenta
Write-Host ""
Write-Host "  What this does:" -ForegroundColor White
Write-Host ""
Write-Host "    [NEW]   CommandPalette.jsx + palette.css  (Ctrl K / Cmd K, jump to any page or action)" -ForegroundColor Green
Write-Host "    [EDIT]  foundation.css, shell.css  (sidebar panel tone, readable labels, clock, autofill)" -ForegroundColor Yellow
Write-Host "    [EDIT]  ui.css  (card headers aligned, autofill on-brand)" -ForegroundColor Yellow
Write-Host "    [EDIT]  BusinessShell.jsx  (business clock in the top bar, command bar)" -ForegroundColor Yellow
Write-Host "    [EDIT]  NewBookingSheet.jsx  (next free day, no autofill of your own details)" -ForegroundColor Yellow
Write-Host "    [EDIT]  GettingStarted.jsx  (no chevron on steps that go nowhere)" -ForegroundColor Yellow
Write-Host ""
Write-Host "  Backups saved as *.backup." -ForegroundColor Gray
Write-Host ""

$confirm = Read-Host "  Apply? (y/n)"
if ($confirm -ne 'y' -and $confirm -ne 'Y') { Write-Host "  [CANCELLED]" -ForegroundColor Yellow; exit 0 }
Write-Host ""

& node (Join-Path $PSScriptRoot 'patch-audit-polish.mjs')
if ($LASTEXITCODE -ne 0) { Write-Host "  [FAIL] Exit code $LASTEXITCODE" -ForegroundColor Red; exit $LASTEXITCODE }

$payloadDir = $PSScriptRoot
if ((Split-Path $payloadDir -Leaf) -eq 'payload') {
    Set-Location (Split-Path $payloadDir -Parent)
    Remove-Item $payloadDir -Recurse -Force
}

Write-Host ""
Write-Host "  Done. npm run build, then press Ctrl K on /portal." -ForegroundColor Green
Write-Host ""
