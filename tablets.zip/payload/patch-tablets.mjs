import fs from 'fs'
import path from 'path'
import crypto from 'crypto'
import { fileURLToPath } from 'url'

const REPO = process.cwd()
const HERE = path.dirname(fileURLToPath(import.meta.url))
const SPEC = {
 "new": [],
 "replace": [
  {
   "path": "src/styles/business/setup.css",
   "sha256": "6959416b99313cb641070f3f2f0130e878b6e6520e43379eedf07888f393888d"
  },
  {
   "path": "src/styles/business/editors.css",
   "sha256": "2c740a4c948cd1c5aa7b3e3e1c19b40b2eb02e18bd64bfa5ec2f2ed95fcc6c13"
  }
 ],
 "patches": [],
 "retires": [],
 "backupSuffix": ".backup-tablet"
}
const BACKUP = SPEC.backupSuffix

let failed = false
const fail = (msg) => { console.error(`[FAIL] ${msg}`); failed = true }
const sha = (buf) => crypto.createHash('sha256').update(buf).digest('hex')
const toCrlf = (text) => text.replace(/\r?\n/g, '\r\n')
const count = (haystack, needle) => (needle === '' ? 0 : haystack.split(needle).length - 1)

for (const rel of SPEC.new) {
    if (fs.existsSync(path.join(REPO, rel))) fail(`Already exists: ${rel}`)
    if (!fs.existsSync(path.join(HERE, 'files', rel))) fail(`Missing in payload: ${rel}`)
}

for (const item of SPEC.replace) {
    const full = path.join(REPO, item.path)
    if (!fs.existsSync(full)) { fail(`Missing: ${item.path}`); continue }
    const current = fs.readFileSync(full)
    if (sha(current) !== item.sha256) fail(`${item.path} differs from the version this patch expects (edited locally, or already replaced). Not overwriting.`)
    if (fs.existsSync(`${full}${BACKUP}`)) fail(`Backup already exists: ${item.path}${BACKUP}`)
}

const fileChanges = new Map()
for (const group of SPEC.patches) {
    const full = path.join(REPO, group.file)
    if (!fs.existsSync(full)) { fail(`Missing: ${group.file}`); continue }
    if (fs.existsSync(`${full}${BACKUP}`)) fail(`Backup already exists: ${group.file}${BACKUP}`)
    const original = fs.readFileSync(full, 'utf8')
    let content = original
    let ok = true
    for (const edit of group.edits) {
        const lf = count(content, edit.find)
        const crlf = count(content, toCrlf(edit.find))
        let find = edit.find
        let replace = edit.replace
        if (lf !== 1 && crlf === 1) { find = toCrlf(edit.find); replace = toCrlf(edit.replace) }
        else if (lf !== 1) { fail(`${group.file}: ${lf || crlf} matches for "${edit.desc}" (expected 1)`); ok = false; break }
        content = content.replace(find, () => replace)
    }
    if (ok) fileChanges.set(full, { original, modified: content, edits: group.edits })
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const rel of SPEC.new) {
    fs.copyFileSync(path.join(HERE, 'files', rel), path.join(REPO, rel))
    console.log(`[NEW] ${rel}`)
}
for (const item of SPEC.replace) {
    const full = path.join(REPO, item.path)
    fs.copyFileSync(full, `${full}${BACKUP}`)
    fs.copyFileSync(path.join(HERE, 'files', item.path), full)
    console.log(`[REPLACE] ${item.path}`)
}
for (const [full, change] of fileChanges) {
    fs.writeFileSync(`${full}${BACKUP}`, change.original)
    fs.writeFileSync(full, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, full)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}

console.log('\n[DONE]')
