$ErrorActionPreference = 'Stop'

Write-Host ""
Write-Host "  Locappoint - Business types and picker" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path 'package.json')) {
    Write-Host "  [ABORT] No package.json. Run from repo root." -ForegroundColor Red
    exit 1
}
$pkg = Get-Content 'package.json' -Raw | ConvertFrom-Json
if ($pkg.name -ne 'locappoint') {
    Write-Host "  [ABORT] Wrong package: $($pkg.name)" -ForegroundColor Red
    exit 1
}
try { $null = & node --version } catch {
    Write-Host "  [ABORT] Node.js not found." -ForegroundColor Red
    exit 1
}

Write-Host "  What this does:" -ForegroundColor White
Write-Host ""
Write-Host "    [NEW]     src/components/ui/Picker.jsx" -ForegroundColor Green
Write-Host "    [NEW]     supabase/migrations/onboarding-c.sql" -ForegroundColor Green
Write-Host "    [NEW]     supabase/migrations/onboarding-c-verify.sql" -ForegroundColor Green
Write-Host "    [REPLACE] src/constants/categories.js" -ForegroundColor Cyan
Write-Host "    [REPLACE] src/services/setup.js" -ForegroundColor Cyan
Write-Host "    [REPLACE] src/styles/ui-kit.css" -ForegroundColor Cyan
Write-Host "    [REPLACE] src/pages/business/Setup.jsx" -ForegroundColor Cyan
Write-Host "    [REPLACE] src/components/business/PublicPageView.jsx" -ForegroundColor Cyan
Write-Host "    [REPLACE] src/styles/public-page.css" -ForegroundColor Cyan
Write-Host "    [REPLACE] src/constants/sampleBusiness.js" -ForegroundColor Cyan
Write-Host "    [REPLACE] src/pages/app/PublicBusinessPage.jsx" -ForegroundColor Cyan
Write-Host "    [EDIT]    src/components/ui/index.js  (1 edit)" -ForegroundColor Yellow
Write-Host ""
Write-Host "  Run onboarding-c.sql in Supabase BEFORE this patch." -ForegroundColor Yellow
Write-Host "  Backups saved as *.backup-types." -ForegroundColor Gray
Write-Host ""

$confirm = Read-Host "  Apply? (y/n)"
if ($confirm -ne 'y' -and $confirm -ne 'Y') { Write-Host "  [CANCELLED]" -ForegroundColor Yellow; exit 0 }
Write-Host ""

& node (Join-Path $PSScriptRoot 'patch-business-types.mjs')
if ($LASTEXITCODE -ne 0) { Write-Host "  [FAIL] Exit code $LASTEXITCODE" -ForegroundColor Red; exit $LASTEXITCODE }

Write-Host ""
$payloadDir = $PSScriptRoot
if ((Split-Path $payloadDir -Leaf) -eq 'payload') {
    Set-Location (Split-Path $payloadDir -Parent)
    Remove-Item $payloadDir -Recurse -Force
}

Write-Host ""
Write-Host "  Done. npm run build, redeploy." -ForegroundColor Green
Write-Host ""
