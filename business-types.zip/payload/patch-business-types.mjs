import fs from 'fs'
import path from 'path'
import crypto from 'crypto'
import { fileURLToPath } from 'url'

const REPO = process.cwd()
const HERE = path.dirname(fileURLToPath(import.meta.url))
const SPEC = {
 "new": [
  "src/components/ui/Picker.jsx",
  "supabase/migrations/onboarding-c.sql",
  "supabase/migrations/onboarding-c-verify.sql"
 ],
 "replace": [
  {
   "path": "src/constants/categories.js",
   "sha256": "41d826865291861305323ed3e4af8402733acca63532f6c339baa335530ecb6d"
  },
  {
   "path": "src/services/setup.js",
   "sha256": "e58a47bdb6595fae89312e7ed9bd8b0381ddf4c552ff085f8aeaff1aa9a9c900"
  },
  {
   "path": "src/styles/ui-kit.css",
   "sha256": "51c3a4a1eceecdb57b5e5288eed98bf1c7bc6fef7435474224006f07ca286fa6"
  },
  {
   "path": "src/pages/business/Setup.jsx",
   "sha256": "9882f1090288d91d8ce26cfb1237f74a74ca04de18fde372e895fb29e1860069"
  },
  {
   "path": "src/components/business/PublicPageView.jsx",
   "sha256": "bb1fe82de62a57e8bf728c238c6bba6115681ce0b658e34bee2b488089d244bf"
  },
  {
   "path": "src/styles/public-page.css",
   "sha256": "78364f0745bed3ade38d4d48cfbfb2c402e137ef33c0697113d2ec169ac39b19"
  },
  {
   "path": "src/constants/sampleBusiness.js",
   "sha256": "fb2c9bfa727d1c6718b08141ef89b971344999eeba7f7db40725ddd3c030f0a1"
  },
  {
   "path": "src/pages/app/PublicBusinessPage.jsx",
   "sha256": "f7f748a3f20f85348356492cdbd0decf9054c4b429d54f8e8aee628a04b00402"
  }
 ],
 "patches": [
  {
   "file": "src/components/ui/index.js",
   "edits": [
    {
     "desc": "Export the Picker primitive",
     "find": "export { AffixInput } from './AffixInput'",
     "replace": "export { AffixInput } from './AffixInput'\nexport { Picker } from './Picker'"
    }
   ]
  }
 ],
 "retires": [],
 "backupSuffix": ".backup-types"
}
const BACKUP = SPEC.backupSuffix

let failed = false
const fail = (msg) => { console.error(`[FAIL] ${msg}`); failed = true }
const sha = (buf) => crypto.createHash('sha256').update(buf).digest('hex')
const toCrlf = (text) => text.replace(/\r?\n/g, '\r\n')
const count = (haystack, needle) => (needle === '' ? 0 : haystack.split(needle).length - 1)

for (const rel of SPEC.new) {
    if (fs.existsSync(path.join(REPO, rel))) fail(`Already exists: ${rel}`)
    if (!fs.existsSync(path.join(HERE, 'files', rel))) fail(`Missing in payload: ${rel}`)
}

for (const item of SPEC.replace) {
    const full = path.join(REPO, item.path)
    if (!fs.existsSync(full)) { fail(`Missing: ${item.path}`); continue }
    const current = fs.readFileSync(full)
    if (sha(current) !== item.sha256) fail(`${item.path} differs from the version this patch expects (edited locally, or already replaced). Not overwriting.`)
    if (fs.existsSync(`${full}${BACKUP}`)) fail(`Backup already exists: ${item.path}${BACKUP}`)
}

const fileChanges = new Map()
for (const group of SPEC.patches) {
    const full = path.join(REPO, group.file)
    if (!fs.existsSync(full)) { fail(`Missing: ${group.file}`); continue }
    if (fs.existsSync(`${full}${BACKUP}`)) fail(`Backup already exists: ${group.file}${BACKUP}`)
    const original = fs.readFileSync(full, 'utf8')
    let content = original
    let ok = true
    for (const edit of group.edits) {
        const lf = count(content, edit.find)
        const crlf = count(content, toCrlf(edit.find))
        let find = edit.find
        let replace = edit.replace
        if (lf !== 1 && crlf === 1) { find = toCrlf(edit.find); replace = toCrlf(edit.replace) }
        else if (lf !== 1) { fail(`${group.file}: ${lf || crlf} matches for "${edit.desc}" (expected 1)`); ok = false; break }
        content = content.replace(find, () => replace)
    }
    if (ok) fileChanges.set(full, { original, modified: content, edits: group.edits })
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const rel of SPEC.new) {
    fs.mkdirSync(path.dirname(path.join(REPO, rel)), { recursive: true })
    fs.copyFileSync(path.join(HERE, 'files', rel), path.join(REPO, rel))
    console.log(`[NEW] ${rel}`)
}
for (const item of SPEC.replace) {
    const full = path.join(REPO, item.path)
    fs.copyFileSync(full, `${full}${BACKUP}`)
    fs.copyFileSync(path.join(HERE, 'files', item.path), full)
    console.log(`[REPLACE] ${item.path}`)
}
for (const [full, change] of fileChanges) {
    fs.writeFileSync(`${full}${BACKUP}`, change.original)
    fs.writeFileSync(full, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, full)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}

console.log('\n[DONE]')
