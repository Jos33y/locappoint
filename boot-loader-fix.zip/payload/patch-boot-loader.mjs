import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const REPO = process.cwd()
const HERE = path.dirname(fileURLToPath(import.meta.url))
const SPEC = {
 "new": [],
 "retires": [],
 "patches": [
  {
   "file": "index.html",
   "edits": [
    {
     "desc": "Boot ring ignores the global svg max-width",
     "find": "    .loca-boot__ring {\n      position: absolute;\n      inset: -18px;\n      width: 92px;\n      height: 92px;\n",
     "replace": "    .loca-boot__ring {\n      position: absolute;\n      inset: -18px;\n      width: 92px;\n      height: 92px;\n      /* reset.css caps svg at 100% of its box; this ring is wider on purpose. */\n      max-width: none;\n"
    }
   ]
  }
 ]
}

let failed = false
const fail = (msg) => { console.error(`[FAIL] ${msg}`); failed = true }

for (const rel of SPEC.new) {
    const full = path.join(REPO, rel)
    const source = path.join(HERE, 'files', rel)
    if (fs.existsSync(full)) fail(`Already exists: ${rel}`)
    if (!fs.existsSync(source)) fail(`Missing in payload: ${rel}`)
}

const toCrlf = (text) => text.replace(/\r?\n/g, '\r\n')
const count = (haystack, needle) => (needle === '' ? 0 : haystack.split(needle).length - 1)

const fileChanges = new Map()
for (const group of SPEC.patches) {
    const full = path.join(REPO, group.file)
    if (!fs.existsSync(full)) { fail(`Missing: ${group.file}`); continue }
    const original = fs.readFileSync(full, 'utf8')
    let content = original
    let ok = true
    for (const edit of group.edits) {
        const lf = count(content, edit.find)
        const crlf = count(content, toCrlf(edit.find))
        let find = edit.find
        let replace = edit.replace
        if (lf !== 1 && crlf === 1) { find = toCrlf(edit.find); replace = toCrlf(edit.replace) }
        else if (lf !== 1) {
            fail(`${group.file}: ${lf || crlf} matches for "${edit.desc}" (expected 1)`)
            ok = false
            break
        }
        content = content.replace(find, () => replace)
    }
    if (ok) fileChanges.set(full, { original, modified: content, edits: group.edits })
}

const retirePaths = []
for (const rel of SPEC.retires) {
    const full = path.join(REPO, rel)
    if (!fs.existsSync(full)) { fail(`Retire target missing: ${rel}`); continue }
    if (fs.existsSync(`${full}.mistake`)) { fail(`Already retired: ${rel}.mistake`); continue }
    retirePaths.push({ full, rel })
}

for (const full of fileChanges.keys()) {
    if (fs.existsSync(`${full}.backup`)) fail(`Backup already exists: ${path.relative(REPO, full)}.backup`)
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const rel of SPEC.new) {
    const full = path.join(REPO, rel)
    fs.mkdirSync(path.dirname(full), { recursive: true })
    fs.copyFileSync(path.join(HERE, 'files', rel), full)
    console.log(`[NEW] ${rel}`)
}
for (const [full, change] of fileChanges) {
    fs.writeFileSync(`${full}.backup`, change.original)
    fs.writeFileSync(full, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, full)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}
for (const { full, rel } of retirePaths) {
    fs.renameSync(full, `${full}.mistake`)
    console.log(`[RETIRE] ${rel} -> .mistake`)
}

console.log('\n[DONE]')
