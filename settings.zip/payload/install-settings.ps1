$ErrorActionPreference = 'Stop'

Write-Host ""
Write-Host "  Locappoint - Settings (patch 23, follows faster-tests)" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path 'package.json')) { Write-Host "  [ABORT] No package.json. Run from repo root." -ForegroundColor Red; exit 1 }
$pkg = Get-Content 'package.json' -Raw | ConvertFrom-Json
if ($pkg.name -ne 'locappoint') { Write-Host "  [ABORT] Wrong package: $($pkg.name)" -ForegroundColor Red; exit 1 }
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { Write-Host "  [ABORT] Node is not on PATH." -ForegroundColor Red; exit 1 }

$patch = Join-Path 'payload' 'patch-settings.mjs'
if (-not (Test-Path $patch)) { Write-Host "  [ABORT] $patch not found. Expand the zip in the repo root first." -ForegroundColor Red; exit 1 }

Write-Host "  Checking every file before anything is written:" -ForegroundColor Gray
& node $patch --list
if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "  [ABORT] Checks failed. Nothing was written." -ForegroundColor Red
    exit 1
}

Write-Host ""
$go = Read-Host "  Apply these changes? (y/n)"
if ($go -ne 'y' -and $go -ne 'Y') { Write-Host "  [CANCELLED] Nothing was written." -ForegroundColor Yellow; exit 0 }

Write-Host ""
& node $patch
if ($LASTEXITCODE -ne 0) { Write-Host "  [FAIL] Patch refused. Nothing was written." -ForegroundColor Red; exit 1 }

Remove-Item 'payload' -Recurse -Force
Write-Host ""
Write-Host "  Done. Next:" -ForegroundColor Green
Write-Host "    npm run build" -ForegroundColor Green
Write-Host "    npm run test:flows" -ForegroundColor Green
Write-Host ""
