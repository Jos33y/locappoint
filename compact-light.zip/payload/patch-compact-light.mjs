import fs from 'fs'
import path from 'path'

const REPO = process.cwd()

const NEW_FILES = []

const PATCHES = [
    {
        file: 'src/components/business/Brand.jsx',
        edits: [
            { desc: "AppLoader, identical to the boot screen", find: `        <Mark size={32} />
    </div>
)
`, replace: `        <Mark size={32} />
    </div>
)

export const AppLoader = () => (
    <div className="lc-apploader" role="status" aria-label="Loading">
        <div className="lc-apploader__stage">
            <svg className="lc-apploader__ring" viewBox="0 0 92 92" aria-hidden="true">
                <defs>
                    <linearGradient id="lc-app-gradient" x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0%" stopColor="var(--azure)" />
                        <stop offset="100%" stopColor="var(--signal)" />
                    </linearGradient>
                </defs>
                <circle className="lc-apploader__track" cx="46" cy="46" r="38" />
                <circle className="lc-apploader__arc" cx="46" cy="46" r="38" />
            </svg>
            <Mark size={56} />
        </div>
    </div>
)
` },
        ],
    },
    {
        file: 'src/styles/foundation.css',
        edits: [
            { desc: "App loader styles match the boot screen", find: `@keyframes lc-spin {
    to { transform: rotate(360deg); }
}
`, replace: `@keyframes lc-spin {
    to { transform: rotate(360deg); }
}

.lc-apploader {
    position: fixed;
    inset: 0;
    z-index: 9998;
    display: grid;
    place-items: center;
    background: var(--lc-canvas);
}

.lc-apploader__stage {
    position: relative;
    width: 56px;
    height: 56px;
}

.lc-apploader__stage .lc-mark {
    width: 56px;
    height: 56px;
}

.lc-apploader__ring {
    position: absolute;
    inset: -18px;
    width: 92px;
    height: 92px;
    animation: lc-spin 1.6s linear infinite;
}

.lc-apploader__track {
    fill: none;
    stroke: rgba(244, 246, 251, 0.1);
    stroke-width: 2.5;
}

.lc-apploader__arc {
    fill: none;
    stroke: url(#lc-app-gradient);
    stroke-width: 2.5;
    stroke-linecap: round;
    stroke-dasharray: 70 170;
}
` },
            { desc: "Reduced motion for the app loader", find: `    .lc-skel,
    .lc-loader__ring {
        animation: none;
    }`, replace: `    .lc-skel,
    .lc-loader__ring,
    .lc-apploader__ring {
        animation: none;
    }` },
        ],
    },
    {
        file: 'src/components/common/ProtectedRoute.jsx',
        edits: [
            { desc: "Import the app loader", find: `import { useAuth } from '../../hooks/useAuth'
`, replace: `import { useAuth } from '../../hooks/useAuth'
import { AppLoader } from '../business/Brand'
` },
            { desc: "Same loader as the boot screen", find: `  if (loading || profileStatus === 'loading') {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Loading...</p>
      </div>
    )
  }`, replace: `  if (loading || profileStatus === 'loading') return <AppLoader />` },
        ],
    },
    {
        file: 'src/components/common/HomeRedirect.jsx',
        edits: [
            { desc: "Import the app loader", find: `import { useAuth } from '../../hooks/useAuth'
`, replace: `import { useAuth } from '../../hooks/useAuth'
import { AppLoader } from '../business/Brand'
` },
            { desc: "Same loader as the boot screen", find: `    if (loading || profileStatus === 'loading') {
        return (
            <div className="loading-container">
                <div className="spinner"></div>
                <p>Loading...</p>
            </div>
        )
    }`, replace: `    if (loading || profileStatus === 'loading') return <AppLoader />` },
        ],
    },
    {
        file: 'src/components/business/nav.js',
        edits: [
            { desc: "Bot icon for Loca AI", find: `import { Bell, CalendarDays, ChartColumn, Clock, MessagesSquare, Scissors, Store, Sun, Users, UsersRound } from 'lucide-react'`, replace: `import { Bell, Bot, CalendarDays, ChartColumn, Clock, Scissors, Store, Sun, Users, UsersRound } from 'lucide-react'` },
            { desc: "Assistant is Loca AI", find: `{ to: '/portal/assistant', label: 'Assistant', icon: MessagesSquare, tab: true, planned: 'assistant' },`, replace: `{ to: '/portal/assistant', label: 'Loca AI', icon: Bot, tab: true, planned: 'assistant' },` },
            { desc: "Planned page title", find: `        title: 'Assistant',`, replace: `        title: 'Loca AI',` },
        ],
    },
    {
        file: 'src/components/business/BusinessShell.jsx',
        edits: [
            { desc: "Ambient tone from the business's local hour", find: `const BusinessShell = () => {
`, replace: `const ambientTone = (timeZone = 'Europe/Lisbon') => {
    const hour = Number(new Intl.DateTimeFormat('en-GB', { timeZone, hour: '2-digit', hourCycle: 'h23' }).format(new Date()))
    if (hour >= 5 && hour < 11) return 'morning'
    if (hour >= 11 && hour < 16) return 'day'
    if (hour >= 16 && hour < 21) return 'evening'
    return 'night'
}

const BusinessShell = () => {
` },
            { desc: "Light that follows the time of day", find: `            <div className="biz-main">
`, replace: `            <div className={\`biz-main biz-main--\${ambientTone(value?.business?.timezone)}\`}>
                <div className="biz-ambient" aria-hidden="true" />
` },
        ],
    },
    {
        file: 'src/pages/business/Today.jsx',
        edits: [
            { desc: "No stray timeline when closed and empty (open)", find: `                            <Agenda
                                dateKey={now.dateKey}`, replace: `                            {!(closedNow && counted.length === 0) && (
                            <Agenda
                                dateKey={now.dateKey}` },
            { desc: "No stray timeline when closed and empty (close)", find: `                                onConfirm={confirm}
                            />
`, replace: `                                onConfirm={confirm}
                            />
                            )}
` },
        ],
    },
    {
        file: 'src/styles/business/shell.css',
        edits: [
            { desc: "Ambient light and compact desktop density", find: `@media (prefers-reduced-motion: reduce) {
    .biz-page,
    .biz-sheet,`, replace: `.biz-main {
    position: relative;
}

.biz-ambient {
    position: fixed;
    top: 0;
    right: 0;
    z-index: 0;
    width: min(1100px, 100vw);
    height: 440px;
    pointer-events: none;
    background: radial-gradient(55% 65% at 78% -8%, var(--lc-ambient), transparent 72%);
    transition: background 2s var(--lc-ease);
}

.biz-main--morning { --lc-ambient: rgba(45, 127, 240, 0.24); }
.biz-main--day { --lc-ambient: rgba(107, 165, 245, 0.17); }
.biz-main--evening { --lc-ambient: rgba(232, 154, 62, 0.21); }
.biz-main--night { --lc-ambient: rgba(45, 76, 170, 0.22); }

.biz-content {
    position: relative;
    z-index: 1;
}

@media (min-width: 1024px) {
    .biz-shell {
        grid-template-columns: 240px 1fr;
    }

    .biz-sidebar {
        width: 240px;
        gap: 14px;
        padding: 12px;
    }

    .biz-brand .lc-mark {
        width: 24px;
        height: 24px;
    }

    .biz-brand .lc-wordmark {
        font-size: 15px;
    }

    .biz-bizcard {
        gap: 10px;
        padding: 8px;
        border-radius: var(--lc-r-md);
    }

    .biz-bizcard .biz-avatar--business {
        width: 32px;
        height: 32px;
        border-radius: 9px;
        font-size: 12px;
    }

    .biz-bizcard__text strong { font-size: 13px; }
    .biz-bizcard__text small { font-size: 11px; }

    .biz-navgroup + .biz-navgroup { margin-top: 12px; }

    .biz-navgroup__label {
        margin-bottom: 2px;
        padding: 0 10px;
        font-size: 11px;
    }

    .biz-navlink {
        gap: 10px;
        min-height: 32px;
        padding: 0 10px;
        border-radius: 7px;
        font-size: 13px;
    }

    .biz-navlink svg {
        width: 16px;
        height: 16px;
    }

    .biz-soon {
        padding: 1px 6px;
        font-size: 10px;
    }

    .biz-sidebar__foot .biz-strength {
        padding: 8px 10px;
        gap: 10px;
    }

    .biz-strength__text strong { font-size: 12.5px; }
    .biz-strength__text small { font-size: 11px; }

    .biz-account__text strong { font-size: 13px; }
    .biz-account__text small { font-size: 11px; }

    .biz-topbar {
        height: 52px;
        padding: 0 28px;
    }

    .biz-topbar__title { font-size: 14px; }

    .biz-search {
        width: 280px;
        height: 34px;
        font-size: 13px;
    }

    .biz-search span {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .biz-topbar .biz-iconbtn {
        width: 34px;
        height: 34px;
    }

    .biz-topbar .biz-topbar__new {
        min-height: 34px;
        padding: 0 14px;
        font-size: 13px;
    }

    .biz-content { padding: 28px 32px 48px; }

    .biz-page { gap: 20px; }

    .biz-page__title { font-size: 26px; }
}

@media (prefers-reduced-motion: reduce) {
    .biz-ambient {
        transition: none;
    }
}

@media (prefers-reduced-motion: reduce) {
    .biz-page,
    .biz-sheet,` },
        ],
    },
    {
        file: 'src/styles/business/day.css',
        edits: [
            { desc: "Compact desktop density", find: `.biz-agenda-skel {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
}
`, replace: `.biz-agenda-skel {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
}

@media (min-width: 1024px) {
    .biz-dayhead__date { font-size: 32px; }
    .biz-dayhead__weekday { font-size: 13px; }
    .biz-stats dt { font-size: 11px; }
    .biz-stats dd { font-size: 18px; }
    .biz-stats div { padding: 8px 0; }
    .biz-agenda__row { grid-template-columns: 52px 1fr; gap: 10px; padding: 3px 0; }
    .biz-agenda__time { padding-top: 10px; font-size: 14px; }
    .biz-agenda__open { padding: 10px 14px; }
    .biz-agenda__who { font-size: 15px; }
    .biz-agenda__what { font-size: 13px; }
    .biz-agenda__confirm { min-height: 32px; padding: 0 12px; font-size: 13px; }
    .biz-agenda__gap { min-height: 40px; }
    .biz-agenda__book { min-height: 30px; }
    .biz-panel { padding: 16px; }
    .biz-closed { padding: 16px; }
    .biz-share__slug { font-size: 16px; }
}
` },
        ],
    },
]

const RETIRES = []

let failed = false

for (const nf of NEW_FILES) {
    const full = path.join(REPO, nf.path)
    if (fs.existsSync(full)) { console.error(`[FAIL] Already exists: ${nf.path}`); failed = true }
    if (!fs.existsSync(path.dirname(full))) { console.error(`[FAIL] Parent dir missing: ${nf.path}`); failed = true }
}

const fileChanges = new Map()
for (const group of PATCHES) {
    const fullPath = path.join(REPO, group.file)
    if (!fs.existsSync(fullPath)) { console.error(`[FAIL] Missing: ${group.file}`); failed = true; continue }
    let content = fs.readFileSync(fullPath, 'utf8')
    const original = content
    const crlf = (content.match(/\r\n/g) || []).length
    const lf = (content.match(/\n/g) || []).length - crlf
    const eol = crlf > lf ? '\r\n' : '\n'
    let ok = true
    for (const edit of group.edits) {
        // Anchors accept CRLF or LF; replacements follow the file's dominant ending.
        const pattern = edit.find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\n/g, '\\r?\\n')
        const matches = (content.match(new RegExp(pattern, 'g')) || []).length
        if (matches !== 1) {
            console.error(`[FAIL] ${group.file}: ${matches} matches for "${edit.desc}" (expected 1)`)
            failed = true; ok = false; break
        }
        const replace = edit.replace.replace(/\n/g, eol)
        content = content.replace(new RegExp(pattern), () => replace)
    }
    if (ok) fileChanges.set(fullPath, { original, modified: content, edits: group.edits })
}

const retirePaths = []
for (const rel of RETIRES) {
    const full = path.join(REPO, rel)
    if (!fs.existsSync(full)) { console.error(`[FAIL] Retire target missing: ${rel}`); failed = true; continue }
    if (fs.existsSync(`${full}.mistake`)) { console.error(`[FAIL] Already retired: ${rel}.mistake`); failed = true; continue }
    retirePaths.push({ full, rel })
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const nf of NEW_FILES) {
    fs.writeFileSync(path.join(REPO, nf.path), nf.content)
    console.log(`[NEW] ${nf.path}`)
}
for (const [fullPath, change] of fileChanges) {
    fs.writeFileSync(`${fullPath}.backup`, change.original)
    fs.writeFileSync(fullPath, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, fullPath)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}
for (const { full, rel } of retirePaths) {
    fs.renameSync(full, `${full}.mistake`)
    console.log(`[RETIRE] ${rel} -> .mistake`)
}

console.log('\n[DONE]')
