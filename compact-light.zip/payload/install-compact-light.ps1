$ErrorActionPreference = 'Stop'

Write-Host ""
Write-Host "  Locappoint - One loader, compact desktop, light that follows the day, Loca AI" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path 'package.json')) { Write-Host "  [ABORT] No package.json. Run from repo root." -ForegroundColor Red; exit 1 }
$pkg = Get-Content 'package.json' -Raw | ConvertFrom-Json
if ($pkg.name -ne 'locappoint') { Write-Host "  [ABORT] Wrong package: $($pkg.name)" -ForegroundColor Red; exit 1 }
try { $null = & node --version } catch { Write-Host "  [ABORT] Node.js not found." -ForegroundColor Red; exit 1 }

Write-Host "  Applies on top of the foundation patch (already installed)." -ForegroundColor Magenta
Write-Host ""
Write-Host "  What this does:" -ForegroundColor White
Write-Host ""
Write-Host "    [EDIT]  Brand.jsx, foundation.css  (AppLoader, identical to the boot screen)" -ForegroundColor Yellow
Write-Host "    [EDIT]  ProtectedRoute.jsx, HomeRedirect.jsx  (use the one loader)" -ForegroundColor Yellow
Write-Host "    [EDIT]  BusinessShell.jsx, shell.css  (ambient light by time of day, compact desktop)" -ForegroundColor Yellow
Write-Host "    [EDIT]  day.css  (compact desktop)" -ForegroundColor Yellow
Write-Host "    [EDIT]  nav.js  (Assistant becomes Loca AI)" -ForegroundColor Yellow
Write-Host "    [EDIT]  Today.jsx  (no stray timeline when closed and empty)" -ForegroundColor Yellow
Write-Host ""
Write-Host "  Backups saved as *.backup." -ForegroundColor Gray
Write-Host ""

$confirm = Read-Host "  Apply? (y/n)"
if ($confirm -ne 'y' -and $confirm -ne 'Y') { Write-Host "  [CANCELLED]" -ForegroundColor Yellow; exit 0 }
Write-Host ""

& node (Join-Path $PSScriptRoot 'patch-compact-light.mjs')
if ($LASTEXITCODE -ne 0) { Write-Host "  [FAIL] Exit code $LASTEXITCODE" -ForegroundColor Red; exit $LASTEXITCODE }

$payloadDir = $PSScriptRoot
if ((Split-Path $payloadDir -Leaf) -eq 'payload') {
    Set-Location (Split-Path $payloadDir -Parent)
    Remove-Item $payloadDir -Recurse -Force
}

Write-Host ""
Write-Host "  Done. npm run build, then reload /portal." -ForegroundColor Green
Write-Host ""
