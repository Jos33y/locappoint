$ErrorActionPreference = 'Stop'

Write-Host ""
Write-Host "  Locappoint - Batch 4a-2 redesign: agenda, new booking sheet, desktop layout" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path 'package.json')) { Write-Host "  [ABORT] No package.json. Run from repo root." -ForegroundColor Red; exit 1 }
$pkg = Get-Content 'package.json' -Raw | ConvertFrom-Json
if ($pkg.name -ne 'locappoint') { Write-Host "  [ABORT] Wrong package: $($pkg.name)" -ForegroundColor Red; exit 1 }
try { $null = & node --version } catch { Write-Host "  [ABORT] Node.js not found." -ForegroundColor Red; exit 1 }

Write-Host "  Applies on top of batch4a2-shell (already installed)." -ForegroundColor Magenta
Write-Host ""
Write-Host "  What this does:" -ForegroundColor White
Write-Host ""
Write-Host "    [NEW]      src/components/business/  Agenda.jsx, ShareLink.jsx, useIsDesktop.js" -ForegroundColor Green
Write-Host "    [REPLACE]  src/components/business/  BusinessShell, DayRail, NewBookingSheet, Sheet" -ForegroundColor Yellow
Write-Host "    [REPLACE]  src/pages/business/  Today, Calendar" -ForegroundColor Yellow
Write-Host "    [REPLACE]  src/services/business.js" -ForegroundColor Yellow
Write-Host "    [REPLACE]  src/styles/business/  shell.css, day.css, calendar.css" -ForegroundColor Yellow
Write-Host ""
Write-Host "  Replaced files are saved as *.backup first." -ForegroundColor Gray
Write-Host ""

$confirm = Read-Host "  Apply? (y/n)"
if ($confirm -ne 'y' -and $confirm -ne 'Y') { Write-Host "  [CANCELLED]" -ForegroundColor Yellow; exit 0 }
Write-Host ""

& node (Join-Path $PSScriptRoot 'patch-batch4a2-redesign.mjs')
if ($LASTEXITCODE -ne 0) { Write-Host "  [FAIL] Exit code $LASTEXITCODE" -ForegroundColor Red; exit $LASTEXITCODE }

$payloadDir = $PSScriptRoot
if ((Split-Path $payloadDir -Leaf) -eq 'payload') {
    Set-Location (Split-Path $payloadDir -Parent)
    Remove-Item $payloadDir -Recurse -Force
}

Write-Host ""
Write-Host "  Done. npm run build, then check /portal at phone width and at desktop width." -ForegroundColor Green
Write-Host ""
