import fs from 'fs'
import path from 'path'

const REPO = process.cwd()

const NEW_FILES = [
    { path: 'src/components/business/Agenda.jsx', content: `import { useMemo } from 'react'
import { parseDateKey } from '../../services/dates'
import { bookingStart, blockMinutes, durationLabel, minutesToLabel, shortTime, windowsFor } from '../../services/business'

const Agenda = ({ dateKey, bookings, blocks, hours, staff, members, nowMinutes, past = false, onBook, onOpen, onConfirm }) => {
    const weekday = parseDateKey(dateKey).getDay()
    const showStaff = !staff && members.length > 1

    const items = useMemo(() => {
        const rows = bookings
            .filter((b) => b.status !== 'cancelled')
            .map((b) => ({ kind: 'booking', start: bookingStart(b), end: bookingStart(b) + b.duration_minutes, booking: b }))

        const blockRows = blocks
            .filter((b) => !staff || !b.staff_id || b.staff_id === staff.id)
            .map((b) => {
                const [start, end] = blockMinutes(b, dateKey)
                return { kind: 'block', start, end, block: b }
            })
            .filter((b) => b.end > b.start)

        const gaps = []
        if (!past && (staff || members.length === 1)) {
            const busy = [...rows, ...blockRows]
                .filter((r) => r.kind === 'block' || ['pending', 'confirmed'].includes(r.booking.status))
                .map((r) => [r.start, r.end])
                .sort((a, b) => a[0] - b[0])
            const floor = nowMinutes != null ? Math.ceil(nowMinutes / 15) * 15 : 0
            windowsFor(hours, staff?.id || members[0]?.id, weekday).forEach(([open, close]) => {
                let cursor = Math.max(open, floor)
                busy.forEach(([from, to]) => {
                    if (to <= cursor || from >= close) return
                    if (from - cursor >= 15) gaps.push({ kind: 'gap', start: cursor, end: from })
                    cursor = Math.max(cursor, to)
                })
                if (close - cursor >= 15) gaps.push({ kind: 'gap', start: cursor, end: close })
            })
        }

        const all = [...rows, ...blockRows, ...gaps].sort((a, b) => a.start - b.start || (a.kind === 'gap') - (b.kind === 'gap'))
        if (nowMinutes != null) {
            const index = all.findIndex((r) => r.end > nowMinutes)
            all.splice(index === -1 ? all.length : index, 0, { kind: 'now', start: nowMinutes })
        }
        return all
    }, [bookings, blocks, hours, staff, members, weekday, dateKey, nowMinutes, past])

    const memberName = (id) => members.find((m) => m.id === id)?.display_name

    return (
        <ol className="biz-agenda">
            {items.map((item) => {
                if (item.kind === 'now') {
                    return (
                        <li key="now" className="biz-agenda__now" aria-label={\`Now, \${minutesToLabel(item.start)}\`}>
                            <span className="biz-num">{minutesToLabel(item.start)}</span>
                        </li>
                    )
                }

                if (item.kind === 'gap') {
                    return (
                        <li key={\`gap-\${item.start}\`} className="biz-agenda__row biz-agenda__row--gap">
                            <span className="biz-agenda__time biz-num">{minutesToLabel(item.start)}</span>
                            <div className="biz-agenda__gap">
                                <span>
                                    Free until <span className="biz-num">{minutesToLabel(item.end)}</span>
                                    <span className="biz-agenda__len">{durationLabel(item.end - item.start)}</span>
                                </span>
                                <button
                                    type="button"
                                    className="biz-agenda__book"
                                    onClick={() => onBook(item.start, staff?.id || members[0]?.id)}
                                >
                                    Book
                                </button>
                            </div>
                        </li>
                    )
                }

                if (item.kind === 'block') {
                    return (
                        <li key={\`block-\${item.block.id}\`} className="biz-agenda__row">
                            <span className="biz-agenda__time biz-num">{minutesToLabel(item.start)}</span>
                            <div className="biz-agenda__block">
                                {\`Blocked until \${minutesToLabel(item.end)}\${item.block.reason ? \`, \${item.block.reason}\` : ''}\`}
                            </div>
                        </li>
                    )
                }

                const { booking } = item
                const done = past || (nowMinutes != null && item.end <= nowMinutes)
                return (
                    <li key={booking.id} className={\`biz-agenda__row\${done ? ' is-past' : ''}\`}>
                        <span className="biz-agenda__time biz-num">
                            {shortTime(booking.appointment_time)}
                            <span className="biz-agenda__end">{minutesToLabel(item.end)}</span>
                        </span>
                        <div className={\`biz-agenda__card biz-agenda__card--\${booking.status}\`}>
                            <button type="button" className="biz-agenda__open" onClick={() => onOpen(booking)}>
                                <span className="biz-agenda__who">{booking.client_name}</span>
                                <span className="biz-agenda__what">
                                    {booking.services?.service_name || 'Booking'}
                                    {showStaff && memberName(booking.staff_id) ? \` with \${memberName(booking.staff_id)}\` : ''}
                                </span>
                                {booking.status !== 'confirmed' && (
                                    <span className={\`biz-agenda__state biz-agenda__state--\${booking.status}\`}>
                                        {booking.status === 'pending' ? 'Needs confirming' : booking.status === 'completed' ? 'Completed' : 'No-show'}
                                    </span>
                                )}
                            </button>
                            {booking.status === 'pending' && (
                                <button type="button" className="biz-agenda__confirm" onClick={() => onConfirm(booking)}>
                                    Confirm
                                </button>
                            )}
                        </div>
                    </li>
                )
            })}
        </ol>
    )
}

export default Agenda
` },
    { path: 'src/components/business/ShareLink.jsx', content: `import { useState } from 'react'
import { Check, Copy, MessageCircle } from 'lucide-react'

const ShareLink = ({ business }) => {
    const [copied, setCopied] = useState(false)
    const link = \`\${window.location.origin}/\${business.slug}\`

    const copy = async () => {
        try {
            await navigator.clipboard.writeText(link)
            setCopied(true)
            setTimeout(() => setCopied(false), 2000)
        } catch {
            setCopied(false)
        }
    }

    return (
        <div className="biz-share">
            <p className="biz-share__intro">Clients book you at</p>
            <p className="biz-share__link">{link.replace(/^https?:\\/\\//, '')}</p>
            <div className="biz-share__actions">
                <button type="button" className="btn btn--secondary" onClick={copy}>
                    {copied ? <Check size={16} aria-hidden="true" /> : <Copy size={16} aria-hidden="true" />}
                    {copied ? 'Copied' : 'Copy link'}
                </button>
                <a
                    className="btn btn--secondary"
                    href={\`https://wa.me/?text=\${encodeURIComponent(\`Book with \${business.business_name}: \${link}\`)}\`}
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    <MessageCircle size={16} aria-hidden="true" /> Send on WhatsApp
                </a>
            </div>
        </div>
    )
}

export default ShareLink
` },
    { path: 'src/components/business/useIsDesktop.js', content: `import { useEffect, useState } from 'react'

const QUERY = '(min-width: 1024px)'

export const useIsDesktop = () => {
    const [matches, setMatches] = useState(() => window.matchMedia(QUERY).matches)
    useEffect(() => {
        const media = window.matchMedia(QUERY)
        const onChange = () => setMatches(media.matches)
        media.addEventListener('change', onChange)
        return () => media.removeEventListener('change', onChange)
    }, [])
    return matches
}
` },
]

// Created by the first 4a-2 patch and rewritten by the redesign, so replaced whole.
const REPLACE_FILES = [
    { path: 'src/components/business/BusinessShell.jsx', content: `import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Link, NavLink, Navigate, Outlet, useLocation } from 'react-router-dom'
import { ArrowLeftRight, CalendarDays, Clock, LogOut, Menu, Plus, Scissors, Settings, Share2, Store, Sun } from 'lucide-react'
import { useAuth } from '../../hooks/useAuth'
import { loadWorkspace } from '../../services/business'
import { WorkspaceContext } from './WorkspaceContext'
import Sheet from './Sheet'
import NewBookingSheet from './NewBookingSheet'
import BookingDetailSheet from './BookingDetailSheet'
import ShareLink from './ShareLink'
import '../../styles/business/shell.css'

const NAV = [
    { to: '/portal', label: 'Today', icon: Sun, end: true, tab: true },
    { to: '/portal/calendar', label: 'Calendar', icon: CalendarDays, tab: true },
    { to: '/portal/services', label: 'Services', icon: Scissors, tab: true },
    { to: '/portal/hours', label: 'Hours', icon: Clock },
    { to: '/portal/page', label: 'Business page', icon: Store },
    { to: '/portal/settings', label: 'Settings', icon: Settings },
]

const Wordmark = () => (
    <span className="biz-wordmark" aria-label="LocAppoint">
        <span>Loc</span><span className="biz-wordmark__accent">Appoint</span>
    </span>
)

const BusinessShell = () => {
    const { user, userProfile, business: ownedBusiness, signOut, setMode } = useAuth()
    const location = useLocation()
    const [workspace, setWorkspace] = useState(null)
    const [loadError, setLoadError] = useState('')
    const [bookingsVersion, setBookingsVersion] = useState(0)
    const [newBooking, setNewBooking] = useState(null)
    const [openBookingRow, setOpenBookingRow] = useState(null)
    const [moreOpen, setMoreOpen] = useState(false)
    const [shareOpen, setShareOpen] = useState(false)
    const [toast, setToast] = useState(null)
    const toastTimer = useRef(null)

    useEffect(() => { setMode('business') }, [setMode])

    const reloadWorkspace = useCallback(async () => {
        if (!ownedBusiness?.id) return
        try {
            setLoadError('')
            setWorkspace(await loadWorkspace(ownedBusiness.id))
        } catch (err) {
            console.error('Workspace load failed:', err)
            setLoadError('Could not load your business. Check your connection and reload.')
        }
    }, [ownedBusiness?.id])

    useEffect(() => { reloadWorkspace() }, [reloadWorkspace])

    useEffect(() => () => clearTimeout(toastTimer.current), [])

    const notify = useCallback((message) => {
        clearTimeout(toastTimer.current)
        setToast(message)
        toastTimer.current = setTimeout(() => setToast(null), 3200)
    }, [])

    const refreshBookings = useCallback(() => setBookingsVersion((v) => v + 1), [])
    const openNewBooking = useCallback((prefill = {}) => setNewBooking(prefill), [])
    const closeNewBooking = useCallback(() => setNewBooking(null), [])
    const openBooking = useCallback((booking) => setOpenBookingRow(booking), [])
    const closeBooking = useCallback(() => setOpenBookingRow(null), [])

    const value = useMemo(() => {
        if (!workspace) return null
        const me = workspace.members.find((m) => m.user_id === user?.id) || null
        return {
            ...workspace,
            me,
            isOwner: me?.role === 'owner',
            bookableMembers: workspace.members.filter((m) => m.is_bookable),
            activeServices: workspace.services.filter((s) => s.is_active),
            reloadWorkspace,
            bookingsVersion,
            refreshBookings,
            openNewBooking,
            openBooking,
            notify,
        }
    }, [workspace, user?.id, reloadWorkspace, bookingsVersion, refreshBookings, openNewBooking, openBooking, notify])

    if (!ownedBusiness) {
        if (location.pathname !== '/portal/page') return <Navigate to="/portal/page" replace />
        return (
            <div className="biz-bare">
                <header className="biz-topbar">
                    <Wordmark />
                    <Link to="/client" className="biz-textbtn">Back to Booking</Link>
                </header>
                <main className="biz-content"><Outlet /></main>
            </div>
        )
    }

    if (loadError) return <div className="biz-state" role="alert">{loadError}</div>
    if (!value) return <div className="biz-state"><span className="spinner" /> Loading your business</div>

    const moreActive = NAV.filter((item) => !item.tab).some((item) => location.pathname.startsWith(item.to))

    return (
        <WorkspaceContext.Provider value={value}>
            <div className="biz-shell">
                <aside className="biz-sidebar">
                    <div className="biz-sidebar__brand">
                        <Wordmark />
                        <span className="biz-sidebar__business">{value.business.business_name}</span>
                    </div>
                    <nav className="biz-sidebar__nav" aria-label="Business">
                        {NAV.map(({ to, label, icon: Icon, end }) => (
                            <NavLink key={to} to={to} end={end} className="biz-navlink">
                                <Icon size={18} aria-hidden="true" />
                                <span>{label}</span>
                            </NavLink>
                        ))}
                    </nav>
                    <div className="biz-sidebar__foot">
                        <Link to="/client" className="biz-navlink">
                            <ArrowLeftRight size={18} aria-hidden="true" />
                            <span>Switch to Booking</span>
                        </Link>
                        <button type="button" className="biz-navlink" onClick={signOut}>
                            <LogOut size={18} aria-hidden="true" />
                            <span>Sign out</span>
                        </button>
                        <p className="biz-sidebar__who">
                            {userProfile?.full_name}
                            <span>{user?.email}</span>
                        </p>
                    </div>
                </aside>

                <div className="biz-main">
                    <header className="biz-topbar">
                        <span className="biz-topbar__name">{value.business.business_name}</span>
                        <button type="button" className="biz-icon-btn biz-topbar__share" onClick={() => setShareOpen(true)} aria-label="Share your booking link">
                            <Share2 size={18} aria-hidden="true" />
                        </button>
                        <button type="button" className="btn btn--primary biz-topbar__new" onClick={() => openNewBooking()}>
                            <Plus size={18} aria-hidden="true" /> New booking
                        </button>
                    </header>
                    <main className="biz-content">
                        <Outlet />
                    </main>
                </div>

                <nav className="biz-tabbar" aria-label="Business">
                    {NAV.filter((item) => item.tab).map(({ to, label, icon: Icon, end }) => (
                        <NavLink key={to} to={to} end={end} className="biz-tab">
                            <Icon size={22} aria-hidden="true" />
                            <span>{label}</span>
                        </NavLink>
                    ))}
                    <button
                        type="button"
                        className={\`biz-tab\${moreActive ? ' active' : ''}\`}
                        onClick={() => setMoreOpen(true)}
                        aria-haspopup="dialog"
                    >
                        <Menu size={22} aria-hidden="true" />
                        <span>More</span>
                    </button>
                </nav>

                <button type="button" className="biz-fab" onClick={() => openNewBooking()} aria-label="New booking">
                    <Plus size={26} aria-hidden="true" />
                </button>

                <Sheet open={moreOpen} onClose={() => setMoreOpen(false)} title="More">
                    <nav className="biz-morelist" aria-label="More">
                        {NAV.filter((item) => !item.tab).map(({ to, label, icon: Icon }) => (
                            <NavLink key={to} to={to} className="biz-navlink" onClick={() => setMoreOpen(false)}>
                                <Icon size={20} aria-hidden="true" />
                                <span>{label}</span>
                            </NavLink>
                        ))}
                        <Link to="/client" className="biz-navlink" onClick={() => setMoreOpen(false)}>
                            <ArrowLeftRight size={20} aria-hidden="true" />
                            <span>Switch to Booking</span>
                        </Link>
                        <button type="button" className="biz-navlink" onClick={signOut}>
                            <LogOut size={20} aria-hidden="true" />
                            <span>Sign out</span>
                        </button>
                    </nav>
                </Sheet>

                <Sheet open={shareOpen} onClose={() => setShareOpen(false)} title="Your booking link">
                    <ShareLink business={value.business} />
                </Sheet>

                <NewBookingSheet open={Boolean(newBooking)} prefill={newBooking} onClose={closeNewBooking} />
                <BookingDetailSheet booking={openBookingRow} onClose={closeBooking} />

                <div className="biz-toast" role="status" aria-live="polite">
                    {toast && <span className="biz-toast__msg">{toast}</span>}
                </div>
            </div>
        </WorkspaceContext.Provider>
    )
}

export default BusinessShell
` },
    { path: 'src/components/business/DayRail.jsx', content: `import { useEffect, useMemo, useRef } from 'react'
import { parseDateKey, toMinutes } from '../../services/dates'
import { STATUS_LABEL, bookingStart, minutesToLabel, shortTime } from '../../services/business'

const PX_PER_MINUTE = 1.4
const SNAP = 15

const windowsFor = (hours, memberId, weekday) => {
    const own = hours.filter((h) => h.staff_id === memberId)
    const source = own.length > 0 ? own : hours.filter((h) => !h.staff_id)
    return source
        .filter((h) => h.day_of_week === weekday)
        .map((h) => [toMinutes(h.start_time), toMinutes(h.end_time)])
}

const blockRange = (block, dateKey) => {
    const dayStart = new Date(\`\${dateKey}T00:00:00\`).getTime()
    const start = Math.max(0, (new Date(block.starts_at).getTime() - dayStart) / 60000)
    const end = Math.min(24 * 60, (new Date(block.ends_at).getTime() - dayStart) / 60000)
    return [start, end]
}

const DayRail = ({ dateKey, columns, bookings, blocks, hours, nowMinutes, onSlotTap, onBookingTap }) => {
    const scrollRef = useRef(null)
    const weekday = parseDateKey(dateKey).getDay()

    const layout = useMemo(() => {
        const perColumn = columns.map((member) => ({
            member,
            windows: windowsFor(hours, member.id, weekday),
            bookings: bookings.filter((b) => b.staff_id === member.id && b.status !== 'cancelled'),
            blocks: blocks
                .filter((b) => b.staff_id === member.id || !b.staff_id)
                .map((b) => ({ ...b, range: blockRange(b, dateKey) }))
                .filter((b) => b.range[1] > b.range[0]),
        }))

        const marks = perColumn.flatMap((c) => [
            ...c.windows.flat(),
            ...c.bookings.flatMap((b) => [bookingStart(b), bookingStart(b) + b.duration_minutes]),
        ])
        const start = marks.length ? Math.floor(Math.min(...marks) / 60) * 60 : 9 * 60
        const end = marks.length ? Math.ceil(Math.max(...marks) / 60) * 60 : 18 * 60
        return { perColumn, start: Math.max(0, start), end: Math.min(24 * 60, Math.max(end, start + 60)) }
    }, [columns, bookings, blocks, hours, weekday, dateKey, nowMinutes])

    const { perColumn, start, end } = layout
    const height = (end - start) * PX_PER_MINUTE
    const y = (minutes) => (minutes - start) * PX_PER_MINUTE
    const hourMarks = []
    for (let m = start; m <= end; m += 60) hourMarks.push(m)
    const showNow = nowMinutes != null && nowMinutes >= start && nowMinutes <= end

    useEffect(() => {
        const box = scrollRef.current
        if (!box) return
        box.scrollTop = showNow ? Math.max(0, y(nowMinutes) - box.clientHeight / 3) : 0
    }, [dateKey])

    const handleColumnClick = (event, memberId) => {
        if (event.target !== event.currentTarget) return
        const rect = event.currentTarget.getBoundingClientRect()
        const minutes = start + Math.floor((event.clientY - rect.top) / PX_PER_MINUTE / SNAP) * SNAP
        onSlotTap?.(memberId, Math.min(Math.max(minutes, start), end - SNAP))
    }

    return (
        <div ref={scrollRef} className={\`biz-rail\${columns.length > 1 ? ' biz-rail--multi' : ''}\`}>
            {columns.length > 1 && (
                <div className="biz-rail__heads" aria-hidden="true">
                    <span className="biz-rail__gutter" />
                    {columns.map((member) => (
                        <span key={member.id} className="biz-rail__head">{member.display_name}</span>
                    ))}
                </div>
            )}

            <div className="biz-rail__body" style={{ height }}>
                <div className="biz-rail__gutter">
                    {hourMarks.map((m) => (
                        <span key={m} className="biz-rail__hour" style={{ top: y(m) }}>{minutesToLabel(m)}</span>
                    ))}
                </div>

                {perColumn.map((column) => (
                    <div
                        key={column.member.id}
                        className="biz-rail__col"
                        onClick={(event) => handleColumnClick(event, column.member.id)}
                        role="presentation"
                    >
                        {hourMarks.map((m) => (
                            <span key={m} className="biz-rail__line" style={{ top: y(m) }} />
                        ))}

                        {column.windows.map(([from, to]) => (
                            <span key={\`\${from}-\${to}\`} className="biz-rail__open" style={{ top: y(from), height: (to - from) * PX_PER_MINUTE }} />
                        ))}

                        {column.blocks.map((block) => (
                            <div
                                key={block.id}
                                className="biz-rail__block"
                                style={{ top: y(block.range[0]), height: (block.range[1] - block.range[0]) * PX_PER_MINUTE }}
                            >
                                <span>Blocked{block.reason ? \`: \${block.reason}\` : ''}</span>
                            </div>
                        ))}

                        {column.bookings.map((booking) => {
                            const from = bookingStart(booking)
                            const blockHeight = Math.max(booking.duration_minutes * PX_PER_MINUTE, 30)
                            return (
                                <button
                                    key={booking.id}
                                    type="button"
                                    className={\`biz-booking biz-booking--\${booking.status}\${blockHeight < 56 ? ' biz-booking--compact' : ''}\`}
                                    style={{ top: y(from), height: blockHeight }}
                                    onClick={() => onBookingTap?.(booking)}
                                    aria-label={\`\${shortTime(booking.appointment_time)} \${booking.client_name}, \${booking.services?.service_name || 'booking'}, \${STATUS_LABEL[booking.status]}\`}
                                >
                                    <span className="biz-booking__time">
                                        {shortTime(booking.appointment_time)}
                                        {booking.status === 'pending' && <span className="biz-booking__flag">Needs confirming</span>}
                                    </span>
                                    <span className="biz-booking__who">{booking.client_name}</span>
                                    <span className="biz-booking__what">{booking.services?.service_name}</span>
                                </button>
                            )
                        })}
                    </div>
                ))}

                {showNow && (
                    <div className="biz-rail__now" style={{ top: y(nowMinutes) }} aria-hidden="true">
                        <span className="biz-rail__now-label">{minutesToLabel(nowMinutes)}</span>
                    </div>
                )}
            </div>
        </div>
    )
}

export default DayRail
` },
    { path: 'src/components/business/NewBookingSheet.jsx', content: `import { useEffect, useMemo, useState } from 'react'
import Sheet from './Sheet'
import { useWorkspace } from './WorkspaceContext'
import { addBooking, addDays, durationLabel, formatDay, formatMoney, friendlyError, getSlots, shortTime, zonedNow } from '../../services/business'

const STRIP_DAYS = 14

const groupSlots = (slots) => {
    const groups = [
        { label: 'Morning', items: [] },
        { label: 'Afternoon', items: [] },
        { label: 'Evening', items: [] },
    ]
    slots.forEach((slot) => {
        const hour = Number(slot.slot_time.slice(0, 2))
        groups[hour < 12 ? 0 : hour < 17 ? 1 : 2].items.push(slot)
    })
    return groups.filter((g) => g.items.length > 0)
}

const NewBookingSheet = ({ open, prefill, onClose }) => {
    const { business, bookableMembers, activeServices, me, isOwner, refreshBookings, notify } = useWorkspace()
    const [form, setForm] = useState(null)
    const [slots, setSlots] = useState([])
    const [slotsLoading, setSlotsLoading] = useState(false)
    const [otherTime, setOtherTime] = useState(false)
    const [otherDate, setOtherDate] = useState(false)
    const [saving, setSaving] = useState(false)
    const [error, setError] = useState('')

    const today = zonedNow(business.timezone).dateKey
    const strip = useMemo(() => Array.from({ length: STRIP_DAYS }, (_, i) => addDays(today, i)), [today])

    useEffect(() => {
        if (!open) return
        const date = prefill?.date || today
        setForm({
            serviceId: activeServices[0]?.id || '',
            staffId: prefill?.staffId || (isOwner ? bookableMembers[0]?.id : me?.id) || '',
            date,
            time: prefill?.time || '',
            name: '',
            phone: '',
            email: '',
            notes: '',
        })
        setOtherDate(!strip.includes(date))
        setOtherTime(false)
        setError('')
    }, [open, prefill, activeServices, bookableMembers, isOwner, me, today, strip])

    useEffect(() => {
        if (!open || !form?.serviceId || !form?.staffId || !form?.date) return undefined
        let cancelled = false
        setSlotsLoading(true)
        getSlots({ businessId: business.id, serviceId: form.serviceId, date: form.date, staffId: form.staffId })
            .then((rows) => {
                if (cancelled) return
                setSlots(rows)
                setForm((current) => {
                    if (!current?.time) return current
                    const wanted = current.time.length === 5 ? \`\${current.time}:00\` : current.time
                    if (rows.some((r) => r.slot_time === wanted)) return { ...current, time: wanted }
                    setOtherTime(true)
                    return current
                })
            })
            .catch(() => { if (!cancelled) setSlots([]) })
            .finally(() => { if (!cancelled) setSlotsLoading(false) })
        return () => { cancelled = true }
    }, [open, business.id, form?.serviceId, form?.staffId, form?.date])

    if (!form) return null

    const set = (field, value) => setForm((current) => ({ ...current, [field]: value }))
    const update = (field) => (event) => set(field, event.target.value)
    const service = activeServices.find((s) => s.id === form.serviceId)

    const submit = async (event) => {
        event.preventDefault()
        if (!form.time) {
            setError('Pick a time.')
            return
        }
        setSaving(true)
        setError('')
        try {
            await addBooking({
                businessId: business.id,
                serviceId: form.serviceId,
                staffId: form.staffId,
                date: form.date,
                time: form.time.length === 5 ? \`\${form.time}:00\` : form.time,
                name: form.name,
                phone: form.phone,
                email: form.email,
                notes: form.notes,
            })
            refreshBookings()
            notify('Booking added')
            onClose()
        } catch (err) {
            setError(friendlyError(err))
        } finally {
            setSaving(false)
        }
    }

    if (activeServices.length === 0) {
        return (
            <Sheet open={open} onClose={onClose} title="New booking">
                <p className="biz-empty">Add a service first, then you can book it.</p>
            </Sheet>
        )
    }

    const dayLabel = (dateKey, index) => {
        if (index === 0) return 'Today'
        if (index === 1) return 'Tomorrow'
        return formatDay(dateKey, { weekday: 'short' })
    }

    return (
        <Sheet
            open={open}
            onClose={onClose}
            title="New booking"
            footer={
                <button type="submit" form="biz-new-booking" className="btn btn--primary btn--lg btn--full" disabled={saving}>
                    {saving ? 'Adding' : form.time && service ? \`Add booking at \${shortTime(form.time)}\` : 'Add booking'}
                </button>
            }
        >
            <form id="biz-new-booking" className="biz-form" onSubmit={submit}>
                <fieldset className="biz-field">
                    <legend className="biz-field__label">Service</legend>
                    {activeServices.length <= 6 ? (
                        <div className="biz-options" role="radiogroup" aria-label="Service">
                            {activeServices.map((s) => (
                                <button
                                    key={s.id}
                                    type="button"
                                    role="radio"
                                    aria-checked={form.serviceId === s.id}
                                    className={\`biz-option\${form.serviceId === s.id ? ' is-selected' : ''}\`}
                                    onClick={() => set('serviceId', s.id)}
                                >
                                    <span className="biz-option__name">{s.service_name}</span>
                                    <span className="biz-option__meta">{durationLabel(s.duration_minutes)}, <span className="biz-num">{formatMoney(s.price)}</span></span>
                                </button>
                            ))}
                        </div>
                    ) : (
                        <select className="biz-input" value={form.serviceId} onChange={update('serviceId')} required>
                            {activeServices.map((s) => (
                                <option key={s.id} value={s.id}>{s.service_name}, {durationLabel(s.duration_minutes)}</option>
                            ))}
                        </select>
                    )}
                </fieldset>

                {isOwner && bookableMembers.length > 1 && (
                    <fieldset className="biz-field">
                        <legend className="biz-field__label">With</legend>
                        <div className="biz-chips" role="radiogroup" aria-label="With">
                            {bookableMembers.map((m) => (
                                <button
                                    key={m.id}
                                    type="button"
                                    role="radio"
                                    aria-checked={form.staffId === m.id}
                                    className={\`biz-chip\${form.staffId === m.id ? ' is-selected' : ''}\`}
                                    onClick={() => set('staffId', m.id)}
                                >
                                    {m.display_name}
                                </button>
                            ))}
                        </div>
                    </fieldset>
                )}

                <fieldset className="biz-field">
                    <legend className="biz-field__label">Day</legend>
                    {otherDate ? (
                        <input className="biz-input" type="date" value={form.date} onChange={update('date')} required />
                    ) : (
                        <div className="biz-days" role="radiogroup" aria-label="Day">
                            {strip.map((dateKey, index) => (
                                <button
                                    key={dateKey}
                                    type="button"
                                    role="radio"
                                    aria-checked={form.date === dateKey}
                                    className={\`biz-day\${form.date === dateKey ? ' is-selected' : ''}\`}
                                    onClick={() => setForm((current) => ({ ...current, date: dateKey, time: '' }))}
                                >
                                    <span className="biz-day__name">{dayLabel(dateKey, index)}</span>
                                    <span className="biz-day__num biz-num">{formatDay(dateKey, { day: 'numeric' })}</span>
                                </button>
                            ))}
                        </div>
                    )}
                    <button type="button" className="biz-textbtn" onClick={() => setOtherDate((v) => !v)}>
                        {otherDate ? 'Show the next two weeks' : 'Another date'}
                    </button>
                </fieldset>

                <fieldset className="biz-field">
                    <legend className="biz-field__label">Time</legend>
                    {otherTime ? (
                        <input className="biz-input" type="time" step="300" value={form.time.slice(0, 5)} onChange={update('time')} required />
                    ) : slotsLoading ? (
                        <p className="biz-hint">Finding free times</p>
                    ) : slots.length === 0 ? (
                        <p className="biz-hint">No free times in opening hours on this day.</p>
                    ) : (
                        <div className="biz-slotgroups" role="radiogroup" aria-label="Free times">
                            {groupSlots(slots).map((group) => (
                                <div key={group.label} className="biz-slotgroup">
                                    <span className="biz-slotgroup__label">{group.label}</span>
                                    <div className="biz-slotrow">
                                        {group.items.map((slot) => (
                                            <button
                                                key={slot.slot_time}
                                                type="button"
                                                role="radio"
                                                aria-checked={form.time === slot.slot_time}
                                                className={\`biz-slot\${form.time === slot.slot_time ? ' is-selected' : ''}\`}
                                                onClick={() => set('time', slot.slot_time)}
                                            >
                                                {shortTime(slot.slot_time)}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                    <button
                        type="button"
                        className="biz-textbtn"
                        onClick={() => {
                            setOtherTime((v) => !v)
                            set('time', '')
                        }}
                    >
                        {otherTime ? 'Show free times' : 'A time outside opening hours'}
                    </button>
                </fieldset>

                <fieldset className="biz-field biz-client">
                    <legend className="biz-field__label">Client</legend>
                    <input className="biz-input" aria-label="Client name" placeholder="Name" value={form.name} onChange={update('name')} autoComplete="off" required maxLength={120} />
                    <div className="biz-field-row">
                        <input className="biz-input" aria-label="Phone, optional" placeholder="Phone (optional)" type="tel" inputMode="tel" value={form.phone} onChange={update('phone')} autoComplete="off" />
                        <input className="biz-input" aria-label="Email, optional" placeholder="Email (optional)" type="email" value={form.email} onChange={update('email')} autoComplete="off" />
                    </div>
                    <textarea className="biz-input biz-input--area" aria-label="Notes, optional" placeholder="Notes (optional)" value={form.notes} onChange={update('notes')} maxLength={1000} rows={2} />
                </fieldset>

                {error && <p className="biz-error" role="alert">{error}</p>}
            </form>
        </Sheet>
    )
}

export default NewBookingSheet
` },
    { path: 'src/components/business/Sheet.jsx', content: `import { useEffect, useId, useRef } from 'react'
import { createPortal } from 'react-dom'
import { X } from 'lucide-react'

const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled])'

const Sheet = ({ open, onClose, title, children, footer }) => {
    const titleId = useId()
    const panelRef = useRef(null)
    const closeRef = useRef(onClose)
    closeRef.current = onClose

    useEffect(() => {
        if (!open) return undefined
        const returnTo = document.activeElement
        const previousOverflow = document.body.style.overflow
        document.body.style.overflow = 'hidden'

        const onKey = (event) => {
            if (event.key === 'Escape') {
                closeRef.current()
                return
            }
            if (event.key !== 'Tab' || !panelRef.current) return
            const items = [...panelRef.current.querySelectorAll(FOCUSABLE)]
            if (items.length === 0) return
            const first = items[0]
            const last = items[items.length - 1]
            if (event.shiftKey && document.activeElement === first) {
                event.preventDefault()
                last.focus()
            } else if (!event.shiftKey && document.activeElement === last) {
                event.preventDefault()
                first.focus()
            }
        }

        document.addEventListener('keydown', onKey)
        requestAnimationFrame(() => panelRef.current?.focus())

        return () => {
            document.body.style.overflow = previousOverflow
            document.removeEventListener('keydown', onKey)
            returnTo?.focus?.()
        }
    }, [open])

    if (!open) return null

    return createPortal(
        <div
            className="biz-sheet"
            onMouseDown={(event) => { if (event.target === event.currentTarget) closeRef.current() }}
        >
            <section
                ref={panelRef}
                className="biz-sheet__panel"
                role="dialog"
                aria-modal="true"
                aria-labelledby={titleId}
                tabIndex={-1}
            >
                <header className="biz-sheet__head">
                    <h2 id={titleId} className="biz-sheet__title">{title}</h2>
                    <button type="button" className="biz-icon-btn" aria-label="Close" onClick={() => closeRef.current()}>
                        <X size={20} />
                    </button>
                </header>
                <div className="biz-sheet__body">{children}</div>
                {footer && <footer className="biz-sheet__foot">{footer}</footer>}
            </section>
        </div>,
        document.body
    )
}

export default Sheet
` },
    { path: 'src/pages/business/Calendar.jsx', content: `import { useEffect, useMemo, useState } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { useWorkspace } from '../../components/business/WorkspaceContext'
import DayRail from '../../components/business/DayRail'
import Agenda from '../../components/business/Agenda'
import { useIsDesktop } from '../../components/business/useIsDesktop'
import StaffFilter from '../../components/business/StaffFilter'
import {
    STATUS_LABEL,
    addDays,
    formatDay,
    friendlyError,
    minutesToLabel,
    setBookingStatus,
    loadBlocks,
    loadBookings,
    shortTime,
    startOfWeek,
    zonedNow,
} from '../../services/business'
import '../../styles/business/day.css'
import '../../styles/business/calendar.css'

const Calendar = () => {
    const { business, bookableMembers, hours, me, isOwner, bookingsVersion, refreshBookings, openNewBooking, openBooking, notify } = useWorkspace()
    const isDesktop = useIsDesktop()
    const today = zonedNow(business.timezone)
    const [view, setView] = useState('day')
    const [anchor, setAnchor] = useState(today.dateKey)
    const [staffFilter, setStaffFilter] = useState(isOwner ? 'all' : me?.id)
    const [bookings, setBookings] = useState([])
    const [blocks, setBlocks] = useState([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState('')

    const range = useMemo(() => {
        if (view === 'day') return [anchor, anchor]
        const from = startOfWeek(anchor)
        return [from, addDays(from, 6)]
    }, [view, anchor])

    useEffect(() => {
        let cancelled = false
        setLoading(true)
        Promise.all([loadBookings(business.id, range[0], range[1]), loadBlocks(business.id, range[0], range[1])])
            .then(([rows, blockRows]) => {
                if (cancelled) return
                setBookings(rows)
                setBlocks(blockRows)
                setError('')
            })
            .catch(() => { if (!cancelled) setError('Could not load the calendar. Reload to try again.') })
            .finally(() => { if (!cancelled) setLoading(false) })
        return () => { cancelled = true }
    }, [business.id, range, bookingsVersion])

    const columns = useMemo(
        () => (staffFilter === 'all' ? bookableMembers : bookableMembers.filter((m) => m.id === staffFilter)),
        [staffFilter, bookableMembers]
    )
    const visible = useMemo(
        () => bookings.filter((b) => columns.some((c) => c.id === b.staff_id)),
        [bookings, columns]
    )

    const step = view === 'day' ? 1 : 7
    const title = view === 'day'
        ? formatDay(anchor)
        : \`\${formatDay(range[0], { day: 'numeric', month: 'short' })} to \${formatDay(range[1], { day: 'numeric', month: 'short' })}\`

    const days = view === 'week' ? Array.from({ length: 7 }, (_, i) => addDays(range[0], i)) : []

    return (
        <div className="biz-page">
            <header className="biz-page__head">
                <div>
                    <h1 className="biz-page__title">Calendar</h1>
                    <p className="biz-page__sub">{title}</p>
                </div>
                <div className="biz-seg" role="radiogroup" aria-label="View">
                    {['day', 'week'].map((option) => (
                        <button
                            key={option}
                            type="button"
                            role="radio"
                            aria-checked={view === option}
                            className={\`biz-seg__btn\${view === option ? ' is-selected' : ''}\`}
                            onClick={() => setView(option)}
                        >
                            {option === 'day' ? 'Day' : 'Week'}
                        </button>
                    ))}
                </div>
            </header>

            <div className="biz-datenav">
                <button type="button" className="biz-icon-btn" aria-label={view === 'day' ? 'Previous day' : 'Previous week'} onClick={() => setAnchor(addDays(anchor, -step))}>
                    <ChevronLeft size={20} />
                </button>
                <button type="button" className="btn btn--ghost btn--sm" onClick={() => setAnchor(today.dateKey)} disabled={anchor === today.dateKey}>
                    Today
                </button>
                <button type="button" className="biz-icon-btn" aria-label={view === 'day' ? 'Next day' : 'Next week'} onClick={() => setAnchor(addDays(anchor, step))}>
                    <ChevronRight size={20} />
                </button>
                <label className="biz-datenav__pick">
                    <span className="biz-visually-hidden">Go to date</span>
                    <input className="biz-input" type="date" value={anchor} onChange={(event) => event.target.value && setAnchor(event.target.value)} />
                </label>
            </div>

            <StaffFilter members={isOwner ? bookableMembers : []} value={staffFilter} onChange={setStaffFilter} />

            {error && <p className="biz-error" role="alert">{error}</p>}
            {loading && bookings.length === 0 && <div className="biz-state"><span className="spinner" /> Loading</div>}

            {view === 'day' && !(loading && bookings.length === 0) && !isDesktop && (
                <Agenda
                    dateKey={anchor}
                    bookings={visible}
                    blocks={blocks}
                    hours={hours}
                    staff={staffFilter === 'all' ? null : bookableMembers.find((m) => m.id === staffFilter) || null}
                    members={bookableMembers}
                    nowMinutes={anchor === today.dateKey ? today.minutes : null}
                    past={anchor < today.dateKey}
                    onBook={(minutes, staffId) => openNewBooking({ staffId, date: anchor, time: minutesToLabel(minutes) })}
                    onOpen={openBooking}
                    onConfirm={async (booking) => {
                        try {
                            await setBookingStatus(booking.id, 'confirmed')
                            refreshBookings()
                            notify(\`\${booking.client_name} confirmed\`)
                        } catch (err) {
                            notify(friendlyError(err))
                        }
                    }}
                />
            )}

            {view === 'day' && !(loading && bookings.length === 0) && isDesktop && (
                <DayRail
                    dateKey={anchor}
                    columns={columns}
                    bookings={visible}
                    blocks={blocks}
                    hours={hours}
                    nowMinutes={anchor === today.dateKey ? today.minutes : null}
                    onSlotTap={(staffId, minutes) => openNewBooking({
                        staffId,
                        date: anchor,
                        time: \`\${String(Math.floor(minutes / 60)).padStart(2, '0')}:\${String(minutes % 60).padStart(2, '0')}\`,
                    })}
                    onBookingTap={openBooking}
                />
            )}

            {view === 'week' && (
                <div className="biz-week">
                    {days.map((dateKey) => {
                        const dayBookings = visible
                            .filter((b) => b.appointment_date === dateKey && b.status !== 'cancelled')
                            .sort((a, b) => a.appointment_time.localeCompare(b.appointment_time))
                        const isToday = dateKey === today.dateKey
                        return (
                            <section key={dateKey} className={\`biz-week__day\${isToday ? ' is-today' : ''}\`} aria-label={formatDay(dateKey)}>
                                <button
                                    type="button"
                                    className="biz-week__head"
                                    onClick={() => { setAnchor(dateKey); setView('day') }}
                                >
                                    <span className="biz-week__dow">{formatDay(dateKey, { weekday: 'short' })}</span>
                                    <span className="biz-num biz-week__date">{formatDay(dateKey, { day: 'numeric' })}</span>
                                    <span className="biz-week__count">{dayBookings.length || ''}</span>
                                </button>
                                <ul className="biz-week__list">
                                    {dayBookings.map((booking) => (
                                        <li key={booking.id}>
                                            <button
                                                type="button"
                                                className={\`biz-week__item biz-week__item--\${booking.status}\`}
                                                onClick={() => openBooking(booking)}
                                                aria-label={\`\${shortTime(booking.appointment_time)} \${booking.client_name}, \${STATUS_LABEL[booking.status]}\`}
                                            >
                                                <span className="biz-num">{shortTime(booking.appointment_time)}</span>
                                                <span className="biz-week__client">{booking.client_name}</span>
                                            </button>
                                        </li>
                                    ))}
                                </ul>
                                <button
                                    type="button"
                                    className="biz-week__add"
                                    onClick={() => openNewBooking({ date: dateKey, staffId: staffFilter !== 'all' ? staffFilter : undefined })}
                                    aria-label={\`Add a booking on \${formatDay(dateKey)}\`}
                                >
                                    Add
                                </button>
                            </section>
                        )
                    })}
                </div>
            )}
        </div>
    )
}

export default Calendar
` },
    { path: 'src/pages/business/Today.jsx', content: `import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { Check } from 'lucide-react'
import { useWorkspace } from '../../components/business/WorkspaceContext'
import Agenda from '../../components/business/Agenda'
import ShareLink from '../../components/business/ShareLink'
import StaffFilter from '../../components/business/StaffFilter'
import {
    formatMoney,
    friendlyError,
    loadBlocks,
    loadBookings,
    minutesToLabel,
    setBookingStatus,
    zonedNow,
} from '../../services/business'
import { parseDateKey } from '../../services/dates'
import '../../styles/business/day.css'

const Today = () => {
    const { business, bookableMembers, activeServices, hours, me, isOwner, bookingsVersion, refreshBookings, openNewBooking, openBooking, notify } = useWorkspace()
    const [now, setNow] = useState(() => zonedNow(business.timezone))
    const [staffFilter, setStaffFilter] = useState(isOwner ? 'all' : me?.id)
    const [bookings, setBookings] = useState([])
    const [blocks, setBlocks] = useState([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState('')

    useEffect(() => {
        const timer = setInterval(() => setNow(zonedNow(business.timezone)), 60000)
        return () => clearInterval(timer)
    }, [business.timezone])

    useEffect(() => {
        let cancelled = false
        Promise.all([loadBookings(business.id, now.dateKey, now.dateKey), loadBlocks(business.id, now.dateKey, now.dateKey)])
            .then(([rows, blockRows]) => {
                if (cancelled) return
                setBookings(rows)
                setBlocks(blockRows)
                setError('')
            })
            .catch(() => { if (!cancelled) setError('Could not load today. Check your connection and reload.') })
            .finally(() => { if (!cancelled) setLoading(false) })
        return () => { cancelled = true }
    }, [business.id, now.dateKey, bookingsVersion])

    const staff = staffFilter === 'all' ? null : bookableMembers.find((m) => m.id === staffFilter) || null
    const visible = useMemo(
        () => (staff ? bookings.filter((b) => b.staff_id === staff.id) : bookings),
        [bookings, staff]
    )

    const counted = visible.filter((b) => b.status !== 'cancelled')
    const expected = counted
        .filter((b) => b.status !== 'no_show')
        .reduce((sum, b) => sum + Number(b.services?.price || 0), 0)
    const pending = visible.filter((b) => b.status === 'pending')

    const hasService = activeServices.length > 0
    const hasHours = hours.some((h) => !h.staff_id)
    const setupDone = hasService && hasHours && business.is_active

    const date = parseDateKey(now.dateKey)
    const weekday = date.toLocaleDateString('en-GB', { weekday: 'long' })
    const dayMonth = date.toLocaleDateString('en-GB', { day: 'numeric', month: 'long' })

    const confirm = async (booking) => {
        try {
            await setBookingStatus(booking.id, 'confirmed')
            refreshBookings()
            notify(\`\${booking.client_name} confirmed\`)
        } catch (err) {
            notify(friendlyError(err))
        }
    }

    const book = (minutes, staffId) => openNewBooking({ staffId, date: now.dateKey, time: minutesToLabel(minutes) })

    return (
        <div className="biz-page biz-today">
            <header className="biz-dayhead">
                <h1 className="biz-dayhead__date">
                    <span className="biz-dayhead__weekday">{weekday}</span>
                    {dayMonth}
                </h1>
                <dl className="biz-stats">
                    <div>
                        <dt>Bookings</dt>
                        <dd className="biz-num">{counted.length}</dd>
                    </div>
                    <div>
                        <dt>Expected</dt>
                        <dd className="biz-num">{formatMoney(expected)}</dd>
                    </div>
                    <div className={pending.length ? 'is-warn' : ''}>
                        <dt>To confirm</dt>
                        <dd className="biz-num">{pending.length}</dd>
                    </div>
                </dl>
            </header>

            {!setupDone && (
                <section className="biz-setup" aria-labelledby="setup-title">
                    <h2 id="setup-title" className="biz-subhead">Finish setting up to take bookings</h2>
                    <ol className="biz-setup__list">
                        <li className="is-done"><Check size={16} aria-hidden="true" /> Business page created</li>
                        <li className={hasService ? 'is-done' : ''}>
                            {hasService ? <Check size={16} aria-hidden="true" /> : <span className="biz-setup__dot" />}
                            {hasService ? 'Services added' : <Link to="/portal/services">Add your first service</Link>}
                        </li>
                        <li className={hasHours ? 'is-done' : ''}>
                            {hasHours ? <Check size={16} aria-hidden="true" /> : <span className="biz-setup__dot" />}
                            {hasHours ? 'Opening hours set' : <Link to="/portal/hours">Set your opening hours</Link>}
                        </li>
                        {!business.is_active && (
                            <li>
                                <span className="biz-setup__dot" />
                                <Link to="/portal/page">Bookings are paused. Turn them back on</Link>
                            </li>
                        )}
                    </ol>
                </section>
            )}

            <div className="biz-today__grid">
                <section className="biz-today__main" aria-label="Today's schedule">
                    <StaffFilter members={isOwner ? bookableMembers : []} value={staffFilter} onChange={setStaffFilter} />
                    {error && <p className="biz-error" role="alert">{error}</p>}
                    {loading ? (
                        <div className="biz-state"><span className="spinner" /> Loading today</div>
                    ) : (
                        <>
                            {counted.length === 0 && (
                                <p className="biz-empty">No bookings yet today. The free times below are ready to book.</p>
                            )}
                            <Agenda
                                dateKey={now.dateKey}
                                bookings={visible}
                                blocks={blocks}
                                hours={hours}
                                staff={staff}
                                members={bookableMembers}
                                nowMinutes={now.minutes}
                                onBook={book}
                                onOpen={openBooking}
                                onConfirm={confirm}
                            />
                        </>
                    )}
                </section>

                <aside className="biz-today__side">
                    {pending.length > 0 && (
                        <section className="biz-panel" aria-labelledby="pending-title">
                            <h2 id="pending-title" className="biz-subhead">Waiting for you</h2>
                            <ul className="biz-pending">
                                {pending.map((b) => (
                                    <li key={b.id}>
                                        <button type="button" className="biz-pending__open" onClick={() => openBooking(b)}>
                                            <span className="biz-num">{b.appointment_time.slice(0, 5)}</span>
                                            <span>{b.client_name}</span>
                                        </button>
                                        <button type="button" className="btn btn--secondary btn--sm" onClick={() => confirm(b)}>Confirm</button>
                                    </li>
                                ))}
                            </ul>
                        </section>
                    )}
                    <section className="biz-panel" aria-label="Your booking link">
                        <ShareLink business={business} />
                    </section>
                </aside>
            </div>
        </div>
    )
}

export default Today
` },
    { path: 'src/services/business.js', content: `import { supabase } from '../config/supabase'
import { parseDateKey, toDateKey } from './dates'

export const ACTIVE_STATUSES = ['pending', 'confirmed']

export const STATUS_LABEL = {
    pending: 'Needs confirming',
    confirmed: 'Confirmed',
    completed: 'Completed',
    cancelled: 'Cancelled',
    no_show: 'No-show',
}

const KNOWN_ERRORS = ['23P01', '22023', 'P0002', '42501', '28000']

export const friendlyError = (error) =>
    KNOWN_ERRORS.includes(error?.code) ? error.message : 'Something went wrong. Try again.'

export const zonedNow = (timeZone) => {
    const parts = Object.fromEntries(
        new Intl.DateTimeFormat('en-GB', {
            timeZone,
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            hourCycle: 'h23',
        }).formatToParts(new Date()).map((part) => [part.type, part.value])
    )
    return {
        dateKey: \`\${parts.year}-\${parts.month}-\${parts.day}\`,
        minutes: Number(parts.hour) * 60 + Number(parts.minute),
    }
}

export const addDays = (dateKey, days) => {
    const date = parseDateKey(dateKey)
    date.setDate(date.getDate() + days)
    return toDateKey(date)
}

export const startOfWeek = (dateKey) => {
    const date = parseDateKey(dateKey)
    const offset = (date.getDay() + 6) % 7
    date.setDate(date.getDate() - offset)
    return toDateKey(date)
}

export const formatDay = (dateKey, options = { weekday: 'long', day: 'numeric', month: 'long' }) =>
    parseDateKey(dateKey).toLocaleDateString('en-GB', options)

export const shortTime = (time) => (time || '').slice(0, 5)

export const minutesToLabel = (total) =>
    \`\${String(Math.floor(total / 60)).padStart(2, '0')}:\${String(total % 60).padStart(2, '0')}\`

const money = new Intl.NumberFormat('en-IE', { style: 'currency', currency: 'EUR' })
export const formatMoney = (value) => money.format(Number(value) || 0)

export const loadWorkspace = async (businessId) => {
    const [business, members, services, hours] = await Promise.all([
        supabase.from('businesses')
            .select('id, business_name, slug, timezone, is_active, city, phone')
            .eq('id', businessId)
            .single(),
        supabase.from('business_members')
            .select('id, user_id, role, display_name, status, is_bookable, sort_order')
            .eq('business_id', businessId)
            .eq('status', 'active')
            .order('sort_order')
            .order('created_at'),
        supabase.from('services')
            .select('id, service_name, duration_minutes, price, is_active')
            .eq('business_id', businessId)
            .order('service_name'),
        supabase.from('availability')
            .select('id, staff_id, day_of_week, start_time, end_time')
            .eq('business_id', businessId)
            .eq('is_active', true),
    ])
    for (const result of [business, members, services, hours]) {
        if (result.error) throw result.error
    }
    return {
        business: business.data,
        members: members.data,
        services: services.data,
        hours: hours.data,
    }
}

export const loadBookings = async (businessId, fromKey, toKey) => {
    const { data, error } = await supabase
        .from('appointments')
        .select('id, staff_id, service_id, appointment_date, appointment_time, duration_minutes, status, source, client_name, client_phone, client_email, notes, services(service_name, price)')
        .eq('business_id', businessId)
        .gte('appointment_date', fromKey)
        .lte('appointment_date', toKey)
        .order('appointment_date')
        .order('appointment_time')
    if (error) throw error
    return data
}

export const loadBlocks = async (businessId, fromKey, toKey) => {
    const { data, error } = await supabase
        .from('time_blocks')
        .select('id, staff_id, starts_at, ends_at, reason')
        .eq('business_id', businessId)
        .lt('starts_at', \`\${addDays(toKey, 1)}T00:00:00\`)
        .gt('ends_at', \`\${fromKey}T00:00:00\`)
    if (error) throw error
    return data
}

export const setBookingStatus = async (id, status) => {
    const { data, error } = await supabase
        .from('appointments')
        .update({ status })
        .eq('id', id)
        .select('id')
    if (error) throw error
    if (!data || data.length === 0) throw new Error('Update returned 0 rows for booking ' + id)
}

export const addBooking = async ({ businessId, serviceId, staffId, date, time, name, phone, email, notes }) => {
    const { data, error } = await supabase.rpc('owner_book_appointment', {
        p_business_id: businessId,
        p_service_id: serviceId,
        p_staff_id: staffId,
        p_date: date,
        p_time: time,
        p_client_name: name,
        p_client_phone: phone || null,
        p_client_email: email || null,
        p_notes: notes || null,
    })
    if (error) throw error
    return data
}

export const moveBooking = async ({ id, date, time, staffId }) => {
    const { error } = await supabase.rpc('reschedule_appointment', {
        p_appointment_id: id,
        p_date: date,
        p_time: time,
        p_staff_id: staffId || null,
    })
    if (error) throw error
}

export const getSlots = async ({ businessId, serviceId, date, staffId }) => {
    const { data, error } = await supabase.rpc('get_available_slots', {
        p_business_id: businessId,
        p_service_id: serviceId,
        p_date: date,
        p_staff_id: staffId || null,
    })
    if (error) throw error
    return data || []
}

export const bookingStart = (booking) => {
    const [hours, minutes] = booking.appointment_time.split(':').map(Number)
    return hours * 60 + minutes
}

export const whatsappLink = (phone, text = '') => {
    const digits = (phone || '').replace(/[^\\d]/g, '').replace(/^00/, '')
    if (!digits) return null
    return \`https://wa.me/\${digits}\${text ? \`?text=\${encodeURIComponent(text)}\` : ''}\`
}

export const windowsFor = (hours, memberId, weekday) => {
    const own = memberId ? hours.filter((h) => h.staff_id === memberId) : []
    const source = own.length > 0 ? own : hours.filter((h) => !h.staff_id)
    return source
        .filter((h) => h.day_of_week === weekday)
        .map((h) => {
            const [sh, sm] = h.start_time.split(':').map(Number)
            const [eh, em] = h.end_time.split(':').map(Number)
            return [sh * 60 + sm, eh * 60 + em]
        })
        .sort((a, b) => a[0] - b[0])
}

export const blockMinutes = (block, dateKey) => {
    const dayStart = new Date(\`\${dateKey}T00:00:00\`).getTime()
    const from = Math.max(0, (new Date(block.starts_at).getTime() - dayStart) / 60000)
    const to = Math.min(24 * 60, (new Date(block.ends_at).getTime() - dayStart) / 60000)
    return [from, to]
}

export const durationLabel = (minutes) => {
    const h = Math.floor(minutes / 60)
    const m = minutes % 60
    if (!h) return \`\${m} min\`
    return m ? \`\${h} h \${m} min\` : \`\${h} h\`
}
` },
    { path: 'src/styles/business/calendar.css', content: `.biz-datenav {
    display: flex;
    align-items: center;
    gap: var(--space-2);
}

.biz-datenav__pick {
    margin-left: auto;
}

.biz-datenav__pick .biz-input {
    min-height: 44px;
    width: auto;
}

.biz-week {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
}

.biz-week__day {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
    padding: var(--space-3);
    border: 1px solid var(--border-subtle);
    border-radius: var(--radius-md);
    background: var(--surface-1);
}

.biz-week__day.is-today {
    border-color: var(--signal);
}

.biz-week__head {
    display: flex;
    align-items: baseline;
    gap: var(--space-2);
    padding: 0;
    border: 0;
    background: none;
    color: var(--text-primary);
    font-family: var(--font-body);
    text-align: left;
    cursor: pointer;
}

.biz-week__head:focus-visible,
.biz-week__item:focus-visible,
.biz-week__add:focus-visible {
    outline: 2px solid var(--azure);
    outline-offset: 2px;
}

.biz-week__dow {
    color: var(--text-secondary);
    font-size: var(--text-sm);
}

.biz-week__date {
    font-size: var(--text-lg);
}

.biz-week__count {
    margin-left: auto;
    color: var(--text-muted);
    font-family: var(--font-mono);
    font-size: var(--text-xs);
}

.biz-week__list {
    display: flex;
    flex-direction: column;
    gap: var(--space-1);
    margin: 0;
    padding: 0;
    list-style: none;
}

.biz-week__item {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    width: 100%;
    min-height: 40px;
    padding: 0 var(--space-2);
    border: 0;
    border-left: 3px solid var(--azure);
    border-radius: var(--radius-xs);
    background: var(--surface-2);
    color: var(--text-primary);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    text-align: left;
    cursor: pointer;
}

.biz-week__item--pending { border-left-color: var(--signal); }
.biz-week__item--completed { border-left-color: var(--success); color: var(--text-secondary); }
.biz-week__item--no_show { border-left-color: var(--danger); color: var(--text-muted); }

.biz-week__client {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.biz-week__add {
    align-self: flex-start;
    min-height: 36px;
    padding: 0 var(--space-3);
    border: 1px dashed var(--border-strong);
    border-radius: var(--radius-sm);
    background: none;
    color: var(--text-secondary);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    cursor: pointer;
}

@media (min-width: 1024px) {
    .biz-week {
        display: grid;
        grid-template-columns: repeat(7, minmax(0, 1fr));
        align-items: start;
    }

    .biz-week__day {
        min-height: 320px;
    }

    .biz-week__item {
        flex-direction: column;
        align-items: flex-start;
        justify-content: center;
        gap: 0;
        min-height: 48px;
        padding: var(--space-1) var(--space-2);
    }

    .biz-week__item .biz-num {
        color: var(--text-secondary);
        font-size: var(--text-xs);
    }

    .biz-week__client {
        width: 100%;
    }
}
` },
    { path: 'src/styles/business/day.css', content: `.biz-dayhead {
    display: flex;
    flex-direction: column;
    gap: var(--space-4);
}

.biz-dayhead__date {
    margin: 0;
    display: flex;
    flex-direction: column;
    font-family: var(--font-display);
    font-size: var(--text-4xl);
    font-weight: var(--font-weight-semibold);
    letter-spacing: var(--tracking-tight);
    line-height: var(--leading-tight);
}

.biz-dayhead__weekday {
    color: var(--text-secondary);
    font-size: var(--text-base);
    font-weight: var(--font-weight-medium);
    letter-spacing: 0;
}

.biz-stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    margin: 0;
    border-top: 1px solid var(--border-subtle);
    border-bottom: 1px solid var(--border-subtle);
}

.biz-stats div {
    padding: var(--space-3) 0;
}

.biz-stats div + div {
    padding-left: var(--space-4);
    border-left: 1px solid var(--border-subtle);
}

.biz-stats dt {
    color: var(--text-muted);
    font-size: var(--text-xs);
}

.biz-stats dd {
    margin: var(--space-1) 0 0;
    font-size: var(--text-xl);
    font-weight: var(--font-weight-medium);
}

.biz-stats .is-warn dd {
    color: var(--signal);
}

.biz-setup {
    padding: var(--space-4);
    border: 1px solid var(--border-medium);
    border-left: 3px solid var(--signal);
    border-radius: var(--radius-md);
    background: var(--surface-1);
}

.biz-setup__list {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
    margin: 0;
    padding: 0;
    list-style: none;
    font-size: var(--text-sm);
}

.biz-setup__list li {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    min-height: 32px;
}

.biz-setup__list li.is-done {
    color: var(--text-muted);
}

.biz-setup__list li.is-done svg {
    color: var(--success);
}

.biz-setup__list a {
    color: var(--azure-link);
}

.biz-setup__dot {
    width: 16px;
    height: 16px;
    border: 1px solid var(--text-muted);
    border-radius: var(--radius-full);
}

.biz-today__grid {
    display: grid;
    gap: var(--space-6);
}

.biz-today__main {
    display: flex;
    flex-direction: column;
    gap: var(--space-4);
    min-width: 0;
}

.biz-today__side {
    display: none;
}

.biz-panel {
    padding: var(--space-5);
    border: 1px solid var(--border-subtle);
    border-radius: var(--radius-lg);
    background: var(--surface-1);
}

.biz-pending {
    display: flex;
    flex-direction: column;
    margin: 0;
    padding: 0;
    list-style: none;
}

.biz-pending li {
    display: flex;
    align-items: center;
    gap: var(--space-3);
    padding: var(--space-2) 0;
    border-top: 1px solid var(--border-subtle);
}

.biz-pending__open {
    flex: 1;
    display: flex;
    gap: var(--space-3);
    min-height: 40px;
    align-items: center;
    padding: 0;
    border: 0;
    background: none;
    color: var(--text-primary);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    text-align: left;
    cursor: pointer;
}

.biz-share__intro {
    margin: 0;
    color: var(--text-secondary);
    font-size: var(--text-sm);
}

.biz-share__link {
    margin: var(--space-1) 0 var(--space-4);
    font-family: var(--font-mono);
    font-size: var(--text-base);
    word-break: break-all;
}

.biz-share__actions {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-2);
}


.biz-agenda {
    display: flex;
    flex-direction: column;
    margin: 0;
    padding: 0;
    list-style: none;
}

.biz-agenda__row {
    display: grid;
    grid-template-columns: 56px 1fr;
    gap: var(--space-3);
    padding: var(--space-1) 0;
}

.biz-agenda__time {
    display: flex;
    flex-direction: column;
    padding-top: var(--space-3);
    font-size: var(--text-base);
    font-weight: var(--font-weight-medium);
}

.biz-agenda__end {
    color: var(--text-muted);
    font-size: var(--text-xs);
    font-weight: var(--font-weight-normal);
}

.biz-agenda__card {
    display: flex;
    align-items: stretch;
    min-width: 0;
    border: 1px solid var(--border-medium);
    border-left: 3px solid var(--azure);
    border-radius: var(--radius-md);
    background: var(--surface-2);
}

.biz-agenda__card--pending { border-left-color: var(--signal); }
.biz-agenda__card--completed { border-left-color: var(--success); background: var(--surface-1); }
.biz-agenda__card--no_show { border-left-color: var(--danger); background: var(--surface-1); }

.biz-agenda__open {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
    padding: var(--space-3) var(--space-4);
    border: 0;
    background: none;
    color: var(--text-primary);
    font-family: var(--font-body);
    text-align: left;
    cursor: pointer;
}

.biz-agenda__who {
    font-family: var(--font-display);
    font-size: var(--text-lg);
    font-weight: var(--font-weight-semibold);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.biz-agenda__what {
    color: var(--text-secondary);
    font-size: var(--text-sm);
}

.biz-agenda__state {
    margin-top: var(--space-1);
    font-size: var(--text-xs);
    font-weight: var(--font-weight-medium);
}

.biz-agenda__state--pending { color: var(--signal); }
.biz-agenda__state--completed { color: var(--success); }
.biz-agenda__state--no_show { color: var(--danger); }

.biz-agenda__confirm {
    align-self: center;
    margin-right: var(--space-3);
    min-height: 40px;
    padding: 0 var(--space-4);
    border: 1px solid var(--signal);
    border-radius: var(--radius-full);
    background: none;
    color: var(--text-primary);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
    cursor: pointer;
}

.biz-agenda__confirm:hover {
    background: var(--surface-3);
}

.biz-agenda__row.is-past .biz-agenda__time,
.biz-agenda__row.is-past .biz-agenda__who {
    color: var(--text-muted);
}

.biz-agenda__row--gap .biz-agenda__time {
    color: var(--text-muted);
    font-weight: var(--font-weight-normal);
}

.biz-agenda__gap {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--space-3);
    min-height: 48px;
    padding: 0 var(--space-2) 0 var(--space-4);
    border: 1px dashed var(--border-strong);
    border-radius: var(--radius-md);
    color: var(--text-secondary);
    font-size: var(--text-sm);
}

.biz-agenda__len {
    margin-left: var(--space-2);
    color: var(--text-muted);
    font-size: var(--text-xs);
}

.biz-agenda__book {
    min-height: 36px;
    padding: 0 var(--space-4);
    border: 0;
    border-radius: var(--radius-full);
    background: var(--surface-3);
    color: var(--text-primary);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
    cursor: pointer;
}

.biz-agenda__book:hover {
    background: var(--surface-4);
}

.biz-agenda__block {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 0.25em;
    min-height: 44px;
    padding: 0 var(--space-4);
    border-radius: var(--radius-md);
    background: var(--surface-1);
    color: var(--text-muted);
    font-size: var(--text-sm);
}

.biz-agenda__now {
    position: relative;
    display: flex;
    align-items: center;
    height: 24px;
    margin: var(--space-1) 0;
}

.biz-agenda__now::after {
    content: '';
    flex: 1;
    height: 2px;
    margin-left: var(--space-2);
    background: var(--signal);
}

.biz-agenda__now span {
    padding: 2px var(--space-2);
    border-radius: var(--radius-xs);
    background: var(--signal);
    color: var(--surface-0);
    font-size: var(--text-xs);
    font-weight: var(--font-weight-medium);
}

.biz-agenda__open:focus-visible,
.biz-agenda__confirm:focus-visible,
.biz-agenda__book:focus-visible,
.biz-pending__open:focus-visible {
    outline: 2px solid var(--azure);
    outline-offset: 2px;
}


.biz-rail {
    max-height: calc(100vh - 280px);
    min-height: 360px;
    overflow-y: auto;
    border: 1px solid var(--border-subtle);
    border-radius: var(--radius-lg);
    background: var(--surface-0);
}

.biz-rail__heads {
    position: sticky;
    top: 0;
    z-index: 3;
    display: flex;
    background: var(--surface-1);
    border-bottom: 1px solid var(--border-medium);
}

.biz-rail__heads .biz-rail__gutter {
    width: 64px;
}

.biz-rail__head {
    flex: 1 1 0;
    min-width: 0;
    padding: var(--space-3);
    border-left: 1px solid var(--border-subtle);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-semibold);
}

.biz-rail__body {
    position: relative;
    display: flex;
    box-sizing: content-box;
    padding: var(--space-3) 0;
}

.biz-rail__gutter {
    position: relative;
    flex: none;
    width: 64px;
}

.biz-rail__hour {
    position: absolute;
    right: var(--space-3);
    transform: translateY(-50%);
    color: var(--text-secondary);
    font-family: var(--font-mono);
    font-size: var(--text-xs);
}

.biz-rail__col {
    position: relative;
    flex: 1 1 0;
    min-width: 0;
    border-left: 1px solid var(--border-subtle);
    cursor: copy;
}

.biz-rail__line {
    position: absolute;
    left: 0;
    right: 0;
    height: 1px;
    background: var(--border-subtle);
    pointer-events: none;
}

.biz-rail__open {
    position: absolute;
    left: 0;
    right: 0;
    background: var(--surface-2);
    pointer-events: none;
}

.biz-rail__block {
    position: absolute;
    left: 6px;
    right: 6px;
    z-index: 1;
    padding: var(--space-1) var(--space-2);
    border: 1px dashed var(--border-strong);
    border-radius: var(--radius-sm);
    background: var(--surface-0);
    color: var(--text-muted);
    font-size: var(--text-xs);
    pointer-events: none;
    overflow: hidden;
}

.biz-booking {
    position: absolute;
    left: 6px;
    right: 6px;
    z-index: 2;
    display: flex;
    flex-direction: column;
    gap: 2px;
    padding: var(--space-2) var(--space-3);
    overflow: hidden;
    border: 1px solid var(--border-strong);
    border-left: 3px solid var(--azure);
    border-radius: var(--radius-sm);
    background: var(--surface-4);
    color: var(--text-primary);
    font-family: var(--font-body);
    text-align: left;
    cursor: pointer;
}

.biz-booking:focus-visible {
    outline: 2px solid var(--azure);
    outline-offset: 1px;
}

.biz-booking--pending { border-left-color: var(--signal); }
.biz-booking--completed { border-left-color: var(--success); background: var(--surface-3); color: var(--text-secondary); }
.biz-booking--no_show { border-left-color: var(--danger); background: var(--surface-3); color: var(--text-muted); }
.biz-booking--no_show .biz-booking__who { text-decoration: line-through; }

.biz-booking__time {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    color: var(--text-secondary);
    font-family: var(--font-mono);
    font-size: var(--text-xs);
}

.biz-booking__flag {
    color: var(--signal);
    font-family: var(--font-body);
}

.biz-booking__who {
    font-size: var(--text-sm);
    font-weight: var(--font-weight-semibold);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.biz-booking__what {
    color: var(--text-secondary);
    font-size: var(--text-xs);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.biz-booking--compact {
    flex-direction: row;
    align-items: center;
    gap: var(--space-2);
    padding-top: 0;
    padding-bottom: 0;
}

.biz-booking--compact .biz-booking__what,
.biz-booking--compact .biz-booking__flag {
    display: none;
}

.biz-rail__now {
    position: absolute;
    left: 64px;
    right: 0;
    z-index: 4;
    height: 2px;
    background: var(--signal);
    pointer-events: none;
}

.biz-rail__now-label {
    position: absolute;
    left: -60px;
    top: -10px;
    padding: 2px var(--space-1);
    border-radius: var(--radius-xs);
    background: var(--signal);
    color: var(--surface-0);
    font-family: var(--font-mono);
    font-size: var(--text-xs);
    font-weight: var(--font-weight-medium);
}

@media (min-width: 1024px) {
    .biz-dayhead {
        flex-direction: row;
        align-items: flex-end;
        justify-content: space-between;
    }

    .biz-stats {
        min-width: 420px;
        border: 0;
    }

    .biz-today__grid {
        grid-template-columns: minmax(0, 1fr) 320px;
        align-items: start;
    }

    .biz-today__side {
        position: sticky;
        top: calc(56px + var(--space-6));
        display: flex;
        flex-direction: column;
        gap: var(--space-4);
    }
}
` },
    { path: 'src/styles/business/shell.css', content: `.biz-shell,
.biz-bare {
    min-height: 100vh;
    min-height: 100dvh;
    background: var(--surface-0);
    color: var(--text-primary);
    font-family: var(--font-body);
}

.biz-wordmark {
    font-family: var(--font-display);
    font-weight: var(--font-weight-semibold);
    font-size: var(--text-lg);
    letter-spacing: var(--tracking-tight);
}

.biz-wordmark__accent {
    color: var(--azure);
}

.biz-num {
    font-family: var(--font-mono);
    font-variant-numeric: tabular-nums;
}

.biz-muted {
    color: var(--text-muted);
}

.biz-visually-hidden {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip: rect(0 0 0 0);
    white-space: nowrap;
}

.biz-sidebar {
    display: none;
}

.biz-topbar {
    position: sticky;
    top: 0;
    z-index: var(--z-header);
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--space-3);
    height: 56px;
    padding: 0 var(--space-4);
    padding-top: env(safe-area-inset-top, 0px);
    box-sizing: content-box;
    background: var(--surface-0);
    border-bottom: 1px solid var(--border-subtle);
}

.biz-topbar__name {
    font-family: var(--font-display);
    font-weight: var(--font-weight-semibold);
    font-size: var(--text-base);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.biz-topbar__new {
    display: none;
}

.biz-topbar__share {
    flex: none;
    width: 40px;
    height: 40px;
}

.biz-content {
    padding: var(--space-4) var(--space-4) calc(96px + env(safe-area-inset-bottom, 0px));
}

.biz-page {
    max-width: 960px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    gap: var(--space-4);
}

.biz-page__head {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: var(--space-3);
}

.biz-page__title {
    margin: 0;
    font-family: var(--font-display);
    font-size: var(--text-3xl);
    font-weight: var(--font-weight-semibold);
    letter-spacing: var(--tracking-tight);
    line-height: var(--leading-tight);
}

.biz-page__sub {
    margin: var(--space-1) 0 0;
    color: var(--text-secondary);
    font-size: var(--text-sm);
}

.biz-subhead {
    margin: 0 0 var(--space-2);
    font-family: var(--font-display);
    font-size: var(--text-base);
    font-weight: var(--font-weight-semibold);
}

.biz-state {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: var(--space-3);
    min-height: 40vh;
    color: var(--text-secondary);
    font-size: var(--text-sm);
}

.biz-empty {
    margin: 0;
    color: var(--text-secondary);
    font-size: var(--text-sm);
}

.biz-error {
    margin: 0;
    padding: var(--space-3);
    border: 1px solid var(--danger);
    border-radius: var(--radius-md);
    color: var(--text-primary);
    font-size: var(--text-sm);
}

.biz-hint {
    margin: 0;
    color: var(--text-muted);
    font-size: var(--text-sm);
}

.biz-tabbar {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: var(--z-header);
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    padding-bottom: env(safe-area-inset-bottom, 0px);
    background: var(--surface-1);
    border-top: 1px solid var(--border-medium);
}

.biz-tab {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 2px;
    min-height: 56px;
    padding: var(--space-1) 0;
    border: 0;
    background: none;
    color: var(--text-muted);
    font-family: var(--font-body);
    font-size: 11px;
    font-weight: var(--font-weight-medium);
    text-decoration: none;
    cursor: pointer;
}

.biz-tab.active {
    color: var(--text-primary);
}

.biz-tab.active svg {
    color: var(--azure);
}

.biz-tab:focus-visible,
.biz-navlink:focus-visible,
.biz-icon-btn:focus-visible,
.biz-fab:focus-visible,
.biz-chip:focus-visible,
.biz-option:focus-visible,
.biz-day:focus-visible,
.biz-slot:focus-visible,
.biz-seg__btn:focus-visible,
.biz-textbtn:focus-visible {
    outline: 2px solid var(--azure);
    outline-offset: 2px;
}

.biz-fab {
    position: fixed;
    right: var(--space-4);
    bottom: calc(72px + env(safe-area-inset-bottom, 0px));
    z-index: var(--z-header);
    display: grid;
    place-items: center;
    width: 56px;
    height: 56px;
    border: 0;
    border-radius: var(--radius-full);
    background: var(--azure);
    color: var(--text-primary);
    box-shadow: var(--shadow-md);
    cursor: pointer;
}

.biz-fab:active {
    background: var(--azure-soft);
}

.biz-navlink {
    display: flex;
    align-items: center;
    gap: var(--space-3);
    width: 100%;
    min-height: 44px;
    padding: 0 var(--space-3);
    border: 0;
    border-radius: var(--radius-md);
    background: none;
    color: var(--text-secondary);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
    text-align: left;
    text-decoration: none;
    cursor: pointer;
}

.biz-navlink:hover {
    background: var(--surface-2);
    color: var(--text-primary);
}

.biz-navlink.active {
    background: var(--surface-2);
    color: var(--text-primary);
}

.biz-navlink.active svg {
    color: var(--azure);
}

.biz-morelist {
    display: flex;
    flex-direction: column;
    gap: var(--space-1);
}

.biz-icon-btn {
    display: grid;
    place-items: center;
    width: 44px;
    height: 44px;
    border: 1px solid var(--border-medium);
    border-radius: var(--radius-full);
    background: var(--surface-1);
    color: var(--text-primary);
    cursor: pointer;
}

.biz-icon-btn:hover {
    background: var(--surface-2);
}

.biz-textbtn {
    align-self: flex-start;
    padding: var(--space-2) 0;
    border: 0;
    background: none;
    color: var(--azure-link);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    text-decoration: none;
    cursor: pointer;
}

.biz-chips {
    display: flex;
    gap: var(--space-2);
    overflow-x: auto;
    padding-bottom: var(--space-1);
}

.biz-chip {
    flex: none;
    min-height: 36px;
    padding: 0 var(--space-4);
    border: 1px solid var(--border-medium);
    border-radius: var(--radius-full);
    background: var(--surface-1);
    color: var(--text-secondary);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    cursor: pointer;
}

.biz-chip.is-selected {
    border-color: var(--azure);
    color: var(--text-primary);
}

.biz-seg {
    display: inline-flex;
    padding: 3px;
    border: 1px solid var(--border-medium);
    border-radius: var(--radius-full);
    background: var(--surface-1);
}

.biz-seg__btn {
    min-height: 36px;
    min-width: 64px;
    padding: 0 var(--space-3);
    border: 0;
    border-radius: var(--radius-full);
    background: none;
    color: var(--text-secondary);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
    cursor: pointer;
}

.biz-seg__btn.is-selected {
    background: var(--surface-3);
    color: var(--text-primary);
}

.biz-form {
    display: flex;
    flex-direction: column;
    gap: var(--space-4);
}

.biz-field {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
    min-width: 0;
    margin: 0;
    padding: 0;
    border: 0;
}

.biz-field__label {
    padding: 0;
    color: var(--text-secondary);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
}

.biz-optional {
    color: var(--text-muted);
    font-weight: var(--font-weight-normal);
}

.biz-field-row {
    display: grid;
    grid-template-columns: 1fr;
    gap: var(--space-4);
}

.biz-input {
    width: 100%;
    min-height: 48px;
    padding: 0 var(--space-3);
    border: 1px solid var(--border-medium);
    border-radius: var(--radius-md);
    background: var(--surface-1);
    color: var(--text-primary);
    font-family: var(--font-body);
    font-size: 16px;
    color-scheme: dark;
}

.biz-input:focus {
    outline: none;
    border-color: var(--azure);
}

.biz-input--area {
    min-height: 72px;
    padding: var(--space-3);
    resize: vertical;
}

.biz-options {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
}

.biz-option {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    gap: var(--space-3);
    min-height: 52px;
    padding: 0 var(--space-4);
    border: 1px solid var(--border-medium);
    border-radius: var(--radius-md);
    background: var(--surface-1);
    color: var(--text-primary);
    font-family: var(--font-body);
    text-align: left;
    cursor: pointer;
    align-items: center;
}

.biz-option.is-selected {
    border-color: var(--azure);
    background: var(--surface-2);
}

.biz-option__name {
    font-size: var(--text-base);
    font-weight: var(--font-weight-medium);
}

.biz-option__meta {
    color: var(--text-secondary);
    font-size: var(--text-sm);
    white-space: nowrap;
}

.biz-days,
.biz-slotrow {
    display: flex;
    gap: var(--space-2);
    overflow-x: auto;
    margin: 0 calc(-1 * var(--space-4));
    padding: 2px var(--space-4) var(--space-1);
    scrollbar-width: none;
}

.biz-days::-webkit-scrollbar,
.biz-slotrow::-webkit-scrollbar {
    display: none;
}

.biz-day {
    flex: none;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 2px;
    width: 72px;
    height: 64px;
    border: 1px solid var(--border-medium);
    border-radius: var(--radius-md);
    background: var(--surface-1);
    color: var(--text-primary);
    font-family: var(--font-body);
    cursor: pointer;
}

.biz-day__name {
    color: var(--text-secondary);
    font-size: var(--text-xs);
}

.biz-day__num {
    font-size: var(--text-lg);
}

.biz-day.is-selected {
    border-color: var(--azure);
    background: var(--azure);
}

.biz-day.is-selected .biz-day__name {
    color: var(--text-primary);
}

.biz-slotgroups {
    display: flex;
    flex-direction: column;
    gap: var(--space-3);
}

.biz-slotgroup__label {
    display: block;
    margin-bottom: var(--space-1);
    color: var(--text-muted);
    font-size: var(--text-xs);
}

.biz-slotrow .biz-slot {
    flex: none;
    width: 72px;
}

.biz-client .biz-input + .biz-input,
.biz-client .biz-field-row {
    margin-top: 0;
}

.biz-slots {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(72px, 1fr));
    gap: var(--space-2);
    max-height: 212px;
    overflow-y: auto;
}

.biz-slot {
    min-height: 44px;
    border: 1px solid var(--border-medium);
    border-radius: var(--radius-md);
    background: var(--surface-1);
    color: var(--text-primary);
    font-family: var(--font-mono);
    font-size: var(--text-sm);
    cursor: pointer;
}

.biz-slot.is-selected {
    border-color: var(--azure);
    background: var(--azure);
}

.biz-sheet {
    position: fixed;
    inset: 0;
    z-index: var(--z-modal);
    display: flex;
    align-items: flex-end;
    background: rgba(8, 9, 12, 0.72);
}

.biz-sheet__panel {
    display: flex;
    flex-direction: column;
    width: 100%;
    max-height: 92dvh;
    background: var(--surface-1);
    border-top: 1px solid var(--border-medium);
    border-radius: var(--radius-xl) var(--radius-xl) 0 0;
    animation: biz-sheet-up var(--transition-base);
}

.biz-sheet__panel:focus {
    outline: none;
}

.biz-sheet__head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--space-3);
    padding: var(--space-4) var(--space-4) var(--space-2);
}

.biz-sheet__title {
    margin: 0;
    font-family: var(--font-display);
    font-size: var(--text-xl);
    font-weight: var(--font-weight-semibold);
}

.biz-sheet__body {
    flex: 1;
    overflow-y: auto;
    padding: var(--space-2) var(--space-4) var(--space-4);
    display: flex;
    flex-direction: column;
    gap: var(--space-4);
}

.biz-sheet__foot {
    padding: var(--space-3) var(--space-4) calc(var(--space-3) + env(safe-area-inset-bottom, 0px));
    border-top: 1px solid var(--border-subtle);
}

@keyframes biz-sheet-up {
    from { transform: translateY(24px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

.biz-facts {
    display: flex;
    flex-direction: column;
    gap: var(--space-3);
    margin: 0;
}

.biz-facts div {
    display: grid;
    grid-template-columns: 72px 1fr;
    gap: var(--space-3);
}

.biz-facts dt {
    color: var(--text-muted);
    font-size: var(--text-sm);
}

.biz-facts dd {
    margin: 0;
    font-size: var(--text-sm);
}

.biz-status {
    display: inline-flex;
    align-items: center;
    gap: var(--space-2);
}

.biz-status::before {
    content: '';
    width: 8px;
    height: 8px;
    border-radius: var(--radius-full);
    background: var(--text-subtle);
}

.biz-status--pending::before { background: var(--signal); }
.biz-status--confirmed::before { background: var(--azure); }
.biz-status--completed::before { background: var(--success); }
.biz-status--no_show::before { background: var(--danger); }

.biz-contact {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(96px, 1fr));
    gap: var(--space-2);
}

.biz-contact__btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: var(--space-2);
    min-height: 48px;
    border: 1px solid var(--border-medium);
    border-radius: var(--radius-md);
    background: var(--surface-2);
    color: var(--text-primary);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
    text-decoration: none;
}

.biz-actions {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: var(--space-2);
}

.biz-actions .btn:first-child {
    grid-column: 1 / -1;
}

.biz-move {
    padding-top: var(--space-4);
    border-top: 1px solid var(--border-subtle);
}

.biz-toast {
    position: fixed;
    left: 50%;
    bottom: calc(140px + env(safe-area-inset-bottom, 0px));
    z-index: var(--z-tooltip);
    transform: translateX(-50%);
    pointer-events: none;
}

.biz-toast__msg {
    display: block;
    padding: var(--space-3) var(--space-5);
    border: 1px solid var(--border-strong);
    border-radius: var(--radius-full);
    background: var(--surface-3);
    color: var(--text-primary);
    font-size: var(--text-sm);
    white-space: nowrap;
}

@media (min-width: 640px) {
    .biz-field-row {
        grid-template-columns: 1fr 1fr;
    }
}

@media (min-width: 768px) {
    .biz-sheet {
        align-items: stretch;
        justify-content: flex-end;
    }

    .biz-sheet__panel {
        width: 440px;
        max-height: none;
        border-top: 0;
        border-left: 1px solid var(--border-medium);
        border-radius: 0;
        animation-name: biz-sheet-in;
    }

    @keyframes biz-sheet-in {
        from { transform: translateX(24px); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
}

@media (min-width: 1024px) {
    .biz-shell {
        display: grid;
        grid-template-columns: 248px 1fr;
    }

    .biz-sidebar {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        width: 248px;
        box-sizing: border-box;
        z-index: var(--z-header);
        display: flex;
        flex-direction: column;
        gap: var(--space-6);
        padding: var(--space-5) var(--space-3);
        background: var(--surface-1);
        border-right: 1px solid var(--border-subtle);
    }

    .biz-sidebar__brand {
        display: flex;
        flex-direction: column;
        gap: var(--space-1);
        padding: 0 var(--space-3);
    }

    .biz-sidebar__business {
        color: var(--text-secondary);
        font-size: var(--text-sm);
    }

    .biz-sidebar__nav {
        display: flex;
        flex-direction: column;
        gap: var(--space-1);
    }

    .biz-sidebar__foot {
        margin-top: auto;
        display: flex;
        flex-direction: column;
        gap: var(--space-1);
    }

    .biz-sidebar__who {
        margin: var(--space-3) 0 0;
        padding: var(--space-3) var(--space-3) 0;
        border-top: 1px solid var(--border-subtle);
        font-size: var(--text-sm);
        display: flex;
        flex-direction: column;
    }

    .biz-sidebar__who span {
        color: var(--text-muted);
        font-size: var(--text-xs);
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .biz-main {
        grid-column: 2;
        min-width: 0;
    }

    .biz-topbar__share,
    .biz-topbar__name {
        display: none;
    }

    .biz-topbar {
        justify-content: flex-end;
    }

    .biz-topbar__new {
        display: inline-flex;
    }

    .biz-tabbar,
    .biz-fab {
        display: none;
    }

    .biz-content {
        padding: var(--space-8) var(--space-10) var(--space-12);
    }

    .biz-page {
        max-width: 1120px;
    }

    .biz-toast {
        bottom: var(--space-8);
    }
}

@media (prefers-reduced-motion: reduce) {
    .biz-sheet__panel {
        animation: none;
    }
}
` },
]

let failed = false

for (const nf of NEW_FILES) {
    if (fs.existsSync(path.join(REPO, nf.path))) { console.error(`[FAIL] Already exists: ${nf.path}`); failed = true }
}
for (const rf of REPLACE_FILES) {
    if (!fs.existsSync(path.join(REPO, rf.path))) { console.error(`[FAIL] Missing, apply the first 4a-2 patch first: ${rf.path}`); failed = true }
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const nf of NEW_FILES) {
    fs.mkdirSync(path.dirname(path.join(REPO, nf.path)), { recursive: true })
    fs.writeFileSync(path.join(REPO, nf.path), nf.content)
    console.log(`[NEW] ${nf.path}`)
}
for (const rf of REPLACE_FILES) {
    const full = path.join(REPO, rf.path)
    fs.writeFileSync(`${full}.backup`, fs.readFileSync(full))
    fs.writeFileSync(full, rf.content)
    console.log(`[REPLACE] ${rf.path}`)
}

console.log('\n[DONE]')
