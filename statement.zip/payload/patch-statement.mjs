import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const SPEC = {
  "name": "statement",
  "backup": ".backup-statement",
  "prefixes": [
    "lc-ins-stmt"
  ],
  "newFiles": [
    "supabase/migrations/weekly-statement.sql",
    "supabase/queries/weekly-statement-verify.sql",
    "supabase/functions/notify/emails/statement.ts",
    "src/components/insights/Statement.jsx"
  ],
  "replaceFiles": [],
  "patches": [
    {
      "file": "supabase/functions/notify/blocks.ts",
      "find": "// Someone's words: the client's review, the owner's reply.",
      "replace": "// A fee that would have applied, struck through.\nexport const fee = (text: string) => note('fee', SOLID, text, { gap: true, strike: true })\n\n// Visits counted that never carry a fee.\nexport const added = (text: string) => note('added', DASHED, text, { lineHeight: '1.4' })\n\n// Someone's words: the client's review, the owner's reply."
    },
    {
      "file": "supabase/functions/notify/emails/index.ts",
      "find": "import { BOOKING } from './booking.ts'\n",
      "replace": "import { BOOKING } from './booking.ts'\nimport { STATEMENT } from './statement.ts'\n"
    },
    {
      "file": "supabase/functions/notify/emails/index.ts",
      "find": "{ ...ACCOUNT, ...BOOKING }",
      "replace": "{ ...ACCOUNT, ...BOOKING, ...STATEMENT }"
    },
    {
      "file": "tests/suites/emails.mjs",
      "find": "    ['booking_request', { audience: 'business', status: 'pending', moved_from: '2026-09-30T11:00' }],\n]",
      "replace": "    ['booking_request', { audience: 'business', status: 'pending', moved_from: '2026-09-30T11:00' }],\n    ['weekly_statement', { audience: 'business', ...WEEK }],\n    ['weekly_statement', { audience: 'business', ...WEEK, online: { count: 0, value: 0 }, fee: 0, name: null }],\n    ['weekly_statement', { audience: 'business', ...WEEK, from: '2026-09-28', to: '2026-10-04', country: 'NG', fee: null, online: { count: 1, value: 15000 }, added: { count: 0, value: 0 } }],\n]"
    },
    {
      "file": "tests/suites/emails.mjs",
      "find": "const tomorrow = () =>",
      "replace": "const WEEK = { from: '2026-09-21', to: '2026-09-27', online: { count: 12, value: 286.5 }, added: { count: 4, value: 72 }, fee: 10.71, due: 0, beta: true }\n\nconst tomorrow = () =>"
    },
    {
      "file": "tests/suites/emails.mjs",
      "find": "        if (kind === 'review_new') {",
      "replace": "        if (kind === 'weekly_statement') {\n            const online = extra.online.count > 0\n            const priced = extra.fee !== null\n            check(/You pay/.test(msg.html) && /Free during the beta/.test(msg.html) && /statement, not a bill/.test(msg.text), `${label} says there is nothing to pay and that it is not a bill`)\n            check((online && priced) === /line-through;[^>]*>\\s*LocAppoint fee/.test(msg.html), `${label} strikes the fee only when there is one`)\n            check(extra.added.count > 0 === /Never a fee/.test(msg.html), `${label} lists walk-ins as never carrying a fee`)\n            check(new RegExp(`/portal/insights\\\\?statement=${extra.from}`).test(msg.html), `${label} opens the statement in Insights`)\n            check(/to pay$/.test(msg.subject) && (extra.country === 'NG' ? /NGN|\\u20A6/.test(msg.subject) : /\\u20AC0 to pay/.test(msg.subject)), `${label} subject ends on what is owed: ${msg.subject}`)\n            check(!msg.attachments, `${label} carries no calendar invite`)\n        }\n        if (kind === 'review_new') {"
    },
    {
      "file": "src/services/insights.js",
      "find": "// What reminders did in the period.",
      "replace": "// The weekly statement: 1 is last week. Owner only.\nexport const loadStatement = async (businessId, weeksBack = 1) => {\n    const { data, error } = await supabase.rpc('week_statement', { p_business_id: businessId, p_weeks_back: weeksBack })\n    if (error) throw error\n    return data\n}\n\n// What reminders did in the period."
    },
    {
      "file": "src/pages/business/Insights.jsx",
      "find": "import { Heatmap } from '../../components/insights/Heatmap'\n",
      "replace": "import { Heatmap } from '../../components/insights/Heatmap'\nimport { Statement } from '../../components/insights/Statement'\n"
    },
    {
      "file": "src/pages/business/Insights.jsx",
      "find": "            {state.status === 'loading' && (\n                <div className=\"lc-ins__skel\" aria-hidden=\"true\">",
      "replace": "            <Statement businessId={business.id} country={business.country} money={money} />\n\n            {state.status === 'loading' && (\n                <div className=\"lc-ins__skel\" aria-hidden=\"true\">"
    },
    {
      "file": "src/styles/business/insights.css",
      "find": "/* Tooltip */\n",
      "replace": "/* Weekly statement: a slip, lines then a total under a dashed rule, like the booking ticket. */\n\n.lc-ins-stmt {\n    display: flex;\n    flex-direction: column;\n    gap: var(--space-4);\n    min-width: 0;\n    padding: var(--space-5) var(--space-4);\n    border-radius: var(--lc-r-xl);\n    background: var(--lc-card);\n    box-shadow: inset 0 0 0 1px var(--lc-line);\n    scroll-margin-top: var(--space-6);\n    transition: opacity var(--lc-base) var(--lc-ease);\n}\n\n.lc-ins-stmt.is-refreshing { opacity: 0.55; }\n\n.lc-ins-stmt__skel { display: block; height: 220px; border-radius: var(--lc-r-xl); }\n\n.lc-ins-stmt__head {\n    display: flex;\n    align-items: flex-start;\n    justify-content: space-between;\n    gap: var(--space-3);\n}\n\n.lc-ins-stmt__head h2 {\n    margin: 0;\n    color: var(--lc-ink-1);\n    font-size: var(--lc-t-heading);\n    font-weight: var(--font-weight-semibold);\n}\n\n.lc-ins-stmt__range {\n    display: flex;\n    flex-wrap: wrap;\n    align-items: baseline;\n    gap: var(--space-1) var(--space-2);\n    margin: var(--space-1) 0 0;\n    color: var(--lc-ink-2);\n    font-size: var(--lc-t-label);\n}\n\n.lc-ins-stmt__pt {\n    color: var(--lc-ink-3);\n    font-family: var(--lc-font-mono);\n    font-size: 12px;\n}\n\n.lc-ins-stmt__nav { display: flex; gap: var(--space-1); }\n\n.lc-ins-stmt__step {\n    display: grid;\n    place-items: center;\n    width: 40px;\n    height: 40px;\n    padding: 0;\n    border: 0;\n    border-radius: var(--radius-full);\n    background: transparent;\n    box-shadow: inset 0 0 0 1px var(--lc-line);\n    color: var(--lc-ink-1);\n    cursor: pointer;\n}\n\n.lc-ins-stmt__step:hover:not(:disabled) { box-shadow: inset 0 0 0 1px var(--lc-line-strong); }\n.lc-ins-stmt__step:focus-visible { outline: 2px solid var(--azure); outline-offset: 2px; }\n.lc-ins-stmt__step:disabled { color: var(--lc-ink-3); cursor: default; opacity: 0.5; }\n\n.lc-ins-stmt__lines {\n    display: flex;\n    flex-direction: column;\n    gap: var(--space-3);\n    margin: 0;\n}\n\n.lc-ins-stmt__lines > div {\n    display: flex;\n    align-items: baseline;\n    justify-content: space-between;\n    gap: var(--space-3);\n}\n\n.lc-ins-stmt__lines dt,\n.lc-ins-stmt__total span {\n    display: flex;\n    flex-direction: column;\n    gap: 2px;\n    min-width: 0;\n    color: var(--lc-ink-1);\n    font-size: var(--lc-t-body);\n    font-weight: var(--font-weight-medium);\n}\n\n.lc-ins-stmt__lines small,\n.lc-ins-stmt__total small {\n    color: var(--lc-ink-3);\n    font-size: var(--lc-t-label);\n    font-weight: var(--font-weight-normal);\n}\n\n.lc-ins-stmt__lines dd {\n    margin: 0;\n    color: var(--lc-ink-1);\n    font-size: var(--lc-t-body);\n    font-weight: var(--font-weight-semibold);\n    white-space: nowrap;\n}\n\n.lc-ins-stmt__lines .is-fee dd { color: var(--lc-ink-2); }\n.lc-ins-stmt__lines s { text-decoration-thickness: 1.5px; }\n\n.lc-ins-stmt__total {\n    display: flex;\n    align-items: center;\n    justify-content: space-between;\n    gap: var(--space-3);\n    padding-top: var(--space-4);\n    border-top: 1.5px dashed var(--lc-line-strong);\n}\n\n.lc-ins-stmt__total b {\n    color: var(--lc-success);\n    font-family: var(--lc-font-display);\n    font-size: var(--lc-t-figure);\n    font-weight: var(--font-weight-semibold);\n    line-height: var(--lc-lh-tight);\n    white-space: nowrap;\n}\n\n.lc-ins-stmt__note {\n    margin: 0;\n    color: var(--lc-ink-3);\n    font-size: 12px;\n}\n\n/* Tooltip */\n"
    },
    {
      "file": "src/services/inbox.js",
      "find": "        referral_points: (p) => ({ label: `+${p.points} points`, tone: 'success' }),",
      "replace": "        referral_points: (p) => ({ label: `+${p.points} points`, tone: 'success' }),\n        weekly_statement: () => ({ label: 'Weekly statement', tone: 'info' }),"
    },
    {
      "file": "src/services/inbox.js",
      "find": "    if (item.kind === 'referral_points') return `${p.business_name || 'A business you invited'}: ${String(p.label || '').toLowerCase()}`",
      "replace": "    if (item.kind === 'referral_points') return `${p.business_name || 'A business you invited'}: ${String(p.label || '').toLowerCase()}`\n    if (item.kind === 'weekly_statement') {\n        const n = (Number(p.online?.count) || 0) + (Number(p.added?.count) || 0)\n        return `${n} ${n === 1 ? 'visit' : 'visits'}. You pay ${p.country === 'NG' ? '₦0' : '€0'}, free during the beta.`\n    }"
    },
    {
      "file": "src/services/inbox.js",
      "find": "    if (item.kind === 'referral_points') return '/portal/invite'",
      "replace": "    if (item.kind === 'referral_points') return '/portal/invite'\n    if (item.kind === 'weekly_statement') return `/portal/insights?statement=${p.from || ''}`"
    },
    {
      "file": "src/services/inbox.js",
      "find": "        day: p.date ? shortDay(p.date) : '',\n        title: item.kind === 'referral_points' ? 'Points earned' :",
      "replace": "        day: p.date ? shortDay(p.date) : item.kind === 'weekly_statement' && p.from ? shortDay(p.from) : '',\n        title: item.kind === 'referral_points' ? 'Points earned' : item.kind === 'weekly_statement' ? `Your week, ${shortDay(p.from)} to ${shortDay(p.to)}` :"
    },
    {
      "file": "tests/harness/fakeSupabase.js",
      "find": "// A believable Insights answer for any period",
      "replace": "// Last week's statement, or ?nostatement=1 for a week with no visits.\nconst weekStatement = (back) => {\n  const empty = quiet('nostatement')\n  const monday = new Date(today); monday.setDate(monday.getDate() - ((monday.getDay() + 6) % 7) - 7 * (back || 1))\n  const key = (d) => new Intl.DateTimeFormat('en-CA').format(d)\n  const sunday = new Date(monday); sunday.setDate(sunday.getDate() + 6)\n  return { from: key(monday), to: key(sunday), country: 'PT', online: { count: empty ? 0 : 12, value: empty ? 0 : 286.5 }, added: { count: empty ? 0 : 4, value: empty ? 0 : 72 }, fee: empty ? 0 : 10.71, due: 0, beta: true, weeks_back: back || 1, older: (back || 1) < 3 }\n}\n\n// A believable Insights answer for any period"
    },
    {
      "file": "tests/harness/fakeSupabase.js",
      "find": "if (name === 'reminder_effect') return { data: reminderEffect(), error: null };",
      "replace": "if (name === 'reminder_effect') return { data: reminderEffect(), error: null }; if (name === 'week_statement') return { data: weekStatement(args.p_weeks_back), error: null };"
    },
    {
      "file": "tests/suites/insights.mjs",
      "find": "    check(p.errors.length === 0, `no page errors: ${p.errors.join(' | ')}`)\n    await p.close()\n\n    p = await open(390, 844, '&noinsights=1')",
      "replace": "    check(p.errors.length === 0, `no page errors: ${p.errors.join(' | ')}`)\n    await p.close()\n\n    // Weekly statement\n    p = await open(390, 844)\n    const stmt = () => p.evaluate(() => {\n        const s = document.querySelector('.lc-ins-stmt')\n        return s && { range: s.querySelector('.lc-ins-stmt__range')?.textContent || '', fee: s.querySelector('.is-fee s')?.textContent || '', total: s.querySelector('.lc-ins-stmt__total b')?.textContent || '', lines: s.querySelectorAll('.lc-ins-stmt__lines > div').length, next: s.querySelector('[aria-label=\"Week after\"]')?.disabled }\n    })\n    let s = await stmt()\n    check(s && /^Last week/.test(s.range) && /Resumo semanal/.test(s.range), `the statement opens on last week, named in Portuguese too: ${s?.range}`)\n    check(s?.fee === '\\u20AC10.71' && s.total === '\\u20AC0' && s.lines === 3, `the fee is struck through and nothing is owed: ${s?.fee} ${s?.total}`)\n    check(s?.next === true, 'there is no week after last week')\n    await p.evaluate(() => document.querySelector('.lc-ins-stmt [aria-label=\"Week before\"]').click())\n    await wait(400)\n    s = await stmt()\n    check(/^2 weeks ago/.test(s?.range || '') && (await p.evaluate(() => window.__calls.filter((c) => c[1] === 'week_statement').map((c) => c[2].p_weeks_back))).includes(2), 'stepping back loads the week before')\n    check(await p.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), 'the statement fits a phone')\n    await p.close()\n    p = await open(390, 844, '&nostatement=1')\n    check(await p.evaluate(() => !document.querySelector('.lc-ins-stmt')), 'a week with no visits shows no statement')\n    await p.close()\n\n    p = await open(390, 844, '&noinsights=1')"
    }
  ],
  "retires": []
}

const here = path.dirname(fileURLToPath(import.meta.url))
const root = process.cwd()
const check = process.argv.includes('--check')
const problems = []
const plan = []

const abs = (rel) => path.join(root, ...rel.split('/'))
const source = (rel) => path.join(here, 'files', ...rel.split('/'))
const read = (p) => fs.readFileSync(p, 'utf8')
const eolOf = (text) => (text.includes('\r\n') ? '\r\n' : '\n')
const toEol = (text, eol) => text.replace(/\r\n/g, '\n').replace(/\n/g, eol)
const sha = (text) => crypto.createHash('sha256').update(text.replace(/\r\n/g, '\n')).digest('hex')
const count = (hay, needle) => (needle ? hay.split(needle).length - 1 : 0)

const pkg = JSON.parse(read(abs('package.json')))
if (pkg.name !== 'locappoint') {
    console.error('  [ABORT] This is not the locappoint repo.')
    process.exit(1)
}

for (const rel of SPEC.newFiles) {
    if (fs.existsSync(abs(rel))) problems.push(`${rel} already exists (patch already applied?)`)
    else if (!fs.existsSync(source(rel))) problems.push(`payload is missing ${rel}`)
    else plan.push(['NEW', rel])
}

for (const { file, sha: expected } of SPEC.replaceFiles) {
    if (!fs.existsSync(abs(file))) { problems.push(`${file} is missing`); continue }
    if (sha(read(abs(file))) !== expected) { problems.push(`${file} changed since this patch was built (or it is already applied)`); continue }
    plan.push(['REPLACE', file])
}

const srcFiles = () => {
    const out = []
    const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const full = path.join(dir, entry.name)
            if (entry.isDirectory()) { if (entry.name !== 'node_modules') walk(full) }
            else if (/\.(jsx?|css)$/.test(entry.name)) out.push(full)
        }
    }
    walk(abs('src'))
    return out
}

for (const prefix of SPEC.prefixes || []) {
    const owners = srcFiles().filter((full) => read(full).includes(prefix)).map((full) => path.relative(root, full))
    if (owners.length) problems.push(`class prefix ${prefix} is already used in ${owners.join(', ')}`)
}

const edits = new Map()
for (const p of SPEC.patches) {
    if (!fs.existsSync(abs(p.file))) { problems.push(`${p.file} is missing`); continue }
    if (!edits.has(p.file)) edits.set(p.file, read(abs(p.file)))
    const current = edits.get(p.file)
    const eol = eolOf(current)
    const find = toEol(p.find, eol)
    const hits = count(current, find)
    if (hits !== 1) { problems.push(`${p.file}: anchor matched ${hits} times, expected 1: ${JSON.stringify(p.find.slice(0, 60))}`); continue }
    edits.set(p.file, current.replace(find, () => toEol(p.replace, eol)))
}
for (const file of edits.keys()) plan.push(['EDIT', file])

for (const rel of SPEC.retires) {
    if (!fs.existsSync(abs(rel))) { problems.push(`${rel} is missing`); continue }
    const base = path.basename(rel)
    const stem = /\.(jsx?)$/.test(base) ? base.replace(/\.(jsx?)$/, '') : base
    const pattern = new RegExp(`[\\/'"]${stem.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\.jsx?)?['"]`)
    const planned = (full) => {
        const key = path.relative(root, full).split(path.sep).join('/')
        if (SPEC.replaceFiles.some((f) => f.file === key)) return read(source(key))
        return edits.has(key) ? edits.get(key) : read(full)
    }
    const users = srcFiles().filter((full) => full !== abs(rel) && pattern.test(planned(full))).map((full) => path.relative(root, full))
    if (users.length) problems.push(`${rel} is still imported by ${users.join(', ')}`)
    else plan.push(['RETIRE', rel])
}

if (problems.length) {
    console.error('  [ABORT] Nothing was written:')
    for (const p of problems) console.error(`    ${p}`)
    process.exit(1)
}

if (check) {
    for (const [kind, rel] of plan) console.log(`  [${kind}] ${rel}`)
    console.log('  Checks passed.')
    process.exit(0)
}

for (const [kind, rel] of plan) {
    const target = abs(rel)
    if (kind === 'NEW') {
        fs.mkdirSync(path.dirname(target), { recursive: true })
        fs.copyFileSync(source(rel), target)
    } else if (kind === 'REPLACE') {
        const eol = eolOf(read(target))
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, toEol(read(source(rel)), eol))
    } else if (kind === 'EDIT') {
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, edits.get(rel))
    } else if (kind === 'RETIRE') {
        fs.renameSync(target, target + '.mistake')
    }
    console.log(`  [${kind}] ${rel}`)
}
console.log('  Patch applied.')
