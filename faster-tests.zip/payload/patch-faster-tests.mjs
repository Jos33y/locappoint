import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'

const NAME = 'faster-tests'
const BACKUP = '.backup-tests'
const NEW_FILES = {}
const NEW_BINARY = {}
const REPLACE_FILES = {
    "tests/suites/layout.mjs": {
        "expect": "a363e98afa98a275c0d6421e132cfedcfbe2b2c77fda8382fd73cddff0cfb4a4",
        "content": "export default async ({ browser, url, check, only }) => {\n    const SCREENS = [\n      ['phone-320', 320, 568, true], ['phone-360', 360, 740, true], ['phone-390', 390, 844, true],\n      ['tab-768', 768, 1024, true], ['tab-820', 820, 1180, true], ['tab-1024', 1024, 768, true], ['tab-1180', 1180, 820, true], ['tab-1366', 1366, 1024, true],\n      ['lap-1272x588', 1272, 588, false], ['lap-1280x720', 1280, 720, false], ['lap-1280x800', 1280, 800, false], ['lap-1440x900', 1440, 900, false], ['lap-1920x1080', 1920, 1080, false],\n    ]\n    const PAGES = ['/portal', '/portal/calendar', '/portal/page', '/portal/services', '/portal/hours', '/portal/team', '/portal/channels', '/portal/insights', '/portal/reviews', '/portal/invite', '/portal/settings', '/portal/help', '/portal/start']\n    const QUICK = ['phone-320', 'phone-390', 'tab-1024', 'lap-1272x588']\n    const chosen = SCREENS.filter(([name]) => (only === 'quick' ? QUICK.includes(name) : !only || name.includes(only)))\n    const runScreen = async ([name, w, h, touch]) => {\n      const page = await browser.newPage()\n      const errors = []\n      page.on('pageerror', (e) => errors.push(e.message))\n      await page.setViewport({ width: w, height: h, deviceScaleFactor: 1, hasTouch: touch, isMobile: touch && w < 1024 })\n      for (const path of PAGES) {\n        await page.goto(`${url}/?path=${encodeURIComponent(path)}`, { waitUntil: 'networkidle0' })\n        await page.waitForFunction(() => document.querySelector('.biz-shell') && !document.querySelector('[aria-busy=\"true\"]'), { timeout: 15000 }).catch(() => {})\n        await page.waitForFunction(() => {\n          const bp = document.querySelector('.biz-bp')\n          return !bp || innerWidth < 1272 || bp.classList.contains('is-wide')\n        }, { timeout: 5000 }).catch(() => {})\n        await page.evaluate(() => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r))))\n        const tag = `${name} ${path}`\n        const r = await page.evaluate(() => {\n          const q = (s) => document.querySelector(s)\n          const box = (el) => el && el.getBoundingClientRect()\n          const side = q('.biz-sidebar')\n          const sideOn = side && getComputedStyle(side).display !== 'none'\n          const nav = q('.biz-sidebar__nav')\n          const rows = [...document.querySelectorAll('.biz-sidebar .biz-navlink, .biz-account__btn')].map((el) => ({ t: el.textContent.trim(), b: el.getBoundingClientRect().bottom, top: el.getBoundingClientRect().top, h: el.getBoundingClientRect().height }))\n          const hub = q('.biz-hubnav__track')\n          const tabs = [...document.querySelectorAll('.biz-hubnav__tab')].map((el) => { const l = el.querySelector('.biz-hubnav__label'); const b = el.getBoundingClientRect(); return { t: l.textContent, trunc: l.scrollWidth > l.clientWidth + 0.5, h: b.height, r: b.right, l: b.left, active: el.classList.contains('active') } })\n          const activeRows = [...document.querySelectorAll('.biz-sidebar .biz-navlink.active')].map((el) => el.textContent.trim())\n          return {\n            vw: innerWidth, vh: innerHeight, docW: document.documentElement.scrollWidth,\n            sideOn, navScroll: nav ? nav.scrollHeight - nav.clientHeight : 0, rows,\n            hub: hub && { l: box(hub).left, r: box(hub).right, w: box(hub).width },\n            tabs, activeRows, path: window.__path,\n            acctCurrent: q('.biz-account__btn')?.classList.contains('is-current'),\n            sh: q('.biz-sh') && {\n              small: [...document.querySelectorAll('.biz-sh button, .biz-sh a.ui-btn, .biz-sh [role=switch]')].filter((b) => !b.classList.contains('biz-sched__day')).filter((b) => { const hit = b.classList.contains('biz-sched__switch') && getComputedStyle(b, '::before').content !== 'none' ? 16 : 0; const h = (b.getAttribute('role') === 'switch' && b.closest('.ui-switchrow') ? b.closest('.ui-switchrow') : b).getBoundingClientRect().height + hit; return h > hit && h < 44 }).map((b) => `${b.textContent.trim() || b.getAttribute('aria-label') || b.className} ${Math.round(b.getBoundingClientRect().height)}`),\n              days: (() => { const rs = [...document.querySelectorAll('.biz-sched__day')].map((b) => b.getBoundingClientRect()); return { min: rs.length ? Math.min(...rs.map((r) => r.width)) : 999, rows: new Set(rs.map((r) => Math.round(r.top))).size } })(),\n              spill: [...document.querySelectorAll('.biz-sh__column > *, .biz-sched__card, .biz-svc__item')].filter((e) => e.scrollWidth > e.clientWidth + 1).map((e) => e.className),\n            },\n            bp: q('.biz-bp') && {\n              wide: q('.biz-bp').classList.contains('is-wide'),\n              phone: q('.biz-bp__preview .ui-phone') && (() => { const b = q('.biz-bp__preview .ui-phone').getBoundingClientRect(); return { top: b.top, bottom: b.bottom, w: b.width } })(),\n              cards: [...document.querySelectorAll('.biz-bp__card, .biz-bp__link')].filter((c) => c.scrollWidth > c.clientWidth + 1).map((c) => c.id || c.className),\n              small: [...document.querySelectorAll('.biz-bp button, .biz-bp a.ui-btn, .biz-bp [role=switch]')].filter((b) => !b.closest('.lc-pub--preview') && !b.closest('.ui-sheet')).filter((b) => { const h = (b.getAttribute('role') === 'switch' ? b.closest('.ui-switchrow') : b).getBoundingClientRect().height; return h > 0 && h < 44 }).map((b) => `${b.textContent.trim() || b.getAttribute('aria-label') || b.className} ${Math.round(b.getBoundingClientRect().height)}`),\n              url: (() => { const u = q('.biz-bp__url'); const card = q('.biz-bp__link'); return u.getBoundingClientRect().right <= card.getBoundingClientRect().right })(),\n            },\n          }\n        })\n        check(r.docW <= r.vw, `${tag} horizontal overflow ${r.docW} > ${r.vw}`)\n        const inHub = ['/portal/page', '/portal/services', '/portal/hours', '/portal/team', '/portal/channels', '/portal/insights', '/portal/reviews', '/portal/invite'].includes(path)\n        check(Boolean(r.hub) === inHub, `${tag} hub nav presence ${Boolean(r.hub)}`)\n        if (r.hub) {\n          check(r.hub.l >= 0 && r.hub.r <= r.vw, `${tag} hub track off screen ${r.hub.l}-${r.hub.r}`)\n          for (const t of r.tabs) {\n            check(!t.trunc, `${tag} tab label truncated ${t.t}`)\n            check(t.r <= r.hub.r + 0.5 && t.l >= r.hub.l - 0.5, `${tag} tab outside track ${t.t}`)\n            if (touch) check(t.h >= 44, `${tag} touch tab ${t.t} ${t.h}px`)\n          }\n          check(r.tabs.filter((t) => t.active).length === 1, `${tag} one active tab`)\n        }\n        if (r.sh) {\n          check(r.sh.spill.length === 0, `${tag} content spills ${r.sh.spill}`)\n          if (touch) check(r.sh.small.length === 0, `${tag} small touch targets ${r.sh.small}`)\n          if (r.sh.days.min !== 999) {\n            check(r.sh.days.rows === 1, `${tag} day buttons wrap`)\n            check(r.sh.days.min >= 32, `${tag} day buttons too small ${r.sh.days.min}`)\n          }\n        }\n        if (r.bp) {\n          check(r.bp.cards.length === 0, `${tag} card overflow ${r.bp.cards}`)\n          check(r.bp.url, `${tag} link spills out of its card`)\n          if (touch) check(r.bp.small.length === 0, `${tag} small touch targets ${r.bp.small}`)\n          if (r.bp.phone) check(r.bp.phone.top >= 0 && r.bp.phone.bottom <= r.vh, `${tag} preview phone clipped ${JSON.stringify(r.bp.phone)}`)\n          if (w >= 1272) check(r.bp.wide, `${tag} expected the rail beside the form`)\n        }\n        if (w >= 1024) {\n          check(r.sideOn, `${tag} sidebar shown`)\n          check(r.navScroll <= 0, `${tag} nav scrolls by ${r.navScroll}px`)\n          for (const row of r.rows) check(row.b <= r.vh && row.top >= 0, `${tag} row off screen ${row.t} ${row.b}`)\n          const labels = r.rows.map((x) => x.t)\n          for (const need of ['Today', 'Calendar', 'Your business', 'Grow']) check(labels.some((x) => x.startsWith(need)), `${tag} missing ${need}`)\n          const expectHub = path in { '/portal/page': 1, '/portal/services': 1, '/portal/hours': 1, '/portal/team': 1 } ? 'Your business' : ['/portal/channels', '/portal/insights', '/portal/reviews', '/portal/invite'].includes(path) ? 'Grow' : null\n          if (expectHub) check(r.activeRows.includes(expectHub) && r.activeRows.length === 1, `${tag} active rows ${r.activeRows}`)\n          if (path === '/portal') check(r.activeRows.join() === 'Today', `${tag} active rows ${r.activeRows}`)\n          check(r.acctCurrent === ['/portal/settings', '/portal/help'].includes(path), `${tag} account current ${r.acctCurrent}`)\n        } else {\n          check(!r.sideOn, `${tag} sidebar hidden`)\n        }\n      }\n      if (w >= 1024) {\n        await page.goto(`${url}/?path=/portal/services`, { waitUntil: 'networkidle0' })\n        await page.click('.biz-account__btn')\n        await new Promise((r) => setTimeout(r, 250))\n        const m = await page.evaluate(() => {\n          const menu = document.querySelector('.biz-acctmenu').getBoundingClientRect()\n          const btn = document.querySelector('.biz-account__btn').getBoundingClientRect()\n          const items = [...document.querySelectorAll('.biz-acctmenu [role=menuitem]')].map((el) => el.textContent.trim())\n          return { top: menu.top, bottom: menu.bottom, left: menu.left, right: menu.right, btnTop: btn.top, items, focus: document.activeElement.textContent.trim(), vh: innerHeight }\n        })\n        check(m.top >= 0 && m.bottom <= m.btnTop, `${name} menu placement ${JSON.stringify(m)}`)\n        check(m.items.join('|') === 'Settings|Help and support|Replay the tour|Switch to Booking|Sign out', `${name} menu items ${m.items}`)\n        check(m.focus === 'Settings', `${name} menu first focus ${m.focus}`)\n      }\n      check(errors.length === 0, `${name} page errors ${errors}`)\n      await page.close()\n    }\n    const queue = [...chosen]\n    const worker = async () => {\n      while (queue.length) await runScreen(queue.shift())\n    }\n    await Promise.all(Array.from({ length: Math.min(4, queue.length) }, worker))\n}\n"
    },
    "tests/run.mjs": {
        "expect": "e43ce1f1f9d88cc119868b2836cfb694c24af58793520257f82d1b540963b745",
        "content": "import fs from 'node:fs'\nimport os from 'node:os'\nimport path from 'node:path'\nimport { fileURLToPath } from 'node:url'\nimport { createServer } from 'vite'\nimport puppeteer from 'puppeteer-core'\nimport layout from './suites/layout.mjs'\nimport shell from './suites/shell.mjs'\nimport businessPage from './suites/business-page.mjs'\nimport servicesHours from './suites/services-hours.mjs'\n\nconst here = path.dirname(fileURLToPath(import.meta.url))\nconst [target = 'quick', filter] = process.argv.slice(2)\nconst SUITES = { layout: [['layout', layout]], flows: [['shell', shell], ['business page', businessPage], ['services and hours', servicesHours]] }\nSUITES.all = [...SUITES.flows, ...SUITES.layout]\nSUITES.quick = [...SUITES.flows, ['layout, 4 key screens', layout]]\nconst only = target === 'quick' ? 'quick' : filter\n\nif (!SUITES[target]) {\n    console.log(`Unknown suite \"${target}\". Use quick, flows, layout or all.`)\n    process.exit(1)\n}\n\nconst findBrowser = () => {\n    const local = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local')\n    const candidates = [\n        process.env.CHROME_PATH,\n        'C:\\\\Program Files\\\\Google\\\\Chrome\\\\Application\\\\chrome.exe',\n        'C:\\\\Program Files (x86)\\\\Google\\\\Chrome\\\\Application\\\\chrome.exe',\n        path.join(local, 'Google', 'Chrome', 'Application', 'chrome.exe'),\n        'C:\\\\Program Files (x86)\\\\Microsoft\\\\Edge\\\\Application\\\\msedge.exe',\n        'C:\\\\Program Files\\\\Microsoft\\\\Edge\\\\Application\\\\msedge.exe',\n        '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',\n        '/usr/bin/google-chrome',\n        '/usr/bin/chromium',\n        '/usr/bin/chromium-browser',\n    ]\n    return candidates.find((file) => file && fs.existsSync(file))\n}\n\nconst executablePath = findBrowser()\nif (!executablePath) {\n    console.log('No Chrome or Edge found. Set CHROME_PATH to your chrome.exe and run again.')\n    process.exit(1)\n}\n\nconst server = await createServer({ configFile: path.join(here, 'harness', 'vite.config.mjs') })\nawait server.listen()\nconst url = server.resolvedUrls.local[0].replace(/\\/$/, '')\nconst browser = await puppeteer.launch({ executablePath, headless: true, args: ['--no-sandbox'] })\n\nconst warm = await browser.newPage()\nawait warm.goto(`${url}/?path=/portal`, { waitUntil: 'networkidle0', timeout: 120000 })\nawait warm.close()\n\nlet failed = 0\nconst started = Date.now()\ntry {\n    for (const [name, suite] of SUITES[target]) {\n        let pass = 0\n        let fail = 0\n        const check = (ok, message) => {\n            if (ok) pass += 1\n            else { fail += 1; console.log(`  FAIL ${message}`) }\n        }\n        await suite({ browser, url, check, only, cover: path.join(here, 'fixtures', 'cover.jpg') })\n        failed += fail\n        console.log(`${name}: ${pass} passed, ${fail} failed`)\n    }\n} finally {\n    await browser.close()\n    await server.close()\n}\n\nconsole.log(`Done in ${Math.round((Date.now() - started) / 1000)}s`)\nprocess.exit(failed ? 1 : 0)\n"
    },
    "tests/README.md": {
        "expect": "58199813ddc9fa78ab5100046fa8272345cbec3ff6fc9e63d29c477e5a41158e",
        "content": "# Tests\n\nFrontend checks that run in a real Chrome against a stand-in Supabase. Nothing touches the real database.\n\n| Command | What it checks | Time |\n|---------|----------------|------|\n| `npm run test:flows` | Clicks through the shell, hubs, account menu, search, tour, the Business page, Services and Hours, including autosave | about 2 minutes |\n| `npm run test:layout` | 13 screens from a 320px phone to 1920 x 1080, including the 13-inch at 1272 x 588: overflow, clipping, fit, touch sizes | about 2 minutes |\n| `npm test` | Flows plus 4 key screens (320 and 390 phones, 1024 tablet, 1272 x 588 laptop) | about 3 minutes |\n| `npm run test:full` | Everything | about 4 minutes |\n\nOne-time setup: `npm install -D puppeteer-core`. The runner uses the Chrome or Edge already on the computer. If it cannot find one, set `CHROME_PATH` to the full path of `chrome.exe`.\n\n- `harness/` renders the business side with a fake signed-in owner (Femtos Barbearia) and a fake Supabase that records every call.\n- `suites/` holds the checks. Add to them when a screen changes.\n- `node tests/run.mjs layout 1272` runs only the screens whose name contains `1272`.\n"
    }
}
const PATCHES = [
    {
        "file": "package.json",
        "find": "    \"test\": \"node tests/run.mjs all\",\n    \"test:flows\": \"node tests/run.mjs flows\",",
        "replace": "    \"test\": \"node tests/run.mjs quick\",\n    \"test:full\": \"node tests/run.mjs all\",\n    \"test:flows\": \"node tests/run.mjs flows\","
    }
]
const RETIRES = []

const root = process.cwd()
const abs = (rel) => path.join(root, ...rel.split('/'))
const norm = (s) => s.replace(/\r\n/g, '\n')
const hash = (s) => crypto.createHash('sha256').update(norm(s)).digest('hex')
const eol = (s) => (s.includes('\r\n') ? '\r\n' : '\n')
const withEol = (s, e) => (e === '\r\n' ? norm(s).replace(/\n/g, '\r\n') : norm(s))

const problems = []
const plan = []
const results = new Map()

for (const rel of [...Object.keys(NEW_FILES), ...Object.keys(NEW_BINARY)]) {
    if (fs.existsSync(abs(rel))) problems.push(`[NEW] ${rel} already exists. Patch already applied?`)
    else plan.push(['NEW', rel])
}

for (const [rel, spec] of Object.entries(REPLACE_FILES)) {
    if (!fs.existsSync(abs(rel))) { problems.push(`[REPLACE] ${rel} is missing`); continue }
    const current = fs.readFileSync(abs(rel), 'utf8')
    if (hash(current) === hash(spec.content)) problems.push(`[REPLACE] ${rel} already has the new version. Patch already applied?`)
    else if (hash(current) !== spec.expect) problems.push(`[REPLACE] ${rel} differs from the collected version. Send a fresh collector before applying.`)
    else if (fs.existsSync(abs(rel) + BACKUP)) problems.push(`[REPLACE] ${rel}${BACKUP} already exists`)
    else { plan.push(['REPLACE', rel]); results.set(rel, withEol(spec.content, eol(current))) }
}

const byFile = new Map()
for (const p of PATCHES) {
    if (!byFile.has(p.file)) byFile.set(p.file, [])
    byFile.get(p.file).push(p)
}
for (const [rel, list] of byFile) {
    if (!fs.existsSync(abs(rel))) { problems.push(`[EDIT] ${rel} is missing`); continue }
    const raw = fs.readFileSync(abs(rel), 'utf8')
    const e = eol(raw)
    let text = norm(raw)
    for (const p of list) {
        const find = norm(p.find)
        const replace = norm(p.replace)
        const count = text.split(find).length - 1
        if (count !== 1) {
            const applied = text.split(replace).length - 1 === 1
            problems.push(`[EDIT] ${rel}: anchor matched ${count} times${applied ? ' (already applied?)' : ''}: ${find.split('\n')[0].trim()}`)
            continue
        }
        text = text.replace(find, () => replace)
    }
    if (fs.existsSync(abs(rel) + BACKUP)) problems.push(`[EDIT] ${rel}${BACKUP} already exists`)
    plan.push(['EDIT', rel])
    results.set(rel, withEol(text, e))
}

for (const rel of RETIRES) {
    if (!fs.existsSync(abs(rel))) problems.push(`[RETIRE] ${rel} is missing. Patch already applied?`)
    else if (fs.existsSync(abs(rel) + '.mistake')) problems.push(`[RETIRE] ${rel}.mistake already exists`)
    else plan.push(['RETIRE', rel])
}

if (process.argv.includes('--list')) {
    for (const [kind, rel] of plan) console.log(`  [${kind}] ${rel}`)
    if (problems.length) { for (const p of problems) console.log(`  [PROBLEM] ${p}`); process.exit(1) }
    process.exit(0)
}

if (problems.length) {
    console.log(`  ${NAME}: nothing written. ${problems.length} problem(s):`)
    for (const p of problems) console.log(`    ${p}`)
    process.exit(1)
}

for (const [kind, rel] of plan) {
    const file = abs(rel)
    if (kind === 'NEW') {
        fs.mkdirSync(path.dirname(file), { recursive: true })
        if (rel in NEW_BINARY) fs.writeFileSync(file, Buffer.from(NEW_BINARY[rel], 'base64'))
        else fs.writeFileSync(file, NEW_FILES[rel])
    } else if (kind === 'RETIRE') {
        fs.renameSync(file, file + '.mistake')
    } else {
        fs.copyFileSync(file, file + BACKUP)
        fs.writeFileSync(file, results.get(rel))
    }
    console.log(`  [${kind}] ${rel}`)
}
console.log(`  ${NAME}: applied.`)
