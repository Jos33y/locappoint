$ErrorActionPreference = 'Stop'
$name = 'pay1'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $here

$pj = Join-Path $root 'package.json'
if (-not (Test-Path $pj)) { Write-Host 'Run this from the locappoint repo root.'; exit 1 }
$pkg = (Get-Content $pj -Raw | ConvertFrom-Json).name
if ($pkg -ne 'locappoint') { Write-Host ('package.json name is ' + $pkg + ', expected locappoint.'); exit 1 }

Push-Location $root
try {
  Write-Host ('Kit ' + $name + ': Paid page says You paid; business logo after paying; receipt address without Lagos, Lagos; support card heading; Cancel booking on its own line; footer free for businesses; no amber on Beta and rating. Run supabase/migrations/pay-logo.sql in the Supabase SQL editor')
  Write-Host ''
  node "payload/patch-$name.mjs" --list
  if ($LASTEXITCODE -ne 0) { Write-Host ''; Write-Host 'Nothing was changed.'; exit 1 }
  Write-Host ''
  $answer = Read-Host 'Apply these changes? (y/n)'
  if ($answer -ne 'y') { Write-Host 'Nothing was changed.'; exit 0 }

  node "payload/patch-$name.mjs" --apply
  if ($LASTEXITCODE -ne 0) { Write-Host 'The patch stopped. Nothing was written.'; exit 1 }

  Remove-Item -Recurse -Force (Join-Path $root 'payload')
  Write-Host ''
  Write-Host 'Installed. No new packages to install.'
  Write-Host 'run pay-logo.sql in Supabase'
}
finally {
  Pop-Location
}
