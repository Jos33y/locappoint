import crypto from 'node:crypto'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const NAME = 'pay1'
const here = path.dirname(fileURLToPath(import.meta.url))
const root = path.resolve(here, '..')
const files = path.join(here, 'files')
const mode = process.argv[2] || '--list'

const NEW_FILES = [
    "supabase/migrations/pay-logo.sql"
]

const REPLACE_FILES = {}

// Retired files: checked against the version this kit was built on, then kept as a backup.
const DELETE_FILES = {}

const PATCHES = [
    ["src/components/common/Appfooter.jsx", "                            Book anyone, anywhere the service happens. Live in Porto, Lagos and Lisbon. Free during the beta.", "                            Book anyone, anywhere the service happens. Live in Porto, Lagos and Lisbon. Free for businesses during the beta."],
    ["src/pages/app/PayReturn.jsx", "                <b>{amount}</b> paid to {business}.", "                You paid <b>{amount}</b>."],
    ["src/pages/app/PayReturn.jsx", "                            business={{ business_name: business, address: state.address, city: state.city }}", "                            business={{ business_name: business, address: state.address, city: state.city, country: state.country, logo_url: state.logo_url }}"],
    ["src/pages/app/ReceiptPage.jsx", "import { parseDateKey } from '../../services/dates'\nimport '../../styles/client/receipt.css'", "import { parseDateKey } from '../../services/dates'\nimport { fullAddress } from '../../components/business/public/PublicFind'\nimport '../../styles/client/receipt.css'"],
    ["src/pages/app/ReceiptPage.jsx", "    const place = r ? [r.business?.address, r.business?.city].filter(Boolean).join(', ') : ''", "    const place = r ? (r.business?.address?.trim() ? fullAddress(r.business.address, r.business.city) : r.business?.city || '') : ''"],
    ["src/styles/app/header.css", "    background: rgba(232, 154, 62, 0.10);\n    border: 1px solid rgba(232, 154, 62, 0.28);\n    color: var(--signal);", "    background: var(--lc-info-tint);\n    border: 1px solid var(--lc-line);\n    color: var(--lc-info);"],
    ["src/styles/client/home-overview.css", ".lc-cl-todo__icon.is-rate { background: var(--lc-warning-tint); color: var(--lc-warning); }", ".lc-cl-todo__icon.is-rate { background: var(--lc-info-tint); color: var(--lc-info); }"],
    ["src/styles/client/manage-booking.css", "\n.lc-mb__all {", "\n/* The page is narrow enough that Cancel booking always wraps; it starts its own line on the left. */\n.lc-mb .lc-cl-bk__cancel { margin-left: 0; }\n\n.lc-mb__all {"],
    ["src/styles/support.css", ".lc-sup-link__head > div { flex: 1 1 220px; min-width: 0; }\n.lc-sup-link__head p { margin: 4px 0 0; color: var(--lc-ink-2); font-size: var(--lc-t-label); line-height: var(--lc-lh-snug); }", ".lc-sup-link__head > div { flex: 1 1 220px; min-width: 0; }\n.lc-sup-link__head .lc-mb__heading {\n    margin: 0;\n    color: var(--lc-ink-1);\n    font-family: var(--lc-font-body);\n    font-size: var(--lc-t-body);\n    font-weight: var(--font-weight-semibold);\n    letter-spacing: normal;\n    line-height: var(--lc-lh-snug);\n}\n.lc-sup-link__head p { margin: 4px 0 0; color: var(--lc-ink-2); font-size: var(--lc-t-label); line-height: var(--lc-lh-snug); }"],
    ["supabase/migrations/pay-at-booking.sql", "    'city', b.city,\n    'timezone', b.timezone,", "    'city', b.city,\n    'country', b.country,\n    'logo_url', b.logo_url,\n    'timezone', b.timezone,"],
]

const PREFIXES = []

const full = (rel) => path.join(root, ...rel.split('/'))
const lf = (s) => s.replace(/\r\n/g, '\n')
const sha = (s) => crypto.createHash('sha256').update(lf(s), 'utf8').digest('hex')
const eol = (s) => (s.includes('\r\n') ? '\r\n' : '\n')
const withEol = (s, e) => (e === '\r\n' ? lf(s).replace(/\n/g, '\r\n') : lf(s))
const count = (hay, needle) => hay.split(needle).length - 1
const binary = (rel) => /\.(woff2?|png|jpe?g|webp|ico)$/.test(rel)

const problems = []
const plan = []

const pkg = (() => { try { return JSON.parse(fs.readFileSync(full('package.json'), 'utf8')).name } catch { return null } })()
if (pkg !== 'locappoint') problems.push(`package.json name is ${pkg}, expected locappoint`)

for (const rel of NEW_FILES) {
    if (!fs.existsSync(path.join(files, ...rel.split('/')))) problems.push(`kit is missing ${rel}`)
    if (fs.existsSync(full(rel))) problems.push(`${rel} already exists; this kit may already be installed`)
    else plan.push(`[NEW]     ${rel}`)
}

for (const [rel, want] of Object.entries(REPLACE_FILES)) {
    if (!fs.existsSync(full(rel))) { problems.push(`${rel} is missing`); continue }
    if (sha(fs.readFileSync(full(rel), 'utf8')) !== want) problems.push(`${rel} is not the version this kit was built against (it was edited, or the kit is already in)`)
    else plan.push(`[REPLACE] ${rel}`)
}

for (const [rel, want] of Object.entries(DELETE_FILES)) {
    if (!fs.existsSync(full(rel))) { problems.push(`${rel} is missing; this kit may already be installed`); continue }
    if (sha(fs.readFileSync(full(rel), 'utf8')) !== want) problems.push(`${rel} is not the version this kit was built against`)
    else plan.push(`[RETIRE]  ${rel}`)
}

const edited = {}
for (const [rel, find, replace] of PATCHES) {
    if (!fs.existsSync(full(rel))) { problems.push(`${rel} is missing`); continue }
    if (!(rel in edited)) edited[rel] = lf(fs.readFileSync(full(rel), 'utf8'))
    const text = edited[rel]
    const n = count(text, find)
    if (n !== 1) {
        problems.push(replace && count(text, replace) ? `${rel}: already patched` : `${rel}: anchor found ${n} times, expected 1: ${find.split('\n').find((l) => l.trim()).slice(0, 60)}`)
        continue
    }
    edited[rel] = text.replace(find, () => replace)
}
for (const rel of Object.keys(edited)) plan.push(`[EDIT]    ${rel}`)

const ours = new Set([...NEW_FILES, ...Object.keys(REPLACE_FILES), ...Object.keys(DELETE_FILES)])
const walk = (dir, out = []) => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
        const p = path.join(dir, e.name)
        if (e.isDirectory()) { if (e.name !== 'node_modules') walk(p, out) } else if (/\.(jsx?|css|mjs)$/.test(e.name)) out.push(p)
    }
    return out
}
for (const file of walk(full('src'))) {
    const rel = path.relative(root, file).split(path.sep).join('/')
    if (ours.has(rel)) continue
    const text = fs.readFileSync(file, 'utf8')
    for (const re of PREFIXES) if (re.test(text)) problems.push(`class prefix ${re.source} is already used in ${rel}`)
}

if (mode === '--list') {
    console.log(plan.join('\n'))
    if (problems.length) { console.log('\nProblems:\n  ' + problems.join('\n  ')); process.exit(1) }
    process.exit(0)
}

if (mode !== '--apply') { console.log('Use --list or --apply'); process.exit(1) }
if (problems.length) { console.log('Nothing written:\n  ' + problems.join('\n  ')); process.exit(1) }

const backup = (rel) => fs.copyFileSync(full(rel), `${full(rel)}.backup-${NAME}`)

for (const rel of Object.keys(REPLACE_FILES)) {
    const before = fs.readFileSync(full(rel), 'utf8')
    backup(rel)
    fs.writeFileSync(full(rel), withEol(fs.readFileSync(path.join(files, ...rel.split('/')), 'utf8'), eol(before)))
}
for (const [rel, text] of Object.entries(edited)) {
    const before = fs.readFileSync(full(rel), 'utf8')
    backup(rel)
    fs.writeFileSync(full(rel), withEol(text, eol(before)))
}
for (const rel of NEW_FILES) {
    fs.mkdirSync(path.dirname(full(rel)), { recursive: true })
    const src = path.join(files, ...rel.split('/'))
    if (binary(rel)) fs.copyFileSync(src, full(rel))
    else fs.writeFileSync(full(rel), fs.readFileSync(src, 'utf8'))
}
for (const rel of Object.keys(DELETE_FILES)) fs.renameSync(full(rel), `${full(rel)}.backup-${NAME}`)
console.log(`${NAME}: ${NEW_FILES.length} new, ${Object.keys(REPLACE_FILES).length} replaced, ${Object.keys(edited).length} edited, ${Object.keys(DELETE_FILES).length} retired.`)
