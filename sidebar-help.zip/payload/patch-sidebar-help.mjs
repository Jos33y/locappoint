import fs from 'fs'
import path from 'path'

const REPO = process.cwd()

const NEW_FILES = [
    { path: 'src/components/business/Tour.jsx', content: `import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { TOUR_STEPS } from './nav'
import '../../styles/business/tour.css'

const GAP = 12
const CARD_WIDTH = 320

const visibleTarget = (key) =>
    [...document.querySelectorAll(\`[data-tour="\${key}"]\`)].find((el) => {
        const r = el.getBoundingClientRect()
        return r.width > 0 && r.height > 0
    })

const placeCard = (rect, card) => {
    const vw = window.innerWidth
    const vh = window.innerHeight
    const w = Math.min(CARD_WIDTH, vw - 24)
    const h = card?.offsetHeight || 180
    if (rect.right + GAP + w < vw) {
        return { left: rect.right + GAP, top: Math.min(Math.max(12, rect.top - 8), vh - h - 12), width: w }
    }
    const left = Math.min(Math.max(12, rect.left + rect.width / 2 - w / 2), vw - w - 12)
    if (rect.top - GAP - h > 12) return { left, top: rect.top - GAP - h, width: w }
    return { left, top: Math.min(rect.bottom + GAP, vh - h - 12), width: w }
}

const Tour = ({ open, onClose }) => {
    const steps = useMemo(() => (open ? TOUR_STEPS.filter((s) => visibleTarget(s.target)) : []), [open])
    const [index, setIndex] = useState(0)
    const [rect, setRect] = useState(null)
    const cardRef = useRef(null)
    const [cardPos, setCardPos] = useState(null)
    const step = steps[index]

    useEffect(() => { if (open) setIndex(0) }, [open])

    const measure = useCallback(() => {
        if (!step) return
        const el = visibleTarget(step.target)
        if (!el) return
        setRect(el.getBoundingClientRect())
    }, [step])

    useLayoutEffect(() => { measure() }, [measure])

    useLayoutEffect(() => {
        if (rect) setCardPos(placeCard(rect, cardRef.current))
    }, [rect])

    useEffect(() => {
        if (!open) return undefined
        window.addEventListener('resize', measure)
        window.addEventListener('scroll', measure, true)
        return () => {
            window.removeEventListener('resize', measure)
            window.removeEventListener('scroll', measure, true)
        }
    }, [open, measure])

    const finish = useCallback(() => onClose(), [onClose])
    const next = useCallback(() => (index < steps.length - 1 ? setIndex(index + 1) : finish()), [index, steps.length, finish])
    const back = useCallback(() => setIndex((i) => Math.max(0, i - 1)), [])

    useEffect(() => {
        if (!open) return undefined
        const onKey = (event) => {
            if (event.key === 'Escape') finish()
            if (event.key === 'ArrowRight') next()
            if (event.key === 'ArrowLeft') back()
        }
        document.addEventListener('keydown', onKey)
        return () => document.removeEventListener('keydown', onKey)
    }, [open, next, back, finish])

    useEffect(() => { if (open) cardRef.current?.focus() }, [open, index])

    if (!open || !step || !rect) return null

    const pad = 6
    return createPortal(
        <div className="lc-tour" role="presentation">
            <div
                className="lc-tour__spot"
                style={{ left: rect.left - pad, top: rect.top - pad, width: rect.width + pad * 2, height: rect.height + pad * 2 }}
                aria-hidden="true"
            />
            <section
                ref={cardRef}
                className="lc-tour__card"
                role="dialog"
                aria-modal="true"
                aria-labelledby="lc-tour-title"
                tabIndex={-1}
                style={cardPos || { left: -9999, top: 0, width: CARD_WIDTH }}
            >
                <p className="lc-tour__count">Step {index + 1} of {steps.length}</p>
                <h2 id="lc-tour-title" className="lc-tour__title">{step.title}</h2>
                <p className="lc-tour__body">{step.body}</p>
                <div className="lc-tour__dots" aria-hidden="true">
                    {steps.map((s, i) => <span key={s.target} className={i === index ? 'is-on' : ''} />)}
                </div>
                <div className="lc-tour__actions">
                    <button type="button" className="ui-btn ui-btn--quiet ui-btn--sm" onClick={finish}>
                        <span className="ui-btn__content">Skip</span>
                    </button>
                    <span className="lc-tour__spacer" />
                    {index > 0 && (
                        <button type="button" className="ui-btn ui-btn--secondary ui-btn--sm" onClick={back}>
                            <span className="ui-btn__content">Back</span>
                        </button>
                    )}
                    <button type="button" className="ui-btn ui-btn--primary ui-btn--sm" onClick={next}>
                        <span className="ui-btn__content">{index === steps.length - 1 ? 'Done' : 'Next'}</span>
                    </button>
                </div>
            </section>
        </div>,
        document.body
    )
}

export default Tour
` },
    { path: 'src/constants/support.js', content: `export const SUPPORT = {
    email: 'hello@locappoint.com',
    whatsapp: '',
    hours: 'Monday to Friday, 09:00 to 18:00 Lisbon time',
}

export const TICKET_CATEGORIES = [
    { value: 'bookings', label: 'Bookings and calendar' },
    { value: 'business_page', label: 'My business page' },
    { value: 'billing', label: 'Plan and billing' },
    { value: 'account', label: 'Account and sign-in' },
    { value: 'other', label: 'Something else' },
]

export const TICKET_STATUS = {
    open: { label: 'Open', tone: 'warning' },
    answered: { label: 'Answered', tone: 'info' },
    closed: { label: 'Closed', tone: 'neutral' },
}
` },
    { path: 'src/pages/business/Channels.jsx', content: `import { Bot, Copy, Link2, MapPin, MessageCircle } from 'lucide-react'
import { useWorkspace } from '../../components/business/WorkspaceContext'
import { Button, Card, Stat, Status } from '../../components/ui'
import '../../styles/business/support.css'

const Channels = () => {
    const { business, notify } = useWorkspace()
    const link = \`\${window.location.origin}/\${business.slug}\`

    const copy = async () => {
        try {
            await navigator.clipboard.writeText(link)
            notify('Link copied')
        } catch {
            notify('Copy did not work. Select the link and copy it.')
        }
    }

    const channels = [
        {
            key: 'link',
            icon: Link2,
            name: 'Your booking link',
            body: 'Clients open your page, pick a service and a time, and book. Put it in your Instagram bio and WhatsApp status.',
            status: { tone: 'success', label: 'Live' },
            action: <Button variant="secondary" icon={Copy} onClick={copy}>Copy link</Button>,
            detail: link.replace(/^https?:\\/\\//, ''),
        },
        {
            key: 'whatsapp',
            icon: MessageCircle,
            name: 'WhatsApp',
            body: 'Clients book by sending a message to Locappoint on WhatsApp. No app, no form. Loca AI answers and books for you.',
            status: { tone: 'warning', label: 'Setting up' },
        },
        {
            key: 'google',
            icon: MapPin,
            name: 'Google Maps and Search',
            body: 'A Book button on your Google listing that opens your Locappoint page.',
            status: { tone: 'warning', label: 'Applying to Google' },
        },
        {
            key: 'ai',
            icon: Bot,
            name: 'Claude, ChatGPT and Gemini',
            body: 'Clients ask their AI assistant for a barber nearby on Saturday, and book you right there.',
            status: { tone: 'neutral', label: 'In build' },
        },
    ]

    const live = channels.filter((c) => c.status.tone === 'success').length

    return (
        <div className="biz-page lc-channels">
            <header className="biz-page__head">
                <div>
                    <h1 className="biz-page__title">Channels</h1>
                    <p className="biz-page__sub">Everywhere clients can book you. More open as Locappoint grows.</p>
                </div>
                <Stat label="Live now" value={\`\${live} of \${channels.length}\`} size="sm" animate={false} />
            </header>

            <div className="lc-channels__list">
                {channels.map(({ key, icon: Icon, name, body, status, action, detail }) => (
                    <Card key={key} variant={status.tone === 'success' ? 'raised' : 'flat'} padding="md" className="lc-channel">
                        <span className={\`lc-channel__icon\${status.tone === 'success' ? ' is-live' : ''}\`}><Icon size={22} aria-hidden="true" /></span>
                        <div className="lc-channel__main">
                            <div className="lc-channel__head">
                                <h2 className="ui-heading">{name}</h2>
                                <Status tone={status.tone} size="sm">{status.label}</Status>
                            </div>
                            <p className="lc-channel__body">{body}</p>
                            {detail && <p className="lc-channel__detail">{detail}</p>}
                        </div>
                        {action && <div className="lc-channel__action">{action}</div>}
                    </Card>
                ))}
            </div>
        </div>
    )
}

export default Channels
` },
    { path: 'src/pages/business/GettingStarted.jsx', content: `import { Check, CirclePlay, LifeBuoy } from 'lucide-react'
import { useWorkspace } from '../../components/business/WorkspaceContext'
import { Button, Card, ListRow, Ring } from '../../components/ui'
import { pageSteps } from '../../services/business'
import '../../styles/business/support.css'

const GUIDES = [
    { id: 'phone-booking', title: 'Add a booking from a phone call' },
    { id: 'confirm', title: 'Confirm, move or cancel a booking' },
    { id: 'share', title: 'Share your link so clients can book' },
    { id: 'hours', title: 'Change your hours or take a day off' },
]

const GettingStarted = () => {
    const { business, services, hours, openTour } = useWorkspace()
    const steps = pageSteps({ business, services, hours })
    const done = steps.filter((s) => s.done).length
    const value = done / steps.length

    return (
        <div className="biz-page lc-start">
            <header className="biz-page__head">
                <div>
                    <h1 className="biz-page__title">Getting started</h1>
                    <p className="biz-page__sub">Everything that makes your page book more, in one list.</p>
                </div>
            </header>

            <Card variant="accent" padding="lg" className="lc-start__hero">
                <Ring value={value} size={112} stroke={10} label={\`\${done} of \${steps.length} done\`}>
                    <span className="lc-start__percent">{Math.round(value * 100)}%</span>
                </Ring>
                <div className="lc-start__heroText">
                    <h2 className="ui-heading">{done === steps.length ? 'Your page is complete' : \`\${done} of \${steps.length} done\`}</h2>
                    <p className="lc-start__lede">
                        {done === steps.length
                            ? 'Everything is in place. Share your link and let the bookings come in.'
                            : 'Businesses with a complete page get booked more. Each step takes about a minute.'}
                    </p>
                    <div className="lc-start__actions">
                        <Button icon={CirclePlay} onClick={openTour}>Take the tour</Button>
                        <Button variant="secondary" icon={LifeBuoy} to="/portal/help">Get help</Button>
                    </div>
                </div>
            </Card>

            <Card title="Your checklist" padding="sm">
                {steps.map((step) => (
                    <ListRow
                        key={step.label}
                        leading={
                            <span className={\`lc-check\${step.done ? ' is-done' : ''}\`} aria-hidden="true">
                                {step.done && <Check size={14} />}
                            </span>
                        }
                        title={step.label}
                        subtitle={step.done ? 'Done' : step.hint}
                        to={step.done ? undefined : step.to}
                        chevron={!step.done}
                    />
                ))}
            </Card>

            <Card title="Short guides" padding="sm">
                {GUIDES.map((guide) => (
                    <ListRow key={guide.id} title={guide.title} to={\`/portal/help#\${guide.id}\`} dense />
                ))}
            </Card>
        </div>
    )
}

export default GettingStarted
` },
    { path: 'src/pages/business/Help.jsx', content: `import { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom'
import { Mail, MessageCircle, Send } from 'lucide-react'
import { useAuth } from '../../hooks/useAuth'
import { useWorkspace } from '../../components/business/WorkspaceContext'
import { Button, Card, EmptyState, Field, Input, ListRow, Select, Skeleton, Status, Textarea } from '../../components/ui'
import { SUPPORT, TICKET_CATEGORIES, TICKET_STATUS } from '../../constants/support'
import { listMyTickets, openTicket } from '../../services/support'
import '../../styles/business/support.css'

const ANSWERS = [
    { id: 'phone-booking', q: 'How do I add a booking from a phone call?', a: 'Tap New booking (the + button on your phone). Pick the service, the day and a free time, type the client’s name, and add it. Phone and email are optional. If they want a time outside your hours, choose “A time outside opening hours”.' },
    { id: 'confirm', q: 'How do I confirm, move or cancel a booking?', a: 'Open Today or Calendar and tap the booking. Confirm, Completed, No-show and Cancel are right there. Move lets you pick a new free time. Bookings waiting for you also have a Confirm button on the row itself.' },
    { id: 'share', q: 'How do clients find and book me?', a: 'Share your link from the share button at the top, or from Channels. Clients open it, choose a service and a time, and the booking lands on your Today screen.' },
    { id: 'hours', q: 'How do I change my hours or take a day off?', a: 'Open Hours to change your weekly opening times. Closed dates for holidays and sick days arrive with the next Hours update; until then, ask Loca support and we will block the day for you.' },
    { id: 'pause', q: 'Can I stop taking bookings for a while?', a: 'Yes. Open Business page and turn off taking bookings. Your page stays, but clients cannot book until you turn it back on.' },
    { id: 'price', q: 'What does Locappoint cost?', a: 'Your first twelve months are free. After that it is nineteen euros a month, flat, with no commission on your bookings.' },
]

const Help = () => {
    const { user } = useAuth()
    const { business, notify } = useWorkspace()
    const location = useLocation()
    const [tickets, setTickets] = useState(null)
    const [ticketsError, setTicketsError] = useState('')
    const [form, setForm] = useState({ category: 'bookings', subject: '', message: '' })
    const [errors, setErrors] = useState({})
    const [sending, setSending] = useState(false)
    const [openId, setOpenId] = useState(location.hash.replace('#', '') || null)

    const loadTickets = () => {
        listMyTickets()
            .then((rows) => { setTickets(rows); setTicketsError('') })
            .catch(() => { setTickets([]); setTicketsError('Tickets are not available yet. Email or WhatsApp us instead.') })
    }

    useEffect(() => { loadTickets() }, [])

    useEffect(() => {
        const id = location.hash.replace('#', '')
        if (!id) return
        setOpenId(id)
        requestAnimationFrame(() => document.getElementById(id)?.scrollIntoView({ block: 'center' }))
    }, [location.hash])

    const update = (field) => (event) => setForm((f) => ({ ...f, [field]: event.target.value }))

    const submit = async (event) => {
        event.preventDefault()
        const next = {}
        if (!form.subject.trim()) next.subject = 'Give your question a short title.'
        if (form.message.trim().length < 10) next.message = 'Tell us a little more, so we can help first time.'
        setErrors(next)
        if (Object.keys(next).length) return
        setSending(true)
        try {
            await openTicket({ userId: user.id, businessId: business.id, ...form })
            setForm({ category: form.category, subject: '', message: '' })
            notify('Ticket sent. We reply within one working day.')
            loadTickets()
        } catch {
            notify('Could not send your ticket. Email us instead.')
        } finally {
            setSending(false)
        }
    }

    const whatsapp = SUPPORT.whatsapp
        ? \`https://wa.me/\${SUPPORT.whatsapp.replace(/[^\\d]/g, '')}?text=\${encodeURIComponent(\`Hi Locappoint, this is \${business.business_name}. \`)}\`
        : null

    return (
        <div className="biz-page lc-help">
            <header className="biz-page__head">
                <div>
                    <h1 className="biz-page__title">Help and support</h1>
                    <p className="biz-page__sub">Real people, {SUPPORT.hours}.</p>
                </div>
            </header>

            <div className="lc-help__contact">
                {whatsapp && (
                    <Card variant="raised" padding="md">
                        <MessageCircle size={22} className="lc-help__icon" aria-hidden="true" />
                        <div>
                            <h2 className="ui-heading">WhatsApp</h2>
                            <p className="lc-help__text">The fastest way to reach us.</p>
                        </div>
                        <Button href={whatsapp} target="_blank" rel="noopener noreferrer" variant="secondary">Message us</Button>
                    </Card>
                )}
                <Card variant="raised" padding="md">
                    <Mail size={22} className="lc-help__icon" aria-hidden="true" />
                    <div>
                        <h2 className="ui-heading">Email</h2>
                        <p className="lc-help__text">{SUPPORT.email}</p>
                    </div>
                    <Button href={\`mailto:\${SUPPORT.email}?subject=\${encodeURIComponent(\`Help for \${business.business_name}\`)}\`} variant="secondary">Write to us</Button>
                </Card>
            </div>

            <section aria-labelledby="answers-title" className="lc-help__section">
                <h2 id="answers-title" className="ui-heading">Quick answers</h2>
                <div className="lc-faq">
                    {ANSWERS.map((item) => (
                        <details
                            key={item.id}
                            id={item.id}
                            className="lc-faq__item"
                            open={openId === item.id}
                            onToggle={(event) => { if (event.currentTarget.open) setOpenId(item.id) }}
                        >
                            <summary className="lc-faq__q">{item.q}</summary>
                            <p className="lc-faq__a">{item.a}</p>
                        </details>
                    ))}
                </div>
            </section>

            <div className="lc-help__grid">
                <Card title="Open a ticket" padding="lg">
                    <form className="lc-help__form" onSubmit={submit} noValidate>
                        <Field label="About">
                            <Select value={form.category} onChange={update('category')}>
                                {TICKET_CATEGORIES.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
                            </Select>
                        </Field>
                        <Field label="Title" error={errors.subject}>
                            <Input value={form.subject} onChange={update('subject')} maxLength={140} placeholder="For example: a client cannot see Saturday" />
                        </Field>
                        <Field label="What happened" error={errors.message} hint="Include the day and time if it is about a booking.">
                            <Textarea value={form.message} onChange={update('message')} maxLength={4000} rows={5} />
                        </Field>
                        <Button type="submit" icon={Send} loading={sending}>Send ticket</Button>
                    </form>
                </Card>

                <Card title="Your tickets" padding="sm">
                    {tickets === null ? (
                        <div className="lc-help__loading"><Skeleton height={48} /><Skeleton height={48} /></div>
                    ) : ticketsError ? (
                        <p className="lc-help__text lc-help__pad">{ticketsError}</p>
                    ) : tickets.length === 0 ? (
                        <EmptyState title="No tickets yet" body="When you open one, it appears here with its status." />
                    ) : (
                        tickets.map((t) => (
                            <ListRow
                                key={t.id}
                                title={t.subject}
                                subtitle={\`\${TICKET_CATEGORIES.find((c) => c.value === t.category)?.label || 'Other'}, \${new Date(t.created_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}\`}
                                trailing={<Status tone={TICKET_STATUS[t.status]?.tone} size="sm">{TICKET_STATUS[t.status]?.label}</Status>}
                                chevron={false}
                            />
                        ))
                    )}
                </Card>
            </div>
        </div>
    )
}

export default Help
` },
    { path: 'src/services/support.js', content: `import { supabase } from '../config/supabase'

export const listMyTickets = async () => {
    const { data, error } = await supabase
        .from('support_tickets')
        .select('id, category, subject, status, created_at')
        .order('created_at', { ascending: false })
        .limit(20)
    if (error) throw error
    return data
}

export const openTicket = async ({ userId, businessId, category, subject, message }) => {
    const { data, error } = await supabase
        .from('support_tickets')
        .insert({ user_id: userId, business_id: businessId, category, subject: subject.trim(), message: message.trim() })
        .select('id')
        .single()
    if (error) throw error
    return data
}
` },
    { path: 'src/styles/business/support.css', content: `.lc-start__hero {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    align-items: center;
    gap: var(--space-6);
}

.lc-start__percent {
    font-family: var(--lc-font-display);
    font-size: 1.75rem;
    font-weight: var(--font-weight-semibold);
    letter-spacing: var(--lc-track-title);
}

.lc-start__heroText {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
    flex: 1;
    min-width: 240px;
}

.lc-start__heroText h2 {
    margin: 0;
}

.lc-start__lede {
    max-width: 48ch;
    margin: 0;
    color: var(--lc-ink-2);
    line-height: var(--lc-lh-body);
}

.lc-start__actions {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-2);
    margin-top: var(--space-2);
}

.lc-check {
    display: grid;
    place-items: center;
    width: 24px;
    height: 24px;
    border-radius: var(--radius-full);
    box-shadow: inset 0 0 0 1.5px var(--lc-line-strong);
    color: var(--lc-canvas);
}

.lc-check.is-done {
    background: var(--lc-success);
    box-shadow: none;
}


.lc-help__contact {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: var(--space-4);
}

.lc-help__contact .ui-card {
    flex-direction: row;
    align-items: center;
    gap: var(--space-4);
}

.lc-help__contact .ui-card > div {
    flex: 1;
    min-width: 0;
}

.lc-help__contact h2 {
    margin: 0;
}

.lc-help__icon {
    flex: none;
    color: var(--azure);
}

.lc-help__text {
    margin: 2px 0 0;
    overflow: hidden;
    color: var(--lc-ink-3);
    font-size: var(--lc-t-label);
    text-overflow: ellipsis;
}

.lc-help__pad {
    padding: var(--space-3);
}

.lc-help__section {
    display: flex;
    flex-direction: column;
    gap: var(--space-3);
}

.lc-help__section h2 {
    margin: 0;
}

.lc-faq {
    display: flex;
    flex-direction: column;
    border-radius: var(--lc-r-lg);
    background: var(--lc-card);
    box-shadow: inset 0 0 0 1px var(--lc-line);
}

.lc-faq__item + .lc-faq__item {
    border-top: 1px solid var(--lc-line);
}

.lc-faq__q {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--space-4);
    min-height: 52px;
    padding: 0 var(--space-5);
    font-weight: var(--font-weight-medium);
    list-style: none;
    cursor: pointer;
}

.lc-faq__q::-webkit-details-marker {
    display: none;
}

.lc-faq__q::after {
    content: '';
    flex: none;
    width: 8px;
    height: 8px;
    border-right: 1.5px solid var(--lc-ink-3);
    border-bottom: 1.5px solid var(--lc-ink-3);
    transform: rotate(45deg);
    transition: transform var(--lc-fast) var(--lc-ease);
}

.lc-faq__item[open] .lc-faq__q::after {
    transform: rotate(-135deg);
}

.lc-faq__q:hover {
    color: var(--lc-ink-1);
    background: var(--lc-raised);
}

.lc-faq__q:focus-visible {
    outline: 2px solid var(--azure);
    outline-offset: -2px;
}

.lc-faq__a {
    max-width: 68ch;
    margin: 0;
    padding: 0 var(--space-5) var(--space-5);
    color: var(--lc-ink-2);
    line-height: var(--lc-lh-body);
}

.lc-help__grid {
    display: grid;
    gap: var(--space-4);
    align-items: start;
}

.lc-help__form {
    display: flex;
    flex-direction: column;
    gap: var(--space-4);
}

.lc-help__form .ui-btn {
    align-self: flex-start;
}

.lc-help__loading {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
    padding: var(--space-2);
}


.lc-channels__list {
    display: flex;
    flex-direction: column;
    gap: var(--space-3);
}

.lc-channel {
    flex-direction: row;
    align-items: flex-start;
    gap: var(--space-4);
}

.lc-channel__icon {
    display: grid;
    place-items: center;
    flex: none;
    width: 44px;
    height: 44px;
    border-radius: var(--lc-r-md);
    background: var(--lc-raised);
    color: var(--lc-ink-3);
}

.lc-channel__icon.is-live {
    background: var(--azure);
    box-shadow: var(--lc-shadow-accent);
    color: var(--lc-on-accent);
}

.lc-channel__main {
    display: flex;
    flex-direction: column;
    gap: var(--space-1);
    flex: 1;
    min-width: 0;
}

.lc-channel__head {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: var(--space-2) var(--space-3);
}

.lc-channel__head h2 {
    margin: 0;
}

.lc-channel__body {
    max-width: 60ch;
    margin: 0;
    color: var(--lc-ink-2);
    font-size: var(--lc-t-body);
    line-height: var(--lc-lh-body);
}

.lc-channel__detail {
    margin: var(--space-1) 0 0;
    overflow: hidden;
    color: var(--lc-ink-1);
    font-family: var(--lc-font-mono);
    font-size: var(--lc-t-label);
    text-overflow: ellipsis;
    white-space: nowrap;
}

.lc-channel__action {
    flex: none;
    align-self: center;
}


@media (min-width: 1024px) {
    .lc-help__grid {
        grid-template-columns: 1.2fr 1fr;
    }
}
` },
    { path: 'src/styles/business/tour.css', content: `.lc-tour {
    position: fixed;
    inset: 0;
    z-index: calc(var(--z-modal) + 20);
}

.lc-tour__spot {
    position: fixed;
    border-radius: var(--lc-r-md);
    box-shadow: 0 0 0 2px var(--azure), 0 0 0 9999px rgba(5, 6, 8, 0.74);
    transition: left var(--lc-base) var(--lc-ease), top var(--lc-base) var(--lc-ease), width var(--lc-base) var(--lc-ease), height var(--lc-base) var(--lc-ease);
    pointer-events: none;
}

.lc-tour__card {
    position: fixed;
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
    padding: var(--space-5);
    border-radius: var(--lc-r-lg);
    background: var(--lc-overlay);
    box-shadow: var(--lc-shadow-overlay);
    animation: lc-arrive var(--lc-base) var(--lc-ease);
}

.lc-tour__card:focus {
    outline: none;
}

.lc-tour__count {
    margin: 0;
    color: var(--azure-link);
    font-size: var(--lc-t-label);
    font-weight: var(--font-weight-medium);
}

.lc-tour__title {
    margin: 0;
    font-family: var(--lc-font-display);
    font-size: 1.125rem;
    font-weight: var(--font-weight-semibold);
}

.lc-tour__body {
    margin: 0;
    color: var(--lc-ink-2);
    font-size: var(--lc-t-body);
    line-height: var(--lc-lh-body);
}

.lc-tour__dots {
    display: flex;
    gap: 4px;
    margin: var(--space-2) 0 var(--space-1);
}

.lc-tour__dots span {
    width: 6px;
    height: 6px;
    border-radius: var(--radius-full);
    background: var(--lc-line-strong);
}

.lc-tour__dots span.is-on {
    width: 18px;
    background: var(--azure);
}

.lc-tour__actions {
    display: flex;
    align-items: center;
    gap: var(--space-2);
}

.lc-tour__spacer {
    flex: 1;
}

@media (prefers-reduced-motion: reduce) {
    .lc-tour__spot {
        transition: none;
    }

    .lc-tour__card {
        animation: none;
    }
}
` },
]

// The shell and navigation were restructured for the new sections, so they are replaced whole.
const REPLACE_FILES = [
    { path: 'src/components/business/BusinessShell.jsx', content: `import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Link, NavLink, Navigate, Outlet, useLocation } from 'react-router-dom'
import { ArrowLeftRight, Bell, ChevronRight, CirclePlay, LogOut, Menu, Plus, Search, Settings, Share2 } from 'lucide-react'
import { useAuth } from '../../hooks/useAuth'
import { loadWorkspace, pageStrength } from '../../services/business'
import { WorkspaceContext } from './WorkspaceContext'
import { NAV_FOOT, NAV_GROUPS, NAV_ITEMS, titleFor } from './nav'
import { BrandLoader, Mark, Ring, Wordmark, initials } from './Brand'
import Sheet from './Sheet'
import NewBookingSheet from './NewBookingSheet'
import BookingDetailSheet from './BookingDetailSheet'
import ShareLink from './ShareLink'
import Tour from './Tour'
import '../../styles/business/shell.css'

const NavItem = ({ item, onClick, compact = false }) => {
    const Icon = item.icon
    return (
        <NavLink to={item.to} end={item.end} className="biz-navlink" onClick={onClick} data-tour={item.tour}>
            <Icon size={compact ? 20 : 18} aria-hidden="true" />
            <span className="biz-navlink__label">{item.label}</span>
            {item.planned && <span className="biz-soon">Soon</span>}
        </NavLink>
    )
}

const ShellSkeleton = () => (
    <div className="biz-page" aria-hidden="true">
        <span className="lc-skel" style={{ width: 120, height: 16 }} />
        <span className="lc-skel" style={{ width: '55%', height: 40 }} />
        <span className="lc-skel" style={{ width: '100%', height: 72 }} />
        {[0, 1, 2].map((i) => <span key={i} className="lc-skel" style={{ width: '100%', height: 84 }} />)}
    </div>
)

const TOUR_KEY = 'locappoint_tour_done'

const tourSeen = () => {
    try { return localStorage.getItem(TOUR_KEY) === '1' } catch { return true }
}

const StartRow = ({ strength }) => (
    <NavLink to="/portal/start" className="biz-navlink biz-startrow" data-tour="start">
        <Ring value={strength.value} size={18} stroke={2.5} label={\`Setup \${strength.percent}% done\`} />
        <span className="biz-navlink__label">{strength.percent === 100 ? 'All set up' : 'Getting started'}</span>
        <span className="biz-startrow__pct biz-num">{strength.percent}%</span>
    </NavLink>
)

const StartCard = ({ strength, onClick }) => (
    <Link to="/portal/start" className="biz-strength" onClick={onClick}>
        <Ring value={strength.value} size={34} stroke={3.5} label={\`Setup \${strength.percent}% done\`} />
        <span className="biz-strength__text">
            <strong>{strength.percent === 100 ? 'All set up' : 'Getting started'} <span className="biz-num">{strength.percent}%</span></strong>
            <small>{strength.next ? \`Next: \${strength.next.label.toLowerCase()}\` : 'Replay the tour any time'}</small>
        </span>
    </Link>
)

const ambientTone = (timeZone = 'Europe/Lisbon') => {
    const hour = Number(new Intl.DateTimeFormat('en-GB', { timeZone, hour: '2-digit', hourCycle: 'h23' }).format(new Date()))
    if (hour >= 5 && hour < 11) return 'morning'
    if (hour >= 11 && hour < 16) return 'day'
    if (hour >= 16 && hour < 21) return 'evening'
    return 'night'
}

const BusinessShell = () => {
    const { user, userProfile, business: ownedBusiness, signOut, setMode } = useAuth()
    const location = useLocation()
    const [workspace, setWorkspace] = useState(null)
    const [loadError, setLoadError] = useState('')
    const [bookingsVersion, setBookingsVersion] = useState(0)
    const [newBooking, setNewBooking] = useState(null)
    const [openBookingRow, setOpenBookingRow] = useState(null)
    const [moreOpen, setMoreOpen] = useState(false)
    const [shareOpen, setShareOpen] = useState(false)
    const [tourOpen, setTourOpen] = useState(false)
    const [toast, setToast] = useState(null)
    const toastTimer = useRef(null)

    useEffect(() => { setMode('business') }, [setMode])

    const reloadWorkspace = useCallback(async () => {
        if (!ownedBusiness?.id) return
        try {
            setLoadError('')
            setWorkspace(await loadWorkspace(ownedBusiness.id))
        } catch (err) {
            console.error('Workspace load failed:', err)
            setLoadError('We could not load your business. Check your connection, then reload the page.')
        }
    }, [ownedBusiness?.id])

    useEffect(() => { reloadWorkspace() }, [reloadWorkspace])
    useEffect(() => () => clearTimeout(toastTimer.current), [])

    const notify = useCallback((message) => {
        clearTimeout(toastTimer.current)
        setToast({ message, key: Date.now() })
        toastTimer.current = setTimeout(() => setToast(null), 3200)
    }, [])

    const refreshBookings = useCallback(() => setBookingsVersion((v) => v + 1), [])
    const openNewBooking = useCallback((prefill = {}) => setNewBooking(prefill), [])
    const closeNewBooking = useCallback(() => setNewBooking(null), [])
    const openBooking = useCallback((booking) => setOpenBookingRow(booking), [])
    const openTour = useCallback(() => {
        setMoreOpen(false)
        setTourOpen(true)
    }, [])
    const closeTour = useCallback(() => {
        setTourOpen(false)
        try { localStorage.setItem(TOUR_KEY, '1') } catch { /* noop */ }
    }, [])

    useEffect(() => {
        if (!workspace || tourSeen()) return undefined
        const timer = setTimeout(() => setTourOpen(true), 900)
        return () => clearTimeout(timer)
    }, [workspace])
    const closeBooking = useCallback(() => setOpenBookingRow(null), [])

    const value = useMemo(() => {
        if (!workspace) return null
        const me = workspace.members.find((m) => m.user_id === user?.id) || null
        return {
            ...workspace,
            me,
            isOwner: me?.role === 'owner',
            bookableMembers: workspace.members.filter((m) => m.is_bookable),
            activeServices: workspace.services.filter((s) => s.is_active),
            strength: pageStrength(workspace),
            reloadWorkspace,
            bookingsVersion,
            refreshBookings,
            openNewBooking,
            openBooking,
            openTour,
            notify,
        }
    }, [workspace, user?.id, reloadWorkspace, bookingsVersion, refreshBookings, openNewBooking, openBooking, openTour, notify])

    if (!ownedBusiness) {
        if (location.pathname !== '/portal/page') return <Navigate to="/portal/page" replace />
        return (
            <div className="biz-bare">
                <header className="biz-topbar">
                    <span className="biz-topbar__brand"><Mark size={26} /><Wordmark /></span>
                    <Link to="/client" className="biz-textbtn">Back to Booking</Link>
                </header>
                <main className="biz-content"><Outlet /></main>
            </div>
        )
    }

    const business = value?.business || ownedBusiness
    const title = titleFor(location.pathname)
    const tabs = NAV_ITEMS.filter((item) => item.tab)
    const moreActive = !tabs.some((item) => (item.end ? location.pathname === item.to : location.pathname.startsWith(item.to)))
    const strength = value?.strength
    const name = userProfile?.full_name || user?.email || ''

    return (
        <div className="biz-shell">
            <aside className="biz-sidebar" aria-label="Business navigation">
                <div className="biz-brand">
                    <Mark size={28} />
                    <Wordmark />
                </div>

                <Link to="/portal/page" className="biz-bizcard">
                    <span className="biz-avatar biz-avatar--business">{initials(business.business_name)}</span>
                    <span className="biz-bizcard__text">
                        <strong>{business.business_name}</strong>
                        <small className={business.is_active === false ? 'is-paused' : ''}>
                            {business.is_active === false ? 'Bookings paused' : 'Taking bookings'}
                        </small>
                    </span>
                    <ChevronRight size={16} aria-hidden="true" className="biz-bizcard__chevron" />
                </Link>

                <nav className="biz-sidebar__nav">
                    {NAV_GROUPS.map((group) => (
                        <div key={group.label} className="biz-navgroup">
                            <p className="biz-navgroup__label">{group.label}</p>
                            {group.items.map((item) => <NavItem key={item.to} item={item} />)}
                        </div>
                    ))}
                </nav>

                <div className="biz-sidebar__foot">
                    {strength && <StartRow strength={strength} />}
                    {NAV_FOOT.filter((item) => item.to !== '/portal/start').map((item) => <NavItem key={item.to} item={item} />)}
                    <Link to="/client" className="biz-navlink">
                        <ArrowLeftRight size={18} aria-hidden="true" />
                        <span className="biz-navlink__label">Switch to Booking</span>
                    </Link>
                    <div className="biz-account">
                        <span className="biz-avatar">{initials(name)}</span>
                        <span className="biz-account__text">
                            <strong>{userProfile?.full_name}</strong>
                            <small>{user?.email}</small>
                        </span>
                        <NavLink to="/portal/settings" className="biz-iconbtn biz-iconbtn--quiet" aria-label="Settings">
                            <Settings size={16} aria-hidden="true" />
                        </NavLink>
                        <button type="button" className="biz-iconbtn biz-iconbtn--quiet" onClick={signOut} aria-label="Sign out">
                            <LogOut size={16} aria-hidden="true" />
                        </button>
                    </div>
                </div>
            </aside>

            <div className={\`biz-main biz-main--\${ambientTone(value?.business?.timezone)}\`}>
                <div className="biz-ambient" aria-hidden="true" />
                <header className="biz-topbar">
                    <span className="biz-topbar__brand">
                        <Mark size={26} />
                        <span className="biz-topbar__name">{business.business_name}</span>
                    </span>
                    <span className="biz-topbar__title">{title}</span>
                    <button type="button" className="biz-search" onClick={() => notify('Search arrives with Clients')}>
                        <Search size={16} aria-hidden="true" />
                        <span>Search clients and bookings</span>
                        <kbd>Ctrl K</kbd>
                    </button>
                    <div className="biz-topbar__actions">
                        <NavLink to="/portal/notifications" className="biz-iconbtn" aria-label="Notifications">
                            <Bell size={18} aria-hidden="true" />
                        </NavLink>
                        <button type="button" className="biz-iconbtn biz-topbar__share" onClick={() => setShareOpen(true)} aria-label="Share your booking link">
                            <Share2 size={18} aria-hidden="true" />
                        </button>
                        <button type="button" className="btn btn--primary biz-topbar__new" onClick={() => openNewBooking()} disabled={!value} data-tour="new">
                            <Plus size={18} aria-hidden="true" /> New booking
                        </button>
                    </div>
                </header>

                <main className="biz-content">
                    {loadError ? (
                        <div className="biz-state" role="alert">
                            <BrandLoader label="Could not load" />
                            <p>{loadError}</p>
                            <button type="button" className="btn btn--secondary" onClick={reloadWorkspace}>Try again</button>
                        </div>
                    ) : value ? (
                        <WorkspaceContext.Provider value={value}>
                            <Outlet />
                        </WorkspaceContext.Provider>
                    ) : (
                        <ShellSkeleton />
                    )}
                </main>
            </div>

            <nav className="biz-tabbar" aria-label="Business">
                {tabs.map((item) => {
                    const Icon = item.icon
                    return (
                        <NavLink key={item.to} to={item.to} end={item.end} className="biz-tab" data-tour={item.tour}>
                            <Icon size={22} aria-hidden="true" />
                            <span>{item.label}</span>
                        </NavLink>
                    )
                })}
                <button type="button" className={\`biz-tab\${moreActive ? ' active' : ''}\`} onClick={() => setMoreOpen(true)} aria-haspopup="dialog" data-tour="more">
                    <Menu size={22} aria-hidden="true" />
                    <span>More</span>
                </button>
            </nav>

            {value && (
                <button type="button" className="biz-fab" onClick={() => openNewBooking()} aria-label="New booking" data-tour="new">
                    <Plus size={26} aria-hidden="true" />
                </button>
            )}

            <Sheet open={moreOpen} onClose={() => setMoreOpen(false)} title="More">
                <div className="biz-more">
                    {strength && <StartCard strength={strength} onClick={() => setMoreOpen(false)} />}
                    {NAV_GROUPS.map((group) => {
                        const items = group.items.filter((item) => !item.tab)
                        if (!items.length) return null
                        return (
                            <div key={group.label} className="biz-navgroup">
                                <p className="biz-navgroup__label">{group.label}</p>
                                {items.map((item) => <NavItem key={item.to} item={item} compact onClick={() => setMoreOpen(false)} />)}
                            </div>
                        )
                    })}
                    <div className="biz-navgroup">
                        <p className="biz-navgroup__label">Help</p>
                        {NAV_FOOT.map((item) => <NavItem key={item.to} item={item} compact onClick={() => setMoreOpen(false)} />)}
                        <button type="button" className="biz-navlink" onClick={openTour}>
                            <CirclePlay size={20} aria-hidden="true" />
                            <span className="biz-navlink__label">Replay the tour</span>
                        </button>
                    </div>
                    <div className="biz-navgroup">
                        <p className="biz-navgroup__label">Account</p>
                        <NavLink to="/portal/settings" className="biz-navlink" onClick={() => setMoreOpen(false)}>
                            <Settings size={20} aria-hidden="true" />
                            <span className="biz-navlink__label">Settings</span>
                        </NavLink>
                        <Link to="/client" className="biz-navlink" onClick={() => setMoreOpen(false)}>
                            <ArrowLeftRight size={20} aria-hidden="true" />
                            <span className="biz-navlink__label">Switch to Booking</span>
                        </Link>
                        <button type="button" className="biz-navlink" onClick={signOut}>
                            <LogOut size={20} aria-hidden="true" />
                            <span className="biz-navlink__label">Sign out</span>
                        </button>
                    </div>
                </div>
            </Sheet>

            {value && (
                <WorkspaceContext.Provider value={value}>
                    <Sheet open={shareOpen} onClose={() => setShareOpen(false)} title="Your booking link">
                        <ShareLink business={value.business} />
                    </Sheet>
                    <NewBookingSheet open={Boolean(newBooking)} prefill={newBooking} onClose={closeNewBooking} />
                    <BookingDetailSheet booking={openBookingRow} onClose={closeBooking} />
                    <Tour open={tourOpen} onClose={closeTour} />
                </WorkspaceContext.Provider>
            )}

            <div className="biz-toast" role="status" aria-live="polite">
                {toast && <span key={toast.key} className="biz-toast__msg">{toast.message}</span>}
            </div>
        </div>
    )
}

export default BusinessShell
` },
    { path: 'src/components/business/nav.js', content: `import { Bell, Bot, CalendarDays, ChartColumn, Clock, Gift, LifeBuoy, Radio, Rocket, Scissors, Star, Store, Sun, Users, UsersRound } from 'lucide-react'

export const NAV_GROUPS = [
    {
        label: 'Run the day',
        items: [
            { to: '/portal', label: 'Today', icon: Sun, end: true, tab: true, tour: 'today' },
            { to: '/portal/calendar', label: 'Calendar', icon: CalendarDays, tab: true, tour: 'calendar' },
            { to: '/portal/assistant', label: 'Loca AI', icon: Bot, tab: true, planned: 'assistant', tour: 'ai' },
            { to: '/portal/clients', label: 'Clients', icon: Users, tab: true, planned: 'clients' },
        ],
    },
    {
        label: 'Set up',
        items: [
            { to: '/portal/services', label: 'Services', icon: Scissors, tour: 'services' },
            { to: '/portal/team', label: 'Team', icon: UsersRound, planned: 'team' },
            { to: '/portal/hours', label: 'Hours', icon: Clock },
            { to: '/portal/page', label: 'Business page', icon: Store, tour: 'page' },
        ],
    },
    {
        label: 'Grow',
        items: [
            { to: '/portal/channels', label: 'Channels', icon: Radio, tour: 'channels' },
            { to: '/portal/insights', label: 'Insights', icon: ChartColumn, planned: 'insights' },
            { to: '/portal/reviews', label: 'Reviews', icon: Star, planned: 'reviews' },
            { to: '/portal/invite', label: 'Invite a business', icon: Gift, planned: 'invite' },
        ],
    },
]

export const NAV_FOOT = [
    { to: '/portal/start', label: 'Getting started', icon: Rocket, tour: 'start' },
    { to: '/portal/help', label: 'Help and support', icon: LifeBuoy, tour: 'help' },
]

export const NAV_ITEMS = NAV_GROUPS.flatMap((group) => group.items)

export const PLANNED = {
    assistant: {
        title: 'Loca AI',
        icon: Bot,
        promise: 'Run your day in a sentence. Ask what is next, book a caller, block an hour, and it is done.',
        points: [
            'Ask "What is my day?" or "Who is next?" and get the answer in a line',
            'Book, confirm, move and cancel by chat, always with a confirm step first',
            'See every conversation Loca AI has with your clients on WhatsApp',
            'Decide what it may answer, and when it hands the chat over to you',
        ],
        preview: 'chat',
    },
    clients: {
        title: 'Clients',
        icon: Users,
        promise: 'Everyone who books you, in one place, with the history that matters.',
        points: [
            'Everyone who booked online, by phone or walked in, searchable',
            'Visits, last visit and total spent on every client',
            'Reliability at a glance: kept, cancelled and no-show counts',
            'Private notes, and book again in one tap',
        ],
        preview: 'list',
    },
    team: {
        title: 'Team',
        icon: UsersRound,
        promise: 'Add the people who take bookings, each with their own calendar.',
        points: [
            'Invite by email or phone; they join with their own account',
            'Owner and staff roles: staff see their own day, you see everyone',
            'Each person has their own hours and the services they do',
            'Clients pick a person, or anyone who is free',
        ],
        preview: 'list',
    },
    insights: {
        title: 'Insights',
        icon: ChartColumn,
        promise: 'See what your time is worth, week by week.',
        points: [
            'Money this week against last, earned and still to come',
            'Lost to no-shows, and saved by reminders',
            'Your busiest days and hours, and your most booked services',
            'A weekly recap, ready to share on WhatsApp or Instagram',
        ],
        preview: 'chart',
    },
    reviews: {
        title: 'Reviews',
        icon: Star,
        promise: 'Let happy clients say so, where new clients will read it.',
        points: [
            'Clients rate their visit after it is marked completed',
            'Reviews show on your business page and in Browse',
            'Reply publicly, or privately when something went wrong',
            'Only clients who really visited can leave a review',
        ],
        preview: 'list',
    },
    invite: {
        title: 'Invite a business',
        icon: Gift,
        promise: 'Know a business that should be on Locappoint? Invite them. When they start, you both get a month free.',
        points: [
            'Your own invite link to send on WhatsApp or by email',
            'One free month for you and one for them when they take their first booking',
            'See who you invited and which months you have earned',
            'No limit on how many businesses you invite',
        ],
        preview: 'list',
    },
    notifications: {
        title: 'Notifications',
        icon: Bell,
        promise: 'Everything that changed, the moment it changes.',
        points: [
            'New bookings, cancellations and moves, as they happen',
            'An unread count on the bell, so nothing slips',
            'Email and WhatsApp alerts with your reminders',
        ],
        preview: 'list',
    },
}

const EXTRA_TITLES = [
    ['/portal/settings', 'Settings'],
    ['/portal/notifications', 'Notifications'],
    ['/portal/ui', 'Primitives'],
]

export const titleFor = (pathname) => {
    const match = [...NAV_ITEMS, ...NAV_FOOT]
        .sort((a, b) => b.to.length - a.to.length)
        .find((item) => (item.end ? pathname === item.to : pathname.startsWith(item.to)))
    if (match) return match.label
    const extra = EXTRA_TITLES.find(([path]) => pathname.startsWith(path))
    return extra ? extra[1] : 'Today'
}

export const TOUR_STEPS = [
    { target: 'today', title: 'Today is your home', body: 'Your day at a glance: who is next, what needs confirming, and the free time you can still fill.' },
    { target: 'new', title: 'Add a booking in seconds', body: 'Phone call or walk-in? Tap here, pick a time, type a name. That is it.' },
    { target: 'calendar', title: 'Plan ahead', body: 'See any day or the whole week. Tap a booking to confirm, move or cancel it.' },
    { target: 'more', title: 'Everything else lives here', body: 'Services, hours, your page, channels and help. Your setup progress is at the top.' },
    { target: 'services', title: 'What you offer', body: 'Your services, prices and how long each one takes. Clients book from this list.' },
    { target: 'page', title: 'Your page', body: 'What clients see at your link. A description, photos and your address make it book more.' },
    { target: 'channels', title: 'Everywhere you can be booked', body: 'Your link today; WhatsApp, Google Maps and AI assistants as they come online.' },
    { target: 'help', title: 'We are here', body: 'Guides, WhatsApp support and tickets. You can replay this tour from Getting started any time.' },
]
` },
]

const PATCHES = [
    {
        file: 'src/styles/business/shell.css',
        edits: [
            { desc: "Middle density on desktop", find: `@media (min-width: 1024px) {
    .biz-shell {
        grid-template-columns: 240px 1fr;
    }

    .biz-sidebar {
        width: 240px;
        gap: 14px;
        padding: 12px;
    }

    .biz-brand .lc-mark {
        width: 24px;
        height: 24px;
    }

    .biz-brand .lc-wordmark {
        font-size: 15px;
    }

    .biz-bizcard {
        gap: 10px;
        padding: 8px;
        border-radius: var(--lc-r-md);
    }

    .biz-bizcard .biz-avatar--business {
        width: 32px;
        height: 32px;
        border-radius: 9px;
        font-size: 12px;
    }

    .biz-bizcard__text strong { font-size: 13px; }
    .biz-bizcard__text small { font-size: 11px; }

    .biz-navgroup + .biz-navgroup { margin-top: 12px; }

    .biz-navgroup__label {
        margin-bottom: 2px;
        padding: 0 10px;
        font-size: 11px;
    }

    .biz-navlink {
        gap: 10px;
        min-height: 32px;
        padding: 0 10px;
        border-radius: 7px;
        font-size: 13px;
    }

    .biz-navlink svg {
        width: 16px;
        height: 16px;
    }

    .biz-soon {
        padding: 1px 6px;
        font-size: 10px;
    }

    .biz-sidebar__foot .biz-strength {
        padding: 8px 10px;
        gap: 10px;
    }

    .biz-strength__text strong { font-size: 12.5px; }
    .biz-strength__text small { font-size: 11px; }

    .biz-account__text strong { font-size: 13px; }
    .biz-account__text small { font-size: 11px; }

    .biz-topbar {
        height: 52px;
        padding: 0 28px;
    }

    .biz-topbar__title { font-size: 14px; }

    .biz-search {
        width: 280px;
        height: 34px;
        font-size: 13px;
    }

    .biz-search span {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .biz-topbar .biz-iconbtn {
        width: 34px;
        height: 34px;
    }

    .biz-topbar .biz-topbar__new {
        min-height: 34px;
        padding: 0 14px;
        font-size: 13px;
    }

    .biz-content { padding: 28px 32px 48px; }

    .biz-page { gap: 20px; }

    .biz-page__title { font-size: 26px; }
}

`, replace: `@media (min-width: 1024px) {
    .biz-shell {
        grid-template-columns: 256px 1fr;
    }

    .biz-sidebar {
        width: 256px;
        gap: 16px;
        padding: 14px;
    }

    .biz-brand .lc-mark {
        width: 26px;
        height: 26px;
    }

    .biz-brand .lc-wordmark {
        font-size: 16px;
    }

    .biz-bizcard {
        gap: 10px;
        padding: 10px;
        border-radius: var(--lc-r-md);
    }

    .biz-bizcard .biz-avatar--business {
        width: 32px;
        height: 32px;
        border-radius: 9px;
        font-size: 12px;
    }

    .biz-bizcard__text strong { font-size: 14px; }
    .biz-bizcard__text small { font-size: 12px; }

    .biz-navgroup + .biz-navgroup { margin-top: 14px; }

    .biz-navgroup__label {
        margin-bottom: 2px;
        padding: 0 12px;
        font-size: 12px;
    }

    .biz-navlink {
        gap: 12px;
        min-height: 34px;
        padding: 0 12px;
        border-radius: 8px;
        font-size: 14px;
    }

    .biz-navlink svg {
        width: 17px;
        height: 17px;
    }

    .biz-soon {
        padding: 1px 7px;
        font-size: 10.5px;
    }

    .biz-sidebar__foot .biz-strength {
        padding: 10px 12px;
        gap: 12px;
    }

    .biz-strength__text strong { font-size: 13px; }
    .biz-strength__text small { font-size: 12px; }

    .biz-account__text strong { font-size: 14px; }
    .biz-account__text small { font-size: 12px; }

    .biz-topbar {
        height: 56px;
        padding: 0 32px;
    }

    .biz-topbar__title { font-size: 15px; }

    .biz-search {
        width: 300px;
        height: 36px;
        font-size: 13.5px;
    }

    .biz-search span {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .biz-topbar .biz-iconbtn {
        width: 36px;
        height: 36px;
    }

    .biz-topbar .biz-topbar__new {
        min-height: 36px;
        padding: 0 16px;
        font-size: 14px;
    }

    .biz-content { padding: 32px 36px 56px; }

    .biz-page { gap: 22px; }

    .biz-page__title { font-size: 28px; }
}

@media (min-width: 1024px) and (max-height: 860px) {
    .biz-sidebar {
        gap: 10px;
        padding-top: 12px;
        padding-bottom: 10px;
    }

    .biz-bizcard {
        padding: 8px;
    }

    .biz-navlink {
        min-height: 32px;
    }

    .biz-navgroup + .biz-navgroup {
        margin-top: 10px;
    }

    .biz-navgroup__label {
        margin-bottom: 0;
    }

    .biz-account {
        margin-top: 4px;
        padding-top: 8px;
    }
}

.biz-startrow .ui-ring {
    flex: none;
}

.biz-startrow__pct {
    color: var(--lc-ink-3);
    font-size: 12px;
}

.biz-startrow.active .biz-startrow__pct {
    color: var(--lc-ink-1);
}

` },
        ],
    },
    {
        file: 'src/styles/business/day.css',
        edits: [
            { desc: "Middle density on desktop", find: `@media (min-width: 1024px) {
    .biz-dayhead__date { font-size: 32px; }
    .biz-dayhead__weekday { font-size: 13px; }
    .biz-stats dt { font-size: 11px; }
    .biz-stats dd { font-size: 18px; }
    .biz-stats div { padding: 8px 0; }
    .biz-agenda__row { grid-template-columns: 52px 1fr; gap: 10px; padding: 3px 0; }
    .biz-agenda__time { padding-top: 10px; font-size: 14px; }
    .biz-agenda__open { padding: 10px 14px; }
    .biz-agenda__who { font-size: 15px; }
    .biz-agenda__what { font-size: 13px; }
    .biz-agenda__confirm { min-height: 32px; padding: 0 12px; font-size: 13px; }
    .biz-agenda__gap { min-height: 40px; }
    .biz-agenda__book { min-height: 30px; }
    .biz-panel { padding: 16px; }
    .biz-closed { padding: 16px; }
    .biz-share__slug { font-size: 16px; }
}`, replace: `@media (min-width: 1024px) {
    .biz-dayhead__date { font-size: 34px; }
    .biz-dayhead__weekday { font-size: 13px; }
    .biz-stats dt { font-size: 11px; }
    .biz-stats dd { font-size: 20px; }
    .biz-stats div { padding: 8px 0; }
    .biz-agenda__row { grid-template-columns: 56px 1fr; gap: 12px; padding: 4px 0; }
    .biz-agenda__time { padding-top: 12px; font-size: 15px; }
    .biz-agenda__open { padding: 12px 16px; }
    .biz-agenda__who { font-size: 16px; }
    .biz-agenda__what { font-size: 13px; }
    .biz-agenda__confirm { min-height: 36px; padding: 0 14px; font-size: 13.5px; }
    .biz-agenda__gap { min-height: 44px; }
    .biz-agenda__book { min-height: 30px; }
    .biz-panel { padding: 18px; }
    .biz-closed { padding: 16px; }
    .biz-share__slug { font-size: 16px; }
}` },
        ],
    },
    {
        file: 'src/services/business.js',
        edits: [
            { desc: "Setup steps shared by sidebar, More and Getting started; no dead-end suggestions", find: `export const pageStrength = ({ business, services, hours }) => {
    const steps = [
        { done: true, label: 'Business details' },
        { done: Boolean(business.description?.trim()), label: 'Add a description', to: '/portal/page' },
        { done: Boolean(business.address?.trim()), label: 'Add your address', to: '/portal/page' },
        { done: Boolean(business.whatsapp?.trim()), label: 'Add your WhatsApp', to: '/portal/page' },
        { done: Boolean(business.logo_url), label: 'Add a logo', to: '/portal/page' },
        { done: Boolean(business.banner_url), label: 'Add a cover photo', to: '/portal/page' },
        { done: services.some((s) => s.is_active), label: 'Add a service', to: '/portal/services' },
        { done: hours.some((h) => !h.staff_id), label: 'Set your opening hours', to: '/portal/hours' },
    ]
    const done = steps.filter((step) => step.done).length
    return { value: done / steps.length, percent: Math.round((done / steps.length) * 100), next: steps.find((step) => !step.done) }
}
`, replace: `export const pageSteps = ({ business, services, hours }) => [
    { done: true, label: 'Business details', hint: 'Name, category and city' },
    { done: Boolean(business.description?.trim()), label: 'Add a description', to: '/portal/page', hint: 'Two lines on what makes you worth the visit' },
    { done: Boolean(business.address?.trim()), label: 'Add your address', to: '/portal/page', hint: 'So clients can find you' },
    { done: Boolean(business.whatsapp?.trim()), label: 'Add your WhatsApp', to: '/portal/page', hint: 'Clients can message you before they book' },
    { done: Boolean(business.logo_url), label: 'Add a logo', soon: true, hint: 'Arrives with the business page update' },
    { done: Boolean(business.banner_url), label: 'Add a cover photo', soon: true, hint: 'Arrives with the business page update' },
    { done: services.some((s) => s.is_active), label: 'Add a service', to: '/portal/services', hint: 'Name, price and how long it takes' },
    { done: hours.some((h) => !h.staff_id), label: 'Set your opening hours', to: '/portal/hours', hint: 'When clients can book you' },
]

export const pageStrength = (workspace) => {
    const steps = pageSteps(workspace)
    const done = steps.filter((step) => step.done).length
    return {
        value: done / steps.length,
        percent: Math.round((done / steps.length) * 100),
        next: steps.find((step) => !step.done && !step.soon),
    }
}
` },
        ],
    },
    {
        file: 'src/pages/business/Planned.jsx',
        edits: [
            { desc: "Icon comes from the plan itself", find: `    const nav = NAV_ITEMS.find((item) => item.planned === section)
    const Icon = nav?.icon
`, replace: `    const Icon = plan.icon
` },
            { desc: "Drop the unused nav import", find: `import { NAV_ITEMS, PLANNED } from '../../components/business/nav'`, replace: `import { PLANNED } from '../../components/business/nav'` },
        ],
    },
    {
        file: 'src/BookingApp.jsx',
        edits: [
            { desc: "Import the new pages", find: `import UiGallery from './pages/business/UiGallery'
`, replace: `import UiGallery from './pages/business/UiGallery'
import GettingStarted from './pages/business/GettingStarted'
import Help from './pages/business/Help'
import Channels from './pages/business/Channels'
` },
            { desc: "Routes for the new sections", find: `                    <Route path="ui" element={<UiGallery />} />
`, replace: `                    <Route path="ui" element={<UiGallery />} />
                    <Route path="start" element={<GettingStarted />} />
                    <Route path="help" element={<Help />} />
                    <Route path="channels" element={<Channels />} />
                    <Route path="reviews" element={<Planned section="reviews" />} />
                    <Route path="invite" element={<Planned section="invite" />} />
` },
        ],
    },
    {
        file: 'src/pages/app/legal/Cookies.jsx',
        edits: [
            { desc: "List the tour key", find: `    { name: 'locappoint_mode', type: 'Local storage', purpose: 'Opens the side you used last: Booking or My business', kept: 'Until you clear it' },
`, replace: `    { name: 'locappoint_mode', type: 'Local storage', purpose: 'Opens the side you used last: Booking or My business', kept: 'Until you clear it' },
    { name: 'locappoint_tour_done', type: 'Local storage', purpose: 'Remembers that you have seen the dashboard tour', kept: 'Until you clear it' },
` },
        ],
    },
]

const RETIRES = []

let failed = false

for (const nf of NEW_FILES) {
    if (fs.existsSync(path.join(REPO, nf.path))) { console.error(`[FAIL] Already exists: ${nf.path}`); failed = true }
}
for (const rf of REPLACE_FILES) {
    if (!fs.existsSync(path.join(REPO, rf.path))) { console.error(`[FAIL] Missing, apply the 4a-2 redesign first: ${rf.path}`); failed = true }
}

const fileChanges = new Map()
for (const group of PATCHES) {
    const fullPath = path.join(REPO, group.file)
    if (!fs.existsSync(fullPath)) { console.error(`[FAIL] Missing: ${group.file}`); failed = true; continue }
    let content = fs.readFileSync(fullPath, 'utf8')
    const original = content
    const crlf = (content.match(/\r\n/g) || []).length
    const lf = (content.match(/\n/g) || []).length - crlf
    const eol = crlf > lf ? '\r\n' : '\n'
    let ok = true
    for (const edit of group.edits) {
        // Anchors accept CRLF or LF; replacements follow the file's dominant ending.
        const pattern = edit.find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\n/g, '\\r?\\n')
        const matches = (content.match(new RegExp(pattern, 'g')) || []).length
        if (matches !== 1) {
            console.error(`[FAIL] ${group.file}: ${matches} matches for "${edit.desc}" (expected 1)`)
            failed = true; ok = false; break
        }
        content = content.replace(new RegExp(pattern), () => edit.replace.replace(/\n/g, eol))
    }
    if (ok) fileChanges.set(fullPath, { original, modified: content, edits: group.edits })
}

const retirePaths = []
for (const rel of RETIRES) {
    const full = path.join(REPO, rel)
    if (!fs.existsSync(full)) { console.error(`[FAIL] Retire target missing: ${rel}`); failed = true; continue }
    if (fs.existsSync(`${full}.mistake`)) { console.error(`[FAIL] Already retired: ${rel}.mistake`); failed = true; continue }
    retirePaths.push({ full, rel })
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const nf of NEW_FILES) {
    fs.mkdirSync(path.dirname(path.join(REPO, nf.path)), { recursive: true })
    fs.writeFileSync(path.join(REPO, nf.path), nf.content)
    console.log(`[NEW] ${nf.path}`)
}
for (const rf of REPLACE_FILES) {
    const full = path.join(REPO, rf.path)
    fs.writeFileSync(`${full}.backup`, fs.readFileSync(full))
    fs.writeFileSync(full, rf.content)
    console.log(`[REPLACE] ${rf.path}`)
}
for (const [fullPath, change] of fileChanges) {
    fs.writeFileSync(`${fullPath}.backup`, change.original)
    fs.writeFileSync(fullPath, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, fullPath)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}

for (const { full, rel } of retirePaths) {
    fs.renameSync(full, `${full}.mistake`)
    console.log(`[RETIRE] ${rel} -> .mistake`)
}

console.log('\n[DONE]')
