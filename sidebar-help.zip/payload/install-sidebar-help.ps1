$ErrorActionPreference = 'Stop'

Write-Host ""
Write-Host "  Locappoint - Sidebar, Getting started and tour, Help and support, Channels" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path 'package.json')) { Write-Host "  [ABORT] No package.json. Run from repo root." -ForegroundColor Red; exit 1 }
$pkg = Get-Content 'package.json' -Raw | ConvertFrom-Json
if ($pkg.name -ne 'locappoint') { Write-Host "  [ABORT] Wrong package: $($pkg.name)" -ForegroundColor Red; exit 1 }
try { $null = & node --version } catch { Write-Host "  [ABORT] Node.js not found." -ForegroundColor Red; exit 1 }

Write-Host "  Applies on top of compact-light (already installed)." -ForegroundColor Magenta
Write-Host "  Run support-tickets.sql in Supabase for tickets to work." -ForegroundColor Magenta
Write-Host ""
Write-Host "  What this does:" -ForegroundColor White
Write-Host ""
Write-Host "    [NEW]      Tour.jsx + tour.css  (guided tour, plays once, replayable)" -ForegroundColor Green
Write-Host "    [NEW]      pages/business/  GettingStarted, Help, Channels + support.css" -ForegroundColor Green
Write-Host "    [NEW]      constants/support.js, services/support.js" -ForegroundColor Green
Write-Host "    [REPLACE]  BusinessShell.jsx, nav.js  (new groups, Getting started, Help)" -ForegroundColor Yellow
Write-Host "    [EDIT]     shell.css, day.css  (middle density, fits laptop screens)" -ForegroundColor Yellow
Write-Host "    [EDIT]     business.js, Planned.jsx, BookingApp.jsx, legal/Cookies.jsx" -ForegroundColor Yellow
Write-Host ""
Write-Host "  Everything replaced or edited is saved as *.backup first." -ForegroundColor Gray
Write-Host ""

$confirm = Read-Host "  Apply? (y/n)"
if ($confirm -ne 'y' -and $confirm -ne 'Y') { Write-Host "  [CANCELLED]" -ForegroundColor Yellow; exit 0 }
Write-Host ""

& node (Join-Path $PSScriptRoot 'patch-sidebar-help.mjs')
if ($LASTEXITCODE -ne 0) { Write-Host "  [FAIL] Exit code $LASTEXITCODE" -ForegroundColor Red; exit $LASTEXITCODE }

$payloadDir = $PSScriptRoot
if ((Split-Path $payloadDir -Leaf) -eq 'payload') {
    Set-Location (Split-Path $payloadDir -Parent)
    Remove-Item $payloadDir -Recurse -Force
}

Write-Host ""
Write-Host "  Done. npm run build. The tour plays once on first visit to /portal." -ForegroundColor Green
Write-Host ""
