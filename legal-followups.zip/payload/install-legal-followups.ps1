$ErrorActionPreference = 'Stop'

Write-Host ""
Write-Host "  Locappoint - Legal follow-ups" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path 'package.json')) { Write-Host "  [ABORT] No package.json. Run from repo root." -ForegroundColor Red; exit 1 }
$pkg = Get-Content 'package.json' -Raw | ConvertFrom-Json
if ($pkg.name -ne 'locappoint') { Write-Host "  [ABORT] Wrong package: $($pkg.name)" -ForegroundColor Red; exit 1 }
try { $null = & node --version } catch { Write-Host "  [ABORT] Node.js not found." -ForegroundColor Red; exit 1 }

Write-Host "  What this does:" -ForegroundColor White
Write-Host ""
Write-Host "    [EDIT]    src/hooks/useUserCountry.js  (1 edit: browser guess, no IP lookup)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/constants/legalEntity.js  (1 edit: Supabase region Ireland)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/pages/app/legal/Ranking.jsx  (2 edits: matches the real Browse query)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/pages/app/Businesses.jsx  (2 edits: active pages only, header comment)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/main.jsx  (1 edit: Latin font subsets only)" -ForegroundColor Yellow
Write-Host ""
Write-Host "  Backups saved as *.backup." -ForegroundColor Gray
Write-Host ""

$confirm = Read-Host "  Apply? (y/n)"
if ($confirm -ne 'y' -and $confirm -ne 'Y') { Write-Host "  [CANCELLED]" -ForegroundColor Yellow; exit 0 }
Write-Host ""

& node (Join-Path $PSScriptRoot 'patch-legal-followups.mjs')
if ($LASTEXITCODE -ne 0) { Write-Host "  [FAIL] Exit code $LASTEXITCODE" -ForegroundColor Red; exit $LASTEXITCODE }

$payloadDir = $PSScriptRoot
if ((Split-Path $payloadDir -Leaf) -eq 'payload') {
    Set-Location (Split-Path $payloadDir -Parent)
    Remove-Item $payloadDir -Recurse -Force
}

Write-Host ""
Write-Host "  Done. npm run build, redeploy." -ForegroundColor Green
Write-Host ""
