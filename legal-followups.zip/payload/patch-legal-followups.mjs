import fs from 'fs'
import path from 'path'

const REPO = process.cwd()

const NEW_FILES = []

const PATCHES = [
    {
        file: 'src/hooks/useUserCountry.js',
        edits: [
            { desc: "Browser-based country guess, no IP lookup", find: `// useUserCountry.js - Hook for detecting user's country via IP
// Location: src/hooks/useUserCountry.js

import { useState, useEffect } from 'react'

// Module-level cache - persists across component instances
let cachedCountry = null
let detectionPromise = null

const detectCountry = async () => {
    // Return cached result if available
    if (cachedCountry !== null) {
        return cachedCountry
    }

    // If detection is already in progress, wait for it
    if (detectionPromise) {
        return detectionPromise
    }

    // Start detection
    detectionPromise = (async () => {
        try {
            const response = await fetch('https://api.country.is/', {
                signal: AbortSignal.timeout(3000)
            })
            const data = await response.json()
            cachedCountry = data.country || null
            return cachedCountry
        } catch (error) {
            console.warn('Could not detect user country:', error)
            cachedCountry = null
            return null
        } finally {
            detectionPromise = null
        }
    })()

    return detectionPromise
}

/**
 * Hook to detect user's country via IP geolocation
 * Results are cached - only one API call is made per session
 * 
 * @returns {{ countryCode: string | null, isDetecting: boolean }}
 * 
 * @example
 * const { countryCode, isDetecting } = useUserCountry()
 * // countryCode: 'US', 'BR', 'NG', 'PT', etc. or null if detection failed
 */
export const useUserCountry = () => {
    const [countryCode, setCountryCode] = useState(cachedCountry)
    const [isDetecting, setIsDetecting] = useState(cachedCountry === null)

    useEffect(() => {
        // Skip if already cached
        if (cachedCountry !== null) {
            setCountryCode(cachedCountry)
            setIsDetecting(false)
            return
        }

        let isMounted = true

        detectCountry().then(code => {
            if (isMounted) {
                setCountryCode(code)
                setIsDetecting(false)
            }
        })

        return () => {
            isMounted = false
        }
    }, [])

    return { countryCode, isDetecting }
}

// Optional: manually clear cache (useful for testing)
export const clearCountryCache = () => {
    cachedCountry = null
    detectionPromise = null
}

export default useUserCountry`, replace: `import { useState } from 'react'

const TIMEZONE_COUNTRY = {
    'Europe/Lisbon': 'PT',
    'Atlantic/Madeira': 'PT',
    'Atlantic/Azores': 'PT',
    'Africa/Lagos': 'NG',
}

// Guessed from the browser, not the IP address, so nothing leaves the device before consent.
const guessCountry = () => {
    try {
        const zone = Intl.DateTimeFormat().resolvedOptions().timeZone
        if (TIMEZONE_COUNTRY[zone]) return TIMEZONE_COUNTRY[zone]
    } catch { /* noop */ }
    const region = navigator.language?.split('-')[1]
    return region && region.length === 2 ? region.toUpperCase() : null
}

export const useUserCountry = () => {
    const [countryCode] = useState(guessCountry)
    return { countryCode, isDetecting: false }
}
` },
        ],
    },
    {
        file: 'src/constants/legalEntity.js',
        edits: [
            { desc: "Supabase region", find: `        data: 'Account, business profile and booking data',
        location: null,`, replace: `        data: 'Account, business profile and booking data',
        location: 'European Union (Ireland)',` },
        ],
    },
    {
        file: 'src/pages/app/legal/Ranking.jsx',
        edits: [
            { desc: "Parameters match the Browse query", find: `                <ul className="legal__list">
                    <li><strong>City.</strong> Businesses are grouped by the city they operate in, starting with our launch city.</li>
                    <li><strong>Filters you choose.</strong> Category, city and search words narrow the list to businesses that match.</li>
                    <li><strong>Date the business went live.</strong> Within a city, businesses appear in the order they started taking bookings on Locappoint.</li>
                </ul>`, replace: `                <ul className="legal__list">
                    <li><strong>Active pages only.</strong> A business appears only while its page is active.</li>
                    <li><strong>Join date.</strong> Businesses appear in the order they joined Locappoint, earliest first.</li>
                    <li><strong>Launch cohort.</strong> Browse currently shows our first Lisbon cohort, up to ten businesses.</li>
                </ul>` },
            { desc: "Planned factors", find: `As Locappoint grows we expect to add factors such as availability and client reviews.`, replace: `As Locappoint grows we expect to add city and category filters, search, and factors such as availability and client reviews.` },
        ],
    },
    {
        file: 'src/pages/app/Businesses.jsx',
        edits: [
            { desc: "Strip header comment", find: `// src/pages/app/Businesses.jsx
// Browse - Cohort 1 marketplace.
// Cover = banner image OR StreetGridCover placeholder (per-business variation).
// Logo = avatar beside business name (image OR initials fallback).
// Open slots remain informational; SME recruitment lives in the closing CTA.

`, replace: `` },
            { desc: "Active businesses only", find: `                    .select('*')
                    .order('created_at', { ascending: true })`, replace: `                    .select('*')
                    .eq('is_active', true)
                    .order('created_at', { ascending: true })` },
        ],
    },
    {
        file: 'src/main.jsx',
        edits: [
            { desc: "Latin and Latin Extended subsets only", find: `import '@fontsource/inter/400.css'
import '@fontsource/inter/500.css'
import '@fontsource/inter/600.css'
import '@fontsource/jetbrains-mono/400.css'
import '@fontsource/jetbrains-mono/500.css'
`, replace: `import '@fontsource/inter/latin-400.css'
import '@fontsource/inter/latin-ext-400.css'
import '@fontsource/inter/latin-500.css'
import '@fontsource/inter/latin-ext-500.css'
import '@fontsource/inter/latin-600.css'
import '@fontsource/inter/latin-ext-600.css'
import '@fontsource/jetbrains-mono/latin-400.css'
import '@fontsource/jetbrains-mono/latin-ext-400.css'
import '@fontsource/jetbrains-mono/latin-500.css'
import '@fontsource/jetbrains-mono/latin-ext-500.css'
` },
        ],
    },
]

const RETIRES = []

let failed = false

for (const nf of NEW_FILES) {
    const full = path.join(REPO, nf.path)
    if (fs.existsSync(full)) { console.error(`[FAIL] Already exists: ${nf.path}`); failed = true }
    if (!fs.existsSync(path.dirname(full))) { console.error(`[FAIL] Parent dir missing: ${nf.path}`); failed = true }
}

const fileChanges = new Map()
for (const group of PATCHES) {
    const fullPath = path.join(REPO, group.file)
    if (!fs.existsSync(fullPath)) { console.error(`[FAIL] Missing: ${group.file}`); failed = true; continue }
    let content = fs.readFileSync(fullPath, 'utf8')
    const original = content
    const crlf = (content.match(/\r\n/g) || []).length
    const lf = (content.match(/\n/g) || []).length - crlf
    const eol = crlf > lf ? '\r\n' : '\n'
    let ok = true
    for (const edit of group.edits) {
        // Anchors accept CRLF or LF; replacements follow the file's dominant ending.
        const pattern = edit.find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\n/g, '\\r?\\n')
        const matches = (content.match(new RegExp(pattern, 'g')) || []).length
        if (matches !== 1) {
            console.error(`[FAIL] ${group.file}: ${matches} matches for "${edit.desc}" (expected 1)`)
            failed = true; ok = false; break
        }
        const replace = edit.replace.replace(/\n/g, eol)
        content = content.replace(new RegExp(pattern), () => replace)
    }
    if (ok) fileChanges.set(fullPath, { original, modified: content, edits: group.edits })
}

const retirePaths = []
for (const rel of RETIRES) {
    const full = path.join(REPO, rel)
    if (!fs.existsSync(full)) { console.error(`[FAIL] Retire target missing: ${rel}`); failed = true; continue }
    if (fs.existsSync(`${full}.mistake`)) { console.error(`[FAIL] Already retired: ${rel}.mistake`); failed = true; continue }
    retirePaths.push({ full, rel })
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const nf of NEW_FILES) {
    fs.writeFileSync(path.join(REPO, nf.path), nf.content)
    console.log(`[NEW] ${nf.path}`)
}
for (const [fullPath, change] of fileChanges) {
    fs.writeFileSync(`${fullPath}.backup`, change.original)
    fs.writeFileSync(fullPath, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, fullPath)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}
for (const { full, rel } of retirePaths) {
    fs.renameSync(full, `${full}.mistake`)
    console.log(`[RETIRE] ${rel} -> .mistake`)
}

console.log('\n[DONE]')
