import fs from 'fs'
import path from 'path'

const REPO = process.cwd()

const NEW_FILES = [
    { path: 'src/components/ui/Avatar.jsx', content: `export const initials = (name = '') =>
    name.split(/\\s+/).filter(Boolean).slice(0, 2).map((part) => part[0].toUpperCase()).join('') || 'L'

export const Avatar = ({ name, src, size = 'md', shape = 'round', tone = 'neutral' }) => (
    <span className={\`ui-avatar ui-avatar--\${size} ui-avatar--\${shape} ui-avatar--\${tone}\`} aria-hidden={!name}>
        {src ? <img src={src} alt="" /> : initials(name)}
    </span>
)
` },
    { path: 'src/components/ui/BarChart.jsx', content: `export const BarChart = ({ data, height = 140, highlight, format = (v) => v, label }) => {
    const max = Math.max(1, ...data.map((d) => d.value))
    return (
        <figure className="ui-bars" aria-label={label}>
            <div className="ui-bars__plot" style={{ height }}>
                {data.map((d, i) => (
                    <div key={d.label} className="ui-bars__col">
                        <span className="ui-bars__value">{d.value ? format(d.value) : ''}</span>
                        <span
                            className={\`ui-bars__bar\${i === highlight ? ' is-highlight' : ''}\`}
                            style={{ height: \`\${(d.value / max) * 100}%\`, animationDelay: \`\${i * 40}ms\` }}
                        />
                    </div>
                ))}
            </div>
            <div className="ui-bars__labels" aria-hidden="true">
                {data.map((d) => <span key={d.label}>{d.label}</span>)}
            </div>
            <table className="ui-visually-hidden">
                <tbody>
                    {data.map((d) => <tr key={d.label}><th>{d.label}</th><td>{format(d.value)}</td></tr>)}
                </tbody>
            </table>
        </figure>
    )
}
` },
    { path: 'src/components/ui/Button.jsx', content: `import { forwardRef } from 'react'
import { Link } from 'react-router-dom'

const Spinner = () => (
    <svg className="ui-btn__spinner" viewBox="0 0 20 20" aria-hidden="true">
        <circle cx="10" cy="10" r="8" />
    </svg>
)

export const Button = forwardRef(function Button(
    { variant = 'primary', size = 'md', icon: Icon, iconRight: IconRight, loading = false, full = false, to, href, className = '', children, disabled, type = 'button', ...rest },
    ref
) {
    const classes = [
        'ui-btn',
        \`ui-btn--\${variant}\`,
        \`ui-btn--\${size}\`,
        full && 'ui-btn--full',
        loading && 'is-loading',
        className,
    ].filter(Boolean).join(' ')

    const content = (
        <>
            {loading && <Spinner />}
            <span className="ui-btn__content">
                {Icon && <Icon size={size === 'sm' ? 16 : 18} aria-hidden="true" />}
                {children}
                {IconRight && <IconRight size={size === 'sm' ? 16 : 18} aria-hidden="true" />}
            </span>
        </>
    )

    if (to) return <Link ref={ref} to={to} className={classes} {...rest}>{content}</Link>
    if (href) return <a ref={ref} href={href} className={classes} {...rest}>{content}</a>

    return (
        <button ref={ref} type={type} className={classes} disabled={disabled || loading} aria-busy={loading || undefined} {...rest}>
            {content}
        </button>
    )
})

export const IconButton = forwardRef(function IconButton({ icon: Icon, label, variant = 'secondary', size = 'md', className = '', ...rest }, ref) {
    return (
        <button ref={ref} type="button" aria-label={label} title={label} className={\`ui-iconbtn ui-iconbtn--\${variant} ui-iconbtn--\${size} \${className}\`} {...rest}>
            <Icon size={size === 'sm' ? 16 : 18} aria-hidden="true" />
        </button>
    )
})
` },
    { path: 'src/components/ui/Card.jsx', content: `import { Link } from 'react-router-dom'

export const Card = ({ variant = 'flat', padding = 'md', as, to, onClick, title, action, footer, className = '', children, ...rest }) => {
    const interactive = Boolean(to || onClick)
    const classes = [
        'ui-card',
        \`ui-card--\${variant}\`,
        \`ui-card--pad-\${padding}\`,
        interactive && 'ui-card--interactive',
        className,
    ].filter(Boolean).join(' ')

    const body = (
        <>
            {(title || action) && (
                <header className="ui-card__head">
                    {title && <h3 className="ui-card__title">{title}</h3>}
                    {action && <div className="ui-card__action">{action}</div>}
                </header>
            )}
            {children}
            {footer && <footer className="ui-card__foot">{footer}</footer>}
        </>
    )

    if (to) return <Link to={to} className={classes} {...rest}>{body}</Link>
    if (onClick) return <button type="button" className={classes} onClick={onClick} {...rest}>{body}</button>
    const Tag = as || 'section'
    return <Tag className={classes} {...rest}>{body}</Tag>
}
` },
    { path: 'src/components/ui/Chip.jsx', content: `export const Chip = ({ selected = false, onClick, children, count }) => (
    <button type="button" className={\`ui-chip\${selected ? ' is-selected' : ''}\`} aria-pressed={selected} onClick={onClick}>
        {children}
        {count != null && <span className="ui-chip__count">{count}</span>}
    </button>
)

export const ChipGroup = ({ label, children }) => (
    <div className="ui-chips" role="group" aria-label={label}>{children}</div>
)
` },
    { path: 'src/components/ui/EmptyState.jsx', content: `export const EmptyState = ({ illustration, title, body, actions }) => (
    <div className="ui-empty">
        {illustration && <div className="ui-empty__art" aria-hidden="true">{illustration}</div>}
        <h3 className="ui-empty__title">{title}</h3>
        {body && <p className="ui-empty__body">{body}</p>}
        {actions && <div className="ui-empty__actions">{actions}</div>}
    </div>
)
` },
    { path: 'src/components/ui/Field.jsx', content: `import { cloneElement, isValidElement, useId } from 'react'

export const Field = ({ label, hint, error, optional = false, children }) => {
    const id = useId()
    const hintId = hint ? \`\${id}-hint\` : undefined
    const errorId = error ? \`\${id}-error\` : undefined
    const control = isValidElement(children)
        ? cloneElement(children, {
            id,
            'aria-invalid': error ? true : undefined,
            'aria-describedby': [hintId, errorId].filter(Boolean).join(' ') || undefined,
        })
        : children

    return (
        <div className={\`ui-field\${error ? ' has-error' : ''}\`}>
            <label className="ui-field__label" htmlFor={id}>
                {label}
                {optional && <span className="ui-field__optional">optional</span>}
            </label>
            {control}
            {hint && !error && <span id={hintId} className="ui-field__hint">{hint}</span>}
            {error && <span id={errorId} className="ui-field__error" role="alert">{error}</span>}
        </div>
    )
}

export const Input = (props) => <input className="ui-input" {...props} />

export const Textarea = (props) => <textarea className="ui-input ui-input--area" rows={3} {...props} />

export const Select = ({ children, ...props }) => (
    <span className="ui-select">
        <select className="ui-input" {...props}>{children}</select>
    </span>
)
` },
    { path: 'src/components/ui/ListRow.jsx', content: `import { Link } from 'react-router-dom'
import { ChevronRight } from 'lucide-react'

export const ListRow = ({ leading, title, subtitle, meta, trailing, to, onClick, selected = false, dense = false, chevron }) => {
    const interactive = Boolean(to || onClick)
    const classes = ['ui-row', dense && 'ui-row--dense', interactive && 'ui-row--interactive', selected && 'is-selected'].filter(Boolean).join(' ')
    const body = (
        <>
            {leading && <span className="ui-row__leading">{leading}</span>}
            <span className="ui-row__main">
                <span className="ui-row__title">{title}</span>
                {subtitle && <span className="ui-row__subtitle">{subtitle}</span>}
            </span>
            {meta && <span className="ui-row__meta">{meta}</span>}
            {trailing}
            {(chevron ?? interactive) && <ChevronRight size={16} className="ui-row__chevron" aria-hidden="true" />}
        </>
    )
    if (to) return <Link to={to} className={classes} aria-current={selected || undefined}>{body}</Link>
    if (onClick) return <button type="button" className={classes} onClick={onClick} aria-pressed={selected || undefined}>{body}</button>
    return <div className={classes}>{body}</div>
}
` },
    { path: 'src/components/ui/Progress.jsx', content: `export const Progress = ({ value, label, tone = 'brand', showValue = true }) => {
    const percent = Math.round(Math.max(0, Math.min(1, value || 0)) * 100)
    return (
        <div className="ui-progress">
            {(label || showValue) && (
                <div className="ui-progress__head">
                    {label && <span className="ui-progress__label">{label}</span>}
                    {showValue && <span className="ui-progress__value">{percent}%</span>}
                </div>
            )}
            <div className="ui-progress__track" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={percent} aria-label={label}>
                <span className={\`ui-progress__fill ui-progress__fill--\${tone}\`} style={{ width: \`\${percent}%\` }} />
            </div>
        </div>
    )
}
` },
    { path: 'src/components/ui/Ring.jsx', content: `import { useEffect, useId, useState } from 'react'

export const Ring = ({ value, size = 40, stroke = 4, label, tone = 'brand', children }) => {
    const gradientId = useId()
    const [drawn, setDrawn] = useState(0)
    const radius = (size - stroke) / 2
    const circumference = 2 * Math.PI * radius
    const clamped = Math.max(0, Math.min(1, value || 0))

    useEffect(() => {
        const frame = requestAnimationFrame(() => setDrawn(clamped))
        return () => cancelAnimationFrame(frame)
    }, [clamped])

    const stroked = tone === 'brand' ? \`url(#\${gradientId})\` : \`var(--lc-\${tone})\`

    return (
        <span className="ui-ring" style={{ width: size, height: size }}>
            <svg width={size} height={size} viewBox={\`0 0 \${size} \${size}\`} role="img" aria-label={label}>
                <defs>
                    <linearGradient id={gradientId} x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0%" stopColor="var(--azure)" />
                        <stop offset="100%" stopColor="var(--signal)" />
                    </linearGradient>
                </defs>
                <circle className="lc-ring__track" cx={size / 2} cy={size / 2} r={radius} strokeWidth={stroke} />
                <circle
                    className="lc-ring__value"
                    cx={size / 2}
                    cy={size / 2}
                    r={radius}
                    strokeWidth={stroke}
                    stroke={stroked}
                    strokeDasharray={circumference}
                    strokeDashoffset={circumference * (1 - drawn)}
                    transform={\`rotate(-90 \${size / 2} \${size / 2})\`}
                />
            </svg>
            {children && <span className="ui-ring__center">{children}</span>}
        </span>
    )
}
` },
    { path: 'src/components/ui/Segmented.jsx', content: `import { useRef } from 'react'

export const Segmented = ({ options, value, onChange, label }) => {
    const refs = useRef([])
    const index = options.findIndex((o) => o.value === value)

    const onKeyDown = (event) => {
        if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return
        event.preventDefault()
        const next = (index + (event.key === 'ArrowRight' ? 1 : -1) + options.length) % options.length
        onChange(options[next].value)
        refs.current[next]?.focus()
    }

    return (
        <div className="ui-seg" role="radiogroup" aria-label={label} onKeyDown={onKeyDown}>
            {options.map((option, i) => (
                <button
                    key={option.value}
                    ref={(el) => { refs.current[i] = el }}
                    type="button"
                    role="radio"
                    aria-checked={option.value === value}
                    tabIndex={option.value === value ? 0 : -1}
                    className={\`ui-seg__btn\${option.value === value ? ' is-selected' : ''}\`}
                    onClick={() => onChange(option.value)}
                >
                    {option.label}
                </button>
            ))}
        </div>
    )
}
` },
    { path: 'src/components/ui/Skeleton.jsx', content: `export const Skeleton = ({ width = '100%', height = 16, radius, circle = false, lines }) => {
    if (lines) {
        return (
            <span className="ui-skel-lines" aria-hidden="true">
                {Array.from({ length: lines }, (_, i) => (
                    <span key={i} className="ui-skel" style={{ width: i === lines - 1 ? '60%' : '100%', height }} />
                ))}
            </span>
        )
    }
    return (
        <span
            className="ui-skel"
            aria-hidden="true"
            style={{ width: circle ? height : width, height, borderRadius: circle ? '50%' : radius }}
        />
    )
}
` },
    { path: 'src/components/ui/Sparkline.jsx', content: `export const Sparkline = ({ values, width = 120, height = 36, tone = 'data-1', label }) => {
    if (!values?.length) return null
    const max = Math.max(...values)
    const min = Math.min(...values)
    const span = max - min || 1
    const step = values.length > 1 ? width / (values.length - 1) : width
    const points = values.map((v, i) => [i * step, height - 3 - ((v - min) / span) * (height - 6)])
    const line = points.map(([x, y], i) => \`\${i ? 'L' : 'M'}\${x.toFixed(1)} \${y.toFixed(1)}\`).join(' ')
    const area = \`\${line} L\${width} \${height} L0 \${height} Z\`
    const [lx, ly] = points[points.length - 1]
    return (
        <svg className="ui-spark" width={width} height={height} viewBox={\`0 0 \${width} \${height}\`} role="img" aria-label={label} style={{ color: \`var(--lc-\${tone})\` }}>
            <path d={area} className="ui-spark__area" />
            <path d={line} className="ui-spark__line" />
            <circle cx={lx} cy={ly} r="3" className="ui-spark__dot" />
        </svg>
    )
}
` },
    { path: 'src/components/ui/Stat.jsx', content: `import { ArrowDownRight, ArrowUpRight } from 'lucide-react'
import { useCountUp } from './useCountUp'
import { formatters } from './format'

export const Stat = ({ label, value, format = 'number', size = 'md', tone, delta, note, animate = true }) => {
    const numeric = typeof value === 'number'
    const shown = useCountUp(numeric && animate ? value : 0)
    const formatter = typeof format === 'function' ? format : formatters[format] || formatters.number
    const display = numeric ? formatter(animate ? shown : value) : value

    return (
        <div className={\`ui-stat ui-stat--\${size}\${tone ? \` ui-stat--\${tone}\` : ''}\`}>
            <span className="ui-stat__label">{label}</span>
            <span className="ui-stat__value">
                {display}
                {numeric && animate && <span className="ui-visually-hidden">{formatter(value)}</span>}
            </span>
            {(delta || note) && (
                <span className="ui-stat__meta">
                    {delta && (
                        <span className={\`ui-delta ui-delta--\${delta.good ? 'good' : 'bad'}\`}>
                            {delta.up ? <ArrowUpRight size={14} aria-hidden="true" /> : <ArrowDownRight size={14} aria-hidden="true" />}
                            {delta.label}
                        </span>
                    )}
                    {note && <span className="ui-stat__note">{note}</span>}
                </span>
            )}
        </div>
    )
}
` },
    { path: 'src/components/ui/Status.jsx', content: `const TONE_BY_STATUS = {
    pending: 'warning',
    confirmed: 'info',
    completed: 'success',
    no_show: 'danger',
    cancelled: 'neutral',
}

export const Status = ({ tone, status, children, size = 'md' }) => {
    const resolved = tone || TONE_BY_STATUS[status] || 'neutral'
    return <span className={\`ui-status ui-status--\${resolved} ui-status--\${size}\`}>{children}</span>
}
` },
    { path: 'src/components/ui/Streak.jsx', content: `import { Flame } from 'lucide-react'

export const Streak = ({ count, label, days = [] }) => (
    <div className={\`ui-streak\${count > 0 ? ' is-live' : ''}\`}>
        <span className="ui-streak__icon"><Flame size={18} aria-hidden="true" /></span>
        <span className="ui-streak__text">
            <strong>{count} {count === 1 ? 'day' : 'days'}</strong>
            <small>{label}</small>
        </span>
        {days.length > 0 && (
            <span className="ui-streak__days" aria-hidden="true">
                {days.map((kept, i) => <span key={i} className={kept ? 'is-kept' : ''} />)}
            </span>
        )}
    </div>
)
` },
    { path: 'src/components/ui/Switch.jsx', content: `import { useId } from 'react'

export const Switch = ({ checked, onChange, label, description, disabled = false }) => {
    const id = useId()
    return (
        <div className={\`ui-switchrow\${disabled ? ' is-disabled' : ''}\`}>
            <span className="ui-switchrow__text">
                <label htmlFor={id} className="ui-switchrow__label">{label}</label>
                {description && <span className="ui-switchrow__desc">{description}</span>}
            </span>
            <button
                id={id}
                type="button"
                role="switch"
                aria-checked={checked}
                disabled={disabled}
                className={\`ui-switch\${checked ? ' is-on' : ''}\`}
                onClick={() => onChange(!checked)}
            >
                <span className="ui-switch__thumb" />
            </button>
        </div>
    )
}
` },
    { path: 'src/components/ui/Toast.jsx', content: `import { Check, TriangleAlert } from 'lucide-react'

export const Toast = ({ message, tone = 'neutral' }) => (
    <span className={\`ui-toast ui-toast--\${tone}\`} role="status">
        {tone === 'success' && <Check size={16} aria-hidden="true" />}
        {tone === 'danger' && <TriangleAlert size={16} aria-hidden="true" />}
        {message}
    </span>
)
` },
    { path: 'src/components/ui/format.js', content: `const money = new Intl.NumberFormat('en-IE', { style: 'currency', currency: 'EUR' })
const moneyRound = new Intl.NumberFormat('en-IE', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 })
const number = new Intl.NumberFormat('en-IE')

export const formatters = {
    money: (v) => money.format(v),
    moneyRound: (v) => moneyRound.format(Math.round(v)),
    number: (v) => number.format(Math.round(v)),
    percent: (v) => \`\${Math.round(v)}%\`,
}
` },
    { path: 'src/components/ui/index.js', content: `export { Button, IconButton } from './Button'
export { Card } from './Card'
export { Avatar, initials } from './Avatar'
export { Status } from './Status'
export { Skeleton } from './Skeleton'
export { Stat } from './Stat'
export { Ring } from './Ring'
export { Sparkline } from './Sparkline'
export { BarChart } from './BarChart'
export { Progress } from './Progress'
export { Streak } from './Streak'
export { ListRow } from './ListRow'
export { EmptyState } from './EmptyState'
export { Segmented } from './Segmented'
export { Chip, ChipGroup } from './Chip'
export { Field, Input, Textarea, Select } from './Field'
export { Switch } from './Switch'
export { Toast } from './Toast'
export { useCountUp } from './useCountUp'
export { formatters } from './format'
` },
    { path: 'src/components/ui/useCountUp.js', content: `import { useEffect, useRef, useState } from 'react'

const prefersReducedMotion = () =>
    typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches

export const useCountUp = (target, duration = 700) => {
    const [value, setValue] = useState(() => (prefersReducedMotion() ? target : 0))
    const from = useRef(value)

    useEffect(() => {
        if (prefersReducedMotion() || typeof target !== 'number') {
            setValue(target)
            return undefined
        }
        const initial = from.current
        let start = null
        let frame
        const tick = (now) => {
            if (start === null) start = now
            const t = Math.min(1, (now - start) / duration)
            const eased = 1 - Math.pow(1 - t, 3)
            const next = initial + (target - initial) * eased
            setValue(next)
            if (t < 1) frame = requestAnimationFrame(tick)
            else from.current = target
        }
        frame = requestAnimationFrame(tick)
        return () => cancelAnimationFrame(frame)
    }, [target, duration])

    return value
}
` },
    { path: 'src/pages/business/UiGallery.jsx', content: `import { useState } from 'react'
import { CalendarPlus, Copy, MessageCircle, Plus, Scissors, Trash2 } from 'lucide-react'
import {
    Avatar,
    BarChart,
    Button,
    Card,
    Chip,
    ChipGroup,
    EmptyState,
    Field,
    IconButton,
    Input,
    ListRow,
    Progress,
    Ring,
    Segmented,
    Select,
    Skeleton,
    Sparkline,
    Stat,
    Status,
    Streak,
    Switch,
    Textarea,
    Toast,
    formatters,
} from '../../components/ui'
import '../../styles/business/gallery.css'

const Section = ({ title, note, children }) => (
    <section className="ui-gallery__section">
        <header>
            <h2 className="ui-heading">{title}</h2>
            {note && <p className="ui-gallery__note">{note}</p>}
        </header>
        {children}
    </section>
)

const UiGallery = () => {
    const [view, setView] = useState('day')
    const [chip, setChip] = useState('everyone')
    const [on, setOn] = useState(true)
    const [loading, setLoading] = useState(false)

    const pretendSave = () => {
        setLoading(true)
        setTimeout(() => setLoading(false), 1400)
    }

    return (
        <div className="biz-page ui-gallery">
            <header>
                <p className="ui-label">Internal</p>
                <h1 className="ui-title">Locappoint primitives</h1>
                <p className="ui-gallery__note">Every screen is built from these. Change a primitive here and every screen changes with it.</p>
            </header>

            <Section title="Type" note="One scale, used unevenly. Display for the figure that matters, then clear steps down.">
                <div className="ui-gallery__stack">
                    <span className="ui-display">82%</span>
                    <span className="ui-title">Friday 25 September</span>
                    <span className="ui-heading">Waiting for you</span>
                    <p className="ui-gallery__body">Body text reads at fifteen pixels with generous line height, so a paragraph on a phone never feels cramped.</p>
                    <span className="ui-label">Label</span>
                </div>
            </Section>

            <Section title="Day Ring" note="Signature one. The only gradient in the product, running in the direction of time.">
                <div className="ui-gallery__row">
                    <Ring value={0.82} size={200} stroke={14} label="Day 82% booked">
                        <span className="ui-display ui-gallery__ringfig">82%</span>
                        <span className="ui-label">booked</span>
                    </Ring>
                    <div className="ui-gallery__stack">
                        <Stat label="Earned today" value={184.5} format="money" size="md" tone="brand" />
                        <Stat label="Still to come" value={96} format="money" size="sm" />
                        <Stat label="Lost to no-shows" value={20} format="money" size="sm" tone="danger" />
                    </div>
                </div>
            </Section>

            <Section title="Stats" note="Figures count up when they arrive. Deltas pair colour with an arrow, never colour alone.">
                <div className="ui-gallery__grid">
                    <Card><Stat label="Bookings this week" value={42} size="md" delta={{ up: true, good: true, label: '+18%' }} note="vs last week" /></Card>
                    <Card><Stat label="Fill rate" value={76} format="percent" size="md" delta={{ up: false, good: false, label: '-4%' }} note="vs last week" /></Card>
                    <Card><Stat label="No-shows" value={1} size="md" tone="success" note="Lowest in a month" /></Card>
                </div>
            </Section>

            <Section title="Charts">
                <div className="ui-gallery__grid">
                    <Card title="Revenue, last 8 weeks" action={<Sparkline values={[420, 380, 510, 460, 590, 620, 580, 710]} label="Revenue trend" />}>
                        <Stat label="This week" value={710} format="moneyRound" size="md" delta={{ up: true, good: true, label: '+22%' }} />
                    </Card>
                    <Card title="Bookings by day">
                        <BarChart
                            label="Bookings by day"
                            highlight={5}
                            data={[
                                { label: 'Mon', value: 4 }, { label: 'Tue', value: 6 }, { label: 'Wed', value: 3 },
                                { label: 'Thu', value: 8 }, { label: 'Fri', value: 9 }, { label: 'Sat', value: 12 }, { label: 'Sun', value: 0 },
                            ]}
                        />
                    </Card>
                </div>
            </Section>

            <Section title="Momentum" note="Progress towards things owners already want.">
                <div className="ui-gallery__grid">
                    <Streak count={12} label="Every booking confirmed" days={[true, true, true, true, true, true, true]} />
                    <Streak count={0} label="Start a no-show-free week" days={[true, false, false, false, false, false, false]} />
                    <Card>
                        <Progress label="Page strength" value={0.63} />
                        <Progress label="Weekly fill goal" value={0.76} tone="success" />
                    </Card>
                </div>
            </Section>

            <Section title="Buttons" note="Primary, secondary, quiet, destructive. Loading keeps the width so nothing jumps.">
                <div className="ui-gallery__wrap">
                    <Button icon={Plus}>New booking</Button>
                    <Button variant="secondary" icon={Copy}>Copy link</Button>
                    <Button variant="quiet">Keep as is</Button>
                    <Button variant="destructive" icon={Trash2}>Cancel booking</Button>
                    <Button loading={loading} onClick={pretendSave}>Save changes</Button>
                    <Button disabled>Disabled</Button>
                </div>
                <div className="ui-gallery__wrap">
                    <Button size="sm" variant="secondary">Small</Button>
                    <Button size="lg" icon={CalendarPlus}>Large</Button>
                    <IconButton icon={MessageCircle} label="WhatsApp" />
                    <IconButton icon={Copy} label="Copy" variant="quiet" />
                </div>
            </Section>

            <Section title="Status" note="A dot and a word. Colour never carries meaning alone.">
                <div className="ui-gallery__wrap">
                    <Status status="pending">Needs confirming</Status>
                    <Status status="confirmed">Confirmed</Status>
                    <Status status="completed">Completed</Status>
                    <Status status="no_show">No-show</Status>
                    <Status status="cancelled">Cancelled</Status>
                </div>
            </Section>

            <Section title="Cards and rows" note="Raised means you can act on it. Flat means it is information.">
                <div className="ui-gallery__grid">
                    <Card variant="raised" onClick={() => {}} title="Raised, interactive">
                        <p className="ui-gallery__body">Presses under the finger.</p>
                    </Card>
                    <Card title="Flat">
                        <p className="ui-gallery__body">Sits on the canvas. Not clickable.</p>
                    </Card>
                    <Card variant="accent" title="Accent">
                        <p className="ui-gallery__body">The one card on a screen that matters most.</p>
                    </Card>
                </div>
                <Card padding="sm">
                    <ListRow leading={<Avatar name="Sofia Mendes" />} title="Sofia Mendes" subtitle="Trim, last visit 12 September" meta="€12.50" onClick={() => {}} />
                    <ListRow leading={<Avatar name="Tiago Alves" />} title="Tiago Alves" subtitle="Cut, 9 visits" meta="€180.00" trailing={<Status status="confirmed" size="sm">Regular</Status>} onClick={() => {}} selected />
                    <ListRow leading={<Avatar name="Jameson Wellington" />} title="Jameson Wellington" subtitle="2 no-shows" trailing={<Status tone="danger" size="sm">Unreliable</Status>} onClick={() => {}} />
                    <ListRow dense leading={<Scissors size={18} aria-hidden="true" />} title="Dense row" meta="30 min" />
                </Card>
            </Section>

            <Section title="Controls">
                <div className="ui-gallery__wrap">
                    <Segmented label="View" value={view} onChange={setView} options={[{ value: 'day', label: 'Day' }, { value: 'week', label: 'Week' }, { value: 'month', label: 'Month' }]} />
                </div>
                <ChipGroup label="Show calendar for">
                    {['everyone', 'miles', 'ana'].map((key) => (
                        <Chip key={key} selected={chip === key} onClick={() => setChip(key)} count={key === 'everyone' ? 6 : undefined}>
                            {key === 'everyone' ? 'Everyone' : key === 'miles' ? 'Miles' : 'Ana'}
                        </Chip>
                    ))}
                </ChipGroup>
                <Card>
                    <Switch checked={on} onChange={setOn} label="Take bookings" description="Clients can book you online" />
                    <Switch checked={false} onChange={() => {}} label="WhatsApp reminders" description="Arrives with notifications" disabled />
                </Card>
            </Section>

            <Section title="Fields">
                <div className="ui-gallery__form">
                    <Field label="Business name" hint="Shown at the top of your page">
                        <Input defaultValue="Femtos Hair Salon" />
                    </Field>
                    <Field label="Web address" error="That address is taken. Try femtos-baixa.">
                        <Input defaultValue="femtos" />
                    </Field>
                    <Field label="Category">
                        <Select defaultValue="salon">
                            <option value="salon">Salon</option>
                            <option value="barber">Barbershop</option>
                        </Select>
                    </Field>
                    <Field label="Description" optional>
                        <Textarea placeholder="What makes your place worth the visit" />
                    </Field>
                </div>
            </Section>

            <Section title="Empty state" note="A picture of what will be there, a sentence, and the action that fills it.">
                <EmptyState
                    illustration={<Ring value={0} size={88} stroke={8} label="Empty day" />}
                    title="Your day is wide open"
                    body="No bookings yet. Share your link and the ring starts filling."
                    actions={<><Button icon={Copy} variant="secondary">Copy link</Button><Button icon={Plus}>Add a booking</Button></>}
                />
            </Section>

            <Section title="Loading and feedback">
                <Card>
                    <div className="ui-gallery__row">
                        <Skeleton circle height={40} />
                        <div className="ui-gallery__stack" style={{ flex: 1 }}>
                            <Skeleton height={14} width="40%" />
                            <Skeleton height={12} width="70%" />
                        </div>
                    </div>
                    <Skeleton lines={3} height={12} />
                </Card>
                <div className="ui-gallery__wrap">
                    <Toast message="Booking added" tone="success" />
                    <Toast message="That time was just taken" tone="danger" />
                </div>
            </Section>

            <p className="ui-gallery__note">Money formats: {formatters.money(1234.5)}, {formatters.moneyRound(1234.5)}, {formatters.number(12500)}, {formatters.percent(82.4)}</p>
        </div>
    )
}

export default UiGallery
` },
    { path: 'src/styles/business/gallery.css', content: `.ui-gallery {
    gap: var(--space-10);
}

.ui-gallery__section {
    display: flex;
    flex-direction: column;
    gap: var(--space-4);
}

.ui-gallery__section header h2 {
    margin: 0;
}

.ui-gallery__note {
    max-width: 60ch;
    margin: var(--space-1) 0 0;
    color: var(--lc-ink-3);
    font-size: var(--lc-t-label);
}

.ui-gallery__body {
    margin: 0;
    color: var(--lc-ink-2);
    font-size: var(--lc-t-body);
    line-height: var(--lc-lh-body);
}

.ui-gallery__stack {
    display: flex;
    flex-direction: column;
    gap: var(--space-3);
}

.ui-gallery__row {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: var(--space-6);
}

.ui-gallery__wrap {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: var(--space-3);
}

.ui-gallery__grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: var(--space-4);
}

.ui-gallery__form {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: var(--space-5);
}

.ui-gallery__ringfig {
    font-size: 3rem;
}
` },
    { path: 'src/styles/foundation.css', content: `:root {
    --lc-canvas: #08090C;
    --lc-well: #050608;
    --lc-card: #10131A;
    --lc-raised: #171B25;
    --lc-raised-hover: #1D2230;
    --lc-overlay: #1B202B;
    --lc-line: rgba(244, 246, 251, 0.07);
    --lc-line-strong: rgba(244, 246, 251, 0.12);
    --lc-highlight: rgba(255, 255, 255, 0.05);

    --lc-shadow-raised: inset 0 1px 0 var(--lc-highlight), 0 1px 2px rgba(3, 8, 24, 0.5), 0 8px 24px -12px rgba(3, 8, 24, 0.8);
    --lc-shadow-overlay: inset 0 1px 0 var(--lc-highlight), 0 24px 64px -16px rgba(3, 8, 24, 0.9);
    --lc-shadow-accent: 0 8px 24px -8px rgba(45, 127, 240, 0.55);

    --lc-glass: rgba(8, 9, 12, 0.72);
    --lc-glass-blur: saturate(160%) blur(18px);

    --lc-ink-1: #F4F6FB;
    --lc-ink-2: #B8C0D0;
    --lc-ink-3: #8892A4;
    --lc-ink-4: #5A6272;

    --lc-success: #4CC38A;
    --lc-success-tint: rgba(43, 140, 90, 0.16);
    --lc-warning: #F0B254;
    --lc-warning-tint: rgba(232, 154, 62, 0.16);
    --lc-danger: #F07A6E;
    --lc-danger-tint: rgba(180, 62, 51, 0.2);
    --lc-info: #5BA0FF;
    --lc-info-tint: rgba(45, 127, 240, 0.16);

    --lc-data-1: #2D7FF0;
    --lc-data-2: #E89A3E;
    --lc-data-3: #3FB68B;
    --lc-data-4: #E0607E;
    --lc-data-5: #6BA5F5;
    --lc-data-6: #C9A66B;

    --lc-ease: cubic-bezier(0.22, 1, 0.36, 1);
    --lc-fast: 120ms;
    --lc-base: 280ms;
    --lc-slow: 900ms;

    --lc-r-sm: 8px;
    --lc-r-md: 12px;
    --lc-r-lg: 16px;
    --lc-r-xl: 24px;

    --lc-on-accent: #FFFFFF;
    --lc-azure-hover: #3B8BFF;

    --lc-t-display: clamp(2.75rem, 2.2rem + 2.5vw, 4rem);
    --lc-t-figure: clamp(1.75rem, 1.5rem + 1vw, 2.25rem);
    --lc-t-title: clamp(1.625rem, 1.4rem + 1vw, 2rem);
    --lc-t-heading: 1.125rem;
    --lc-t-body: 0.9375rem;
    --lc-t-label: 0.8125rem;
    --lc-t-micro: 0.6875rem;
    --lc-lh-tight: 1.1;
    --lc-lh-snug: 1.3;
    --lc-lh-body: 1.55;
    --lc-track-display: -0.035em;
    --lc-track-title: -0.02em;
    --lc-font-display: var(--font-display);
    --lc-font-body: var(--font-body);
    --lc-font-mono: var(--font-mono);
}

.lc-skel {
    display: block;
    border-radius: var(--lc-r-sm);
    background: var(--lc-raised);
    animation: lc-pulse 1.4s var(--lc-ease) infinite;
}

@keyframes lc-pulse {
    0%, 100% { opacity: 0.55; }
    50% { opacity: 1; }
}

.lc-loader {
    position: relative;
    display: grid;
    place-items: center;
    width: 72px;
    height: 72px;
}

.lc-loader__ring {
    position: absolute;
    inset: 0;
    animation: lc-spin 1.6s linear infinite;
}

.lc-loader__track {
    fill: none;
    stroke: var(--lc-line-strong);
    stroke-width: 2.5;
}

.lc-loader__arc {
    fill: none;
    stroke: url(#lc-ring-gradient);
    stroke-width: 2.5;
    stroke-linecap: round;
    stroke-dasharray: 60 176;
}

.lc-loader img {
    width: 32px;
    height: 32px;
}

@keyframes lc-spin {
    to { transform: rotate(360deg); }
}

.lc-ring__track {
    fill: none;
    stroke: var(--lc-line-strong);
}

.lc-ring__value {
    fill: none;
    stroke-linecap: round;
    transition: stroke-dashoffset var(--lc-slow) var(--lc-ease);
}

@media (prefers-reduced-motion: reduce) {
    .lc-skel,
    .lc-loader__ring {
        animation: none;
    }

    .lc-ring__value {
        transition: none;
    }
}
` },
    { path: 'src/styles/ui.css', content: `.ui-visually-hidden {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip: rect(0 0 0 0);
    white-space: nowrap;
}

.ui-display {
    font-family: var(--lc-font-display);
    font-size: var(--lc-t-display);
    font-weight: var(--font-weight-semibold);
    letter-spacing: var(--lc-track-display);
    line-height: var(--lc-lh-tight);
}

.ui-title {
    font-family: var(--lc-font-display);
    font-size: var(--lc-t-title);
    font-weight: var(--font-weight-semibold);
    letter-spacing: var(--lc-track-title);
    line-height: var(--lc-lh-tight);
}

.ui-heading {
    font-family: var(--lc-font-display);
    font-size: var(--lc-t-heading);
    font-weight: var(--font-weight-semibold);
    line-height: var(--lc-lh-snug);
}

.ui-label {
    color: var(--lc-ink-3);
    font-size: var(--lc-t-label);
    font-weight: var(--font-weight-medium);
}


.ui-btn {
    position: relative;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: 0;
    border-radius: var(--radius-full);
    font-family: var(--lc-font-body);
    font-weight: var(--font-weight-semibold);
    text-decoration: none;
    white-space: nowrap;
    cursor: pointer;
    user-select: none;
    transition: background var(--lc-fast) var(--lc-ease), box-shadow var(--lc-fast) var(--lc-ease), transform var(--lc-fast) var(--lc-ease), color var(--lc-fast) var(--lc-ease);
}

.ui-btn__content {
    display: inline-flex;
    align-items: center;
    gap: var(--space-2);
}

.ui-btn--sm { min-height: 36px; padding: 0 var(--space-4); font-size: var(--lc-t-label); }
.ui-btn--md { min-height: 44px; padding: 0 var(--space-5); font-size: var(--lc-t-body); }
.ui-btn--lg { min-height: 52px; padding: 0 var(--space-6); font-size: 1rem; }
.ui-btn--full { width: 100%; }

.ui-btn--primary {
    background: var(--azure);
    box-shadow: var(--lc-shadow-accent), inset 0 1px 0 rgba(255, 255, 255, 0.18);
    color: var(--lc-on-accent);
}

.ui-btn--primary:hover { background: var(--lc-azure-hover); }

.ui-btn--secondary {
    background: var(--lc-raised);
    box-shadow: var(--lc-shadow-raised);
    color: var(--lc-ink-1);
}

.ui-btn--secondary:hover { background: var(--lc-raised-hover); }

.ui-btn--quiet {
    background: none;
    color: var(--lc-ink-2);
}

.ui-btn--quiet:hover {
    background: var(--lc-card);
    color: var(--lc-ink-1);
}

.ui-btn--destructive {
    background: var(--lc-danger-tint);
    box-shadow: inset 0 0 0 1px rgba(240, 122, 110, 0.35);
    color: var(--lc-danger);
}

.ui-btn--destructive:hover {
    background: var(--danger);
    color: var(--lc-on-accent);
}

.ui-btn:active:not(:disabled) { transform: scale(0.97); }

.ui-btn:disabled {
    cursor: not-allowed;
    opacity: 0.45;
    box-shadow: none;
}

.ui-btn.is-loading {
    cursor: progress;
    opacity: 1;
}

.ui-btn.is-loading .ui-btn__content { visibility: hidden; }

.ui-btn__spinner {
    position: absolute;
    width: 20px;
    height: 20px;
    fill: none;
    stroke: currentColor;
    stroke-width: 2.5;
    stroke-linecap: round;
    stroke-dasharray: 34 60;
    animation: lc-spin 0.8s linear infinite;
}

.ui-iconbtn {
    display: inline-grid;
    place-items: center;
    flex: none;
    border: 0;
    border-radius: var(--radius-full);
    cursor: pointer;
    transition: background var(--lc-fast) var(--lc-ease), color var(--lc-fast) var(--lc-ease), transform var(--lc-fast) var(--lc-ease);
}

.ui-iconbtn--sm { width: 32px; height: 32px; }
.ui-iconbtn--md { width: 40px; height: 40px; }
.ui-iconbtn--lg { width: 48px; height: 48px; }

.ui-iconbtn--secondary {
    background: var(--lc-card);
    box-shadow: inset 0 0 0 1px var(--lc-line);
    color: var(--lc-ink-2);
}

.ui-iconbtn--secondary:hover { background: var(--lc-raised); color: var(--lc-ink-1); }

.ui-iconbtn--quiet {
    background: none;
    color: var(--lc-ink-3);
}

.ui-iconbtn--quiet:hover { background: var(--lc-card); color: var(--lc-ink-1); }

.ui-iconbtn:active { transform: scale(0.92); }


.ui-card {
    display: flex;
    flex-direction: column;
    gap: var(--space-4);
    min-width: 0;
    border: 0;
    border-radius: var(--lc-r-lg);
    color: var(--lc-ink-1);
    font-family: var(--lc-font-body);
    text-align: left;
    text-decoration: none;
}

.ui-card--pad-sm { padding: var(--space-3); }
.ui-card--pad-md { padding: var(--space-5); }
.ui-card--pad-lg { padding: var(--space-6); }

.ui-card--flat {
    background: var(--lc-card);
    box-shadow: inset 0 0 0 1px var(--lc-line);
}

.ui-card--raised {
    background: var(--lc-raised);
    box-shadow: var(--lc-shadow-raised);
}

.ui-card--outline {
    background: none;
    box-shadow: inset 0 0 0 1px var(--lc-line-strong);
}

.ui-card--accent {
    background: var(--lc-raised);
    box-shadow: inset 0 0 0 1px rgba(45, 127, 240, 0.4), var(--lc-shadow-raised);
}

.ui-card--interactive {
    cursor: pointer;
    transition: background var(--lc-fast) var(--lc-ease), transform var(--lc-fast) var(--lc-ease), box-shadow var(--lc-fast) var(--lc-ease);
}

.ui-card--interactive:hover { background: var(--lc-raised-hover); }
.ui-card--interactive:active { transform: scale(0.99); }

.ui-card__head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--space-3);
}

.ui-card__title {
    margin: 0;
    font-family: var(--lc-font-display);
    font-size: var(--lc-t-heading);
    font-weight: var(--font-weight-semibold);
}

.ui-card__foot {
    margin-top: auto;
    padding-top: var(--space-4);
    border-top: 1px solid var(--lc-line);
}


.ui-avatar {
    display: inline-grid;
    place-items: center;
    flex: none;
    overflow: hidden;
    background: var(--lc-raised);
    box-shadow: inset 0 0 0 1px var(--lc-line-strong);
    color: var(--lc-ink-1);
    font-family: var(--lc-font-display);
    font-weight: var(--font-weight-semibold);
    letter-spacing: 0.02em;
}

.ui-avatar img { width: 100%; height: 100%; object-fit: cover; }
.ui-avatar--round { border-radius: var(--radius-full); }
.ui-avatar--square { border-radius: var(--lc-r-md); }
.ui-avatar--sm { width: 28px; height: 28px; font-size: 11px; }
.ui-avatar--md { width: 36px; height: 36px; font-size: 13px; }
.ui-avatar--lg { width: 48px; height: 48px; font-size: 16px; }
.ui-avatar--xl { width: 72px; height: 72px; font-size: 24px; }

.ui-avatar--brand {
    background: var(--azure);
    box-shadow: var(--lc-shadow-accent);
}


.ui-status {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    border-radius: var(--radius-full);
    font-weight: var(--font-weight-medium);
    white-space: nowrap;
}

.ui-status::before {
    content: '';
    width: 6px;
    height: 6px;
    border-radius: var(--radius-full);
    background: currentColor;
}

.ui-status--sm { padding: 1px 8px 1px 6px; font-size: var(--lc-t-micro); }
.ui-status--md { padding: 3px 10px 3px 8px; font-size: 12px; }

.ui-status--success { background: var(--lc-success-tint); color: var(--lc-success); }
.ui-status--warning { background: var(--lc-warning-tint); color: var(--lc-warning); }
.ui-status--danger { background: var(--lc-danger-tint); color: var(--lc-danger); }
.ui-status--info { background: var(--lc-info-tint); color: var(--lc-info); }
.ui-status--neutral { background: var(--lc-card); color: var(--lc-ink-3); }


.ui-skel {
    display: block;
    border-radius: var(--lc-r-sm);
    background: var(--lc-raised);
    animation: lc-pulse 1.4s var(--lc-ease) infinite;
}

.ui-skel-lines {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
}


.ui-stat {
    display: flex;
    flex-direction: column;
    gap: var(--space-1);
    min-width: 0;
}

.ui-stat__label {
    color: var(--lc-ink-3);
    font-size: var(--lc-t-label);
    font-weight: var(--font-weight-medium);
}

.ui-stat__value {
    color: var(--lc-ink-1);
    font-family: var(--lc-font-mono);
    font-variant-numeric: tabular-nums;
    font-weight: var(--font-weight-medium);
    letter-spacing: -0.02em;
    line-height: var(--lc-lh-tight);
}

.ui-stat--sm .ui-stat__value { font-size: var(--lc-t-heading); }
.ui-stat--md .ui-stat__value { font-size: var(--lc-t-figure); }
.ui-stat--display .ui-stat__value { font-size: var(--lc-t-display); }

.ui-stat--brand .ui-stat__value { color: var(--azure-link); }
.ui-stat--warning .ui-stat__value { color: var(--lc-warning); }
.ui-stat--danger .ui-stat__value { color: var(--lc-danger); }
.ui-stat--success .ui-stat__value { color: var(--lc-success); }

.ui-stat__meta {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: var(--space-2);
    font-size: 12px;
}

.ui-stat__note { color: var(--lc-ink-3); }

.ui-delta {
    display: inline-flex;
    align-items: center;
    gap: 2px;
    padding: 1px 6px;
    border-radius: var(--radius-full);
    font-weight: var(--font-weight-medium);
}

.ui-delta--good { background: var(--lc-success-tint); color: var(--lc-success); }
.ui-delta--bad { background: var(--lc-danger-tint); color: var(--lc-danger); }


.ui-ring {
    position: relative;
    display: inline-grid;
    place-items: center;
    flex: none;
}

.ui-ring svg { display: block; }

.ui-ring__center {
    position: absolute;
    inset: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
}


.ui-spark { display: block; overflow: visible; }

.ui-spark__line {
    fill: none;
    stroke: currentColor;
    stroke-width: 2;
    stroke-linecap: round;
    stroke-linejoin: round;
}

.ui-spark__area {
    fill: currentColor;
    opacity: 0.12;
}

.ui-spark__dot {
    fill: currentColor;
    stroke: var(--lc-canvas);
    stroke-width: 2;
}


.ui-bars {
    margin: 0;
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
}

.ui-bars__plot {
    display: flex;
    align-items: flex-end;
    gap: var(--space-2);
}

.ui-bars__col {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: stretch;
    justify-content: flex-end;
    gap: var(--space-1);
    height: 100%;
    min-width: 0;
}

.ui-bars__value {
    color: var(--lc-ink-3);
    font-family: var(--lc-font-mono);
    font-size: var(--lc-t-micro);
    text-align: center;
}

.ui-bars__bar {
    min-height: 2px;
    border-radius: 6px 6px 2px 2px;
    background: var(--lc-raised-hover);
    box-shadow: inset 0 1px 0 var(--lc-highlight);
    transform-origin: bottom;
    animation: ui-grow var(--lc-slow) var(--lc-ease) both;
}

.ui-bars__bar.is-highlight {
    background: var(--azure);
    box-shadow: var(--lc-shadow-accent);
}

.ui-bars__labels {
    display: flex;
    gap: var(--space-2);
}

.ui-bars__labels span {
    flex: 1;
    color: var(--lc-ink-3);
    font-size: var(--lc-t-micro);
    text-align: center;
}

@keyframes ui-grow {
    from { transform: scaleY(0); }
}


.ui-progress {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
}

.ui-progress__head {
    display: flex;
    justify-content: space-between;
    gap: var(--space-3);
    font-size: var(--lc-t-label);
}

.ui-progress__label { color: var(--lc-ink-2); }

.ui-progress__value {
    font-family: var(--lc-font-mono);
    font-variant-numeric: tabular-nums;
}

.ui-progress__track {
    height: 8px;
    overflow: hidden;
    border-radius: var(--radius-full);
    background: var(--lc-well);
    box-shadow: inset 0 0 0 1px var(--lc-line);
}

.ui-progress__fill {
    display: block;
    height: 100%;
    border-radius: inherit;
    transition: width var(--lc-slow) var(--lc-ease);
}

.ui-progress__fill--brand { background: var(--azure); }
.ui-progress__fill--success { background: var(--lc-success); }
.ui-progress__fill--warning { background: var(--lc-warning); }


.ui-streak {
    display: flex;
    align-items: center;
    gap: var(--space-3);
    padding: var(--space-3) var(--space-4);
    border-radius: var(--lc-r-lg);
    background: var(--lc-card);
    box-shadow: inset 0 0 0 1px var(--lc-line);
}

.ui-streak__icon {
    display: grid;
    place-items: center;
    width: 36px;
    height: 36px;
    border-radius: var(--lc-r-md);
    background: var(--lc-raised);
    color: var(--lc-ink-3);
}

.ui-streak.is-live .ui-streak__icon {
    background: var(--lc-warning-tint);
    color: var(--signal);
}

.ui-streak__text {
    display: flex;
    flex-direction: column;
    flex: 1;
    min-width: 0;
}

.ui-streak__text strong {
    font-family: var(--lc-font-display);
    font-size: 1rem;
    font-weight: var(--font-weight-semibold);
}

.ui-streak__text small {
    color: var(--lc-ink-3);
    font-size: 12px;
}

.ui-streak__days {
    display: flex;
    gap: 4px;
}

.ui-streak__days span {
    width: 8px;
    height: 20px;
    border-radius: var(--radius-full);
    background: var(--lc-raised);
}

.ui-streak__days span.is-kept { background: var(--signal); }


.ui-row {
    display: flex;
    align-items: center;
    gap: var(--space-3);
    width: 100%;
    min-height: 64px;
    padding: var(--space-3) var(--space-4);
    border: 0;
    border-radius: var(--lc-r-md);
    background: none;
    color: var(--lc-ink-1);
    font-family: var(--lc-font-body);
    text-align: left;
    text-decoration: none;
}

.ui-row--dense { min-height: 48px; padding: var(--space-2) var(--space-3); }

.ui-row--interactive {
    cursor: pointer;
    transition: background var(--lc-fast) var(--lc-ease), transform var(--lc-fast) var(--lc-ease);
}

.ui-row--interactive:hover { background: var(--lc-card); }
.ui-row--interactive:active { transform: scale(0.995); }

.ui-row.is-selected {
    background: var(--lc-raised);
    box-shadow: var(--lc-shadow-raised);
}

.ui-row__leading { flex: none; display: flex; }

.ui-row__main {
    display: flex;
    flex-direction: column;
    flex: 1;
    min-width: 0;
}

.ui-row__title {
    overflow: hidden;
    font-size: var(--lc-t-body);
    font-weight: var(--font-weight-medium);
    text-overflow: ellipsis;
    white-space: nowrap;
}

.ui-row__subtitle {
    overflow: hidden;
    color: var(--lc-ink-3);
    font-size: var(--lc-t-label);
    text-overflow: ellipsis;
    white-space: nowrap;
}

.ui-row__meta {
    flex: none;
    color: var(--lc-ink-2);
    font-family: var(--lc-font-mono);
    font-size: var(--lc-t-label);
    font-variant-numeric: tabular-nums;
}

.ui-row__chevron {
    flex: none;
    color: var(--lc-ink-4);
}


.ui-empty {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: var(--space-3);
    padding: var(--space-10) var(--space-5);
    border-radius: var(--lc-r-xl);
    background: var(--lc-card);
    box-shadow: inset 0 0 0 1px var(--lc-line);
    text-align: center;
}

.ui-empty__art {
    display: grid;
    place-items: center;
    margin-bottom: var(--space-2);
}

.ui-empty__title {
    margin: 0;
    font-family: var(--lc-font-display);
    font-size: 1.25rem;
    font-weight: var(--font-weight-semibold);
    letter-spacing: var(--lc-track-title);
}

.ui-empty__body {
    max-width: 38ch;
    margin: 0;
    color: var(--lc-ink-2);
    font-size: var(--lc-t-body);
    line-height: var(--lc-lh-body);
}

.ui-empty__actions {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: var(--space-2);
    margin-top: var(--space-2);
}


.ui-seg {
    display: inline-flex;
    padding: 3px;
    border-radius: var(--radius-full);
    background: var(--lc-well);
    box-shadow: inset 0 0 0 1px var(--lc-line);
}

.ui-seg__btn {
    min-height: 34px;
    min-width: 72px;
    padding: 0 var(--space-4);
    border: 0;
    border-radius: var(--radius-full);
    background: none;
    color: var(--lc-ink-3);
    font-family: var(--lc-font-body);
    font-size: var(--lc-t-label);
    font-weight: var(--font-weight-semibold);
    cursor: pointer;
    transition: background var(--lc-fast) var(--lc-ease), color var(--lc-fast) var(--lc-ease);
}

.ui-seg__btn:hover { color: var(--lc-ink-1); }

.ui-seg__btn.is-selected {
    background: var(--lc-raised);
    box-shadow: var(--lc-shadow-raised);
    color: var(--lc-ink-1);
}


.ui-chips {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-2);
}

.ui-chip {
    display: inline-flex;
    align-items: center;
    gap: var(--space-2);
    min-height: 36px;
    padding: 0 var(--space-4);
    border: 0;
    border-radius: var(--radius-full);
    background: var(--lc-card);
    box-shadow: inset 0 0 0 1px var(--lc-line);
    color: var(--lc-ink-2);
    font-family: var(--lc-font-body);
    font-size: var(--lc-t-label);
    font-weight: var(--font-weight-medium);
    cursor: pointer;
    transition: background var(--lc-fast) var(--lc-ease), color var(--lc-fast) var(--lc-ease), transform var(--lc-fast) var(--lc-ease);
}

.ui-chip:hover { color: var(--lc-ink-1); background: var(--lc-raised); }
.ui-chip:active { transform: scale(0.96); }

.ui-chip.is-selected {
    background: var(--lc-ink-1);
    box-shadow: none;
    color: var(--lc-canvas);
}

.ui-chip__count {
    font-family: var(--lc-font-mono);
    font-size: var(--lc-t-micro);
    opacity: 0.7;
}


.ui-field {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
    min-width: 0;
}

.ui-field__label {
    display: flex;
    align-items: baseline;
    gap: var(--space-2);
    color: var(--lc-ink-2);
    font-size: var(--lc-t-label);
    font-weight: var(--font-weight-medium);
}

.ui-field__optional {
    color: var(--lc-ink-4);
    font-weight: var(--font-weight-normal);
}

.ui-field__hint {
    color: var(--lc-ink-3);
    font-size: 12px;
}

.ui-field__error {
    color: var(--lc-danger);
    font-size: 12px;
    font-weight: var(--font-weight-medium);
}

.ui-input {
    width: 100%;
    min-height: 48px;
    padding: 0 var(--space-4);
    border: 0;
    border-radius: var(--lc-r-md);
    background: var(--lc-well);
    box-shadow: inset 0 0 0 1px var(--lc-line-strong);
    color: var(--lc-ink-1);
    font-family: var(--lc-font-body);
    font-size: 16px;
    color-scheme: dark;
    transition: box-shadow var(--lc-fast) var(--lc-ease), background var(--lc-fast) var(--lc-ease);
}

.ui-input::placeholder { color: var(--lc-ink-4); }
.ui-input:hover { background: var(--lc-canvas); }

.ui-input:focus {
    outline: none;
    box-shadow: inset 0 0 0 1.5px var(--azure), 0 0 0 4px var(--lc-info-tint);
}

.ui-field.has-error .ui-input {
    box-shadow: inset 0 0 0 1.5px var(--lc-danger), 0 0 0 4px var(--lc-danger-tint);
}

.ui-input:disabled {
    cursor: not-allowed;
    opacity: 0.5;
}

.ui-input--area {
    min-height: 96px;
    padding: var(--space-3) var(--space-4);
    line-height: var(--lc-lh-body);
    resize: vertical;
}

.ui-select {
    position: relative;
    display: block;
}

.ui-select::after {
    content: '';
    position: absolute;
    right: var(--space-4);
    top: 50%;
    width: 8px;
    height: 8px;
    margin-top: -6px;
    border-right: 1.5px solid var(--lc-ink-3);
    border-bottom: 1.5px solid var(--lc-ink-3);
    transform: rotate(45deg);
    pointer-events: none;
}

.ui-select .ui-input {
    padding-right: var(--space-10);
    appearance: none;
}


.ui-switchrow {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--space-4);
    min-height: 56px;
}

.ui-switchrow.is-disabled { opacity: 0.5; }

.ui-switchrow__text {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
}

.ui-switchrow__label {
    font-size: var(--lc-t-body);
    font-weight: var(--font-weight-medium);
}

.ui-switchrow__desc {
    color: var(--lc-ink-3);
    font-size: var(--lc-t-label);
}

.ui-switch {
    position: relative;
    flex: none;
    width: 48px;
    height: 28px;
    padding: 0;
    border: 0;
    border-radius: var(--radius-full);
    background: var(--lc-raised-hover);
    box-shadow: inset 0 0 0 1px var(--lc-line-strong);
    cursor: pointer;
    transition: background var(--lc-base) var(--lc-ease);
}

.ui-switch__thumb {
    position: absolute;
    top: 3px;
    left: 3px;
    width: 22px;
    height: 22px;
    border-radius: var(--radius-full);
    background: var(--lc-ink-1);
    box-shadow: 0 2px 6px rgba(3, 8, 24, 0.5);
    transition: transform var(--lc-base) var(--lc-ease);
}

.ui-switch.is-on {
    background: var(--azure);
    box-shadow: none;
}

.ui-switch.is-on .ui-switch__thumb { transform: translateX(20px); }
.ui-switch:disabled { cursor: not-allowed; }


.ui-toast {
    display: inline-flex;
    align-items: center;
    gap: var(--space-2);
    padding: var(--space-3) var(--space-5);
    border-radius: var(--radius-full);
    background: var(--lc-ink-1);
    box-shadow: var(--lc-shadow-overlay);
    color: var(--lc-canvas);
    font-size: var(--lc-t-label);
    font-weight: var(--font-weight-semibold);
    animation: lc-toast var(--lc-base) var(--lc-ease);
}

.ui-toast--success svg { color: var(--success); }
.ui-toast--danger { background: var(--danger); color: var(--lc-on-accent); }

@keyframes lc-toast {
    from { opacity: 0; transform: translateY(8px) scale(0.98); }
}


.ui-btn:focus-visible,
.ui-iconbtn:focus-visible,
.ui-card--interactive:focus-visible,
.ui-row--interactive:focus-visible,
.ui-seg__btn:focus-visible,
.ui-chip:focus-visible,
.ui-switch:focus-visible {
    outline: 2px solid var(--azure);
    outline-offset: 3px;
}

@media (prefers-reduced-motion: reduce) {
    .ui-btn,
    .ui-card--interactive,
    .ui-row--interactive,
    .ui-chip,
    .ui-switch,
    .ui-switch__thumb,
    .ui-progress__fill {
        transition: none;
    }

    .ui-skel,
    .ui-bars__bar,
    .ui-btn__spinner,
    .ui-toast {
        animation: none;
    }
}
` },
]

// Brand.jsx now re-exports the canonical Ring and initials from the primitives.
const REPLACE_FILES = [
    { path: 'src/components/business/Brand.jsx', content: `export { Ring } from '../ui/Ring'
export { initials } from '../ui/Avatar'

export const Mark = ({ size = 28 }) => (
    <img src="/brand/loca-mark.svg" alt="" width={size} height={size} className="lc-mark" draggable="false" />
)

export const Wordmark = () => (
    <span className="lc-wordmark" aria-label="LocAppoint">
        <span>Loc</span><span className="lc-wordmark__accent">Appoint</span>
    </span>
)

export const BrandLoader = ({ label = 'Loading' }) => (
    <div className="lc-loader" role="status" aria-label={label}>
        <svg className="lc-loader__ring" viewBox="0 0 72 72" aria-hidden="true">
            <defs>
                <linearGradient id="lc-ring-gradient" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="var(--azure)" />
                    <stop offset="100%" stopColor="var(--signal)" />
                </linearGradient>
            </defs>
            <circle className="lc-loader__track" cx="36" cy="36" r="30" />
            <circle className="lc-loader__arc" cx="36" cy="36" r="30" />
        </svg>
        <Mark size={32} />
    </div>
)
` },
]

const PATCHES = [
    {
        file: 'src/components/business/nav.js',
        edits: [
            { desc: "Top bar title for the gallery", find: `    if (pathname.startsWith('/portal/settings')) return 'Settings'
`, replace: `    if (pathname.startsWith('/portal/settings')) return 'Settings'
    if (pathname.startsWith('/portal/ui')) return 'Primitives'
` },
        ],
    },
    {
        file: 'src/main.jsx',
        edits: [
            { desc: "Foundation tokens app-wide", find: `import './styles/tokens.css'
`, replace: `import './styles/tokens.css'
import './styles/foundation.css'
` },
            { desc: "Primitives stylesheet app-wide", find: `import './styles/forms.css'
`, replace: `import './styles/forms.css'
import './styles/ui.css'
` },
        ],
    },
    {
        file: 'src/components/business/BusinessShell.jsx',
        edits: [
            { desc: "Tokens now load app-wide", find: `import '../../styles/business/foundation.css'
`, replace: `` },
        ],
    },
    {
        file: 'src/BookingApp.jsx',
        edits: [
            { desc: "Import the primitives gallery", find: `import Planned from './pages/business/Planned'
`, replace: `import Planned from './pages/business/Planned'
import UiGallery from './pages/business/UiGallery'
` },
            { desc: "Internal gallery route", find: `                    <Route path="notifications" element={<Planned section="notifications" />} />
`, replace: `                    <Route path="notifications" element={<Planned section="notifications" />} />
                    <Route path="ui" element={<UiGallery />} />
` },
        ],
    },
]

const RETIRES = ['src/styles/business/foundation.css']

let failed = false

for (const nf of NEW_FILES) {
    if (fs.existsSync(path.join(REPO, nf.path))) { console.error(`[FAIL] Already exists: ${nf.path}`); failed = true }
}
for (const rf of REPLACE_FILES) {
    if (!fs.existsSync(path.join(REPO, rf.path))) { console.error(`[FAIL] Missing, apply the 4a-2 redesign first: ${rf.path}`); failed = true }
}

const fileChanges = new Map()
for (const group of PATCHES) {
    const fullPath = path.join(REPO, group.file)
    if (!fs.existsSync(fullPath)) { console.error(`[FAIL] Missing: ${group.file}`); failed = true; continue }
    let content = fs.readFileSync(fullPath, 'utf8')
    const original = content
    const crlf = (content.match(/\r\n/g) || []).length
    const lf = (content.match(/\n/g) || []).length - crlf
    const eol = crlf > lf ? '\r\n' : '\n'
    let ok = true
    for (const edit of group.edits) {
        // Anchors accept CRLF or LF; replacements follow the file's dominant ending.
        const pattern = edit.find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\n/g, '\\r?\\n')
        const matches = (content.match(new RegExp(pattern, 'g')) || []).length
        if (matches !== 1) {
            console.error(`[FAIL] ${group.file}: ${matches} matches for "${edit.desc}" (expected 1)`)
            failed = true; ok = false; break
        }
        content = content.replace(new RegExp(pattern), () => edit.replace.replace(/\n/g, eol))
    }
    if (ok) fileChanges.set(fullPath, { original, modified: content, edits: group.edits })
}

const retirePaths = []
for (const rel of RETIRES) {
    const full = path.join(REPO, rel)
    if (!fs.existsSync(full)) { console.error(`[FAIL] Retire target missing: ${rel}`); failed = true; continue }
    if (fs.existsSync(`${full}.mistake`)) { console.error(`[FAIL] Already retired: ${rel}.mistake`); failed = true; continue }
    retirePaths.push({ full, rel })
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const nf of NEW_FILES) {
    fs.mkdirSync(path.dirname(path.join(REPO, nf.path)), { recursive: true })
    fs.writeFileSync(path.join(REPO, nf.path), nf.content)
    console.log(`[NEW] ${nf.path}`)
}
for (const rf of REPLACE_FILES) {
    const full = path.join(REPO, rf.path)
    fs.writeFileSync(`${full}.backup`, fs.readFileSync(full))
    fs.writeFileSync(full, rf.content)
    console.log(`[REPLACE] ${rf.path}`)
}
for (const [fullPath, change] of fileChanges) {
    fs.writeFileSync(`${fullPath}.backup`, change.original)
    fs.writeFileSync(fullPath, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, fullPath)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}

for (const { full, rel } of retirePaths) {
    fs.renameSync(full, `${full}.mistake`)
    console.log(`[RETIRE] ${rel} -> .mistake`)
}

console.log('\n[DONE]')
