$ErrorActionPreference = 'Stop'

Write-Host ""
Write-Host "  Locappoint - Foundation: tokens, type scale, primitives, gallery" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path 'package.json')) { Write-Host "  [ABORT] No package.json. Run from repo root." -ForegroundColor Red; exit 1 }
$pkg = Get-Content 'package.json' -Raw | ConvertFrom-Json
if ($pkg.name -ne 'locappoint') { Write-Host "  [ABORT] Wrong package: $($pkg.name)" -ForegroundColor Red; exit 1 }
try { $null = & node --version } catch { Write-Host "  [ABORT] Node.js not found." -ForegroundColor Red; exit 1 }

Write-Host "  Applies on top of business-shell-v2 (already installed)." -ForegroundColor Magenta
Write-Host ""
Write-Host "  What this does:" -ForegroundColor White
Write-Host ""
Write-Host "    [NEW]      src/styles/foundation.css  (tokens + type scale, loaded app-wide)" -ForegroundColor Green
Write-Host "    [NEW]      src/styles/ui.css  (every primitive, every state)" -ForegroundColor Green
Write-Host "    [NEW]      src/components/ui/  18 primitives + useCountUp, format, index" -ForegroundColor Green
Write-Host "    [NEW]      src/pages/business/UiGallery.jsx + gallery.css  (internal, /portal/ui)" -ForegroundColor Green
Write-Host "    [REPLACE]  src/components/business/Brand.jsx  (one canonical Ring)" -ForegroundColor Yellow
Write-Host "    [EDIT]     src/main.jsx, BusinessShell.jsx, BookingApp.jsx, nav.js" -ForegroundColor Yellow
Write-Host "    [RETIRE]   src/styles/business/foundation.css  -> .mistake" -ForegroundColor Magenta
Write-Host ""
Write-Host "  Everything replaced or edited is saved as *.backup first." -ForegroundColor Gray
Write-Host ""

$confirm = Read-Host "  Apply? (y/n)"
if ($confirm -ne 'y' -and $confirm -ne 'Y') { Write-Host "  [CANCELLED]" -ForegroundColor Yellow; exit 0 }
Write-Host ""

& node (Join-Path $PSScriptRoot 'patch-foundation.mjs')
if ($LASTEXITCODE -ne 0) { Write-Host "  [FAIL] Exit code $LASTEXITCODE" -ForegroundColor Red; exit $LASTEXITCODE }

$payloadDir = $PSScriptRoot
if ((Split-Path $payloadDir -Leaf) -eq 'payload') {
    Set-Location (Split-Path $payloadDir -Parent)
    Remove-Item $payloadDir -Recurse -Force
}

Write-Host ""
Write-Host "  Done. npm run build, then open /portal/ui." -ForegroundColor Green
Write-Host ""
