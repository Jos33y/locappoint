import fs from 'fs'
import path from 'path'
import crypto from 'crypto'
import { fileURLToPath } from 'url'

const REPO = process.cwd()
const HERE = path.dirname(fileURLToPath(import.meta.url))
const SPEC = {
 "new": [
  "src/services/links.js"
 ],
 "replace": [
  {
   "path": "src/pages/business/Setup.jsx",
   "sha256": "ad639d5870b882926585fd8637a43aa80fb65ebd634864555a3ba64a76602e35"
  },
  {
   "path": "src/styles/business/setup.css",
   "sha256": "8c39f1c1c0a8893a4b7970af3294aa6c49a2a561afdc6dede7389b3866c4f74b"
  }
 ],
 "patches": [
  {
   "file": "src/components/business/ShareLink.jsx",
   "edits": [
    {
     "desc": "Links use the public address",
     "find": "import { Check, Copy, MessageCircle } from 'lucide-react'\n",
     "replace": "import { Check, Copy, MessageCircle } from 'lucide-react'\nimport { pageUrl, publicHost } from '../../services/links'\n"
    },
    {
     "desc": "Build the link from the public address",
     "find": "    const link = `${window.location.origin}/${business.slug}`",
     "replace": "    const link = pageUrl(business.slug)"
    },
    {
     "desc": "Show the public host",
     "find": "<span className=\"biz-share__host\">{window.location.host}/</span>",
     "replace": "<span className=\"biz-share__host\">{publicHost()}/</span>"
    }
   ]
  },
  {
   "file": "src/pages/business/Channels.jsx",
   "edits": [
    {
     "desc": "Links use the public address",
     "find": "import '../../styles/business/support.css'\n",
     "replace": "import '../../styles/business/support.css'\nimport { pageUrl } from '../../services/links'\n"
    },
    {
     "desc": "Build the link from the public address",
     "find": "    const link = `${window.location.origin}/${business.slug}`",
     "replace": "    const link = pageUrl(business.slug)"
    }
   ]
  }
 ],
 "retires": [],
 "backupSuffix": ".backup-live"
}
const BACKUP = SPEC.backupSuffix

let failed = false
const fail = (msg) => { console.error(`[FAIL] ${msg}`); failed = true }
const sha = (buf) => crypto.createHash('sha256').update(buf).digest('hex')
const toCrlf = (text) => text.replace(/\r?\n/g, '\r\n')
const count = (haystack, needle) => (needle === '' ? 0 : haystack.split(needle).length - 1)

for (const rel of SPEC.new) {
    if (fs.existsSync(path.join(REPO, rel))) fail(`Already exists: ${rel}`)
    if (!fs.existsSync(path.join(HERE, 'files', rel))) fail(`Missing in payload: ${rel}`)
}

for (const item of SPEC.replace) {
    const full = path.join(REPO, item.path)
    if (!fs.existsSync(full)) { fail(`Missing: ${item.path}`); continue }
    const current = fs.readFileSync(full)
    if (sha(current) !== item.sha256) fail(`${item.path} differs from the version this patch expects (edited locally, or already replaced). Not overwriting.`)
    if (fs.existsSync(`${full}${BACKUP}`)) fail(`Backup already exists: ${item.path}${BACKUP}`)
}

const fileChanges = new Map()
for (const group of SPEC.patches) {
    const full = path.join(REPO, group.file)
    if (!fs.existsSync(full)) { fail(`Missing: ${group.file}`); continue }
    if (fs.existsSync(`${full}${BACKUP}`)) fail(`Backup already exists: ${group.file}${BACKUP}`)
    const original = fs.readFileSync(full, 'utf8')
    let content = original
    let ok = true
    for (const edit of group.edits) {
        const lf = count(content, edit.find)
        const crlf = count(content, toCrlf(edit.find))
        let find = edit.find
        let replace = edit.replace
        if (lf !== 1 && crlf === 1) { find = toCrlf(edit.find); replace = toCrlf(edit.replace) }
        else if (lf !== 1) { fail(`${group.file}: ${lf || crlf} matches for "${edit.desc}" (expected 1)`); ok = false; break }
        content = content.replace(find, () => replace)
    }
    if (ok) fileChanges.set(full, { original, modified: content, edits: group.edits })
}

const retirePaths = []
for (const rel of SPEC.retires) {
    const full = path.join(REPO, rel)
    if (!fs.existsSync(full)) { fail(`Retire target missing: ${rel}`); continue }
    if (fs.existsSync(`${full}.mistake`)) { fail(`Already retired: ${rel}.mistake`); continue }
    retirePaths.push({ full, rel })
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const rel of SPEC.new) {
    fs.mkdirSync(path.dirname(path.join(REPO, rel)), { recursive: true })
    fs.copyFileSync(path.join(HERE, 'files', rel), path.join(REPO, rel))
    console.log(`[NEW] ${rel}`)
}
for (const item of SPEC.replace) {
    const full = path.join(REPO, item.path)
    fs.copyFileSync(full, `${full}${BACKUP}`)
    fs.copyFileSync(path.join(HERE, 'files', item.path), full)
    console.log(`[REPLACE] ${item.path}`)
}
for (const [full, change] of fileChanges) {
    fs.writeFileSync(`${full}${BACKUP}`, change.original)
    fs.writeFileSync(full, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, full)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}

for (const { full, rel } of retirePaths) {
    fs.renameSync(full, `${full}.mistake`)
    console.log(`[RETIRE] ${rel} -> .mistake`)
}

console.log('\n[DONE]')
