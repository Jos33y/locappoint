import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowLeftRight, ChevronRight, KeyRound, LogOut, Mail } from 'lucide-react'
import { Button, Field } from '../../components/ui'
import { supabase } from '../../config/supabase'
import { useAuth } from '../../hooks/useAuth'
import { useWorkspace } from '../../components/business/WorkspaceContext'
import { initials } from '../../components/business/Brand'
import StreetGridCover from '../../components/business/StreetGridCover'
import SaveState from '../../components/business/SaveState'
import { PasswordSheet, SettingsRow as Row, SettingsSection as Section, SignOutSheet } from '../../components/business/AccountSheets'
import { useAutosave } from '../../components/business/useAutosave'
import { SUPPORT } from '../../constants/support'
import '../../styles/business/settings-page.css'

const memberSince = (value) => {
    const date = value ? new Date(value) : null
    if (!date || Number.isNaN(date.getTime())) return null
    return date.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })
}

const SettingsPage = () => {
    const { user, userProfile, refreshProfile } = useAuth()
    const { notify } = useWorkspace()
    const email = user?.email || userProfile?.email || ''
    const [name, setName] = useState(userProfile?.full_name || '')
    const [savedName, setSavedName] = useState(userProfile?.full_name || '')
    const [passwordOpen, setPasswordOpen] = useState(false)
    const [signOutOpen, setSignOutOpen] = useState(false)

    const trimmed = name.trim()
    const nameProblem = trimmed ? null : 'Enter the name people know you by'
    const since = useMemo(() => memberSince(userProfile?.created_at || user?.created_at), [userProfile?.created_at, user?.created_at])

    const autosave = useAutosave({
        pending: !nameProblem && trimmed !== savedName.trim() ? trimmed : '',
        ready: Boolean(user?.id),
        blocked: Boolean(nameProblem),
        save: async (value) => {
            const { data, error } = await supabase.from('users').update({ full_name: value }).eq('id', user.id).select('id')
            if (error) throw error
            if (!data || data.length === 0) throw new Error('Update returned 0 rows for user ' + user.id)
            setSavedName(value)
            refreshProfile?.()
        },
    })

    const closeLink = `mailto:${SUPPORT.email}?subject=${encodeURIComponent('Close my Locappoint account')}&body=${encodeURIComponent(`Please close the Locappoint account for ${email}.`)}`

    return (
        <div className="biz-page biz-st">
            <header className="biz-page__head biz-st__head">
                <div>
                    <h1 className="biz-page__title">Settings</h1>
                    <p className="biz-page__sub">Your account, sign-in and security.</p>
                </div>
            </header>

            <div className="biz-st__column">
                <section className="ui-card ui-card--flat biz-st__card biz-st__idcard" aria-labelledby="profile-title">
                    <div className="biz-st__band" aria-hidden="true">
                        <StreetGridCover seed={user?.id || email} tint="azure" focus />
                    </div>
                    <div className="biz-st__id">
                        <span className="biz-st__avatar" aria-hidden="true">{initials(trimmed || email)}</span>
                        <div className="biz-st__idtext">
                            <h2 id="profile-title" className="biz-st__idname">{trimmed || 'Your name'}</h2>
                            <p className="biz-st__idmeta">
                                <span>{email}</span>
                                {since && <span className="biz-st__since">Member since {since}</span>}
                            </p>
                        </div>
                    </div>
                    <div className="biz-st__idbody">
                        <div className="biz-st__namefield">
                            <Field label="Your name" error={name !== savedName ? nameProblem : undefined} hint="Your own name, not the business name">
                                <input className="ui-input" value={name} onChange={(e) => setName(e.target.value)} maxLength={80} autoComplete="name" />
                            </Field>
                            <SaveState state={autosave.state} onRetry={autosave.retry} blockedText="Enter your name to save it" />
                        </div>
                        <div className="biz-st__rule" />
                        <Row title="Sign-in email" detail="Used to sign in and for booking emails. Changing it is done by our team.">
                            <Button variant="secondary" size="sm" icon={Mail} href={`mailto:${SUPPORT.email}?subject=${encodeURIComponent('Change my sign-in email')}`}>Ask to change</Button>
                        </Row>
                    </div>
                </section>

                <Section id="security" title="Sign-in and security">
                    <Row title="Password" detail="Change it any time. You stay signed in on this device.">
                        <Button variant="secondary" size="sm" icon={KeyRound} onClick={() => setPasswordOpen(true)}>Change password</Button>
                    </Row>
                    <div className="biz-st__rule" />
                    <Row title="Sign out everywhere" detail="Lost a phone or shared your password? This signs you out on every device.">
                        <Button variant="secondary" size="sm" icon={LogOut} onClick={() => setSignOutOpen(true)}>Sign out everywhere</Button>
                    </Row>
                </Section>

                <Section id="alerts" title="Notifications">
                    <Row title="Booking alerts" detail="Email and WhatsApp alerts for new, moved and cancelled bookings.">
                        <span className="biz-soon">Soon</span>
                    </Row>
                </Section>

                <Section id="account" title="Your account">
                    <Link to="/client" className="biz-st__linkrow">
                        <ArrowLeftRight size={18} aria-hidden="true" />
                        <span className="biz-st__rowtext">
                            <span className="biz-st__rowtitle">Switch to Booking</span>
                            <span className="biz-st__rowdetail">Book with other businesses using the same account.</span>
                        </span>
                        <ChevronRight size={18} aria-hidden="true" className="biz-st__chevron" />
                    </Link>
                    <div className="biz-st__rule" />
                    <Row title="Close your account" detail="Tell us and we close it for you. If you run a business, we talk you through what happens to your page and bookings first.">
                        <Button variant="secondary" size="sm" className="biz-st__danger" href={closeLink}>Ask us to close it</Button>
                    </Row>
                </Section>

                <p className="biz-st__legal">
                    <Link to="/privacy">Privacy</Link>
                    <span aria-hidden="true">·</span>
                    <Link to="/terms">Terms</Link>
                    <span aria-hidden="true">·</span>
                    <span>Support: <a href={`mailto:${SUPPORT.email}`}>{SUPPORT.email}</a></span>
                </p>
            </div>

            <PasswordSheet
                open={passwordOpen}
                email={email}
                onClose={() => setPasswordOpen(false)}
                onDone={() => { setPasswordOpen(false); notify('Password changed') }}
            />
            <SignOutSheet open={signOutOpen} onClose={() => setSignOutOpen(false)} />
        </div>
    )
}

export default SettingsPage
