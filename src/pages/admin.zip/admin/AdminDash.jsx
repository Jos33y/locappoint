// AdminDash.jsx - Admin dashboard with Waitlist, Partnership & Analytics tabs
// Location: src/pages/admin/AdminDash.jsx

import { useState, useEffect } from 'react'
import { 
    Users, 
    Handshake, 
    Download, 
    RefreshCw, 
    Mail, 
    Phone, 
    MapPin, 
    Calendar, 
    Building2, 
    MessageSquare,
    BarChart3,
    Globe,
    Monitor,
    Smartphone,
    Tablet,
    TrendingUp,
    MousePointer,
    Eye,
    UserCheck,
    Clock,
    ArrowUpRight,
    ChevronDown,
    Filter
} from 'lucide-react'
import { supabase } from '../../config/supabase'

const AdminDash = () => {
    const [activeTab, setActiveTab] = useState('analytics')
    const [waitlistData, setWaitlistData] = useState([])
    const [partnershipData, setPartnershipData] = useState([])
    const [analyticsData, setAnalyticsData] = useState({
        sessions: [],
        events: [],
        stats: {}
    })
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState(null)
    const [dateRange, setDateRange] = useState('7d') // 24h, 7d, 30d, all

    useEffect(() => {
        fetchAllData()
    }, [dateRange])

    const getDateFilter = () => {
        const now = new Date()
        switch (dateRange) {
            case '24h':
                return new Date(now - 24 * 60 * 60 * 1000).toISOString()
            case '7d':
                return new Date(now - 7 * 24 * 60 * 60 * 1000).toISOString()
            case '30d':
                return new Date(now - 30 * 24 * 60 * 60 * 1000).toISOString()
            default:
                return null
        }
    }

    const fetchAllData = async () => {
        try {
            setLoading(true)
            setError(null)

            const dateFilter = getDateFilter()

            // Build queries
            let sessionsQuery = supabase
                .from('analytics_sessions')
                .select('*')
                .order('created_at', { ascending: false })
            
            let eventsQuery = supabase
                .from('analytics_events')
                .select('*')
                .order('created_at', { ascending: false })
                .limit(500)

            if (dateFilter) {
                sessionsQuery = sessionsQuery.gte('created_at', dateFilter)
                eventsQuery = eventsQuery.gte('created_at', dateFilter)
            }

            // Fetch all data in parallel
            const [waitlistRes, partnershipRes, sessionsRes, eventsRes] = await Promise.all([
                supabase
                    .from('waitlist')
                    .select('*')
                    .order('created_at', { ascending: false }),
                supabase
                    .from('partnership_requests')
                    .select('*')
                    .order('created_at', { ascending: false }),
                sessionsQuery,
                eventsQuery
            ])

            if (waitlistRes.error) throw waitlistRes.error
            if (partnershipRes.error) throw partnershipRes.error
            if (sessionsRes.error) throw sessionsRes.error
            if (eventsRes.error) throw eventsRes.error

            const sessions = sessionsRes.data || []
            const events = eventsRes.data || []

            // Calculate analytics stats
            const stats = calculateStats(sessions, events)

            setWaitlistData(waitlistRes.data || [])
            setPartnershipData(partnershipRes.data || [])
            setAnalyticsData({ sessions, events, stats })
        } catch (err) {
            console.error('Error fetching data:', err)
            setError('Failed to load data. Please try again.')
        } finally {
            setLoading(false)
        }
    }

    const calculateStats = (sessions, events) => {
        const totalVisitors = sessions.length
        const uniqueCountries = [...new Set(sessions.map(s => s.country).filter(Boolean))]
        
        // Device breakdown
        const devices = sessions.reduce((acc, s) => {
            acc[s.device_type] = (acc[s.device_type] || 0) + 1
            return acc
        }, {})

        // Country breakdown (top 10)
        const countries = sessions.reduce((acc, s) => {
            if (s.country) {
                acc[s.country] = (acc[s.country] || 0) + 1
            }
            return acc
        }, {})
        const topCountries = Object.entries(countries)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 10)

        // Browser breakdown
        const browsers = sessions.reduce((acc, s) => {
            if (s.browser) {
                acc[s.browser] = (acc[s.browser] || 0) + 1
            }
            return acc
        }, {})

        // Conversion metrics
        const waitlistOpened = sessions.filter(s => s.waitlist_opened).length
        const waitlistSubmitted = sessions.filter(s => s.waitlist_submitted).length
        const partnershipOpened = sessions.filter(s => s.partnership_opened).length
        const partnershipSubmitted = sessions.filter(s => s.partnership_submitted).length
        const whatsappClicked = sessions.filter(s => s.whatsapp_clicked).length

        // Bounce rate
        const bounces = sessions.filter(s => s.is_bounce).length
        const bounceRate = totalVisitors > 0 ? Math.round((bounces / totalVisitors) * 100) : 0

        // Average time on site
        const totalTime = sessions.reduce((acc, s) => acc + (s.total_time_seconds || 0), 0)
        const avgTime = totalVisitors > 0 ? Math.round(totalTime / totalVisitors) : 0

        // Section views from events
        const sectionViews = events
            .filter(e => e.event_type === 'section_view')
            .reduce((acc, e) => {
                acc[e.event_value] = (acc[e.event_value] || 0) + 1
                return acc
            }, {})

        // Traffic sources
        const sources = sessions.reduce((acc, s) => {
            const source = s.utm_source || s.referrer_domain || 'direct'
            acc[source] = (acc[source] || 0) + 1
            return acc
        }, {})

        // Daily visitors (last 7 days)
        const dailyVisitors = {}
        const now = new Date()
        for (let i = 6; i >= 0; i--) {
            const date = new Date(now)
            date.setDate(date.getDate() - i)
            const key = date.toISOString().split('T')[0]
            dailyVisitors[key] = 0
        }
        sessions.forEach(s => {
            const date = new Date(s.created_at).toISOString().split('T')[0]
            if (dailyVisitors.hasOwnProperty(date)) {
                dailyVisitors[date]++
            }
        })

        return {
            totalVisitors,
            uniqueCountries: uniqueCountries.length,
            devices,
            topCountries,
            browsers,
            waitlistOpened,
            waitlistSubmitted,
            waitlistConversion: waitlistOpened > 0 ? Math.round((waitlistSubmitted / waitlistOpened) * 100) : 0,
            partnershipOpened,
            partnershipSubmitted,
            partnershipConversion: partnershipOpened > 0 ? Math.round((partnershipSubmitted / partnershipOpened) * 100) : 0,
            whatsappClicked,
            bounceRate,
            avgTime,
            sectionViews,
            sources,
            dailyVisitors
        }
    }

    const formatDate = (dateString) => {
        const date = new Date(dateString)
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        })
    }

    const formatTime = (seconds) => {
        if (seconds < 60) return `${seconds}s`
        const mins = Math.floor(seconds / 60)
        const secs = seconds % 60
        return `${mins}m ${secs}s`
    }

    // CSV Export functions
    const exportWaitlistCSV = () => {
        if (waitlistData.length === 0) return

        const headers = ['Full Name', 'Email', 'Phone', 'Country', 'User Type', 'Business Type', 'Comments', 'Date Joined']
        const rows = waitlistData.map(item => [
            item.full_name,
            item.email,
            item.phone || '',
            item.country || '',
            item.user_type || '',
            item.business_type || '',
            item.comments || '',
            formatDate(item.created_at)
        ])

        downloadCSV(headers, rows, 'locappoint-waitlist')
    }

    const exportPartnershipCSV = () => {
        if (partnershipData.length === 0) return

        const headers = [
            'First Name', 'Last Name', 'Email', 'Phone', 
            'Organization Type', 'Organization Name', 
            'City', 'Country', 'Partnership Interest', 'Status', 'Date Submitted'
        ]
        const rows = partnershipData.map(item => [
            item.first_name,
            item.last_name,
            item.email,
            item.phone,
            item.organization_type,
            item.organization_name || '',
            item.city || '',
            item.country || '',
            item.partnership_interest || '',
            item.status || 'pending',
            formatDate(item.created_at)
        ])

        downloadCSV(headers, rows, 'locappoint-partnerships')
    }

    const exportAnalyticsCSV = () => {
        if (analyticsData.sessions.length === 0) return

        const headers = [
            'Session ID', 'Country', 'City', 'Region',
            'Device', 'Browser', 'OS',
            'Referrer', 'UTM Source', 'UTM Medium', 'UTM Campaign',
            'Page Views', 'Time on Site (s)', 'Bounce',
            'Waitlist Opened', 'Waitlist Submitted',
            'Partnership Opened', 'Partnership Submitted',
            'WhatsApp Clicked', 'First Seen', 'Last Seen'
        ]
        const rows = analyticsData.sessions.map(s => [
            s.session_id,
            s.country || '',
            s.city || '',
            s.region || '',
            s.device_type || '',
            s.browser || '',
            s.os || '',
            s.referrer_domain || '',
            s.utm_source || '',
            s.utm_medium || '',
            s.utm_campaign || '',
            s.page_views || 0,
            s.total_time_seconds || 0,
            s.is_bounce ? 'Yes' : 'No',
            s.waitlist_opened ? 'Yes' : 'No',
            s.waitlist_submitted ? 'Yes' : 'No',
            s.partnership_opened ? 'Yes' : 'No',
            s.partnership_submitted ? 'Yes' : 'No',
            s.whatsapp_clicked ? 'Yes' : 'No',
            formatDate(s.first_seen_at),
            formatDate(s.last_seen_at)
        ])

        downloadCSV(headers, rows, 'locappoint-analytics')
    }

    const exportEventsCSV = () => {
        if (analyticsData.events.length === 0) return

        const headers = ['Session ID', 'Event Type', 'Event Name', 'Category', 'Value', 'Page', 'Timestamp']
        const rows = analyticsData.events.map(e => [
            e.session_id,
            e.event_type,
            e.event_name,
            e.event_category || '',
            e.event_value || '',
            e.page_path || '',
            formatDate(e.created_at)
        ])

        downloadCSV(headers, rows, 'locappoint-events')
    }

    const downloadCSV = (headers, rows, filename) => {
        const csvContent = [
            headers.join(','),
            ...rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
        ].join('\n')

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `${filename}-${new Date().toISOString().split('T')[0]}.csv`
        a.click()
        window.URL.revokeObjectURL(url)
    }

    const updatePartnershipStatus = async (id, newStatus) => {
        try {
            const { error } = await supabase
                .from('partnership_requests')
                .update({ status: newStatus })
                .eq('id', id)

            if (error) throw error

            setPartnershipData(prev => 
                prev.map(item => 
                    item.id === id ? { ...item, status: newStatus } : item
                )
            )
        } catch (err) {
            console.error('Error updating status:', err)
            alert('Failed to update status')
        }
    }

    const getStatusBadgeClass = (status) => {
        switch (status) {
            case 'contacted': return 'admin__status--contacted'
            case 'approved': return 'admin__status--approved'
            case 'rejected': return 'admin__status--rejected'
            default: return 'admin__status--pending'
        }
    }

    if (loading) {
        return (
            <div className="admin">
                <div className="admin__container">
                    <div className="admin__loading">
                        <RefreshCw size={24} className="spin" />
                        <span>Loading data...</span>
                    </div>
                </div>
            </div>
        )
    }

    if (error) {
        return (
            <div className="admin">
                <div className="admin__container">
                    <div className="admin__error">{error}</div>
                    <button onClick={fetchAllData} className="btn btn--primary">
                        Retry
                    </button>
                </div>
            </div>
        )
    }

    return (
        <div className="admin">
            <div className="admin__container">
                {/* Header */}
                <div className="admin__header">
                    <div>
                        <h1 className="admin__title">Admin Dashboard</h1>
                        <p className="admin__subtitle">
                            Manage waitlist, partnerships & view analytics
                        </p>
                    </div>
                    <button
                        onClick={fetchAllData}
                        className="btn btn--secondary admin__refresh"
                        disabled={loading}
                    >
                        <RefreshCw size={16} />
                        <span>Refresh</span>
                    </button>
                </div>

                {/* Tabs */}
                <div className="admin__tabs">
                    <button
                        className={`admin__tab ${activeTab === 'analytics' ? 'admin__tab--active' : ''}`}
                        onClick={() => setActiveTab('analytics')}
                    >
                        <BarChart3 size={18} />
                        <span>Analytics</span>
                        <span className="admin__tab-count">{analyticsData.stats.totalVisitors || 0}</span>
                    </button>
                    <button
                        className={`admin__tab ${activeTab === 'waitlist' ? 'admin__tab--active' : ''}`}
                        onClick={() => setActiveTab('waitlist')}
                    >
                        <Users size={18} />
                        <span>Waitlist</span>
                        <span className="admin__tab-count">{waitlistData.length}</span>
                    </button>
                    <button
                        className={`admin__tab ${activeTab === 'partnership' ? 'admin__tab--active' : ''}`}
                        onClick={() => setActiveTab('partnership')}
                    >
                        <Handshake size={18} />
                        <span>Partnership</span>
                        <span className="admin__tab-count">{partnershipData.length}</span>
                    </button>
                </div>

                {/* Tab Content */}
                <div className="admin__tab-content">
                    {activeTab === 'analytics' && (
                        <AnalyticsTab 
                            data={analyticsData} 
                            dateRange={dateRange}
                            setDateRange={setDateRange}
                            onExportSessions={exportAnalyticsCSV}
                            onExportEvents={exportEventsCSV}
                            formatDate={formatDate}
                            formatTime={formatTime}
                        />
                    )}
                    {activeTab === 'waitlist' && (
                        <WaitlistTab 
                            data={waitlistData} 
                            formatDate={formatDate}
                            onExport={exportWaitlistCSV}
                        />
                    )}
                    {activeTab === 'partnership' && (
                        <PartnershipTab 
                            data={partnershipData}
                            formatDate={formatDate}
                            onExport={exportPartnershipCSV}
                            onStatusChange={updatePartnershipStatus}
                            getStatusBadgeClass={getStatusBadgeClass}
                        />
                    )}
                </div>
            </div>
        </div>
    )
}

// ========== ANALYTICS TAB ==========
const AnalyticsTab = ({ data, dateRange, setDateRange, onExportSessions, onExportEvents, formatDate, formatTime }) => {
    const { stats, sessions, events } = data

    const getDeviceIcon = (type) => {
        switch (type) {
            case 'mobile': return <Smartphone size={16} />
            case 'tablet': return <Tablet size={16} />
            default: return <Monitor size={16} />
        }
    }

    return (
        <div className="analytics">
            {/* Date Range Filter */}
            <div className="analytics__toolbar">
                <div className="analytics__filter">
                    <Filter size={16} />
                    <select value={dateRange} onChange={(e) => setDateRange(e.target.value)}>
                        <option value="24h">Last 24 hours</option>
                        <option value="7d">Last 7 days</option>
                        <option value="30d">Last 30 days</option>
                        <option value="all">All time</option>
                    </select>
                    <ChevronDown size={14} />
                </div>
                <div className="analytics__exports">
                    <button onClick={onExportSessions} className="btn btn--sm btn--secondary">
                        <Download size={14} />
                        <span>Sessions CSV</span>
                    </button>
                    <button onClick={onExportEvents} className="btn btn--sm btn--secondary">
                        <Download size={14} />
                        <span>Events CSV</span>
                    </button>
                </div>
            </div>

            {/* Overview Stats */}
            <div className="analytics__stats-grid">
                <div className="analytics__stat-card">
                    <div className="analytics__stat-icon analytics__stat-icon--purple">
                        <Eye size={20} />
                    </div>
                    <div className="analytics__stat-content">
                        <span className="analytics__stat-value">{stats.totalVisitors}</span>
                        <span className="analytics__stat-label">Total Visitors</span>
                    </div>
                </div>
                
                <div className="analytics__stat-card">
                    <div className="analytics__stat-icon analytics__stat-icon--cyan">
                        <Globe size={20} />
                    </div>
                    <div className="analytics__stat-content">
                        <span className="analytics__stat-value">{stats.uniqueCountries}</span>
                        <span className="analytics__stat-label">Countries</span>
                    </div>
                </div>

                <div className="analytics__stat-card">
                    <div className="analytics__stat-icon analytics__stat-icon--amber">
                        <Clock size={20} />
                    </div>
                    <div className="analytics__stat-content">
                        <span className="analytics__stat-value">{formatTime(stats.avgTime)}</span>
                        <span className="analytics__stat-label">Avg. Time</span>
                    </div>
                </div>

                <div className="analytics__stat-card">
                    <div className="analytics__stat-icon analytics__stat-icon--red">
                        <TrendingUp size={20} />
                    </div>
                    <div className="analytics__stat-content">
                        <span className="analytics__stat-value">{stats.bounceRate}%</span>
                        <span className="analytics__stat-label">Bounce Rate</span>
                    </div>
                </div>
            </div>

            {/* Conversion Stats */}
            <div className="analytics__section">
                <h3 className="analytics__section-title">
                    <UserCheck size={18} />
                    Conversions
                </h3>
                <div className="analytics__conversion-grid">
                    <div className="analytics__conversion-card">
                        <div className="analytics__conversion-header">
                            <span>Waitlist Modal</span>
                            <span className="analytics__conversion-rate">{stats.waitlistConversion}% conv.</span>
                        </div>
                        <div className="analytics__conversion-stats">
                            <div className="analytics__conversion-stat">
                                <span className="analytics__conversion-value">{stats.waitlistOpened}</span>
                                <span className="analytics__conversion-label">Opened</span>
                            </div>
                            <ArrowUpRight size={16} className="analytics__conversion-arrow" />
                            <div className="analytics__conversion-stat">
                                <span className="analytics__conversion-value analytics__conversion-value--success">{stats.waitlistSubmitted}</span>
                                <span className="analytics__conversion-label">Submitted</span>
                            </div>
                        </div>
                    </div>

                    <div className="analytics__conversion-card">
                        <div className="analytics__conversion-header">
                            <span>Partnership Modal</span>
                            <span className="analytics__conversion-rate">{stats.partnershipConversion}% conv.</span>
                        </div>
                        <div className="analytics__conversion-stats">
                            <div className="analytics__conversion-stat">
                                <span className="analytics__conversion-value">{stats.partnershipOpened}</span>
                                <span className="analytics__conversion-label">Opened</span>
                            </div>
                            <ArrowUpRight size={16} className="analytics__conversion-arrow" />
                            <div className="analytics__conversion-stat">
                                <span className="analytics__conversion-value analytics__conversion-value--success">{stats.partnershipSubmitted}</span>
                                <span className="analytics__conversion-label">Submitted</span>
                            </div>
                        </div>
                    </div>

                    <div className="analytics__conversion-card analytics__conversion-card--whatsapp">
                        <div className="analytics__conversion-header">
                            <span>WhatsApp Channel</span>
                        </div>
                        <div className="analytics__conversion-stats">
                            <div className="analytics__conversion-stat">
                                <span className="analytics__conversion-value analytics__conversion-value--whatsapp">{stats.whatsappClicked}</span>
                                <span className="analytics__conversion-label">Clicked</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Two Column Layout */}
            <div className="analytics__two-col">
                {/* Top Countries */}
                <div className="analytics__section">
                    <h3 className="analytics__section-title">
                        <Globe size={18} />
                        Top Countries
                    </h3>
                    <div className="analytics__list">
                        {stats.topCountries?.length > 0 ? (
                            stats.topCountries.map(([country, count], i) => (
                                <div key={country} className="analytics__list-item">
                                    <span className="analytics__list-rank">{i + 1}</span>
                                    <span className="analytics__list-name">{country}</span>
                                    <span className="analytics__list-value">{count}</span>
                                    <div className="analytics__list-bar">
                                        <div 
                                            className="analytics__list-bar-fill"
                                            style={{ width: `${(count / stats.totalVisitors) * 100}%` }}
                                        />
                                    </div>
                                </div>
                            ))
                        ) : (
                            <div className="analytics__empty-small">No country data yet</div>
                        )}
                    </div>
                </div>

                {/* Device Breakdown */}
                <div className="analytics__section">
                    <h3 className="analytics__section-title">
                        <Monitor size={18} />
                        Devices
                    </h3>
                    <div className="analytics__devices">
                        {Object.entries(stats.devices || {}).map(([device, count]) => (
                            <div key={device} className="analytics__device">
                                <div className="analytics__device-icon">
                                    {getDeviceIcon(device)}
                                </div>
                                <div className="analytics__device-info">
                                    <span className="analytics__device-name">{device}</span>
                                    <span className="analytics__device-count">{count} ({Math.round((count / stats.totalVisitors) * 100)}%)</span>
                                </div>
                                <div className="analytics__device-bar">
                                    <div 
                                        className="analytics__device-bar-fill"
                                        style={{ width: `${(count / stats.totalVisitors) * 100}%` }}
                                    />
                                </div>
                            </div>
                        ))}
                    </div>

                    <h3 className="analytics__section-title" style={{ marginTop: '24px' }}>
                        <MousePointer size={18} />
                        Browsers
                    </h3>
                    <div className="analytics__list">
                        {Object.entries(stats.browsers || {}).slice(0, 5).map(([browser, count]) => (
                            <div key={browser} className="analytics__list-item">
                                <span className="analytics__list-name">{browser}</span>
                                <span className="analytics__list-value">{count}</span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Recent Sessions */}
            <div className="analytics__section">
                <h3 className="analytics__section-title">
                    <Users size={18} />
                    Recent Sessions
                </h3>
                <div className="admin__table-container">
                    <table className="admin__table">
                        <thead>
                            <tr>
                                <th>Location</th>
                                <th>Device</th>
                                <th>Source</th>
                                <th>Pages</th>
                                <th>Time</th>
                                <th>Actions</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            {sessions.slice(0, 20).map((session) => (
                                <tr key={session.id}>
                                    <td>
                                        <div className="analytics__cell-location">
                                            <span>{session.city || session.country || 'Unknown'}</span>
                                            {session.region && <small>{session.region}</small>}
                                        </div>
                                    </td>
                                    <td>
                                        <div className="analytics__cell-device">
                                            {getDeviceIcon(session.device_type)}
                                            <span>{session.browser}</span>
                                        </div>
                                    </td>
                                    <td>{session.utm_source || session.referrer_domain || 'Direct'}</td>
                                    <td>{session.page_views}</td>
                                    <td>{formatTime(session.total_time_seconds || 0)}</td>
                                    <td>
                                        <div className="analytics__cell-actions">
                                            {session.waitlist_submitted && <span className="analytics__action-badge analytics__action-badge--waitlist">W</span>}
                                            {session.partnership_submitted && <span className="analytics__action-badge analytics__action-badge--partner">P</span>}
                                            {session.whatsapp_clicked && <span className="analytics__action-badge analytics__action-badge--whatsapp">WA</span>}
                                            {!session.waitlist_submitted && !session.partnership_submitted && !session.whatsapp_clicked && '-'}
                                        </div>
                                    </td>
                                    <td className="admin__td-date">{formatDate(session.created_at)}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    )
}

// ========== WAITLIST TAB ==========
const WaitlistTab = ({ data, formatDate, onExport }) => {
    if (data.length === 0) {
        return (
            <div className="admin__empty">
                <Users size={48} />
                <p>No waitlist signups yet</p>
            </div>
        )
    }

    return (
        <>
            <div className="admin__toolbar">
                <span className="admin__toolbar-info">
                    Showing {data.length} signup{data.length !== 1 ? 's' : ''}
                </span>
                <button onClick={onExport} className="btn btn--primary btn--sm">
                    <Download size={16} />
                    <span>Export CSV</span>
                </button>
            </div>

            {/* Mobile Cards */}
            <div className="admin__cards">
                {data.map((item) => (
                    <div key={item.id} className="admin__card">
                        <div className="admin__card-header">
                            <h3 className="admin__card-name">{item.full_name}</h3>
                            <span className="admin__card-date">{formatDate(item.created_at)}</span>
                        </div>
                        <div className="admin__card-body">
                            <div className="admin__card-row">
                                <Mail size={14} />
                                <span>{item.email}</span>
                            </div>
                            {item.phone && (
                                <div className="admin__card-row">
                                    <Phone size={14} />
                                    <span>{item.phone}</span>
                                </div>
                            )}
                            <div className="admin__card-row">
                                <Globe size={14} />
                                <span>{item.country || 'N/A'}</span>
                            </div>
                            <div className="admin__card-row">
                                <Users size={14} />
                                <span>{item.user_type || 'N/A'}</span>
                            </div>
                            {item.business_type && (
                                <div className="admin__card-row">
                                    <Building2 size={14} />
                                    <span>{item.business_type}</span>
                                </div>
                            )}
                            {item.comments && (
                                <div className="admin__card-row admin__card-row--comments">
                                    <MessageSquare size={14} />
                                    <span>{item.comments}</span>
                                </div>
                            )}
                        </div>
                    </div>
                ))}
            </div>

            {/* Desktop Table */}
            <div className="admin__table-container">
                <table className="admin__table">
                    <thead>
                        <tr>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Country</th>
                            <th>Type</th>
                            <th>Business Type</th>
                            <th>Comments</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map((item) => (
                            <tr key={item.id}>
                                <td className="admin__td-name">{item.full_name}</td>
                                <td>{item.email}</td>
                                <td>{item.phone || '-'}</td>
                                <td>{item.country || '-'}</td>
                                <td>
                                    <span className={`admin__type-badge admin__type-badge--${item.user_type}`}>
                                        {item.user_type || '-'}
                                    </span>
                                </td>
                                <td>{item.business_type || '-'}</td>
                                <td className="admin__td-comments">{item.comments || '-'}</td>
                                <td className="admin__td-date">{formatDate(item.created_at)}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </>
    )
}

// ========== PARTNERSHIP TAB ==========
const PartnershipTab = ({ data, formatDate, onExport, onStatusChange, getStatusBadgeClass }) => {
    if (data.length === 0) {
        return (
            <div className="admin__empty">
                <Handshake size={48} />
                <p>No partnership requests yet</p>
            </div>
        )
    }

    return (
        <>
            <div className="admin__toolbar">
                <span className="admin__toolbar-info">
                    Showing {data.length} request{data.length !== 1 ? 's' : ''}
                </span>
                <button onClick={onExport} className="btn btn--primary btn--sm">
                    <Download size={16} />
                    <span>Export CSV</span>
                </button>
            </div>

            {/* Mobile Cards */}
            <div className="admin__cards">
                {data.map((item) => (
                    <div key={item.id} className="admin__card">
                        <div className="admin__card-header">
                            <h3 className="admin__card-name">{item.first_name} {item.last_name}</h3>
                            <span className={`admin__status ${getStatusBadgeClass(item.status)}`}>
                                {item.status || 'pending'}
                            </span>
                        </div>
                        <div className="admin__card-body">
                            <div className="admin__card-row">
                                <Mail size={14} />
                                <span>{item.email}</span>
                            </div>
                            <div className="admin__card-row">
                                <Phone size={14} />
                                <span>{item.phone}</span>
                            </div>
                            <div className="admin__card-row">
                                <Building2 size={14} />
                                <span>{item.organization_type}</span>
                            </div>
                            {item.organization_name && (
                                <div className="admin__card-row">
                                    <span className="admin__card-label">Organization:</span>
                                    <span>{item.organization_name}</span>
                                </div>
                            )}
                            {(item.city || item.country) && (
                                <div className="admin__card-row">
                                    <MapPin size={14} />
                                    <span>{[item.city, item.country].filter(Boolean).join(', ')}</span>
                                </div>
                            )}
                            {item.partnership_interest && (
                                <div className="admin__card-row admin__card-row--comments">
                                    <MessageSquare size={14} />
                                    <span>{item.partnership_interest}</span>
                                </div>
                            )}
                            <div className="admin__card-row">
                                <Calendar size={14} />
                                <span>{formatDate(item.created_at)}</span>
                            </div>
                        </div>
                        <div className="admin__card-actions">
                            <select
                                value={item.status || 'pending'}
                                onChange={(e) => onStatusChange(item.id, e.target.value)}
                                className="admin__status-select"
                            >
                                <option value="pending">Pending</option>
                                <option value="contacted">Contacted</option>
                                <option value="approved">Approved</option>
                                <option value="rejected">Rejected</option>
                            </select>
                        </div>
                    </div>
                ))}
            </div>

            {/* Desktop Table */}
            <div className="admin__table-container">
                <table className="admin__table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Contact</th>
                            <th>Organization</th>
                            <th>Location</th>
                            <th>Interest</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map((item) => (
                            <tr key={item.id}>
                                <td className="admin__td-name">
                                    {item.first_name} {item.last_name}
                                </td>
                                <td>
                                    <div className="admin__td-contact">
                                        <span>{item.email}</span>
                                        <span>{item.phone}</span>
                                    </div>
                                </td>
                                <td>
                                    <div className="admin__td-org">
                                        <span className="admin__td-org-type">{item.organization_type}</span>
                                        {item.organization_name && (
                                            <span className="admin__td-org-name">{item.organization_name}</span>
                                        )}
                                    </div>
                                </td>
                                <td>{[item.city, item.country].filter(Boolean).join(', ') || '-'}</td>
                                <td className="admin__td-comments">{item.partnership_interest || '-'}</td>
                                <td>
                                    <select
                                        value={item.status || 'pending'}
                                        onChange={(e) => onStatusChange(item.id, e.target.value)}
                                        className={`admin__status-select ${getStatusBadgeClass(item.status)}`}
                                    >
                                        <option value="pending">Pending</option>
                                        <option value="contacted">Contacted</option>
                                        <option value="approved">Approved</option>
                                        <option value="rejected">Rejected</option>
                                    </select>
                                </td>
                                <td className="admin__td-date">{formatDate(item.created_at)}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </>
    )
}

export default AdminDash