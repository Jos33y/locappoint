import fs from 'fs'
import path from 'path'

const REPO = process.cwd()

const NEW_FILES = []

const PATCHES = [
    {
        file: 'src/styles/foundation.css',
        edits: [
            { desc: "App loader ring keeps its size inside the reset", find: `.lc-apploader__ring {
    position: absolute;
    inset: -18px;
    width: 92px;
    height: 92px;
`, replace: `.lc-apploader__ring {
    position: absolute;
    inset: -18px;
    width: 92px;
    height: 92px;
    max-width: none;
` },
            { desc: "Small loader ring keeps its size inside the reset", find: `.lc-loader__ring {
    position: absolute;
    inset: 0;
`, replace: `.lc-loader__ring {
    position: absolute;
    inset: 0;
    max-width: none;
` },
        ],
    },
    {
        file: 'src/constants/support.js',
        edits: [
            { desc: "Support uses the transactional address; hello@ is for marketing", find: `    email: 'hello@locappoint.com',`, replace: `    email: 'support@locappoint.com',` },
        ],
    },
]

const RETIRES = []

let failed = false

for (const nf of NEW_FILES) {
    const full = path.join(REPO, nf.path)
    if (fs.existsSync(full)) { console.error(`[FAIL] Already exists: ${nf.path}`); failed = true }
    if (!fs.existsSync(path.dirname(full))) { console.error(`[FAIL] Parent dir missing: ${nf.path}`); failed = true }
}

const fileChanges = new Map()
for (const group of PATCHES) {
    const fullPath = path.join(REPO, group.file)
    if (!fs.existsSync(fullPath)) { console.error(`[FAIL] Missing: ${group.file}`); failed = true; continue }
    let content = fs.readFileSync(fullPath, 'utf8')
    const original = content
    const crlf = (content.match(/\r\n/g) || []).length
    const lf = (content.match(/\n/g) || []).length - crlf
    const eol = crlf > lf ? '\r\n' : '\n'
    let ok = true
    for (const edit of group.edits) {
        // Anchors accept CRLF or LF; replacements follow the file's dominant ending.
        const pattern = edit.find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\n/g, '\\r?\\n')
        const matches = (content.match(new RegExp(pattern, 'g')) || []).length
        if (matches !== 1) {
            console.error(`[FAIL] ${group.file}: ${matches} matches for "${edit.desc}" (expected 1)`)
            failed = true; ok = false; break
        }
        const replace = edit.replace.replace(/\n/g, eol)
        content = content.replace(new RegExp(pattern), () => replace)
    }
    if (ok) fileChanges.set(fullPath, { original, modified: content, edits: group.edits })
}

const retirePaths = []
for (const rel of RETIRES) {
    const full = path.join(REPO, rel)
    if (!fs.existsSync(full)) { console.error(`[FAIL] Retire target missing: ${rel}`); failed = true; continue }
    if (fs.existsSync(`${full}.mistake`)) { console.error(`[FAIL] Already retired: ${rel}.mistake`); failed = true; continue }
    retirePaths.push({ full, rel })
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const nf of NEW_FILES) {
    fs.writeFileSync(path.join(REPO, nf.path), nf.content)
    console.log(`[NEW] ${nf.path}`)
}
for (const [fullPath, change] of fileChanges) {
    fs.writeFileSync(`${fullPath}.backup`, change.original)
    fs.writeFileSync(fullPath, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, fullPath)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}
for (const { full, rel } of retirePaths) {
    fs.renameSync(full, `${full}.mistake`)
    console.log(`[RETIRE] ${rel} -> .mistake`)
}

console.log('\n[DONE]')
