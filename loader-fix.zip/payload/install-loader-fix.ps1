$ErrorActionPreference = 'Stop'
if (-not (Test-Path 'package.json')) { Write-Host "  [ABORT] No package.json." -ForegroundColor Red; exit 1 }
$pkg = Get-Content 'package.json' -Raw | ConvertFrom-Json
if ($pkg.name -ne 'locappoint') { Write-Host "  [ABORT] Wrong package." -ForegroundColor Red; exit 1 }
Write-Host ""
Write-Host "  Locappoint - Loader ring fix" -ForegroundColor Cyan
Write-Host "    [EDIT]  src/styles/foundation.css  (rings ignore the global svg max-width)" -ForegroundColor Yellow
Write-Host "    [EDIT]  src/constants/support.js  (support@ address, not hello@)" -ForegroundColor Yellow
Write-Host ""
$confirm = Read-Host "  Apply? (y/n)"
if ($confirm -ne 'y' -and $confirm -ne 'Y') { Write-Host "  [CANCELLED]" -ForegroundColor Yellow; exit 0 }
& node (Join-Path $PSScriptRoot 'patch-loader-fix.mjs')
if ($LASTEXITCODE -ne 0) { Write-Host "  [FAIL] Exit code $LASTEXITCODE" -ForegroundColor Red; exit $LASTEXITCODE }
$payloadDir = $PSScriptRoot
if ((Split-Path $payloadDir -Leaf) -eq 'payload') { Set-Location (Split-Path $payloadDir -Parent); Remove-Item $payloadDir -Recurse -Force }
Write-Host "  Done. npm run build." -ForegroundColor Green
