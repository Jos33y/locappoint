$ErrorActionPreference = 'Stop'

Write-Host ""
Write-Host "  Locappoint - True phone preview" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path 'package.json')) {
    Write-Host "  [ABORT] No package.json. Run from repo root." -ForegroundColor Red
    exit 1
}
$pkg = Get-Content 'package.json' -Raw | ConvertFrom-Json
if ($pkg.name -ne 'locappoint') {
    Write-Host "  [ABORT] Wrong package: $($pkg.name)" -ForegroundColor Red
    exit 1
}
try { $null = & node --version } catch {
    Write-Host "  [ABORT] Node.js not found." -ForegroundColor Red
    exit 1
}

Write-Host "  What this does:" -ForegroundColor White
Write-Host ""
Write-Host "    [REPLACE] src/components/ui/PhoneFrame.jsx" -ForegroundColor Cyan
Write-Host "    [REPLACE] src/styles/ui-kit.css" -ForegroundColor Cyan
Write-Host "    [REPLACE] src/pages/business/Setup.jsx" -ForegroundColor Cyan
Write-Host "    [REPLACE] src/styles/business/setup.css" -ForegroundColor Cyan
Write-Host "    [EDIT]    src/constants/reservedSlugs.js  (1 edit)" -ForegroundColor Yellow
Write-Host ""
Write-Host "  Backups saved as *.backup-preview." -ForegroundColor Gray
Write-Host ""

$confirm = Read-Host "  Apply? (y/n)"
if ($confirm -ne 'y' -and $confirm -ne 'Y') { Write-Host "  [CANCELLED]" -ForegroundColor Yellow; exit 0 }
Write-Host ""

& node (Join-Path $PSScriptRoot 'patch-true-preview.mjs')
if ($LASTEXITCODE -ne 0) { Write-Host "  [FAIL] Exit code $LASTEXITCODE" -ForegroundColor Red; exit $LASTEXITCODE }

Write-Host ""
$payloadDir = $PSScriptRoot
if ((Split-Path $payloadDir -Leaf) -eq 'payload') {
    Set-Location (Split-Path $payloadDir -Parent)
    Remove-Item $payloadDir -Recurse -Force
}

Write-Host ""
Write-Host "  Done. npm run build, redeploy." -ForegroundColor Green
Write-Host ""
