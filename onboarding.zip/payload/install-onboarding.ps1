$ErrorActionPreference = 'Stop'

Write-Host ""
Write-Host "  Locappoint - Onboarding" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path 'package.json')) {
    Write-Host "  [ABORT] No package.json. Run from repo root." -ForegroundColor Red
    exit 1
}
$pkg = Get-Content 'package.json' -Raw | ConvertFrom-Json
if ($pkg.name -ne 'locappoint') {
    Write-Host "  [ABORT] Wrong package: $($pkg.name)" -ForegroundColor Red
    exit 1
}
try { $null = & node --version } catch {
    Write-Host "  [ABORT] Node.js not found." -ForegroundColor Red
    exit 1
}

Write-Host "  What this does:" -ForegroundColor White
Write-Host ""
Write-Host "    [NEW]     src/components/business/HoursEditor.jsx" -ForegroundColor Green
Write-Host "    [NEW]     src/components/business/PublicPageView.jsx" -ForegroundColor Green
Write-Host "    [NEW]     src/components/business/ServiceEditor.jsx" -ForegroundColor Green
Write-Host "    [NEW]     src/components/ui/AffixInput.jsx" -ForegroundColor Green
Write-Host "    [NEW]     src/components/ui/ImagePicker.jsx" -ForegroundColor Green
Write-Host "    [NEW]     src/components/ui/PhoneFrame.jsx" -ForegroundColor Green
Write-Host "    [NEW]     src/components/ui/QrCode.jsx" -ForegroundColor Green
Write-Host "    [NEW]     src/components/ui/Sheet.jsx" -ForegroundColor Green
Write-Host "    [NEW]     src/components/ui/Stepper.jsx" -ForegroundColor Green
Write-Host "    [NEW]     src/components/ui/TimeField.jsx" -ForegroundColor Green
Write-Host "    [NEW]     src/constants/categories.js" -ForegroundColor Green
Write-Host "    [NEW]     src/pages/app/PublicBusinessPage.jsx" -ForegroundColor Green
Write-Host "    [NEW]     src/pages/business/Setup.jsx" -ForegroundColor Green
Write-Host "    [NEW]     src/services/hours.js" -ForegroundColor Green
Write-Host "    [NEW]     src/services/media.js" -ForegroundColor Green
Write-Host "    [NEW]     src/services/setup.js" -ForegroundColor Green
Write-Host "    [NEW]     src/styles/business/editors.css" -ForegroundColor Green
Write-Host "    [NEW]     src/styles/business/setup.css" -ForegroundColor Green
Write-Host "    [NEW]     src/styles/public-page.css" -ForegroundColor Green
Write-Host "    [NEW]     src/styles/ui-kit.css" -ForegroundColor Green
Write-Host "    [NEW]     supabase/migrations/onboarding-a.sql" -ForegroundColor Green
Write-Host "    [NEW]     supabase/migrations/onboarding-b.sql" -ForegroundColor Green
Write-Host "    [NEW]     supabase/migrations/onboarding-verify.sql" -ForegroundColor Green
Write-Host "    [EDIT]    src/components/ui/index.js  (1 edit)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/BookingApp.jsx  (4 edits)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/components/business/BusinessShell.jsx  (4 edits)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/components/business/NewBookingSheet.jsx  (1 edit)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/components/business/BookingDetailSheet.jsx  (1 edit)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/contexts/AuthContext.jsx  (1 edit)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/components/common/ProtectedRoute.jsx  (1 edit)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/pages/portal/Profile.jsx  (1 edit)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/services/business.js  (1 edit)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/styles/business/shell.css  (4 edits)" -ForegroundColor Yellow
Write-Host "    [EDIT]    package.json  (1 edit)" -ForegroundColor Yellow
Write-Host "    [RETIRE]  src/components/business/Sheet.jsx  -> .mistake" -ForegroundColor Magenta
Write-Host "    [RETIRE]  src/pages/app/BusinessPage.jsx  -> .mistake" -ForegroundColor Magenta
Write-Host "    [RETIRE]  supabase/migrations/schema-onboarding.sql  -> .mistake" -ForegroundColor Magenta
Write-Host ""
Write-Host "  Then runs npm install to add qrcode." -ForegroundColor White
Write-Host "  Backups saved as *.backup." -ForegroundColor Gray
Write-Host ""

$confirm = Read-Host "  Apply? (y/n)"
if ($confirm -ne 'y' -and $confirm -ne 'Y') { Write-Host "  [CANCELLED]" -ForegroundColor Yellow; exit 0 }
Write-Host ""

& node (Join-Path $PSScriptRoot 'patch-onboarding.mjs')
if ($LASTEXITCODE -ne 0) { Write-Host "  [FAIL] Exit code $LASTEXITCODE" -ForegroundColor Red; exit $LASTEXITCODE }

Write-Host ""
Write-Host "  Installing qrcode..." -ForegroundColor White
& npm install --no-audit --no-fund
if ($LASTEXITCODE -ne 0) {
    Write-Host "  [WARN] npm install failed. Files are patched; run npm install yourself before building." -ForegroundColor Yellow
}

$payloadDir = $PSScriptRoot
if ((Split-Path $payloadDir -Leaf) -eq 'payload') {
    Set-Location (Split-Path $payloadDir -Parent)
    Remove-Item $payloadDir -Recurse -Force
}

Write-Host ""
Write-Host "  Done. npm run build, redeploy." -ForegroundColor Green
Write-Host "  Then run onboarding-b.sql if the launch rule is not live yet." -ForegroundColor Green
Write-Host ""
