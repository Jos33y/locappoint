import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const REPO = process.cwd()
const HERE = path.dirname(fileURLToPath(import.meta.url))
const SPEC = {
 "new": [
  "src/components/business/HoursEditor.jsx",
  "src/components/business/PublicPageView.jsx",
  "src/components/business/ServiceEditor.jsx",
  "src/components/ui/AffixInput.jsx",
  "src/components/ui/ImagePicker.jsx",
  "src/components/ui/PhoneFrame.jsx",
  "src/components/ui/QrCode.jsx",
  "src/components/ui/Sheet.jsx",
  "src/components/ui/Stepper.jsx",
  "src/components/ui/TimeField.jsx",
  "src/constants/categories.js",
  "src/pages/app/PublicBusinessPage.jsx",
  "src/pages/business/Setup.jsx",
  "src/services/hours.js",
  "src/services/media.js",
  "src/services/setup.js",
  "src/styles/business/editors.css",
  "src/styles/business/setup.css",
  "src/styles/public-page.css",
  "src/styles/ui-kit.css",
  "supabase/migrations/onboarding-a.sql",
  "supabase/migrations/onboarding-b.sql",
  "supabase/migrations/onboarding-verify.sql"
 ],
 "patches": [
  {
   "file": "src/components/ui/index.js",
   "edits": [
    {
     "desc": "Export the new primitives",
     "find": "export { formatters } from './format'",
     "replace": "export { formatters } from './format'\nexport { Sheet } from './Sheet'\nexport { TimeField } from './TimeField'\nexport { Stepper } from './Stepper'\nexport { PhoneFrame } from './PhoneFrame'\nexport { ImagePicker } from './ImagePicker'\nexport { QrCode, downloadQr } from './QrCode'\nexport { AffixInput } from './AffixInput'"
    }
   ]
  },
  {
   "file": "src/BookingApp.jsx",
   "edits": [
    {
     "desc": "Public page uses the shared view",
     "find": "import BusinessPage from './pages/app/BusinessPage'\n",
     "replace": "import PublicBusinessPage from './pages/app/PublicBusinessPage'\n"
    },
    {
     "desc": "Import onboarding",
     "find": "import Channels from './pages/business/Channels'\n",
     "replace": "import Channels from './pages/business/Channels'\nimport Setup from './pages/business/Setup'\n"
    },
    {
     "desc": "Onboarding route",
     "find": "                    <Route path=\"channels\" element={<Channels />} />\n",
     "replace": "                    <Route path=\"channels\" element={<Channels />} />\n                    <Route path=\"setup\" element={<Setup />} />\n"
    },
    {
     "desc": "Slug route renders the new page",
     "find": "<Route path=\"/:businessSlug\" element={<BusinessPage />} />",
     "replace": "<Route path=\"/:businessSlug\" element={<PublicBusinessPage />} />"
    }
   ]
  },
  {
   "file": "src/components/business/BusinessShell.jsx",
   "edits": [
    {
     "desc": "Sheet comes from the primitives",
     "find": "import Sheet from './Sheet'\n",
     "replace": "import { Sheet } from '../ui'\n"
    },
    {
     "desc": "No workspace load until launched",
     "find": "        if (!ownedBusiness?.id) return\n",
     "replace": "        if (!ownedBusiness?.id || !ownedBusiness.launched_at) return\n"
    },
    {
     "desc": "Reload when launch state changes",
     "find": "    }, [ownedBusiness?.id])\n\n    useEffect(() => { reloadWorkspace() }, [reloadWorkspace])",
     "replace": "    }, [ownedBusiness?.id, ownedBusiness?.launched_at])\n\n    useEffect(() => { reloadWorkspace() }, [reloadWorkspace])"
    },
    {
     "desc": "Businesses in setup go to onboarding",
     "find": "    if (!ownedBusiness) {\n        if (location.pathname !== '/portal/page') return <Navigate to=\"/portal/page\" replace />\n        return (\n            <div className=\"biz-bare\">\n                <header className=\"biz-topbar\">\n                    <span className=\"biz-topbar__brand\"><Mark size={26} /><Wordmark /></span>\n                    <Link to=\"/client\" className=\"biz-textbtn\">Back to Booking</Link>\n                </header>\n                <main className=\"biz-content\"><Outlet /></main>\n            </div>\n        )\n    }\n",
     "replace": "    if (!ownedBusiness?.launched_at) {\n        if (location.pathname !== '/portal/setup') return <Navigate to=\"/portal/setup\" replace />\n        return <Outlet />\n    }\n"
    }
   ]
  },
  {
   "file": "src/components/business/NewBookingSheet.jsx",
   "edits": [
    {
     "desc": "Sheet comes from the primitives",
     "find": "import Sheet from './Sheet'\n",
     "replace": "import { Sheet } from '../ui'\n"
    }
   ]
  },
  {
   "file": "src/components/business/BookingDetailSheet.jsx",
   "edits": [
    {
     "desc": "Sheet comes from the primitives",
     "find": "import Sheet from './Sheet'\n",
     "replace": "import { Sheet } from '../ui'\n"
    }
   ]
  },
  {
   "file": "src/contexts/AuthContext.jsx",
   "edits": [
    {
     "desc": "Know whether the business has launched",
     "find": "supabase.from('businesses').select('id, business_name, slug, is_active').eq('user_id', userId).maybeSingle(),",
     "replace": "supabase.from('businesses').select('id, business_name, slug, is_active, launched_at').eq('user_id', userId).maybeSingle(),"
    }
   ]
  },
  {
   "file": "src/components/common/ProtectedRoute.jsx",
   "edits": [
    {
     "desc": "Support address",
     "find": "contact hello@locappoint.com.",
     "replace": "contact support@locappoint.com."
    }
   ]
  },
  {
   "file": "src/pages/portal/Profile.jsx",
   "edits": [
    {
     "desc": "Saving the page no longer unpauses the business",
     "find": "                user_id: userProfile.id,\n                is_active: true,\n",
     "replace": "                user_id: userProfile.id,\n"
    }
   ]
  },
  {
   "file": "src/services/business.js",
   "edits": [
    {
     "desc": "Services in the owner's order",
     "find": "            .eq('business_id', businessId)\n            .order('service_name'),",
     "replace": "            .eq('business_id', businessId)\n            .order('sort_order')\n            .order('service_name'),"
    }
   ]
  },
  {
   "file": "src/styles/business/shell.css",
   "edits": [
    {
     "desc": "Retire sheet base (moved to ui-kit.css)",
     "find": ".biz-sheet {\n    position: fixed;\n    inset: 0;\n    z-index: var(--z-modal);\n    display: flex;\n    align-items: flex-end;\n    background: rgba(5, 6, 8, 0.6);\n    backdrop-filter: blur(6px);\n    -webkit-backdrop-filter: blur(6px);\n    animation: lc-fade var(--lc-base) var(--lc-ease);\n}\n\n",
     "replace": ""
    },
    {
     "desc": "Retire sheet panel styles",
     "find": ".biz-sheet__panel {\n    display: flex;\n    flex-direction: column;\n    width: 100%;\n    max-height: 92dvh;\n    background: var(--lc-overlay);\n    box-shadow: var(--lc-shadow-overlay);\n    border-radius: var(--lc-r-xl) var(--lc-r-xl) 0 0;\n    animation: lc-sheet-up var(--lc-base) var(--lc-ease);\n}\n\n.biz-sheet__panel::before {\n    content: '';\n    align-self: center;\n    width: 40px;\n    height: 4px;\n    margin-top: var(--space-2);\n    border-radius: var(--radius-full);\n    background: var(--lc-line-strong);\n}\n\n.biz-sheet__panel:focus {\n    outline: none;\n}\n\n.biz-sheet__head {\n    display: flex;\n    align-items: center;\n    justify-content: space-between;\n    gap: var(--space-3);\n    padding: var(--space-3) var(--space-5) var(--space-2);\n}\n\n.biz-sheet__title {\n    margin: 0;\n    font-family: var(--font-display);\n    font-size: var(--text-xl);\n    font-weight: var(--font-weight-semibold);\n    letter-spacing: var(--tracking-tight);\n}\n\n.biz-sheet__body {\n    flex: 1;\n    overflow-y: auto;\n    padding: var(--space-2) var(--space-5) var(--space-5);\n    display: flex;\n    flex-direction: column;\n    gap: var(--space-5);\n}\n\n.biz-sheet__foot {\n    padding: var(--space-3) var(--space-5) calc(var(--space-3) + env(safe-area-inset-bottom, 0px));\n    border-top: 1px solid var(--lc-line);\n}\n\n@keyframes lc-sheet-up {\n    from { transform: translateY(32px); opacity: 0; }\n    to { transform: none; opacity: 1; }\n}\n",
     "replace": ""
    },
    {
     "desc": "Retire sheet desktop styles",
     "find": "@media (min-width: 768px) {\n    .biz-sheet {\n        align-items: stretch;\n        justify-content: flex-end;\n        padding: var(--space-3);\n    }\n\n    .biz-sheet__panel {\n        width: 460px;\n        max-height: none;\n        border-radius: var(--lc-r-xl);\n        animation-name: lc-sheet-in;\n    }\n\n    .biz-sheet__panel::before {\n        display: none;\n    }\n\n    @keyframes lc-sheet-in {\n        from { transform: translateX(32px); opacity: 0; }\n        to { transform: none; opacity: 1; }\n    }\n}\n\n",
     "replace": ""
    },
    {
     "desc": "Retire sheet reduced-motion lines",
     "find": "    .biz-sheet,\n    .biz-sheet__panel,\n    .biz-toast__msg {",
     "replace": "    .biz-toast__msg {"
    }
   ]
  },
  {
   "file": "package.json",
   "edits": [
    {
     "desc": "Add qrcode",
     "find": "    \"lucide-react\": \"^0.553.0\",\n    \"react\": \"^19.1.1\",",
     "replace": "    \"lucide-react\": \"^0.553.0\",\n    \"qrcode\": \"^1.5.4\",\n    \"react\": \"^19.1.1\","
    }
   ]
  }
 ],
 "retires": [
  "src/components/business/Sheet.jsx",
  "src/pages/app/BusinessPage.jsx",
  "supabase/migrations/schema-onboarding.sql"
 ]
}

let failed = false
const fail = (msg) => { console.error(`[FAIL] ${msg}`); failed = true }

for (const rel of SPEC.new) {
    const full = path.join(REPO, rel)
    const source = path.join(HERE, 'files', rel)
    if (fs.existsSync(full)) fail(`Already exists: ${rel}`)
    if (!fs.existsSync(source)) fail(`Missing in payload: ${rel}`)
}

const toCrlf = (text) => text.replace(/\r?\n/g, '\r\n')
const count = (haystack, needle) => (needle === '' ? 0 : haystack.split(needle).length - 1)

const fileChanges = new Map()
for (const group of SPEC.patches) {
    const full = path.join(REPO, group.file)
    if (!fs.existsSync(full)) { fail(`Missing: ${group.file}`); continue }
    const original = fs.readFileSync(full, 'utf8')
    let content = original
    let ok = true
    for (const edit of group.edits) {
        const lf = count(content, edit.find)
        const crlf = count(content, toCrlf(edit.find))
        let find = edit.find
        let replace = edit.replace
        if (lf !== 1 && crlf === 1) { find = toCrlf(edit.find); replace = toCrlf(edit.replace) }
        else if (lf !== 1) {
            fail(`${group.file}: ${lf || crlf} matches for "${edit.desc}" (expected 1)`)
            ok = false
            break
        }
        content = content.replace(find, () => replace)
    }
    if (ok) fileChanges.set(full, { original, modified: content, edits: group.edits })
}

const retirePaths = []
for (const rel of SPEC.retires) {
    const full = path.join(REPO, rel)
    if (!fs.existsSync(full)) { fail(`Retire target missing: ${rel}`); continue }
    if (fs.existsSync(`${full}.mistake`)) { fail(`Already retired: ${rel}.mistake`); continue }
    retirePaths.push({ full, rel })
}

for (const full of fileChanges.keys()) {
    if (fs.existsSync(`${full}.backup`)) fail(`Backup already exists: ${path.relative(REPO, full)}.backup`)
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const rel of SPEC.new) {
    const full = path.join(REPO, rel)
    fs.mkdirSync(path.dirname(full), { recursive: true })
    fs.copyFileSync(path.join(HERE, 'files', rel), full)
    console.log(`[NEW] ${rel}`)
}
for (const [full, change] of fileChanges) {
    fs.writeFileSync(`${full}.backup`, change.original)
    fs.writeFileSync(full, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, full)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}
for (const { full, rel } of retirePaths) {
    fs.renameSync(full, `${full}.mistake`)
    console.log(`[RETIRE] ${rel} -> .mistake`)
}

console.log('\n[DONE]')
