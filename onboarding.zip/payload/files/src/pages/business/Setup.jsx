import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Navigate, useNavigate } from 'react-router-dom'
import { ArrowLeft, ArrowRight, Check, Clock, Copy, Download, ExternalLink, Eye, ListChecks, MessageCircle, Share2, Store } from 'lucide-react'
import { useAuth } from '../../hooks/useAuth'
import {
    AffixInput, Button, Field, ImagePicker, Input, PhoneFrame, QrCode, Ring, Select, Sheet, Status, Stepper, Switch, Textarea,
    downloadQr, useCountUp,
} from '../../components/ui'
import { Mark, Wordmark, AppLoader, initials } from '../../components/business/Brand'
import StreetGridCover from '../../components/business/StreetGridCover'
import { ServiceEditor, serviceFromRow, servicesValid } from '../../components/business/ServiceEditor'
import { HoursEditor } from '../../components/business/HoursEditor'
import { PublicPageView } from '../../components/business/PublicPageView'
import { useIsDesktop } from '../../components/business/useIsDesktop'
import { CATEGORIES, CITIES, suggestionsFor } from '../../constants/categories'
import { slugProblem } from '../../constants/reservedSlugs'
import { pageStrength } from '../../services/business'
import { defaultWeek, hasOpenDay, rowsFromWeek, weekFromRows, weekProblems } from '../../services/hours'
import { MEDIA_SHAPES, prepareImage, removeBusinessImage, uploadBusinessImage } from '../../services/media'
import {
    checkSlug, createDraft, goLive, loadSetup, saveDetails, saveHours, saveServices, setupError, slugFrom, updateBusiness,
} from '../../services/setup'
import '../../styles/business/setup.css'

const STEPS = ['Your business', 'Services', 'Hours', 'Make it yours']
const OTHER_CITY = '__other'

const emptyDetails = {
    business_name: '',
    slug: '',
    slugEdited: false,
    category: '',
    cityChoice: 'Lisbon',
    cityOther: '',
    phone: '',
    whatsappSame: true,
}

const cityOf = (details) => (details.cityChoice === OTHER_CITY ? details.cityOther.trim() : details.cityChoice)

const detailsFromBusiness = (b) => {
    const known = CITIES.some((c) => c.value === b.city)
    return {
        business_name: b.business_name,
        slug: b.slug,
        slugEdited: true,
        category: b.category,
        cityChoice: known ? b.city : OTHER_CITY,
        cityOther: known ? '' : b.city,
        phone: b.phone,
        whatsappSame: Boolean(b.whatsapp) && b.whatsapp === b.phone,
    }
}

const detailProblems = (d, slugState) => {
    const p = {}
    if (!d.business_name.trim()) p.business_name = 'Enter the name clients know you by'
    if (!d.category) p.category = 'Choose what kind of business you run'
    if (!cityOf(d)) p.city = 'Enter your city'
    const digits = d.phone.replace(/[^\d]/g, '')
    if (digits.length < 7 || digits.length > 15) p.phone = 'Enter a phone number with the country code, like +351'
    const local = slugProblem(d.slug)
    if (local) p.slug = local
    else if (slugState === 'taken') p.slug = 'That address is taken. Try adding your area.'
    return p
}

const toneOf = () => {
    const hour = new Date().getHours()
    if (hour >= 5 && hour < 11) return 'morning'
    if (hour >= 11 && hour < 16) return 'day'
    if (hour >= 16 && hour < 21) return 'evening'
    return 'night'
}

const useSlugStatus = (slug, ownSlug) => {
    const [state, setState] = useState('idle')
    const seq = useRef(0)
    useEffect(() => {
        const id = ++seq.current
        if (!slug) { setState('idle'); return undefined }
        if (slugProblem(slug)) { setState('invalid'); return undefined }
        if (slug === ownSlug) { setState('available'); return undefined }
        setState('checking')
        const timer = setTimeout(async () => {
            try {
                const result = await checkSlug(slug)
                if (id === seq.current) setState(result)
            } catch {
                if (id === seq.current) setState('error')
            }
        }, 350)
        return () => clearTimeout(timer)
    }, [slug, ownSlug])
    return state
}

const SLUG_STATUS = {
    checking: { tone: 'neutral', word: 'Checking', text: 'Looking it up' },
    available: { tone: 'success', word: 'Available', text: 'This address is yours if you continue' },
    taken: { tone: 'danger', word: 'Taken', text: 'Try adding your area, like femtos-baixa' },
    error: { tone: 'warning', word: 'Not checked', text: 'We will check it when you continue' },
}

const Welcome = ({ onStart, onLater }) => (
    <section className="lc-setup__welcome" aria-labelledby="lc-setup-welcome">
        <Mark size={52} />
        <h1 id="lc-setup-welcome" className="lc-setup__hero">Let's get you booked.</h1>
        <p className="lc-setup__lede">Set up your booking page in about ten minutes. Free for your first twelve months.</p>
        <ul className="lc-setup__promise">
            <li><span className="lc-setup__promiseicon"><Store size={18} aria-hidden="true" /></span><span><strong>Your business</strong>Name, city and your own web address</span></li>
            <li><span className="lc-setup__promiseicon"><ListChecks size={18} aria-hidden="true" /></span><span><strong>What you offer</strong>Services, prices and how long each takes</span></li>
            <li><span className="lc-setup__promiseicon"><Clock size={18} aria-hidden="true" /></span><span><strong>When you work</strong>The hours clients can book you</span></li>
        </ul>
        <div className="lc-setup__welcomeactions">
            <Button size="lg" iconRight={ArrowRight} onClick={onStart}>Let's start</Button>
            <Button size="lg" variant="quiet" onClick={onLater}>Not now</Button>
        </div>
        <p className="lc-setup__fine">Your progress saves at every step. Nothing goes live until you say so.</p>
    </section>
)

const LiveScreen = ({ business, strength, onDone, finishing }) => {
    const link = `${window.location.origin}/${business.slug}`
    const [copied, setCopied] = useState(false)
    const percent = useCountUp(strength.percent)
    const canShare = typeof navigator !== 'undefined' && typeof navigator.share === 'function'

    const copy = async () => {
        try {
            await navigator.clipboard.writeText(link)
            setCopied(true)
            setTimeout(() => setCopied(false), 2200)
        } catch {
            setCopied(false)
        }
    }

    const share = async () => {
        try { await navigator.share({ title: business.business_name, text: `Book with ${business.business_name}`, url: link }) } catch { /* noop */ }
    }

    return (
        <section className="lc-setup__live" aria-labelledby="lc-setup-live">
            <div className="lc-setup__livehead">
                <Ring value={strength.value} size={176} stroke={12} label={`Page ${strength.percent}% complete`}>
                    <span className="lc-setup__livepct">{Math.round(percent)}<small>%</small></span>
                    <span className="lc-setup__livecap">page strength</span>
                </Ring>
                <div className="lc-setup__livetext">
                    <Status tone="success">Live</Status>
                    <h1 id="lc-setup-live" className="lc-setup__hero">You're live.</h1>
                    <p className="lc-setup__lede">Clients can book {business.business_name} from now on. Share your link where they already find you.</p>
                </div>
            </div>

            <div className="lc-setup__linkcard">
                <span className="lc-setup__linklabel">Your booking link</span>
                <p className="lc-setup__link">
                    <span className="lc-setup__host">{window.location.host}/</span>
                    <span className="lc-setup__slug">{business.slug}</span>
                </p>
                <div className="lc-setup__linkactions">
                    <Button icon={copied ? Check : Copy} onClick={copy}>{copied ? 'Copied' : 'Copy link'}</Button>
                    <Button
                        variant="secondary"
                        icon={MessageCircle}
                        href={`https://wa.me/?text=${encodeURIComponent(`Book with ${business.business_name}: ${link}`)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                    >
                        Send on WhatsApp
                    </Button>
                    {canShare && <Button variant="secondary" icon={Share2} onClick={share}>Share</Button>}
                    <Button variant="quiet" icon={ExternalLink} href={link} target="_blank" rel="noopener noreferrer">Open my page</Button>
                </div>
            </div>

            <div className="lc-setup__qrcard">
                <QrCode value={link} label={`QR code for ${link}`} size={132} />
                <div className="lc-setup__qrtext">
                    <strong>Put it on the mirror</strong>
                    <span>Clients scan it and book the next visit before they leave.</span>
                    <Button variant="secondary" size="sm" icon={Download} onClick={() => downloadQr(link, `${business.slug}-booking-qr.png`)}>Download QR code</Button>
                </div>
            </div>

            {strength.next && (
                <p className="lc-setup__nextstep">
                    Still to add for a complete page: {strength.missing.join(', ').toLowerCase()}.
                </p>
            )}

            <Button size="lg" iconRight={ArrowRight} loading={finishing} onClick={onDone}>Go to Today</Button>
        </section>
    )
}

const Setup = () => {
    const { user, business: owned, refreshProfile } = useAuth()
    const navigate = useNavigate()
    const isDesktop = useIsDesktop()
    const headingRef = useRef(null)

    const [phase, setPhase] = useState(owned ? 'loading' : 'welcome')
    const [business, setBusiness] = useState(null)
    const [details, setDetails] = useState(emptyDetails)
    const [services, setServices] = useState([])
    const [savedServiceIds, setSavedServiceIds] = useState([])
    const [week, setWeek] = useState(defaultWeek)
    const [hourRows, setHourRows] = useState([])
    const [extras, setExtras] = useState({ description: '', address: '' })
    const [media, setMedia] = useState({ logo: { busy: false, error: '' }, cover: { busy: false, error: '' } })
    const [showErrors, setShowErrors] = useState(false)
    const [saving, setSaving] = useState(false)
    const [formError, setFormError] = useState('')
    const [previewOpen, setPreviewOpen] = useState(false)
    const [finishing, setFinishing] = useState(false)
    const [tone] = useState(toneOf)

    const slugState = useSlugStatus(details.slug, business?.slug)

    useEffect(() => {
        if (!owned || owned.launched_at) return undefined
        let cancelled = false
        loadSetup(owned.id)
            .then((data) => {
                if (cancelled) return
                setBusiness(data.business)
                setDetails(detailsFromBusiness(data.business))
                setServices(data.services.map(serviceFromRow))
                setSavedServiceIds(data.services.map((s) => s.id))
                setHourRows(data.hours)
                const loadedWeek = weekFromRows(data.hours)
                if (hasOpenDay(loadedWeek)) setWeek(loadedWeek)
                setExtras({ description: data.business.description || '', address: data.business.address || '' })
                if (data.services.length === 0) setPhase(1)
                else if (!hasOpenDay(loadedWeek)) setPhase(2)
                else setPhase(3)
            })
            .catch((err) => {
                console.error('Setup load failed:', err)
                if (!cancelled) setPhase('failed')
            })
        return () => { cancelled = true }
    }, [owned])

    useEffect(() => {
        if (typeof phase === 'number') headingRef.current?.focus({ preventScroll: true })
    }, [phase])

    const setDetail = (patch) => setDetails((d) => {
        const next = { ...d, ...patch }
        if ('business_name' in patch && !d.slugEdited) next.slug = slugFrom(patch.business_name)
        return next
    })

    const draftBusiness = useMemo(() => ({
        ...(business || {}),
        business_name: details.business_name,
        slug: details.slug,
        category: details.category,
        city: cityOf(details),
        phone: details.phone,
        whatsapp: details.whatsappSame ? details.phone : business?.whatsapp || null,
        description: extras.description,
        address: extras.address,
    }), [business, details, extras])

    const strength = useMemo(() => {
        const s = pageStrength({ business: draftBusiness, services, hours: rowsFromWeek(week) })
        const missing = []
        if (!draftBusiness.description?.trim()) missing.push('A description')
        if (!draftBusiness.address?.trim()) missing.push('Your address')
        if (!draftBusiness.whatsapp?.trim()) missing.push('Your WhatsApp')
        if (!draftBusiness.logo_url) missing.push('A logo')
        if (!draftBusiness.banner_url) missing.push('A cover photo')
        return { ...s, missing }
    }, [draftBusiness, services, week])

    const go = (next) => {
        setShowErrors(false)
        setFormError('')
        setPhase(next)
        window.scrollTo({ top: 0 })
    }

    const run = async (task) => {
        setSaving(true)
        setFormError('')
        try {
            await task()
        } catch (err) {
            console.error('Setup save failed:', err)
            const { field, message } = setupError(err)
            if (field === 'slug') {
                setShowErrors(true)
                setDetails((d) => ({ ...d, slugEdited: true }))
            }
            setFormError(message)
        } finally {
            setSaving(false)
        }
    }

    const submitDetails = () => {
        const problems = detailProblems(details, slugState)
        if (Object.keys(problems).length > 0) { setShowErrors(true); return }
        const payload = { ...details, city: cityOf(details) }
        run(async () => {
            const saved = business ? await saveDetails(business.id, payload) : await createDraft(user.id, payload)
            setBusiness(saved)
            go(1)
        })
    }

    const submitServices = () => {
        if (!servicesValid(services)) { setShowErrors(true); return }
        run(async () => {
            const saved = await saveServices(business.id, services, savedServiceIds)
            setServices(saved.map((s) => ({ ...s, key: s.key })))
            setSavedServiceIds(saved.map((s) => s.id))
            go(2)
        })
    }

    const submitHours = () => {
        if (!hasOpenDay(week) || weekProblems(week).some(Boolean)) { setShowErrors(true); return }
        run(async () => {
            setHourRows(await saveHours(business.id, week, hourRows))
            go(3)
        })
    }

    const submitLaunch = () => {
        run(async () => {
            await updateBusiness(business.id, {
                description: extras.description.trim() || null,
                address: extras.address.trim() || null,
            })
            setBusiness(await goLive(business.id))
            setPhase('live')
            window.scrollTo({ top: 0 })
        })
    }

    const pickImage = useCallback(async (shape, file) => {
        setMedia((m) => ({ ...m, [shape]: { busy: true, error: '' } }))
        try {
            const blob = await prepareImage(file, shape)
            const column = MEDIA_SHAPES[shape].column
            const url = await uploadBusinessImage(business.id, shape, blob, business[column])
            setBusiness(await updateBusiness(business.id, { [column]: url }))
            setMedia((m) => ({ ...m, [shape]: { busy: false, error: '' } }))
        } catch (err) {
            console.error('Photo upload failed:', err)
            const message = err?.message && !err.statusCode ? err.message : 'That photo did not upload. Try again.'
            setMedia((m) => ({ ...m, [shape]: { busy: false, error: message } }))
        }
    }, [business])

    const removeImage = useCallback(async (shape) => {
        const column = MEDIA_SHAPES[shape].column
        setMedia((m) => ({ ...m, [shape]: { busy: true, error: '' } }))
        try {
            await removeBusinessImage(business.id, business[column])
            setBusiness(await updateBusiness(business.id, { [column]: null }))
            setMedia((m) => ({ ...m, [shape]: { busy: false, error: '' } }))
        } catch (err) {
            console.error('Photo remove failed:', err)
            setMedia((m) => ({ ...m, [shape]: { busy: false, error: 'We could not remove that photo. Try again.' } }))
        }
    }, [business])

    const finish = async () => {
        setFinishing(true)
        await refreshProfile()
        navigate('/portal', { replace: true })
    }

    if (owned?.launched_at && phase !== 'live') return <Navigate to="/portal" replace />
    if (phase === 'loading') return <AppLoader />

    const submit = [submitDetails, submitServices, submitHours, submitLaunch][phase]
    const problems = showErrors && phase === 0 ? detailProblems(details, slugState) : {}
    const slugInfo = SLUG_STATUS[slugState]
    const preview = <PublicPageView business={draftBusiness} services={services} week={week} preview />

    return (
        <div className={`lc-setup lc-setup--${tone}${phase === 'welcome' || phase === 'live' || phase === 'failed' ? ' lc-setup--solo' : ''}`}>
            <div className="lc-setup__ambient" aria-hidden="true" />

            <div className="lc-setup__work">
                <header className="lc-setup__top">
                    <span className="lc-setup__brand"><Mark size={26} /><Wordmark /></span>
                    {typeof phase === 'number' && <div className="lc-setup__stepper"><Stepper steps={STEPS} current={phase} /></div>}
                    <span className="lc-setup__topactions">
                        {typeof phase === 'number' && !isDesktop && (
                            <Button variant="secondary" size="sm" icon={Eye} onClick={() => setPreviewOpen(true)}>Preview</Button>
                        )}
                        {phase !== 'live' && <Button variant="quiet" size="sm" to="/client">Finish later</Button>}
                    </span>
                </header>

                {phase === 'welcome' && <Welcome onStart={() => go(0)} onLater={() => navigate('/client')} />}

                {phase === 'failed' && (
                    <section className="lc-setup__welcome">
                        <h1 className="lc-setup__hero">We could not load your setup.</h1>
                        <p className="lc-setup__lede">Check your connection, then reload the page. Everything you saved is safe.</p>
                        <div className="lc-setup__welcomeactions"><Button onClick={() => window.location.reload()}>Reload</Button></div>
                    </section>
                )}

                {phase === 'live' && <LiveScreen business={business} strength={strength} onDone={finish} finishing={finishing} />}

                {typeof phase === 'number' && (
                    <form
                        className="lc-setup__form"
                        noValidate
                        onSubmit={(event) => { event.preventDefault(); submit() }}
                    >
                        <div className="lc-setup__intro">
                            <h1 ref={headingRef} tabIndex={-1} className="lc-setup__title">
                                {['Tell us about your business', 'What do you offer?', 'When can clients book?', 'Make it yours'][phase]}
                            </h1>
                            <p className="lc-setup__lede">
                                {[
                                    'This is the first thing clients see.',
                                    'Add at least one service. You can change prices and add more later.',
                                    'Set your usual week. You can change it any time.',
                                    'Photos and a few words help clients choose you. All optional.',
                                ][phase]}
                            </p>
                        </div>

                        {phase === 0 && (
                            <div className="lc-setup__fields">
                                <Field label="Business name" error={problems.business_name}>
                                    <Input
                                        value={details.business_name}
                                        onChange={(e) => setDetail({ business_name: e.target.value })}
                                        placeholder="Femtos Hair"
                                        maxLength={80}
                                        autoComplete="organization"
                                    />
                                </Field>

                                <Field
                                    label="Your web address"
                                    error={problems.slug}
                                    hint={slugInfo ? undefined : 'Letters, numbers and hyphens'}
                                >
                                    <AffixInput
                                        prefix={`${window.location.host}/`}
                                        mono
                                        value={details.slug}
                                        onChange={(e) => setDetail({ slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 60), slugEdited: true })}
                                        placeholder="femtos-hair"
                                        autoComplete="off"
                                        autoCapitalize="none"
                                        spellCheck={false}
                                    />
                                </Field>
                                <p className="lc-setup__slugstatus" aria-live="polite">
                                    {!problems.slug && slugInfo && (
                                        <>
                                            <Status tone={slugInfo.tone} size="sm">{slugInfo.word}</Status>
                                            <span>{slugInfo.text}</span>
                                        </>
                                    )}
                                </p>

                                <div className="lc-setup__pair">
                                    <Field label="Type of business" error={problems.category}>
                                        <Select value={details.category} onChange={(e) => setDetail({ category: e.target.value })}>
                                            <option value="">Choose one</option>
                                            {CATEGORIES.map((c) => <option key={c.value} value={c.value}>{c.value}</option>)}
                                        </Select>
                                    </Field>
                                    <Field label="City" error={details.cityChoice !== OTHER_CITY ? problems.city : undefined}>
                                        <Select value={details.cityChoice} onChange={(e) => setDetail({ cityChoice: e.target.value })}>
                                            {CITIES.map((c) => <option key={c.value} value={c.value}>{c.value}</option>)}
                                            <option value={OTHER_CITY}>Somewhere else</option>
                                        </Select>
                                    </Field>
                                </div>
                                {details.cityChoice === OTHER_CITY && (
                                    <Field label="Which city?" error={problems.city}>
                                        <Input value={details.cityOther} onChange={(e) => setDetail({ cityOther: e.target.value })} maxLength={80} autoComplete="address-level2" />
                                    </Field>
                                )}

                                <Field label="Business phone" error={problems.phone} hint="Shown on your page so clients can call you">
                                    <Input
                                        type="tel"
                                        inputMode="tel"
                                        value={details.phone}
                                        onChange={(e) => setDetail({ phone: e.target.value })}
                                        placeholder={cityOf(details) === 'Lagos' ? '+234 801 234 5678' : '+351 912 345 678'}
                                        autoComplete="tel"
                                    />
                                </Field>
                                <Switch
                                    checked={details.whatsappSame}
                                    onChange={(on) => setDetail({ whatsappSame: on })}
                                    label="Clients can WhatsApp this number"
                                    description="Adds a WhatsApp button to your page"
                                />
                            </div>
                        )}

                        {phase === 1 && (
                            <ServiceEditor
                                services={services}
                                onChange={setServices}
                                suggestions={suggestionsFor(details.category)}
                                showErrors={showErrors}
                            />
                        )}

                        {phase === 2 && (
                            <>
                                <HoursEditor week={week} onChange={setWeek} />
                                {showErrors && !hasOpenDay(week) && <p className="lc-setup__error" role="alert">Open at least one day so clients can book.</p>}
                            </>
                        )}

                        {phase === 3 && (
                            <div className="lc-setup__fields">
                                <div className="lc-setup__media">
                                    <ImagePicker
                                        shape="logo"
                                        label="Logo"
                                        hint="Square works best"
                                        value={business?.logo_url}
                                        fallback={<span className="lc-setup__monogram">{initials(details.business_name)}</span>}
                                        busy={media.logo.busy}
                                        error={media.logo.error}
                                        onPick={(file) => pickImage('logo', file)}
                                        onRemove={() => removeImage('logo')}
                                    />
                                    <ImagePicker
                                        shape="cover"
                                        label="Cover photo"
                                        hint="Your chair, your shop front or your best work. Wide photos work best."
                                        value={business?.banner_url}
                                        fallback={<StreetGridCover seed={details.slug} tint="azure" />}
                                        busy={media.cover.busy}
                                        error={media.cover.error}
                                        onPick={(file) => pickImage('cover', file)}
                                        onRemove={() => removeImage('cover')}
                                    />
                                </div>
                                <Field label="About you" optional hint="Two lines on what makes you worth the visit">
                                    <Textarea
                                        value={extras.description}
                                        onChange={(e) => setExtras((x) => ({ ...x, description: e.target.value }))}
                                        maxLength={500}
                                        placeholder="Skin fades and beard work in the heart of Baixa. Walk-ins welcome when the chair is free."
                                    />
                                </Field>
                                <Field label="Address" optional hint="Adds a Directions button to your page">
                                    <Input
                                        value={extras.address}
                                        onChange={(e) => setExtras((x) => ({ ...x, address: e.target.value }))}
                                        maxLength={200}
                                        autoComplete="street-address"
                                        placeholder="Rua Augusta 120"
                                    />
                                </Field>
                            </div>
                        )}

                        {formError && <p className="lc-setup__error" role="alert">{formError}</p>}

                        <footer className="lc-setup__foot">
                            {phase > 0 || !business ? (
                                <Button variant="quiet" icon={ArrowLeft} onClick={() => go(phase === 0 ? 'welcome' : phase - 1)} disabled={saving}>
                                    Back
                                </Button>
                            ) : <span />}
                            <span className="lc-setup__footright">
                                {!isDesktop && (
                                    <span className="lc-setup__footstrength" aria-hidden="true">
                                        <Ring value={strength.value} size={28} stroke={3} label="" />
                                    </span>
                                )}
                                <Button type="submit" loading={saving} iconRight={phase === 3 ? undefined : ArrowRight}>
                                    {phase === 3 ? 'Go live' : 'Continue'}
                                </Button>
                            </span>
                        </footer>
                    </form>
                )}
            </div>

            {isDesktop && typeof phase === 'number' && (
                <aside className="lc-setup__stage" aria-label="Live preview of your page">
                    <div className="lc-setup__stagehead">
                        <span className="lc-setup__stagelabel"><span className="lc-setup__pulse" aria-hidden="true" />Live preview</span>
                        <span className="lc-setup__strength">
                            <Ring value={strength.value} size={30} stroke={3.5} label={`Page ${strength.percent}% complete`} />
                            <span><strong className="lc-setup__num">{strength.percent}%</strong> page strength</span>
                        </span>
                    </div>
                    <PhoneFrame label="Your page on a phone">{preview}</PhoneFrame>
                </aside>
            )}

            <Sheet open={previewOpen && !isDesktop} onClose={() => setPreviewOpen(false)} title="Your page" wide>
                <div className="lc-setup__sheetpreview">{preview}</div>
            </Sheet>
        </div>
    )
}

export default Setup
