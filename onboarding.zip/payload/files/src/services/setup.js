import { supabase } from '../config/supabase'
import { slugProblem } from '../constants/reservedSlugs'
import { timezoneFor } from '../constants/categories'
import { rowsFromWeek } from './hours'

export const BUSINESS_FIELDS =
    'id, business_name, slug, category, city, timezone, phone, whatsapp, description, address, logo_url, banner_url, is_active, launched_at'

export const slugFrom = (name) =>
    (name || '')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '')
        .slice(0, 60)
        .replace(/-+$/g, '')

export const checkSlug = async (slug) => {
    if (slugProblem(slug)) return 'invalid'
    const { data, error } = await supabase.rpc('slug_status', { p_slug: slug })
    if (error) throw error
    return data
}

export const loadSetup = async (businessId) => {
    const [business, services, hours] = await Promise.all([
        supabase.from('businesses').select(BUSINESS_FIELDS).eq('id', businessId).single(),
        supabase.from('services')
            .select('id, service_name, duration_minutes, price, description, is_active, sort_order')
            .eq('business_id', businessId)
            .order('sort_order')
            .order('service_name'),
        supabase.from('availability')
            .select('id, staff_id, day_of_week, start_time, end_time, is_active')
            .eq('business_id', businessId),
    ])
    for (const result of [business, services, hours]) {
        if (result.error) throw result.error
    }
    return { business: business.data, services: services.data, hours: hours.data }
}

const detailsPayload = (details) => ({
    business_name: details.business_name.trim(),
    slug: details.slug,
    category: details.category,
    city: details.city.trim(),
    timezone: timezoneFor(details.city),
    phone: details.phone.trim(),
    whatsapp: details.whatsappSame ? details.phone.trim() : null,
})

export const createDraft = async (userId, details) => {
    const { data, error } = await supabase
        .from('businesses')
        .insert({ ...detailsPayload(details), user_id: userId, is_active: false })
        .select(BUSINESS_FIELDS)
        .single()
    if (error) throw error
    return data
}

export const updateBusiness = async (businessId, patch) => {
    const { data, error } = await supabase
        .from('businesses')
        .update(patch)
        .eq('id', businessId)
        .select(BUSINESS_FIELDS)
    if (error) throw error
    if (!data || data.length === 0) throw new Error('Update returned 0 rows for business ' + businessId)
    return data[0]
}

export const saveDetails = (businessId, details) => updateBusiness(businessId, detailsPayload(details))

export const serviceRow = (service, index) => ({
    service_name: service.service_name.trim(),
    duration_minutes: Number(service.duration_minutes),
    price: Number(String(service.price).replace(',', '.')),
    description: service.description?.trim() || null,
    is_active: service.is_active !== false,
    sort_order: index,
})

export const saveServices = async (businessId, services, previousIds) => {
    const keep = new Set(services.filter((s) => s.id).map((s) => s.id))
    const removed = previousIds.filter((id) => !keep.has(id))
    if (removed.length > 0) {
        const { error } = await supabase.from('services').delete().in('id', removed).eq('business_id', businessId)
        if (error) throw error
    }
    const saved = []
    for (const [index, service] of services.entries()) {
        const row = serviceRow(service, index)
        if (service.id) {
            const { data, error } = await supabase.from('services').update(row).eq('id', service.id).select('id')
            if (error) throw error
            if (!data || data.length === 0) throw new Error('Update returned 0 rows for service ' + service.id)
            saved.push({ ...service, id: service.id })
        } else {
            const { data, error } = await supabase
                .from('services')
                .insert({ ...row, business_id: businessId })
                .select('id')
                .single()
            if (error) throw error
            saved.push({ ...service, id: data.id })
        }
    }
    return saved
}

const windowKey = (row) => `${row.day_of_week}|${row.start_time.slice(0, 5)}`

export const saveHours = async (businessId, week, existingRows) => {
    const current = existingRows.filter((r) => !r.staff_id)
    const wanted = rowsFromWeek(week)
    const wantedByKey = new Map(wanted.map((r) => [windowKey(r), r]))
    const currentByKey = new Map(current.map((r) => [windowKey(r), r]))

    const removed = current.filter((r) => !wantedByKey.has(windowKey(r))).map((r) => r.id)
    if (removed.length > 0) {
        const { error } = await supabase.from('availability').delete().in('id', removed).eq('business_id', businessId)
        if (error) throw error
    }

    for (const row of wanted) {
        const existing = currentByKey.get(windowKey(row))
        if (!existing) continue
        if (existing.end_time.slice(0, 5) === row.end_time.slice(0, 5) && existing.is_active !== false) continue
        const { data, error } = await supabase
            .from('availability')
            .update({ end_time: row.end_time, is_active: true })
            .eq('id', existing.id)
            .select('id')
        if (error) throw error
        if (!data || data.length === 0) throw new Error('Update returned 0 rows for hours ' + existing.id)
    }

    const inserts = wanted
        .filter((r) => !currentByKey.has(windowKey(r)))
        .map((r) => ({ ...r, business_id: businessId, staff_id: null, is_active: true }))
    if (inserts.length > 0) {
        const { error } = await supabase.from('availability').insert(inserts)
        if (error) throw error
    }

    const { data, error } = await supabase
        .from('availability')
        .select('id, staff_id, day_of_week, start_time, end_time, is_active')
        .eq('business_id', businessId)
    if (error) throw error
    return data
}

export const goLive = (businessId) => updateBusiness(businessId, { is_active: true })

export const setupError = (error) => {
    if (error?.code === '23505' && /slug/.test(error.message || '')) return { field: 'slug', message: 'Someone just took that address. Try another.' }
    if (error?.code === '23505' && /one_per_owner/.test(error.message || '')) return { message: 'This account already has a business.' }
    if (error?.code === '23514' && /slug/.test(error.message || '')) return { field: 'slug', message: 'That address is not allowed. Try another.' }
    if (error?.code === '22023') return { message: error.message }
    return { message: 'Something went wrong. Check your connection and try again.' }
}
