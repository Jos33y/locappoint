import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const SPEC = {
  "name": "cities",
  "backup": ".backup-cities",
  "prefixes": [],
  "newFiles": [
    "tests/suites/cities.mjs"
  ],
  "replaceFiles": [],
  "patches": [
    {
      "file": "server/seo.mjs",
      "find": "title: 'Locappoint: book local businesses in Lisbon, Porto and Lagos',",
      "replace": "title: 'Locappoint: book local businesses in Porto, Lisbon and Lagos',"
    },
    {
      "file": "server/seo.mjs",
      "find": "title: 'Book local businesses in Lisbon, Porto and Lagos | Locappoint'",
      "replace": "title: 'Book local businesses in Porto, Lisbon and Lagos | Locappoint'"
    },
    {
      "file": "server/seo.mjs",
      "find": "work with in Lisbon, Porto and Lagos.' },",
      "replace": "work with in Porto, Lisbon and Lagos.' },"
    },
    {
      "file": "tests/suites/seo.mjs",
      "find": "<title>Locappoint: book local businesses in Lisbon, Porto and Lagos<\\/title>",
      "replace": "<title>Locappoint: book local businesses in Porto, Lisbon and Lagos<\\/title>"
    },
    {
      "file": "index.html",
      "find": "helps local businesses in Lisbon, Porto, and Lagos get discovered and get booked. Stop",
      "replace": "helps local businesses in Porto, Lisbon, and Lagos get discovered and get booked. Stop"
    },
    {
      "file": "index.html",
      "find": "Portugal, Nigeria, Lisbon, Porto, Lagos, SME",
      "replace": "Portugal, Nigeria, Porto, Lisbon, Lagos, SME"
    },
    {
      "file": "index.html",
      "find": "\"description\": \"Locappoint helps local businesses in Lisbon, Porto, and Lagos get discovered and get booked.\"",
      "replace": "\"description\": \"Locappoint helps local businesses in Porto, Lisbon, and Lagos get discovered and get booked.\""
    },
    {
      "file": "public/site.webmanifest",
      "find": "for local businesses in Lisbon, Porto, and Lagos.",
      "replace": "for local businesses in Porto, Lisbon, and Lagos."
    },
    {
      "file": "supabase/functions/notify/format.ts",
      "find": "['LocAppoint, Lisbon, Porto and Lagos',",
      "replace": "['LocAppoint, Porto, Lisbon and Lagos',"
    },
    {
      "file": "supabase/functions/notify/layout.ts",
      "find": "Lisbon &middot; Porto &middot; Lagos",
      "replace": "Porto &middot; Lisbon &middot; Lagos"
    },
    {
      "file": "supabase/email-templates/change-email.html",
      "find": "Lisbon &middot; Porto &middot; Lagos",
      "replace": "Porto &middot; Lisbon &middot; Lagos"
    },
    {
      "file": "supabase/templates/auth/change-email.html",
      "find": "local businesses in Lisbon, Porto and Lagos.",
      "replace": "local businesses in Porto, Lisbon and Lagos."
    },
    {
      "file": "supabase/email-templates/confirm-signup.html",
      "find": "Lisbon &middot; Porto &middot; Lagos",
      "replace": "Porto &middot; Lisbon &middot; Lagos"
    },
    {
      "file": "supabase/templates/auth/confirm-signup.html",
      "find": "local businesses in Lisbon, Porto and Lagos.",
      "replace": "local businesses in Porto, Lisbon and Lagos."
    },
    {
      "file": "supabase/email-templates/magic-link.html",
      "find": "Lisbon &middot; Porto &middot; Lagos",
      "replace": "Porto &middot; Lisbon &middot; Lagos"
    },
    {
      "file": "supabase/templates/auth/magic-link.html",
      "find": "local businesses in Lisbon, Porto and Lagos.",
      "replace": "local businesses in Porto, Lisbon and Lagos."
    },
    {
      "file": "supabase/email-templates/password-changed.html",
      "find": "Lisbon &middot; Porto &middot; Lagos",
      "replace": "Porto &middot; Lisbon &middot; Lagos"
    },
    {
      "file": "supabase/templates/auth/password-changed.html",
      "find": "local businesses in Lisbon, Porto and Lagos.",
      "replace": "local businesses in Porto, Lisbon and Lagos."
    },
    {
      "file": "supabase/email-templates/reset-password.html",
      "find": "Lisbon &middot; Porto &middot; Lagos",
      "replace": "Porto &middot; Lisbon &middot; Lagos"
    },
    {
      "file": "supabase/templates/auth/reset-password.html",
      "find": "local businesses in Lisbon, Porto and Lagos.",
      "replace": "local businesses in Porto, Lisbon and Lagos."
    },
    {
      "file": "src/components/Footer.jsx",
      "find": "Built for Lisbon, then Porto and Lagos.')",
      "replace": "Built for Porto, then Lisbon and Lagos.')"
    },
    {
      "file": "src/components/Footer.jsx",
      "find": "                            <span>LISBON</span>\n                            <span className=\"footer__cities-dot\" />\n                            <span>PORTO</span>",
      "replace": "                            <span>PORTO</span>\n                            <span className=\"footer__cities-dot\" />\n                            <span>LISBON</span>"
    },
    {
      "file": "src/components/common/Appfooter.jsx",
      "find": "for local businesses in Lisbon, Porto, and Lagos. Twelve",
      "replace": "for local businesses in Porto, Lisbon, and Lagos. Twelve"
    },
    {
      "file": "src/components/common/Appfooter.jsx",
      "find": "loca-app-footer__cities\">Lisbon \u00b7 Porto \u00b7 Lagos<",
      "replace": "loca-app-footer__cities\">Porto \u00b7 Lisbon \u00b7 Lagos<"
    },
    {
      "file": "src/components/common/Appfooter.jsx",
      "find": "<li><span>Lisbon, Portugal</span></li>",
      "replace": "<li><span>Porto, Portugal</span></li>"
    },
    {
      "file": "src/i18n.js",
      "find": "location: 'Lisbon, Portugal',",
      "replace": "location: 'Porto, Portugal',"
    },
    {
      "file": "src/i18n.js",
      "find": "location: 'Lisboa, Portugal',",
      "replace": "location: 'Porto, Portugal',"
    },
    {
      "file": "src/pages/app/auth/AuthPage.jsx",
      "find": "['Be one of the first ten in Lisbon',",
      "replace": "['Be one of the first ten in Porto',"
    },
    {
      "file": "src/pages/app/auth/AuthPage.jsx",
      "find": "'Local businesses in Lisbon, Porto, and Lagos. Free",
      "replace": "'Local businesses in Porto, Lisbon, and Lagos. Free"
    },
    {
      "file": "src/pages/app/auth/AuthShell.jsx",
      "find": "brandSub = 'Local businesses in Lisbon, Porto, and Lagos.",
      "replace": "brandSub = 'Local businesses in Porto, Lisbon, and Lagos."
    },
    {
      "file": "src/pages/app/auth/AuthShell.jsx",
      "find": "auth-brand__tick--tl\">38.74\u00b0 N</span>",
      "replace": "auth-brand__tick--tl\">41.16\u00b0 N</span>"
    },
    {
      "file": "src/pages/app/auth/AuthShell.jsx",
      "find": "auth-brand__tick--tr\">9.13\u00b0 W</span>",
      "replace": "auth-brand__tick--tr\">8.63\u00b0 W</span>"
    },
    {
      "file": "src/pages/app/auth/AuthShell.jsx",
      "find": "auth-brand__coords-geo\">38.7223\u00b0 N \u00b7 9.1393\u00b0 W</span>",
      "replace": "auth-brand__coords-geo\">41.1579\u00b0 N \u00b7 8.6291\u00b0 W</span>"
    },
    {
      "file": "src/pages/app/auth/AuthShell.jsx",
      "find": "auth-brand__coords-place\">Lisbon</span>",
      "replace": "auth-brand__coords-place\">Porto</span>"
    },
    {
      "file": "src/pages/app/auth/AuthShell.jsx",
      "find": "auth-brand__cohort-label\">Cohort 1 in Lisbon</span>",
      "replace": "auth-brand__cohort-label\">Cohort 1 in Porto</span>"
    },
    {
      "file": "src/pages/app/auth/AuthShell.jsx",
      "find": "auth-brand__city-dot--live\"></span>\n                        Lisbon\n                    </span>",
      "replace": "auth-brand__city-dot--live\"></span>\n                        Porto\n                    </span>"
    },
    {
      "file": "src/pages/app/auth/AuthShell.jsx",
      "find": "                        Porto next",
      "replace": "                        Lisbon next"
    },
    {
      "file": "src/pages/app/auth/AuthShell.jsx",
      "find": "businesses onboarded in Lisbon</span>",
      "replace": "businesses onboarded in Porto</span>"
    },
    {
      "file": "src/pages/app/home/Hero.jsx",
      "find": "Beta \u00b7 Lisbon first",
      "replace": "Beta \u00b7 Porto first"
    },
    {
      "file": "src/pages/app/home/Hero.jsx",
      "find": "for local businesses in Lisbon, Porto, and Lagos. Set your hours",
      "replace": "for local businesses in Porto, Lisbon, and Lagos. Set your hours"
    },
    {
      "file": "src/pages/app/home/Cta.jsx",
      "find": "// Cohort progress. Update as Vincent closes Lisbon SMEs.",
      "replace": "// Cohort progress. Update as Vincent closes Porto SMEs."
    },
    {
      "file": "src/pages/app/home/Cta.jsx",
      "find": "                        <span className=\"cta__city-name\">Lisbon</span>\n                        <span className=\"cta__city-note\">Onboarding cohort 1</span>",
      "replace": "                        <span className=\"cta__city-name\">Porto</span>\n                        <span className=\"cta__city-note\">Onboarding cohort 1</span>"
    },
    {
      "file": "src/pages/app/home/Cta.jsx",
      "find": "                        <span className=\"cta__city-name\">Porto</span>\n                        <span className=\"cta__city-note\">After 10 Lisbon businesses live</span>",
      "replace": "                        <span className=\"cta__city-name\">Lisbon</span>\n                        <span className=\"cta__city-note\">After 10 Porto businesses live</span>"
    },
    {
      "file": "src/pages/app/home/Cta.jsx",
      "find": "<span className=\"cta__city-note\">Q4 2026</span>",
      "replace": "<span className=\"cta__city-note\">After Lisbon</span>"
    },
    {
      "file": "src/pages/app/home/Cta.jsx",
      "find": "first ten</span> in Lisbon.",
      "replace": "first ten</span> in Porto."
    },
    {
      "file": "src/pages/app/home/Cta.jsx",
      "find": "cta__cohort-label\">Cohort 1 \u00b7 Lisbon</span>",
      "replace": "cta__cohort-label\">Cohort 1 \u00b7 Porto</span>"
    },
    {
      "file": "src/pages/app/Businesses.jsx",
      "find": "    { name: 'Lisbon', match: ['lisbon', 'lisboa'], later: 'First up' },\n    { name: 'Porto', match: ['porto', 'oporto'], later: 'Next' },",
      "replace": "    { name: 'Porto', match: ['porto', 'oporto'], later: 'First up' },\n    { name: 'Lisbon', match: ['lisbon', 'lisboa'], later: 'Next' },"
    },
    {
      "file": "src/pages/app/Businesses.jsx",
      "find": "    const lisbon = counts[0]\n    const cohortOpen = lisbon < COHORT_SIZE",
      "replace": "    const first = counts[0]\n    const cohortOpen = first < COHORT_SIZE"
    },
    {
      "file": "src/pages/app/Businesses.jsx",
      "find": "lc-br-hero__kicker\">Lisbon, first cohort</p>\n                        <h1 className=\"lc-br-hero__title\">Book Lisbon's first businesses on Locappoint.</h1>",
      "replace": "lc-br-hero__kicker\">Porto, first cohort</p>\n                        <h1 className=\"lc-br-hero__title\">Book Porto's first businesses on Locappoint.</h1>"
    },
    {
      "file": "src/pages/app/Businesses.jsx",
      "find": "A first group of ten Lisbon businesses taking",
      "replace": "A first group of ten Porto businesses taking"
    },
    {
      "file": "src/pages/app/Businesses.jsx",
      "find": "<b>{lisbon}</b>",
      "replace": "<b>{first}</b>"
    },
    {
      "file": "src/pages/app/Businesses.jsx",
      "find": "                                        ? `${lisbon === 1 ? 'place' : 'places'} taking bookings in Lisbon`\n                                        : 'places taking bookings in Lisbon. The first cohort is full.'}",
      "replace": "                                        ? `${first === 1 ? 'place' : 'places'} taking bookings in Porto`\n                                        : 'places taking bookings in Porto. The first cohort is full.'}"
    },
    {
      "file": "src/pages/app/Businesses.jsx",
      "find": "<CohortSlots filled={lisbon} />",
      "replace": "<CohortSlots filled={first} />"
    },
    {
      "file": "src/pages/app/Businesses.jsx",
      "find": "<h2>Run a business in Lisbon?</h2>",
      "replace": "<h2>Run a business in Porto?</h2>"
    },
    {
      "file": "src/pages/app/Contact.jsx",
      "find": "info-card__value\">Lisbon, Portugal</div>",
      "replace": "info-card__value\">Porto, Portugal</div>"
    },
    {
      "file": "src/pages/app/Contact.jsx",
      "find": "<span>Cohort 1 open in Lisbon</span>",
      "replace": "<span>Cohort 1 open in Porto</span>"
    },
    {
      "file": "src/constants/support.js",
      "find": "09:00 to 18:00 Lisbon time',",
      "replace": "09:00 to 18:00 Portugal time',"
    },
    {
      "file": "src/pages/business/Help.jsx",
      "find": "`${status.text} Lisbon time. Tickets",
      "replace": "`${status.text} Portugal time. Tickets"
    },
    {
      "file": "src/pages/business/Help.jsx",
      "find": "'Back')} Lisbon time. Leave",
      "replace": "'Back')} Portugal time. Leave"
    },
    {
      "file": "src/pages/app/legal/Ranking.jsx",
      "find": "shows our first Lisbon cohort,",
      "replace": "shows our first Porto cohort,"
    },
    {
      "file": "src/pages/app/legal/Terms.jsx",
      "find": "in our launch cities (Lisbon, Porto, Lagos).",
      "replace": "in our launch cities (Porto, Lisbon, Lagos)."
    },
    {
      "file": "src/pages/client/Search.jsx",
      "find": "body=\"Businesses in Lisbon are setting up",
      "replace": "body=\"Businesses in Porto are setting up"
    },
    {
      "file": "src/pages/business/Setup.jsx",
      "find": "    country: 'PT',\n    city: 'Lisbon',",
      "replace": "    country: 'PT',\n    city: 'Porto',"
    },
    {
      "file": "src/pages/business/Setup.jsx",
      "find": "city: country === 'PT' ? 'Lisbon' : country === 'NG' ? 'Lagos' : '',",
      "replace": "city: country === 'PT' ? 'Porto' : country === 'NG' ? 'Lagos' : '',"
    },
    {
      "file": "src/pages/business/Setup.jsx",
      "find": "We are opening in Greater Lisbon first.",
      "replace": "We are opening in Porto and Lisbon first."
    },
    {
      "file": "src/pages/business/BusinessPage.jsx",
      "find": "city: country === 'PT' ? 'Lisbon' : country === 'NG' ? 'Lagos' : '', cityOther: ''",
      "replace": "city: country === 'PT' ? 'Porto' : country === 'NG' ? 'Lagos' : '', cityOther: ''"
    },
    {
      "file": "src/pages/business/BusinessPage.jsx",
      "find": "We are opening in Greater Lisbon first.",
      "replace": "We are opening in Porto and Lisbon first."
    },
    {
      "file": "src/constants/locations.js",
      "find": "export const PT_GROUPS = [\"Greater Lisbon\", \"Greater Porto\",",
      "replace": "export const PT_GROUPS = [\"Greater Porto\", \"Greater Lisbon\","
    },
    {
      "file": "src/constants/locations.js",
      "find": "export const GREATER_LISBON = new Set(PT_MUNICIPALITIES.filter((c) => c.group === 'Greater Lisbon').map((c) => c.value))",
      "replace": "export const GREATER_PORTO = new Set(PT_MUNICIPALITIES.filter((c) => c.group === 'Greater Porto').map((c) => c.value))\nexport const GREATER_LISBON = new Set(PT_MUNICIPALITIES.filter((c) => c.group === 'Greater Lisbon').map((c) => c.value))"
    },
    {
      "file": "src/constants/locations.js",
      "find": "export const inLaunchArea = (country, city) => country === 'PT' && GREATER_LISBON.has(city)",
      "replace": "export const inLaunchArea = (country, city) => country === 'PT' && (GREATER_PORTO.has(city) || GREATER_LISBON.has(city))"
    },
    {
      "file": "src/StatusApp.jsx",
      "find": "<span className=\"azure\">Lisbon beta.</span>",
      "replace": "<span className=\"azure\">Porto beta.</span>"
    },
    {
      "file": "src/StatusApp.jsx",
      "find": "What Lisbon and Porto launch with.",
      "replace": "What Porto and Lisbon launch with."
    },
    {
      "file": "src/StatusApp.jsx",
      "find": "First five businesses live in Lisbon</div>",
      "replace": "First five businesses live in Porto</div>"
    },
    {
      "file": "src/StatusApp.jsx",
      "find": "Lisbon first, Porto next, Lagos third.",
      "replace": "Porto first, Lisbon next, Lagos third."
    },
    {
      "file": "src/StatusApp.jsx",
      "find": "<div className=\"city__name\">Lisbon</div>",
      "replace": "<div className=\"city__name\">__FIRST__</div>"
    },
    {
      "file": "src/StatusApp.jsx",
      "find": "<div className=\"city__name\">Porto</div>",
      "replace": "<div className=\"city__name\">Lisbon</div>"
    },
    {
      "file": "src/StatusApp.jsx",
      "find": "<div className=\"city__name\">__FIRST__</div>",
      "replace": "<div className=\"city__name\">Porto</div>"
    },
    {
      "file": "src/StatusApp.jsx",
      "find": "Opens once Lisbon has ten businesses live.",
      "replace": "Opens once Porto has ten businesses live."
    },
    {
      "file": "src/StatusApp.jsx",
      "find": "Opens once Porto settles. Joseey",
      "replace": "Opens once Lisbon settles. Joseey"
    },
    {
      "file": "src/StatusApp.jsx",
      "find": "need__title\">Five Lisbon owners</div>",
      "replace": "need__title\">Five Porto owners</div>"
    },
    {
      "file": "src/pages/app/Partnership.jsx",
      "find": "placeholder=\"Lisbon, Porto, Lagos...\"",
      "replace": "placeholder=\"Porto, Lisbon, Lagos...\""
    },
    {
      "file": "src/components/landing/PartnershipModal.jsx",
      "find": "t('partnershipModal.cityPlaceholder', 'Lisbon')",
      "replace": "t('partnershipModal.cityPlaceholder', 'Porto')"
    },
    {
      "file": "src/contexts/LandingTranslationContext.jsx",
      "find": "            location: 'Lisbon, PT',",
      "replace": "            location: 'Porto, PT',"
    },
    {
      "file": "src/contexts/LandingTranslationContext.jsx",
      "find": "cityPlaceholder: 'Lisbon, Porto, Lagos...',",
      "replace": "cityPlaceholder: 'Porto, Lisbon, Lagos...',"
    },
    {
      "file": "src/contexts/LandingTranslationContext.jsx",
      "find": "            location: 'Lisboa, PT',",
      "replace": "            location: 'Porto, PT',"
    },
    {
      "file": "src/contexts/LandingTranslationContext.jsx",
      "find": "cityPlaceholder: 'Lisboa, Porto, Faro...',",
      "replace": "cityPlaceholder: 'Porto, Lisboa, Faro...',"
    },
    {
      "file": "src/pages/landing/HeroDashboard.jsx",
      "find": "t('heroDashboard.location', 'Lisbon, PT')",
      "replace": "t('heroDashboard.location', 'Porto, PT')"
    },
    {
      "file": "src/pages/landing/FounderNote.jsx",
      "find": "CEO, FlowleXx Group \\u00B7 Lisbon')",
      "replace": "CEO, FlowleXx Group \\u00B7 Porto')"
    },
    {
      "file": "src/pages/landing/Faq.jsx",
      "find": "'We are launching in Lisbon first. Porto follows once we have 10 Lisbon businesses live. Lagos comes third.",
      "replace": "'We are launching in Porto first. Lisbon follows once we have 10 Porto businesses live. Lagos comes third."
    },
    {
      "file": "src/pages/landing/Faq.jsx",
      "find": "'The first 100 businesses in Lisbon get 12 months free.",
      "replace": "'The first 100 businesses in Porto get 12 months free."
    },
    {
      "file": "src/components/landing/WaitlistModal.jsx",
      "find": "the moment Lisbon launches.",
      "replace": "the moment Porto launches."
    },
    {
      "file": "src/components/landing/WaitlistModal.jsx",
      "find": "'First 100 Lisbon businesses get 12 months free,",
      "replace": "'First 100 Porto businesses get 12 months free,"
    },
    {
      "file": "src/pages/landing/WaitlistCTASection.jsx",
      "find": "'Free for 12 months for first 100 Lisbon businesses'",
      "replace": "'Free for 12 months for first 100 Porto businesses'"
    },
    {
      "file": "tests/run.mjs",
      "find": "import brand from './suites/brand.mjs'\n",
      "replace": "import brand from './suites/brand.mjs'\nimport cities from './suites/cities.mjs'\n"
    },
    {
      "file": "tests/run.mjs",
      "find": "['brand', brand]] }",
      "replace": "['brand', brand], ['cities', cities]] }"
    }
  ],
  "retires": []
}

const here = path.dirname(fileURLToPath(import.meta.url))
const root = process.cwd()
const check = process.argv.includes('--check')
const problems = []
const plan = []

const abs = (rel) => path.join(root, ...rel.split('/'))
const source = (rel) => path.join(here, 'files', ...rel.split('/'))
const read = (p) => fs.readFileSync(p, 'utf8')
const eolOf = (text) => (text.includes('\r\n') ? '\r\n' : '\n')
const toEol = (text, eol) => text.replace(/\r\n/g, '\n').replace(/\n/g, eol)
const sha = (text) => crypto.createHash('sha256').update(text.replace(/\r\n/g, '\n')).digest('hex')
const count = (hay, needle) => (needle ? hay.split(needle).length - 1 : 0)

const pkg = JSON.parse(read(abs('package.json')))
if (pkg.name !== 'locappoint') {
    console.error('  [ABORT] This is not the locappoint repo.')
    process.exit(1)
}

for (const rel of SPEC.newFiles) {
    if (fs.existsSync(abs(rel))) problems.push(`${rel} already exists (patch already applied?)`)
    else if (!fs.existsSync(source(rel))) problems.push(`payload is missing ${rel}`)
    else plan.push(['NEW', rel])
}

for (const { file, sha: expected } of SPEC.replaceFiles) {
    if (!fs.existsSync(abs(file))) { problems.push(`${file} is missing`); continue }
    if (sha(read(abs(file))) !== expected) { problems.push(`${file} changed since this patch was built (or it is already applied)`); continue }
    plan.push(['REPLACE', file])
}

const srcFiles = () => {
    const out = []
    const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const full = path.join(dir, entry.name)
            if (entry.isDirectory()) { if (entry.name !== 'node_modules') walk(full) }
            else if (/\.(jsx?|css)$/.test(entry.name)) out.push(full)
        }
    }
    walk(abs('src'))
    return out
}

for (const prefix of SPEC.prefixes || []) {
    const owners = srcFiles().filter((full) => read(full).includes(prefix)).map((full) => path.relative(root, full))
    if (owners.length) problems.push(`class prefix ${prefix} is already used in ${owners.join(', ')}`)
}

const edits = new Map()
for (const p of SPEC.patches) {
    if (!fs.existsSync(abs(p.file))) { problems.push(`${p.file} is missing`); continue }
    if (!edits.has(p.file)) edits.set(p.file, read(abs(p.file)))
    const current = edits.get(p.file)
    const eol = eolOf(current)
    const find = toEol(p.find, eol)
    const hits = count(current, find)
    if (hits !== 1) { problems.push(`${p.file}: anchor matched ${hits} times, expected 1: ${JSON.stringify(p.find.slice(0, 60))}`); continue }
    edits.set(p.file, current.replace(find, () => toEol(p.replace, eol)))
}
for (const file of edits.keys()) plan.push(['EDIT', file])

for (const rel of SPEC.retires) {
    if (!fs.existsSync(abs(rel))) { problems.push(`${rel} is missing`); continue }
    const base = path.basename(rel)
    const stem = /\.(jsx?)$/.test(base) ? base.replace(/\.(jsx?)$/, '') : base
    const pattern = new RegExp(`[\\/'"]${stem.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\.jsx?)?['"]`)
    const planned = (full) => {
        const key = path.relative(root, full).split(path.sep).join('/')
        if (SPEC.replaceFiles.some((f) => f.file === key)) return read(source(key))
        return edits.has(key) ? edits.get(key) : read(full)
    }
    const users = srcFiles().filter((full) => full !== abs(rel) && pattern.test(planned(full))).map((full) => path.relative(root, full))
    if (users.length) problems.push(`${rel} is still imported by ${users.join(', ')}`)
    else plan.push(['RETIRE', rel])
}

if (problems.length) {
    console.error('  [ABORT] Nothing was written:')
    for (const p of problems) console.error(`    ${p}`)
    process.exit(1)
}

if (check) {
    for (const [kind, rel] of plan) console.log(`  [${kind}] ${rel}`)
    console.log('  Checks passed.')
    process.exit(0)
}

for (const [kind, rel] of plan) {
    const target = abs(rel)
    if (kind === 'NEW') {
        fs.mkdirSync(path.dirname(target), { recursive: true })
        fs.copyFileSync(source(rel), target)
    } else if (kind === 'REPLACE') {
        const eol = eolOf(read(target))
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, toEol(read(source(rel)), eol))
    } else if (kind === 'EDIT') {
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, edits.get(rel))
    } else if (kind === 'RETIRE') {
        fs.renameSync(target, target + '.mistake')
    }
    console.log(`  [${kind}] ${rel}`)
}
console.log('  Patch applied.')
