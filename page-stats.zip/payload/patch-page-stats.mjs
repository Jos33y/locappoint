import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const SPEC = {
  "name": "page-stats",
  "backup": ".backup-stats",
  "prefixes": [],
  "newFiles": [
    "src/services/pageStats.js",
    "supabase/migrations/page-stats.sql",
    "supabase/migrations/drop-old-notifications.sql",
    "supabase/queries/page-stats-verify.sql"
  ],
  "replaceFiles": [],
  "patches": [
    {
      "file": "src/pages/app/PublicBusinessPage.jsx",
      "find": "import { clearPending, readBookParam, readPending } from '../../services/booking'\n",
      "replace": "import { clearPending, readBookParam, readPending } from '../../services/booking'\nimport { trackPage, visitSource } from '../../services/pageStats'\n"
    },
    {
      "file": "src/pages/app/PublicBusinessPage.jsx",
      "find": "    const owner = state.status === 'ready' && Boolean(ownBusiness?.id) && ownBusiness.id === state.business.id\n",
      "replace": "    const owner = state.status === 'ready' && Boolean(ownBusiness?.id) && ownBusiness.id === state.business.id\n\n    const visitedId = state.status === 'ready' && !owner ? state.business.id : null\n    const cameFromApp = Boolean(location.state?.from)\n    useEffect(() => {\n        if (visitedId) trackPage(visitedId, 'view', visitSource({ search: location.search, cameFromApp }))\n    }, [visitedId, location.search, cameFromApp])\n"
    },
    {
      "file": "src/components/booking/BookingSheet.jsx",
      "find": "import { USER_ERRORS,",
      "replace": "import { trackPage } from '../../services/pageStats'\nimport { USER_ERRORS,"
    },
    {
      "file": "src/components/booking/BookingSheet.jsx",
      "find": "    const day = days.find((d) => d.key === dayKey) || days[0]\n    const entry = busy[dayKey]\n",
      "replace": "    const day = days.find((d) => d.key === dayKey) || days[0]\n    const entry = busy[dayKey]\n\n    const counts = !move && !owner\n    useEffect(() => {\n        if (counts) trackPage(business.id, 'start')\n    }, [counts, business.id])\n    useEffect(() => {\n        if (counts && step === 'review') trackPage(business.id, 'time')\n    }, [counts, step, business.id])\n"
    },
    {
      "file": "src/services/links.js",
      "find": "export const pageUrl = (slug) => `${publicOrigin()}/${slug}`",
      "replace": "// src tells Insights where a visit came from, for apps that hide the referrer (WhatsApp, QR codes).\nexport const pageUrl = (slug, src) => `${publicOrigin()}/${slug}${src ? `?src=${src}` : ''}`"
    },
    {
      "file": "src/components/business/ShareLink.jsx",
      "find": "href={`https://wa.me/?text=${encodeURIComponent(`Book with ${business.business_name}: ${link}`)}`}",
      "replace": "href={`https://wa.me/?text=${encodeURIComponent(`Book with ${business.business_name}: ${pageUrl(business.slug, 'wa')}`)}`}"
    },
    {
      "file": "src/pages/app/Businesses.jsx",
      "find": "Pick a place, choose a time and send your request in under a minute.",
      "replace": "Pick a place, choose a time and you are booked in under a minute."
    }
  ],
  "retires": []
}

const here = path.dirname(fileURLToPath(import.meta.url))
const root = process.cwd()
const check = process.argv.includes('--check')
const problems = []
const plan = []

const abs = (rel) => path.join(root, ...rel.split('/'))
const source = (rel) => path.join(here, 'files', ...rel.split('/'))
const read = (p) => fs.readFileSync(p, 'utf8')
const eolOf = (text) => (text.includes('\r\n') ? '\r\n' : '\n')
const toEol = (text, eol) => text.replace(/\r\n/g, '\n').replace(/\n/g, eol)
const sha = (text) => crypto.createHash('sha256').update(text.replace(/\r\n/g, '\n')).digest('hex')
const count = (hay, needle) => (needle ? hay.split(needle).length - 1 : 0)

const pkg = JSON.parse(read(abs('package.json')))
if (pkg.name !== 'locappoint') {
    console.error('  [ABORT] This is not the locappoint repo.')
    process.exit(1)
}

for (const rel of SPEC.newFiles) {
    if (fs.existsSync(abs(rel))) problems.push(`${rel} already exists (patch already applied?)`)
    else if (!fs.existsSync(source(rel))) problems.push(`payload is missing ${rel}`)
    else plan.push(['NEW', rel])
}

for (const { file, sha: expected } of SPEC.replaceFiles) {
    if (!fs.existsSync(abs(file))) { problems.push(`${file} is missing`); continue }
    if (sha(read(abs(file))) !== expected) { problems.push(`${file} changed since this patch was built (or it is already applied)`); continue }
    plan.push(['REPLACE', file])
}

const srcFiles = () => {
    const out = []
    const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const full = path.join(dir, entry.name)
            if (entry.isDirectory()) { if (entry.name !== 'node_modules') walk(full) }
            else if (/\.(jsx?|css)$/.test(entry.name)) out.push(full)
        }
    }
    walk(abs('src'))
    return out
}

for (const prefix of SPEC.prefixes || []) {
    const owners = srcFiles().filter((full) => read(full).includes(prefix)).map((full) => path.relative(root, full))
    if (owners.length) problems.push(`class prefix ${prefix} is already used in ${owners.join(', ')}`)
}

const edits = new Map()
for (const p of SPEC.patches) {
    if (!fs.existsSync(abs(p.file))) { problems.push(`${p.file} is missing`); continue }
    if (!edits.has(p.file)) edits.set(p.file, read(abs(p.file)))
    const current = edits.get(p.file)
    const eol = eolOf(current)
    const find = toEol(p.find, eol)
    const hits = count(current, find)
    if (hits !== 1) { problems.push(`${p.file}: anchor matched ${hits} times, expected 1: ${JSON.stringify(p.find.slice(0, 60))}`); continue }
    edits.set(p.file, current.replace(find, () => toEol(p.replace, eol)))
}
for (const file of edits.keys()) plan.push(['EDIT', file])

for (const rel of SPEC.retires) {
    if (!fs.existsSync(abs(rel))) { problems.push(`${rel} is missing`); continue }
    const base = path.basename(rel)
    const stem = /\.(jsx?)$/.test(base) ? base.replace(/\.(jsx?)$/, '') : base
    const pattern = new RegExp(`[\\/'"]${stem.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\.jsx?)?['"]`)
    const planned = (full) => {
        const key = path.relative(root, full).split(path.sep).join('/')
        if (SPEC.replaceFiles.some((f) => f.file === key)) return read(source(key))
        return edits.has(key) ? edits.get(key) : read(full)
    }
    const users = srcFiles().filter((full) => full !== abs(rel) && pattern.test(planned(full))).map((full) => path.relative(root, full))
    if (users.length) problems.push(`${rel} is still imported by ${users.join(', ')}`)
    else plan.push(['RETIRE', rel])
}

if (problems.length) {
    console.error('  [ABORT] Nothing was written:')
    for (const p of problems) console.error(`    ${p}`)
    process.exit(1)
}

if (check) {
    for (const [kind, rel] of plan) console.log(`  [${kind}] ${rel}`)
    console.log('  Checks passed.')
    process.exit(0)
}

for (const [kind, rel] of plan) {
    const target = abs(rel)
    if (kind === 'NEW') {
        fs.mkdirSync(path.dirname(target), { recursive: true })
        fs.writeFileSync(target, read(source(rel)))
    } else if (kind === 'REPLACE') {
        const eol = eolOf(read(target))
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, toEol(read(source(rel)), eol))
    } else if (kind === 'EDIT') {
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, edits.get(rel))
    } else if (kind === 'RETIRE') {
        fs.renameSync(target, target + '.mistake')
    }
    console.log(`  [${kind}] ${rel}`)
}
console.log('  Patch applied.')
