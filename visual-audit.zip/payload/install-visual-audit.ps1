$ErrorActionPreference = 'Stop'

Write-Host ""
Write-Host "  Locappoint - Visual audit fixes" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path 'package.json')) { Write-Host "  [ABORT] No package.json. Run from repo root." -ForegroundColor Red; exit 1 }
$pkg = Get-Content 'package.json' -Raw | ConvertFrom-Json
if ($pkg.name -ne 'locappoint') { Write-Host "  [ABORT] Wrong package: $($pkg.name)" -ForegroundColor Red; exit 1 }
try { $null = & node --version } catch { Write-Host "  [ABORT] Node.js not found." -ForegroundColor Red; exit 1 }

Write-Host "  Applies on top of audit-polish (already installed)." -ForegroundColor Magenta
Write-Host ""
Write-Host "    [EDIT]  foundation.css  (softer primary lift, brand scrollbars, selection colour)" -ForegroundColor Yellow
Write-Host "    [EDIT]  palette.css  (visible highlight in the command bar)" -ForegroundColor Yellow
Write-Host "    [EDIT]  ui.css  (list cards: rows sit together)" -ForegroundColor Yellow
Write-Host ""

$confirm = Read-Host "  Apply? (y/n)"
if ($confirm -ne 'y' -and $confirm -ne 'Y') { Write-Host "  [CANCELLED]" -ForegroundColor Yellow; exit 0 }
Write-Host ""

& node (Join-Path $PSScriptRoot 'patch-visual-audit.mjs')
if ($LASTEXITCODE -ne 0) { Write-Host "  [FAIL] Exit code $LASTEXITCODE" -ForegroundColor Red; exit $LASTEXITCODE }

$payloadDir = $PSScriptRoot
if ((Split-Path $payloadDir -Leaf) -eq 'payload') {
    Set-Location (Split-Path $payloadDir -Parent)
    Remove-Item $payloadDir -Recurse -Force
}

Write-Host ""
Write-Host "  Done. npm run build." -ForegroundColor Green
Write-Host ""
