import fs from 'fs'
import path from 'path'

const REPO = process.cwd()

const NEW_FILES = []

const PATCHES = [
    {
        file: 'src/styles/foundation.css',
        edits: [
            { desc: "Primary lift without a halo", find: `    --lc-shadow-accent: 0 8px 24px -8px rgba(45, 127, 240, 0.55);`, replace: `    --lc-shadow-accent: 0 4px 12px -6px rgba(45, 127, 240, 0.5);` },
            { desc: "Brand scrollbars and text selection", find: `@media (prefers-reduced-motion: reduce) {
    .lc-skel,`, replace: `html {
    scrollbar-color: rgba(244, 246, 251, 0.14) transparent;
    scrollbar-width: thin;
}

::-webkit-scrollbar {
    width: 10px;
    height: 10px;
}

::-webkit-scrollbar-track {
    background: transparent;
}

::-webkit-scrollbar-thumb {
    border: 3px solid transparent;
    border-radius: 999px;
    background: rgba(244, 246, 251, 0.12);
    background-clip: padding-box;
}

::-webkit-scrollbar-thumb:hover {
    background-color: rgba(244, 246, 251, 0.24);
}

::selection {
    background: rgba(45, 127, 240, 0.38);
    color: var(--lc-ink-1);
}

@media (prefers-reduced-motion: reduce) {
    .lc-skel,` },
        ],
    },
    {
        file: 'src/styles/business/palette.css',
        edits: [
            { desc: "Visible highlight in the command bar", find: `.lc-cmd__item.is-active {
    background: var(--lc-raised-hover);
    color: var(--lc-ink-1);
}`, replace: `.lc-cmd__item.is-active {
    background: var(--lc-info-tint);
    box-shadow: inset 0 0 0 1px rgba(45, 127, 240, 0.28);
    color: var(--lc-ink-1);
}` },
        ],
    },
    {
        file: 'src/styles/ui.css',
        edits: [
            { desc: "List cards: rows sit together", find: `.ui-card--pad-sm { padding: var(--space-3); }`, replace: `.ui-card--pad-sm { padding: var(--space-3); gap: var(--space-1); }` },
        ],
    },
]

const RETIRES = []

let failed = false

for (const nf of NEW_FILES) {
    const full = path.join(REPO, nf.path)
    if (fs.existsSync(full)) { console.error(`[FAIL] Already exists: ${nf.path}`); failed = true }
    if (!fs.existsSync(path.dirname(full))) { console.error(`[FAIL] Parent dir missing: ${nf.path}`); failed = true }
}

const fileChanges = new Map()
for (const group of PATCHES) {
    const fullPath = path.join(REPO, group.file)
    if (!fs.existsSync(fullPath)) { console.error(`[FAIL] Missing: ${group.file}`); failed = true; continue }
    let content = fs.readFileSync(fullPath, 'utf8')
    const original = content
    const crlf = (content.match(/\r\n/g) || []).length
    const lf = (content.match(/\n/g) || []).length - crlf
    const eol = crlf > lf ? '\r\n' : '\n'
    let ok = true
    for (const edit of group.edits) {
        // Anchors accept CRLF or LF; replacements follow the file's dominant ending.
        const pattern = edit.find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\n/g, '\\r?\\n')
        const matches = (content.match(new RegExp(pattern, 'g')) || []).length
        if (matches !== 1) {
            console.error(`[FAIL] ${group.file}: ${matches} matches for "${edit.desc}" (expected 1)`)
            failed = true; ok = false; break
        }
        const replace = edit.replace.replace(/\n/g, eol)
        content = content.replace(new RegExp(pattern), () => replace)
    }
    if (ok) fileChanges.set(fullPath, { original, modified: content, edits: group.edits })
}

const retirePaths = []
for (const rel of RETIRES) {
    const full = path.join(REPO, rel)
    if (!fs.existsSync(full)) { console.error(`[FAIL] Retire target missing: ${rel}`); failed = true; continue }
    if (fs.existsSync(`${full}.mistake`)) { console.error(`[FAIL] Already retired: ${rel}.mistake`); failed = true; continue }
    retirePaths.push({ full, rel })
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const nf of NEW_FILES) {
    fs.writeFileSync(path.join(REPO, nf.path), nf.content)
    console.log(`[NEW] ${nf.path}`)
}
for (const [fullPath, change] of fileChanges) {
    fs.writeFileSync(`${fullPath}.backup`, change.original)
    fs.writeFileSync(fullPath, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, fullPath)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}
for (const { full, rel } of retirePaths) {
    fs.renameSync(full, `${full}.mistake`)
    console.log(`[RETIRE] ${rel} -> .mistake`)
}

console.log('\n[DONE]')
