$ErrorActionPreference = 'Stop'

Write-Host ""
Write-Host "  Locappoint - Batch 4a-2: business shell, Today, Calendar, bookings" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path 'package.json')) { Write-Host "  [ABORT] No package.json. Run from repo root." -ForegroundColor Red; exit 1 }
$pkg = Get-Content 'package.json' -Raw | ConvertFrom-Json
if ($pkg.name -ne 'locappoint') { Write-Host "  [ABORT] Wrong package: $($pkg.name)" -ForegroundColor Red; exit 1 }
try { $null = & node --version } catch { Write-Host "  [ABORT] Node.js not found." -ForegroundColor Red; exit 1 }

Write-Host "  Needs batch4a1-staff-model.sql already run in Supabase." -ForegroundColor Magenta
Write-Host ""
Write-Host "  What this does:" -ForegroundColor White
Write-Host ""
Write-Host "    [NEW]     src/services/business.js  (data helpers)" -ForegroundColor Green
Write-Host "    [NEW]     src/components/business/  BusinessShell, WorkspaceContext, Sheet, DayRail, StaffFilter," -ForegroundColor Green
Write-Host "                                        NewBookingSheet, BookingDetailSheet" -ForegroundColor Green
Write-Host "    [NEW]     src/pages/business/  Today, Calendar" -ForegroundColor Green
Write-Host "    [NEW]     src/styles/business/  shell.css, day.css, calendar.css" -ForegroundColor Green
Write-Host "    [EDIT]    src/BookingApp.jsx  (2 edits: new shell and routes, old routes redirect)" -ForegroundColor Yellow
Write-Host "    [RETIRE]  src/pages/portal/  PortalLayout, Dashboard, Appointments  -> .mistake" -ForegroundColor Magenta
Write-Host "    [RETIRE]  src/styles/portal/  portal.css, appointments.css  -> .mistake" -ForegroundColor Magenta
Write-Host ""
Write-Host "  Backups saved as *.backup." -ForegroundColor Gray
Write-Host ""

$confirm = Read-Host "  Apply? (y/n)"
if ($confirm -ne 'y' -and $confirm -ne 'Y') { Write-Host "  [CANCELLED]" -ForegroundColor Yellow; exit 0 }
Write-Host ""

& node (Join-Path $PSScriptRoot 'patch-batch4a2-shell.mjs')
if ($LASTEXITCODE -ne 0) { Write-Host "  [FAIL] Exit code $LASTEXITCODE" -ForegroundColor Red; exit $LASTEXITCODE }

$payloadDir = $PSScriptRoot
if ((Split-Path $payloadDir -Leaf) -eq 'payload') {
    Set-Location (Split-Path $payloadDir -Parent)
    Remove-Item $payloadDir -Recurse -Force
}

Write-Host ""
Write-Host "  Done. npm run build, then check /portal on a phone-sized window." -ForegroundColor Green
Write-Host ""
