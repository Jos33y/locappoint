import fs from 'fs'
import path from 'path'

const REPO = process.cwd()

const NEW_FILES = [
    { path: 'src/components/business/BookingDetailSheet.jsx', content: `import { useEffect, useState } from 'react'
import { Mail, MessageCircle, Phone } from 'lucide-react'
import Sheet from './Sheet'
import { useWorkspace } from './WorkspaceContext'
import {
    STATUS_LABEL,
    formatDay,
    formatMoney,
    friendlyError,
    getSlots,
    moveBooking,
    setBookingStatus,
    shortTime,
    whatsappLink,
} from '../../services/business'

const ACTIONS = {
    pending: [
        { status: 'confirmed', label: 'Confirm', tone: 'primary', done: 'Booking confirmed' },
        { status: 'cancelled', label: 'Decline', tone: 'danger', done: 'Booking declined' },
    ],
    confirmed: [
        { status: 'completed', label: 'Completed', tone: 'primary', done: 'Marked completed' },
        { status: 'no_show', label: 'No-show', tone: 'secondary', done: 'Marked as no-show' },
        { status: 'cancelled', label: 'Cancel', tone: 'danger', done: 'Booking cancelled' },
    ],
}

const BookingDetailSheet = ({ booking, onClose }) => {
    const { business, bookableMembers, isOwner, refreshBookings, notify } = useWorkspace()
    const [moving, setMoving] = useState(false)
    const [move, setMove] = useState(null)
    const [slots, setSlots] = useState([])
    const [otherTime, setOtherTime] = useState(false)
    const [busy, setBusy] = useState(false)
    const [error, setError] = useState('')

    useEffect(() => {
        setMoving(false)
        setError('')
        if (booking) {
            setMove({ date: booking.appointment_date, time: '', staffId: booking.staff_id })
            setOtherTime(!booking.service_id)
        }
    }, [booking])

    useEffect(() => {
        if (!moving || !booking?.service_id || !move?.date) return undefined
        let cancelled = false
        getSlots({ businessId: business.id, serviceId: booking.service_id, date: move.date, staffId: move.staffId })
            .then((rows) => { if (!cancelled) setSlots(rows) })
            .catch(() => { if (!cancelled) setSlots([]) })
        return () => { cancelled = true }
    }, [moving, business.id, booking?.service_id, move?.date, move?.staffId])

    if (!booking) return null

    const staff = bookableMembers.find((m) => m.id === booking.staff_id)
    const actions = ACTIONS[booking.status] || []
    const whatsapp = whatsappLink(booking.client_phone)

    const act = async (action) => {
        setBusy(true)
        setError('')
        try {
            await setBookingStatus(booking.id, action.status)
            refreshBookings()
            notify(action.done)
            onClose()
        } catch (err) {
            setError(friendlyError(err))
        } finally {
            setBusy(false)
        }
    }

    const saveMove = async (event) => {
        event.preventDefault()
        if (!move.time) {
            setError('Pick a new time.')
            return
        }
        setBusy(true)
        setError('')
        try {
            await moveBooking({
                id: booking.id,
                date: move.date,
                time: move.time.length === 5 ? \`\${move.time}:00\` : move.time,
                staffId: move.staffId !== booking.staff_id ? move.staffId : null,
            })
            refreshBookings()
            notify('Booking moved')
            onClose()
        } catch (err) {
            setError(friendlyError(err))
        } finally {
            setBusy(false)
        }
    }

    return (
        <Sheet open={Boolean(booking)} onClose={onClose} title={booking.client_name}>
            <dl className="biz-facts">
                <div>
                    <dt>When</dt>
                    <dd>
                        {formatDay(booking.appointment_date, { weekday: 'short', day: 'numeric', month: 'short' })},{' '}
                        <span className="biz-num">{shortTime(booking.appointment_time)}</span> for {booking.duration_minutes} min
                    </dd>
                </div>
                <div>
                    <dt>Service</dt>
                    <dd>
                        {booking.services?.service_name || 'Service removed'}
                        {booking.services && <span className="biz-num biz-muted"> {formatMoney(booking.services.price)}</span>}
                    </dd>
                </div>
                {staff && bookableMembers.length > 1 && (
                    <div>
                        <dt>With</dt>
                        <dd>{staff.display_name}</dd>
                    </div>
                )}
                <div>
                    <dt>Status</dt>
                    <dd><span className={\`biz-status biz-status--\${booking.status}\`}>{STATUS_LABEL[booking.status]}</span></dd>
                </div>
                {booking.notes && (
                    <div>
                        <dt>Notes</dt>
                        <dd>{booking.notes}</dd>
                    </div>
                )}
            </dl>

            {(booking.client_phone || booking.client_email) && (
                <div className="biz-contact">
                    {booking.client_phone && (
                        <a className="biz-contact__btn" href={\`tel:\${booking.client_phone}\`}>
                            <Phone size={18} /> Call
                        </a>
                    )}
                    {whatsapp && (
                        <a className="biz-contact__btn" href={whatsapp} target="_blank" rel="noopener noreferrer">
                            <MessageCircle size={18} /> WhatsApp
                        </a>
                    )}
                    {booking.client_email && (
                        <a className="biz-contact__btn" href={\`mailto:\${booking.client_email}\`}>
                            <Mail size={18} /> Email
                        </a>
                    )}
                </div>
            )}

            {!moving && actions.length > 0 && (
                <div className="biz-actions">
                    {actions.map((action) => (
                        <button
                            key={action.status}
                            type="button"
                            className={\`btn btn--\${action.tone} btn--lg\`}
                            disabled={busy}
                            onClick={() => act(action)}
                        >
                            {action.label}
                        </button>
                    ))}
                    <button type="button" className="btn btn--ghost btn--lg" disabled={busy} onClick={() => setMoving(true)}>
                        Move
                    </button>
                </div>
            )}

            {moving && move && (
                <form className="biz-form biz-move" onSubmit={saveMove}>
                    <h3 className="biz-subhead">Move to</h3>
                    <label className="biz-field">
                        <span className="biz-field__label">Date</span>
                        <input
                            className="biz-input"
                            type="date"
                            value={move.date}
                            onChange={(event) => setMove((current) => ({ ...current, date: event.target.value, time: '' }))}
                            required
                        />
                    </label>

                    {isOwner && bookableMembers.length > 1 && (
                        <label className="biz-field">
                            <span className="biz-field__label">With</span>
                            <select
                                className="biz-input"
                                value={move.staffId}
                                onChange={(event) => setMove((current) => ({ ...current, staffId: event.target.value, time: '' }))}
                            >
                                {bookableMembers.map((member) => (
                                    <option key={member.id} value={member.id}>{member.display_name}</option>
                                ))}
                            </select>
                        </label>
                    )}

                    <fieldset className="biz-field">
                        <legend className="biz-field__label">Time</legend>
                        {otherTime ? (
                            <input
                                className="biz-input"
                                type="time"
                                step="300"
                                value={move.time.slice(0, 5)}
                                onChange={(event) => setMove((current) => ({ ...current, time: event.target.value }))}
                                required
                            />
                        ) : slots.length === 0 ? (
                            <p className="biz-hint">No free times in opening hours that day.</p>
                        ) : (
                            <div className="biz-slots" role="radiogroup" aria-label="Free times">
                                {slots.map((slot) => (
                                    <button
                                        key={slot.slot_time}
                                        type="button"
                                        role="radio"
                                        aria-checked={move.time === slot.slot_time}
                                        className={\`biz-slot\${move.time === slot.slot_time ? ' is-selected' : ''}\`}
                                        onClick={() => setMove((current) => ({ ...current, time: slot.slot_time }))}
                                    >
                                        {shortTime(slot.slot_time)}
                                    </button>
                                ))}
                            </div>
                        )}
                        {booking.service_id && (
                            <button
                                type="button"
                                className="biz-textbtn"
                                onClick={() => {
                                    setOtherTime((value) => !value)
                                    setMove((current) => ({ ...current, time: '' }))
                                }}
                            >
                                {otherTime ? 'Show free times' : 'Another time, outside opening hours'}
                            </button>
                        )}
                    </fieldset>

                    <div className="biz-actions">
                        <button type="submit" className="btn btn--primary btn--lg" disabled={busy}>Move booking</button>
                        <button type="button" className="btn btn--ghost btn--lg" disabled={busy} onClick={() => setMoving(false)}>Keep as is</button>
                    </div>
                </form>
            )}

            {error && <p className="biz-error" role="alert">{error}</p>}
        </Sheet>
    )
}

export default BookingDetailSheet
` },
    { path: 'src/components/business/BusinessShell.jsx', content: `import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Link, NavLink, Navigate, Outlet, useLocation } from 'react-router-dom'
import { ArrowLeftRight, CalendarDays, Clock, LogOut, Menu, Plus, Scissors, Settings, Store, Sun } from 'lucide-react'
import { useAuth } from '../../hooks/useAuth'
import { loadWorkspace } from '../../services/business'
import { WorkspaceContext } from './WorkspaceContext'
import Sheet from './Sheet'
import NewBookingSheet from './NewBookingSheet'
import BookingDetailSheet from './BookingDetailSheet'
import '../../styles/business/shell.css'

const NAV = [
    { to: '/portal', label: 'Today', icon: Sun, end: true, tab: true },
    { to: '/portal/calendar', label: 'Calendar', icon: CalendarDays, tab: true },
    { to: '/portal/services', label: 'Services', icon: Scissors, tab: true },
    { to: '/portal/hours', label: 'Hours', icon: Clock },
    { to: '/portal/page', label: 'Business page', icon: Store },
    { to: '/portal/settings', label: 'Settings', icon: Settings },
]

const Wordmark = () => (
    <span className="biz-wordmark" aria-label="LocAppoint">
        <span>Loc</span><span className="biz-wordmark__accent">Appoint</span>
    </span>
)

const BusinessShell = () => {
    const { user, userProfile, business: ownedBusiness, signOut, setMode } = useAuth()
    const location = useLocation()
    const [workspace, setWorkspace] = useState(null)
    const [loadError, setLoadError] = useState('')
    const [bookingsVersion, setBookingsVersion] = useState(0)
    const [newBooking, setNewBooking] = useState(null)
    const [openBookingRow, setOpenBookingRow] = useState(null)
    const [moreOpen, setMoreOpen] = useState(false)
    const [toast, setToast] = useState(null)
    const toastTimer = useRef(null)

    useEffect(() => { setMode('business') }, [setMode])

    const reloadWorkspace = useCallback(async () => {
        if (!ownedBusiness?.id) return
        try {
            setLoadError('')
            setWorkspace(await loadWorkspace(ownedBusiness.id))
        } catch (err) {
            console.error('Workspace load failed:', err)
            setLoadError('Could not load your business. Check your connection and reload.')
        }
    }, [ownedBusiness?.id])

    useEffect(() => { reloadWorkspace() }, [reloadWorkspace])

    useEffect(() => () => clearTimeout(toastTimer.current), [])

    const notify = useCallback((message) => {
        clearTimeout(toastTimer.current)
        setToast(message)
        toastTimer.current = setTimeout(() => setToast(null), 3200)
    }, [])

    const refreshBookings = useCallback(() => setBookingsVersion((v) => v + 1), [])
    const openNewBooking = useCallback((prefill = {}) => setNewBooking(prefill), [])
    const closeNewBooking = useCallback(() => setNewBooking(null), [])
    const openBooking = useCallback((booking) => setOpenBookingRow(booking), [])
    const closeBooking = useCallback(() => setOpenBookingRow(null), [])

    const value = useMemo(() => {
        if (!workspace) return null
        const me = workspace.members.find((m) => m.user_id === user?.id) || null
        return {
            ...workspace,
            me,
            isOwner: me?.role === 'owner',
            bookableMembers: workspace.members.filter((m) => m.is_bookable),
            activeServices: workspace.services.filter((s) => s.is_active),
            reloadWorkspace,
            bookingsVersion,
            refreshBookings,
            openNewBooking,
            openBooking,
            notify,
        }
    }, [workspace, user?.id, reloadWorkspace, bookingsVersion, refreshBookings, openNewBooking, openBooking, notify])

    if (!ownedBusiness) {
        if (location.pathname !== '/portal/page') return <Navigate to="/portal/page" replace />
        return (
            <div className="biz-bare">
                <header className="biz-topbar">
                    <Wordmark />
                    <Link to="/client" className="biz-textbtn">Back to Booking</Link>
                </header>
                <main className="biz-content"><Outlet /></main>
            </div>
        )
    }

    if (loadError) return <div className="biz-state" role="alert">{loadError}</div>
    if (!value) return <div className="biz-state"><span className="spinner" /> Loading your business</div>

    const moreActive = NAV.filter((item) => !item.tab).some((item) => location.pathname.startsWith(item.to))

    return (
        <WorkspaceContext.Provider value={value}>
            <div className="biz-shell">
                <aside className="biz-sidebar">
                    <div className="biz-sidebar__brand">
                        <Wordmark />
                        <span className="biz-sidebar__business">{value.business.business_name}</span>
                    </div>
                    <nav className="biz-sidebar__nav" aria-label="Business">
                        {NAV.map(({ to, label, icon: Icon, end }) => (
                            <NavLink key={to} to={to} end={end} className="biz-navlink">
                                <Icon size={18} aria-hidden="true" />
                                <span>{label}</span>
                            </NavLink>
                        ))}
                    </nav>
                    <div className="biz-sidebar__foot">
                        <Link to="/client" className="biz-navlink">
                            <ArrowLeftRight size={18} aria-hidden="true" />
                            <span>Switch to Booking</span>
                        </Link>
                        <button type="button" className="biz-navlink" onClick={signOut}>
                            <LogOut size={18} aria-hidden="true" />
                            <span>Sign out</span>
                        </button>
                        <p className="biz-sidebar__who">
                            {userProfile?.full_name}
                            <span>{user?.email}</span>
                        </p>
                    </div>
                </aside>

                <div className="biz-main">
                    <header className="biz-topbar">
                        <span className="biz-topbar__name">{value.business.business_name}</span>
                        <button type="button" className="btn btn--primary biz-topbar__new" onClick={() => openNewBooking()}>
                            <Plus size={18} aria-hidden="true" /> New booking
                        </button>
                    </header>
                    <main className="biz-content">
                        <Outlet />
                    </main>
                </div>

                <nav className="biz-tabbar" aria-label="Business">
                    {NAV.filter((item) => item.tab).map(({ to, label, icon: Icon, end }) => (
                        <NavLink key={to} to={to} end={end} className="biz-tab">
                            <Icon size={22} aria-hidden="true" />
                            <span>{label}</span>
                        </NavLink>
                    ))}
                    <button
                        type="button"
                        className={\`biz-tab\${moreActive ? ' active' : ''}\`}
                        onClick={() => setMoreOpen(true)}
                        aria-haspopup="dialog"
                    >
                        <Menu size={22} aria-hidden="true" />
                        <span>More</span>
                    </button>
                </nav>

                <button type="button" className="biz-fab" onClick={() => openNewBooking()} aria-label="New booking">
                    <Plus size={26} aria-hidden="true" />
                </button>

                <Sheet open={moreOpen} onClose={() => setMoreOpen(false)} title="More">
                    <nav className="biz-morelist" aria-label="More">
                        {NAV.filter((item) => !item.tab).map(({ to, label, icon: Icon }) => (
                            <NavLink key={to} to={to} className="biz-navlink" onClick={() => setMoreOpen(false)}>
                                <Icon size={20} aria-hidden="true" />
                                <span>{label}</span>
                            </NavLink>
                        ))}
                        <Link to="/client" className="biz-navlink" onClick={() => setMoreOpen(false)}>
                            <ArrowLeftRight size={20} aria-hidden="true" />
                            <span>Switch to Booking</span>
                        </Link>
                        <button type="button" className="biz-navlink" onClick={signOut}>
                            <LogOut size={20} aria-hidden="true" />
                            <span>Sign out</span>
                        </button>
                    </nav>
                </Sheet>

                <NewBookingSheet open={Boolean(newBooking)} prefill={newBooking} onClose={closeNewBooking} />
                <BookingDetailSheet booking={openBookingRow} onClose={closeBooking} />

                <div className="biz-toast" role="status" aria-live="polite">
                    {toast && <span className="biz-toast__msg">{toast}</span>}
                </div>
            </div>
        </WorkspaceContext.Provider>
    )
}

export default BusinessShell
` },
    { path: 'src/components/business/DayRail.jsx', content: `import { useEffect, useMemo, useRef } from 'react'
import { parseDateKey, toMinutes } from '../../services/dates'
import { STATUS_LABEL, bookingStart, minutesToLabel, shortTime } from '../../services/business'

const PX_PER_MINUTE = 1.4
const SNAP = 15

const windowsFor = (hours, memberId, weekday) => {
    const own = hours.filter((h) => h.staff_id === memberId)
    const source = own.length > 0 ? own : hours.filter((h) => !h.staff_id)
    return source
        .filter((h) => h.day_of_week === weekday)
        .map((h) => [toMinutes(h.start_time), toMinutes(h.end_time)])
}

const blockRange = (block, dateKey) => {
    const dayStart = new Date(\`\${dateKey}T00:00:00\`).getTime()
    const start = Math.max(0, (new Date(block.starts_at).getTime() - dayStart) / 60000)
    const end = Math.min(24 * 60, (new Date(block.ends_at).getTime() - dayStart) / 60000)
    return [start, end]
}

const DayRail = ({ dateKey, columns, bookings, blocks, hours, nowMinutes, onSlotTap, onBookingTap }) => {
    const nowRef = useRef(null)
    const weekday = parseDateKey(dateKey).getDay()

    const layout = useMemo(() => {
        const perColumn = columns.map((member) => ({
            member,
            windows: windowsFor(hours, member.id, weekday),
            bookings: bookings.filter((b) => b.staff_id === member.id && b.status !== 'cancelled'),
            blocks: blocks
                .filter((b) => b.staff_id === member.id || !b.staff_id)
                .map((b) => ({ ...b, range: blockRange(b, dateKey) }))
                .filter((b) => b.range[1] > b.range[0]),
        }))

        const marks = perColumn.flatMap((c) => [
            ...c.windows.flat(),
            ...c.bookings.flatMap((b) => [bookingStart(b), bookingStart(b) + b.duration_minutes]),
        ])
        if (nowMinutes != null) marks.push(nowMinutes)
        const start = marks.length ? Math.floor(Math.min(...marks) / 60) * 60 : 9 * 60
        const end = marks.length ? Math.ceil(Math.max(...marks) / 60) * 60 : 18 * 60
        return { perColumn, start: Math.max(0, start), end: Math.min(24 * 60, Math.max(end, start + 60)) }
    }, [columns, bookings, blocks, hours, weekday, dateKey, nowMinutes])

    const { perColumn, start, end } = layout
    const height = (end - start) * PX_PER_MINUTE
    const y = (minutes) => (minutes - start) * PX_PER_MINUTE
    const hourMarks = []
    for (let m = start; m <= end; m += 60) hourMarks.push(m)
    const showNow = nowMinutes != null && nowMinutes >= start && nowMinutes <= end

    useEffect(() => {
        if (!showNow || !nowRef.current) return
        const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches
        nowRef.current.scrollIntoView({ block: 'center', behavior: reduce ? 'auto' : 'smooth' })
    }, [dateKey, showNow])

    const handleColumnClick = (event, memberId) => {
        if (event.target !== event.currentTarget) return
        const rect = event.currentTarget.getBoundingClientRect()
        const minutes = start + Math.floor((event.clientY - rect.top) / PX_PER_MINUTE / SNAP) * SNAP
        onSlotTap?.(memberId, Math.min(Math.max(minutes, start), end - SNAP))
    }

    return (
        <div className={\`biz-rail\${columns.length > 1 ? ' biz-rail--multi' : ''}\`}>
            {columns.length > 1 && (
                <div className="biz-rail__heads" aria-hidden="true">
                    <span className="biz-rail__gutter" />
                    {columns.map((member) => (
                        <span key={member.id} className="biz-rail__head">{member.display_name}</span>
                    ))}
                </div>
            )}

            <div className="biz-rail__body" style={{ height }}>
                <div className="biz-rail__gutter">
                    {hourMarks.map((m) => (
                        <span key={m} className="biz-rail__hour" style={{ top: y(m) }}>{minutesToLabel(m)}</span>
                    ))}
                </div>

                {perColumn.map((column) => (
                    <div
                        key={column.member.id}
                        className="biz-rail__col"
                        onClick={(event) => handleColumnClick(event, column.member.id)}
                        role="presentation"
                    >
                        {hourMarks.map((m) => (
                            <span key={m} className="biz-rail__line" style={{ top: y(m) }} />
                        ))}

                        {column.windows.map(([from, to]) => (
                            <span key={\`\${from}-\${to}\`} className="biz-rail__open" style={{ top: y(from), height: (to - from) * PX_PER_MINUTE }} />
                        ))}

                        {column.blocks.map((block) => (
                            <div
                                key={block.id}
                                className="biz-rail__block"
                                style={{ top: y(block.range[0]), height: (block.range[1] - block.range[0]) * PX_PER_MINUTE }}
                            >
                                <span>Blocked{block.reason ? \`: \${block.reason}\` : ''}</span>
                            </div>
                        ))}

                        {column.bookings.map((booking) => {
                            const from = bookingStart(booking)
                            const blockHeight = Math.max(booking.duration_minutes * PX_PER_MINUTE, 30)
                            return (
                                <button
                                    key={booking.id}
                                    type="button"
                                    className={\`biz-booking biz-booking--\${booking.status}\${blockHeight < 56 ? ' biz-booking--compact' : ''}\`}
                                    style={{ top: y(from), height: blockHeight }}
                                    onClick={() => onBookingTap?.(booking)}
                                    aria-label={\`\${shortTime(booking.appointment_time)} \${booking.client_name}, \${booking.services?.service_name || 'booking'}, \${STATUS_LABEL[booking.status]}\`}
                                >
                                    <span className="biz-booking__time">
                                        {shortTime(booking.appointment_time)}
                                        {booking.status === 'pending' && <span className="biz-booking__flag">Needs confirming</span>}
                                    </span>
                                    <span className="biz-booking__who">{booking.client_name}</span>
                                    <span className="biz-booking__what">{booking.services?.service_name}</span>
                                </button>
                            )
                        })}
                    </div>
                ))}

                {showNow && (
                    <div ref={nowRef} className="biz-rail__now" style={{ top: y(nowMinutes) }} aria-hidden="true">
                        <span className="biz-rail__now-label">{minutesToLabel(nowMinutes)}</span>
                    </div>
                )}
            </div>
        </div>
    )
}

export default DayRail
` },
    { path: 'src/components/business/NewBookingSheet.jsx', content: `import { useEffect, useState } from 'react'
import Sheet from './Sheet'
import { useWorkspace } from './WorkspaceContext'
import { addBooking, friendlyError, getSlots, shortTime, zonedNow } from '../../services/business'

const NewBookingSheet = ({ open, prefill, onClose }) => {
    const { business, bookableMembers, activeServices, me, isOwner, refreshBookings, notify } = useWorkspace()
    const [form, setForm] = useState(null)
    const [slots, setSlots] = useState([])
    const [slotsLoading, setSlotsLoading] = useState(false)
    const [otherTime, setOtherTime] = useState(false)
    const [saving, setSaving] = useState(false)
    const [error, setError] = useState('')

    useEffect(() => {
        if (!open) return
        setForm({
            serviceId: activeServices[0]?.id || '',
            staffId: prefill?.staffId || (isOwner ? bookableMembers[0]?.id : me?.id) || '',
            date: prefill?.date || zonedNow(business.timezone).dateKey,
            time: prefill?.time || '',
            name: '',
            phone: '',
            email: '',
            notes: '',
        })
        setOtherTime(Boolean(prefill?.time))
        setError('')
    }, [open, prefill, activeServices, bookableMembers, business.timezone, isOwner, me])

    useEffect(() => {
        if (!open || !form?.serviceId || !form?.staffId || !form?.date) return undefined
        let cancelled = false
        setSlotsLoading(true)
        getSlots({ businessId: business.id, serviceId: form.serviceId, date: form.date, staffId: form.staffId })
            .then((rows) => { if (!cancelled) setSlots(rows) })
            .catch(() => { if (!cancelled) setSlots([]) })
            .finally(() => { if (!cancelled) setSlotsLoading(false) })
        return () => { cancelled = true }
    }, [open, business.id, form?.serviceId, form?.staffId, form?.date])

    if (!form) return null

    const update = (field) => (event) => setForm((current) => ({ ...current, [field]: event.target.value }))

    const submit = async (event) => {
        event.preventDefault()
        if (!form.time) {
            setError('Pick a time.')
            return
        }
        setSaving(true)
        setError('')
        try {
            await addBooking({
                businessId: business.id,
                serviceId: form.serviceId,
                staffId: form.staffId,
                date: form.date,
                time: form.time.length === 5 ? \`\${form.time}:00\` : form.time,
                name: form.name,
                phone: form.phone,
                email: form.email,
                notes: form.notes,
            })
            refreshBookings()
            notify('Booking added')
            onClose()
        } catch (err) {
            setError(friendlyError(err))
        } finally {
            setSaving(false)
        }
    }

    if (activeServices.length === 0) {
        return (
            <Sheet open={open} onClose={onClose} title="New booking">
                <p className="biz-empty">Add a service first, then you can book it.</p>
            </Sheet>
        )
    }

    return (
        <Sheet
            open={open}
            onClose={onClose}
            title="New booking"
            footer={
                <button type="submit" form="biz-new-booking" className="btn btn--primary btn--lg btn--full" disabled={saving}>
                    {saving ? 'Adding…' : 'Add booking'}
                </button>
            }
        >
            <form id="biz-new-booking" className="biz-form" onSubmit={submit}>
                <label className="biz-field">
                    <span className="biz-field__label">Service</span>
                    <select className="biz-input" value={form.serviceId} onChange={update('serviceId')} required>
                        {activeServices.map((service) => (
                            <option key={service.id} value={service.id}>
                                {service.service_name} ({service.duration_minutes} min)
                            </option>
                        ))}
                    </select>
                </label>

                {isOwner && bookableMembers.length > 1 && (
                    <label className="biz-field">
                        <span className="biz-field__label">With</span>
                        <select className="biz-input" value={form.staffId} onChange={update('staffId')} required>
                            {bookableMembers.map((member) => (
                                <option key={member.id} value={member.id}>{member.display_name}</option>
                            ))}
                        </select>
                    </label>
                )}

                <label className="biz-field">
                    <span className="biz-field__label">Date</span>
                    <input className="biz-input" type="date" value={form.date} onChange={update('date')} required />
                </label>

                <fieldset className="biz-field">
                    <legend className="biz-field__label">Time</legend>
                    {otherTime ? (
                        <input className="biz-input" type="time" step="300" value={form.time.slice(0, 5)} onChange={update('time')} required />
                    ) : slotsLoading ? (
                        <p className="biz-hint">Finding free times…</p>
                    ) : slots.length === 0 ? (
                        <p className="biz-hint">No free times in opening hours that day.</p>
                    ) : (
                        <div className="biz-slots" role="radiogroup" aria-label="Free times">
                            {slots.map((slot) => (
                                <button
                                    key={slot.slot_time}
                                    type="button"
                                    role="radio"
                                    aria-checked={form.time === slot.slot_time}
                                    className={\`biz-slot\${form.time === slot.slot_time ? ' is-selected' : ''}\`}
                                    onClick={() => setForm((current) => ({ ...current, time: slot.slot_time }))}
                                >
                                    {shortTime(slot.slot_time)}
                                </button>
                            ))}
                        </div>
                    )}
                    <button
                        type="button"
                        className="biz-textbtn"
                        onClick={() => {
                            setOtherTime((value) => !value)
                            setForm((current) => ({ ...current, time: '' }))
                        }}
                    >
                        {otherTime ? 'Show free times' : 'Another time, outside opening hours'}
                    </button>
                </fieldset>

                <label className="biz-field">
                    <span className="biz-field__label">Client name</span>
                    <input className="biz-input" value={form.name} onChange={update('name')} autoComplete="off" required maxLength={120} />
                </label>

                <div className="biz-field-row">
                    <label className="biz-field">
                        <span className="biz-field__label">Phone <span className="biz-optional">optional</span></span>
                        <input className="biz-input" type="tel" inputMode="tel" value={form.phone} onChange={update('phone')} autoComplete="off" />
                    </label>
                    <label className="biz-field">
                        <span className="biz-field__label">Email <span className="biz-optional">optional</span></span>
                        <input className="biz-input" type="email" value={form.email} onChange={update('email')} autoComplete="off" />
                    </label>
                </div>

                <label className="biz-field">
                    <span className="biz-field__label">Notes <span className="biz-optional">optional</span></span>
                    <textarea className="biz-input biz-input--area" value={form.notes} onChange={update('notes')} maxLength={1000} rows={2} />
                </label>

                {error && <p className="biz-error" role="alert">{error}</p>}
            </form>
        </Sheet>
    )
}

export default NewBookingSheet
` },
    { path: 'src/components/business/Sheet.jsx', content: `import { useEffect, useId, useRef } from 'react'
import { createPortal } from 'react-dom'
import { X } from 'lucide-react'

const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled])'

const Sheet = ({ open, onClose, title, children, footer }) => {
    const titleId = useId()
    const panelRef = useRef(null)
    const closeRef = useRef(onClose)
    closeRef.current = onClose

    useEffect(() => {
        if (!open) return undefined
        const returnTo = document.activeElement
        const previousOverflow = document.body.style.overflow
        document.body.style.overflow = 'hidden'

        const onKey = (event) => {
            if (event.key === 'Escape') {
                closeRef.current()
                return
            }
            if (event.key !== 'Tab' || !panelRef.current) return
            const items = [...panelRef.current.querySelectorAll(FOCUSABLE)]
            if (items.length === 0) return
            const first = items[0]
            const last = items[items.length - 1]
            if (event.shiftKey && document.activeElement === first) {
                event.preventDefault()
                last.focus()
            } else if (!event.shiftKey && document.activeElement === last) {
                event.preventDefault()
                first.focus()
            }
        }

        document.addEventListener('keydown', onKey)
        requestAnimationFrame(() => {
            const target = panelRef.current?.querySelector('.biz-sheet__body ' + FOCUSABLE)
            ;(target || panelRef.current)?.focus()
        })

        return () => {
            document.body.style.overflow = previousOverflow
            document.removeEventListener('keydown', onKey)
            returnTo?.focus?.()
        }
    }, [open])

    if (!open) return null

    return createPortal(
        <div
            className="biz-sheet"
            onMouseDown={(event) => { if (event.target === event.currentTarget) closeRef.current() }}
        >
            <section
                ref={panelRef}
                className="biz-sheet__panel"
                role="dialog"
                aria-modal="true"
                aria-labelledby={titleId}
                tabIndex={-1}
            >
                <header className="biz-sheet__head">
                    <h2 id={titleId} className="biz-sheet__title">{title}</h2>
                    <button type="button" className="biz-icon-btn" aria-label="Close" onClick={() => closeRef.current()}>
                        <X size={20} />
                    </button>
                </header>
                <div className="biz-sheet__body">{children}</div>
                {footer && <footer className="biz-sheet__foot">{footer}</footer>}
            </section>
        </div>,
        document.body
    )
}

export default Sheet
` },
    { path: 'src/components/business/StaffFilter.jsx', content: `const StaffFilter = ({ members, value, onChange }) => {
    if (members.length < 2) return null
    return (
        <div className="biz-chips" role="radiogroup" aria-label="Show calendar for">
            {[{ id: 'all', display_name: 'Everyone' }, ...members].map((member) => (
                <button
                    key={member.id}
                    type="button"
                    role="radio"
                    aria-checked={value === member.id}
                    className={\`biz-chip\${value === member.id ? ' is-selected' : ''}\`}
                    onClick={() => onChange(member.id)}
                >
                    {member.display_name}
                </button>
            ))}
        </div>
    )
}

export default StaffFilter
` },
    { path: 'src/components/business/WorkspaceContext.js', content: `import { createContext, useContext } from 'react'

export const WorkspaceContext = createContext(null)

export const useWorkspace = () => {
    const workspace = useContext(WorkspaceContext)
    if (!workspace) throw new Error('useWorkspace must be used inside the business shell')
    return workspace
}
` },
    { path: 'src/pages/business/Calendar.jsx', content: `import { useEffect, useMemo, useState } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { useWorkspace } from '../../components/business/WorkspaceContext'
import DayRail from '../../components/business/DayRail'
import StaffFilter from '../../components/business/StaffFilter'
import {
    STATUS_LABEL,
    addDays,
    formatDay,
    loadBlocks,
    loadBookings,
    shortTime,
    startOfWeek,
    zonedNow,
} from '../../services/business'
import '../../styles/business/day.css'
import '../../styles/business/calendar.css'

const Calendar = () => {
    const { business, bookableMembers, hours, me, isOwner, bookingsVersion, openNewBooking, openBooking } = useWorkspace()
    const today = zonedNow(business.timezone)
    const [view, setView] = useState('day')
    const [anchor, setAnchor] = useState(today.dateKey)
    const [staffFilter, setStaffFilter] = useState(isOwner ? 'all' : me?.id)
    const [bookings, setBookings] = useState([])
    const [blocks, setBlocks] = useState([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState('')

    const range = useMemo(() => {
        if (view === 'day') return [anchor, anchor]
        const from = startOfWeek(anchor)
        return [from, addDays(from, 6)]
    }, [view, anchor])

    useEffect(() => {
        let cancelled = false
        setLoading(true)
        Promise.all([loadBookings(business.id, range[0], range[1]), loadBlocks(business.id, range[0], range[1])])
            .then(([rows, blockRows]) => {
                if (cancelled) return
                setBookings(rows)
                setBlocks(blockRows)
                setError('')
            })
            .catch(() => { if (!cancelled) setError('Could not load the calendar. Reload to try again.') })
            .finally(() => { if (!cancelled) setLoading(false) })
        return () => { cancelled = true }
    }, [business.id, range, bookingsVersion])

    const columns = useMemo(
        () => (staffFilter === 'all' ? bookableMembers : bookableMembers.filter((m) => m.id === staffFilter)),
        [staffFilter, bookableMembers]
    )
    const visible = useMemo(
        () => bookings.filter((b) => columns.some((c) => c.id === b.staff_id)),
        [bookings, columns]
    )

    const step = view === 'day' ? 1 : 7
    const title = view === 'day'
        ? formatDay(anchor)
        : \`\${formatDay(range[0], { day: 'numeric', month: 'short' })} to \${formatDay(range[1], { day: 'numeric', month: 'short' })}\`

    const days = view === 'week' ? Array.from({ length: 7 }, (_, i) => addDays(range[0], i)) : []

    return (
        <div className="biz-page">
            <header className="biz-page__head">
                <div>
                    <h1 className="biz-page__title">Calendar</h1>
                    <p className="biz-page__sub">{title}</p>
                </div>
                <div className="biz-seg" role="radiogroup" aria-label="View">
                    {['day', 'week'].map((option) => (
                        <button
                            key={option}
                            type="button"
                            role="radio"
                            aria-checked={view === option}
                            className={\`biz-seg__btn\${view === option ? ' is-selected' : ''}\`}
                            onClick={() => setView(option)}
                        >
                            {option === 'day' ? 'Day' : 'Week'}
                        </button>
                    ))}
                </div>
            </header>

            <div className="biz-datenav">
                <button type="button" className="biz-icon-btn" aria-label={view === 'day' ? 'Previous day' : 'Previous week'} onClick={() => setAnchor(addDays(anchor, -step))}>
                    <ChevronLeft size={20} />
                </button>
                <button type="button" className="btn btn--ghost btn--sm" onClick={() => setAnchor(today.dateKey)} disabled={anchor === today.dateKey}>
                    Today
                </button>
                <button type="button" className="biz-icon-btn" aria-label={view === 'day' ? 'Next day' : 'Next week'} onClick={() => setAnchor(addDays(anchor, step))}>
                    <ChevronRight size={20} />
                </button>
                <label className="biz-datenav__pick">
                    <span className="biz-visually-hidden">Go to date</span>
                    <input className="biz-input" type="date" value={anchor} onChange={(event) => event.target.value && setAnchor(event.target.value)} />
                </label>
            </div>

            <StaffFilter members={isOwner ? bookableMembers : []} value={staffFilter} onChange={setStaffFilter} />

            {error && <p className="biz-error" role="alert">{error}</p>}
            {loading && bookings.length === 0 && <div className="biz-state"><span className="spinner" /> Loading</div>}

            {view === 'day' && !(loading && bookings.length === 0) && (
                <DayRail
                    dateKey={anchor}
                    columns={columns}
                    bookings={visible}
                    blocks={blocks}
                    hours={hours}
                    nowMinutes={anchor === today.dateKey ? today.minutes : null}
                    onSlotTap={(staffId, minutes) => openNewBooking({
                        staffId,
                        date: anchor,
                        time: \`\${String(Math.floor(minutes / 60)).padStart(2, '0')}:\${String(minutes % 60).padStart(2, '0')}\`,
                    })}
                    onBookingTap={openBooking}
                />
            )}

            {view === 'week' && (
                <div className="biz-week">
                    {days.map((dateKey) => {
                        const dayBookings = visible.filter((b) => b.appointment_date === dateKey && b.status !== 'cancelled')
                        const isToday = dateKey === today.dateKey
                        return (
                            <section key={dateKey} className={\`biz-week__day\${isToday ? ' is-today' : ''}\`} aria-label={formatDay(dateKey)}>
                                <button
                                    type="button"
                                    className="biz-week__head"
                                    onClick={() => { setAnchor(dateKey); setView('day') }}
                                >
                                    <span className="biz-week__dow">{formatDay(dateKey, { weekday: 'short' })}</span>
                                    <span className="biz-num biz-week__date">{formatDay(dateKey, { day: 'numeric' })}</span>
                                    <span className="biz-week__count">{dayBookings.length || ''}</span>
                                </button>
                                <ul className="biz-week__list">
                                    {dayBookings.map((booking) => (
                                        <li key={booking.id}>
                                            <button
                                                type="button"
                                                className={\`biz-week__item biz-week__item--\${booking.status}\`}
                                                onClick={() => openBooking(booking)}
                                                aria-label={\`\${shortTime(booking.appointment_time)} \${booking.client_name}, \${STATUS_LABEL[booking.status]}\`}
                                            >
                                                <span className="biz-num">{shortTime(booking.appointment_time)}</span>
                                                <span className="biz-week__client">{booking.client_name}</span>
                                            </button>
                                        </li>
                                    ))}
                                </ul>
                                <button
                                    type="button"
                                    className="biz-week__add"
                                    onClick={() => openNewBooking({ date: dateKey, staffId: staffFilter !== 'all' ? staffFilter : undefined })}
                                    aria-label={\`Add a booking on \${formatDay(dateKey)}\`}
                                >
                                    Add
                                </button>
                            </section>
                        )
                    })}
                </div>
            )}
        </div>
    )
}

export default Calendar
` },
    { path: 'src/pages/business/Today.jsx', content: `import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { Check, Copy, MessageCircle } from 'lucide-react'
import { useWorkspace } from '../../components/business/WorkspaceContext'
import DayRail from '../../components/business/DayRail'
import StaffFilter from '../../components/business/StaffFilter'
import {
    ACTIVE_STATUSES,
    bookingStart,
    formatDay,
    formatMoney,
    loadBlocks,
    loadBookings,
    shortTime,
    zonedNow,
} from '../../services/business'
import '../../styles/business/day.css'

const Today = () => {
    const { business, bookableMembers, activeServices, hours, me, isOwner, bookingsVersion, openNewBooking, openBooking } = useWorkspace()
    const [now, setNow] = useState(() => zonedNow(business.timezone))
    const [staffFilter, setStaffFilter] = useState(isOwner ? 'all' : me?.id)
    const [bookings, setBookings] = useState([])
    const [blocks, setBlocks] = useState([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState('')
    const [copied, setCopied] = useState(false)

    useEffect(() => {
        const timer = setInterval(() => setNow(zonedNow(business.timezone)), 60000)
        return () => clearInterval(timer)
    }, [business.timezone])

    useEffect(() => {
        let cancelled = false
        setLoading(true)
        Promise.all([loadBookings(business.id, now.dateKey, now.dateKey), loadBlocks(business.id, now.dateKey, now.dateKey)])
            .then(([rows, blockRows]) => {
                if (cancelled) return
                setBookings(rows)
                setBlocks(blockRows)
                setError('')
            })
            .catch(() => { if (!cancelled) setError('Could not load today. Pull to refresh or reload.') })
            .finally(() => { if (!cancelled) setLoading(false) })
        return () => { cancelled = true }
    }, [business.id, now.dateKey, bookingsVersion])

    const columns = useMemo(
        () => (staffFilter === 'all' ? bookableMembers : bookableMembers.filter((m) => m.id === staffFilter)),
        [staffFilter, bookableMembers]
    )

    const visible = useMemo(
        () => bookings.filter((b) => columns.some((c) => c.id === b.staff_id)),
        [bookings, columns]
    )

    const counted = visible.filter((b) => b.status !== 'cancelled')
    const expected = counted
        .filter((b) => b.status !== 'no_show')
        .reduce((sum, b) => sum + Number(b.services?.price || 0), 0)
    const toConfirm = visible.filter((b) => b.status === 'pending').length

    const next = visible.find(
        (b) => ACTIVE_STATUSES.includes(b.status) && bookingStart(b) + b.duration_minutes > now.minutes
    )
    const nextIsNow = next && bookingStart(next) <= now.minutes

    const link = \`\${window.location.origin}/\${business.slug}\`
    const hasService = activeServices.length > 0
    const hasHours = hours.some((h) => !h.staff_id)
    const setupDone = hasService && hasHours && business.is_active

    const copyLink = async () => {
        try {
            await navigator.clipboard.writeText(link)
            setCopied(true)
            setTimeout(() => setCopied(false), 2000)
        } catch {
            setCopied(false)
        }
    }

    return (
        <div className="biz-page">
            <header className="biz-page__head">
                <div>
                    <h1 className="biz-page__title">Today</h1>
                    <p className="biz-page__sub">{formatDay(now.dateKey)}</p>
                </div>
            </header>

            {!setupDone && (
                <section className="biz-setup" aria-labelledby="setup-title">
                    <h2 id="setup-title" className="biz-subhead">Finish setting up to take bookings</h2>
                    <ol className="biz-setup__list">
                        <li className="is-done"><Check size={16} aria-hidden="true" /> Business page created</li>
                        <li className={hasService ? 'is-done' : ''}>
                            {hasService ? <Check size={16} aria-hidden="true" /> : <span className="biz-setup__dot" />}
                            {hasService ? 'Services added' : <Link to="/portal/services">Add your first service</Link>}
                        </li>
                        <li className={hasHours ? 'is-done' : ''}>
                            {hasHours ? <Check size={16} aria-hidden="true" /> : <span className="biz-setup__dot" />}
                            {hasHours ? 'Opening hours set' : <Link to="/portal/hours">Set your opening hours</Link>}
                        </li>
                        {!business.is_active && (
                            <li>
                                <span className="biz-setup__dot" />
                                <Link to="/portal/page">Your page is paused. Turn bookings back on</Link>
                            </li>
                        )}
                    </ol>
                </section>
            )}

            <StaffFilter members={isOwner ? bookableMembers : []} value={staffFilter} onChange={setStaffFilter} />

            <p className="biz-daysum">
                <span><strong className="biz-num">{counted.length}</strong> {counted.length === 1 ? 'booking' : 'bookings'}</span>
                <span><strong className="biz-num">{formatMoney(expected)}</strong> expected</span>
                {toConfirm > 0 && <span className="biz-daysum__warn"><strong className="biz-num">{toConfirm}</strong> to confirm</span>}
            </p>

            {next && (
                <button type="button" className="biz-next" onClick={() => openBooking(next)}>
                    <span className="biz-next__label">{nextIsNow ? 'Now' : 'Next'}</span>
                    <span className="biz-num biz-next__time">{shortTime(next.appointment_time)}</span>
                    <span className="biz-next__who">{next.client_name}</span>
                    <span className="biz-next__what">{next.services?.service_name}</span>
                </button>
            )}

            {error && <p className="biz-error" role="alert">{error}</p>}

            {loading && bookings.length === 0 ? (
                <div className="biz-state"><span className="spinner" /> Loading today</div>
            ) : (
                <DayRail
                    dateKey={now.dateKey}
                    columns={columns}
                    bookings={visible}
                    blocks={blocks}
                    hours={hours}
                    nowMinutes={now.minutes}
                    onSlotTap={(staffId, minutes) => openNewBooking({
                        staffId,
                        date: now.dateKey,
                        time: \`\${String(Math.floor(minutes / 60)).padStart(2, '0')}:\${String(minutes % 60).padStart(2, '0')}\`,
                    })}
                    onBookingTap={openBooking}
                />
            )}

            {!loading && counted.length === 0 && (
                <p className="biz-empty">Nothing booked today. Tap the timeline or the + button to add a booking.</p>
            )}

            <section className="biz-share" aria-labelledby="share-title">
                <h2 id="share-title" className="biz-subhead">Your booking link</h2>
                <p className="biz-share__link">{link.replace(/^https?:\\/\\//, '')}</p>
                <div className="biz-share__actions">
                    <button type="button" className="btn btn--secondary" onClick={copyLink}>
                        {copied ? <Check size={16} aria-hidden="true" /> : <Copy size={16} aria-hidden="true" />}
                        {copied ? 'Copied' : 'Copy link'}
                    </button>
                    <a
                        className="btn btn--secondary"
                        href={\`https://wa.me/?text=\${encodeURIComponent(\`Book with \${business.business_name}: \${link}\`)}\`}
                        target="_blank"
                        rel="noopener noreferrer"
                    >
                        <MessageCircle size={16} aria-hidden="true" /> Share on WhatsApp
                    </a>
                </div>
            </section>
        </div>
    )
}

export default Today
` },
    { path: 'src/services/business.js', content: `import { supabase } from '../config/supabase'
import { parseDateKey, toDateKey } from './dates'

export const ACTIVE_STATUSES = ['pending', 'confirmed']

export const STATUS_LABEL = {
    pending: 'Needs confirming',
    confirmed: 'Confirmed',
    completed: 'Completed',
    cancelled: 'Cancelled',
    no_show: 'No-show',
}

const KNOWN_ERRORS = ['23P01', '22023', 'P0002', '42501', '28000']

export const friendlyError = (error) =>
    KNOWN_ERRORS.includes(error?.code) ? error.message : 'Something went wrong. Try again.'

export const zonedNow = (timeZone) => {
    const parts = Object.fromEntries(
        new Intl.DateTimeFormat('en-GB', {
            timeZone,
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            hourCycle: 'h23',
        }).formatToParts(new Date()).map((part) => [part.type, part.value])
    )
    return {
        dateKey: \`\${parts.year}-\${parts.month}-\${parts.day}\`,
        minutes: Number(parts.hour) * 60 + Number(parts.minute),
    }
}

export const addDays = (dateKey, days) => {
    const date = parseDateKey(dateKey)
    date.setDate(date.getDate() + days)
    return toDateKey(date)
}

export const startOfWeek = (dateKey) => {
    const date = parseDateKey(dateKey)
    const offset = (date.getDay() + 6) % 7
    date.setDate(date.getDate() - offset)
    return toDateKey(date)
}

export const formatDay = (dateKey, options = { weekday: 'long', day: 'numeric', month: 'long' }) =>
    parseDateKey(dateKey).toLocaleDateString('en-GB', options)

export const shortTime = (time) => (time || '').slice(0, 5)

export const minutesToLabel = (total) =>
    \`\${String(Math.floor(total / 60)).padStart(2, '0')}:\${String(total % 60).padStart(2, '0')}\`

const money = new Intl.NumberFormat('pt-PT', { style: 'currency', currency: 'EUR' })
export const formatMoney = (value) => money.format(Number(value) || 0)

export const loadWorkspace = async (businessId) => {
    const [business, members, services, hours] = await Promise.all([
        supabase.from('businesses')
            .select('id, business_name, slug, timezone, is_active, city, phone')
            .eq('id', businessId)
            .single(),
        supabase.from('business_members')
            .select('id, user_id, role, display_name, status, is_bookable, sort_order')
            .eq('business_id', businessId)
            .eq('status', 'active')
            .order('sort_order')
            .order('created_at'),
        supabase.from('services')
            .select('id, service_name, duration_minutes, price, is_active')
            .eq('business_id', businessId)
            .order('service_name'),
        supabase.from('availability')
            .select('id, staff_id, day_of_week, start_time, end_time')
            .eq('business_id', businessId)
            .eq('is_active', true),
    ])
    for (const result of [business, members, services, hours]) {
        if (result.error) throw result.error
    }
    return {
        business: business.data,
        members: members.data,
        services: services.data,
        hours: hours.data,
    }
}

export const loadBookings = async (businessId, fromKey, toKey) => {
    const { data, error } = await supabase
        .from('appointments')
        .select('id, staff_id, service_id, appointment_date, appointment_time, duration_minutes, status, source, client_name, client_phone, client_email, notes, services(service_name, price)')
        .eq('business_id', businessId)
        .gte('appointment_date', fromKey)
        .lte('appointment_date', toKey)
        .order('appointment_date')
        .order('appointment_time')
    if (error) throw error
    return data
}

export const loadBlocks = async (businessId, fromKey, toKey) => {
    const { data, error } = await supabase
        .from('time_blocks')
        .select('id, staff_id, starts_at, ends_at, reason')
        .eq('business_id', businessId)
        .lt('starts_at', \`\${addDays(toKey, 1)}T00:00:00\`)
        .gt('ends_at', \`\${fromKey}T00:00:00\`)
    if (error) throw error
    return data
}

export const setBookingStatus = async (id, status) => {
    const { data, error } = await supabase
        .from('appointments')
        .update({ status })
        .eq('id', id)
        .select('id')
    if (error) throw error
    if (!data || data.length === 0) throw new Error('Update returned 0 rows for booking ' + id)
}

export const addBooking = async ({ businessId, serviceId, staffId, date, time, name, phone, email, notes }) => {
    const { data, error } = await supabase.rpc('owner_book_appointment', {
        p_business_id: businessId,
        p_service_id: serviceId,
        p_staff_id: staffId,
        p_date: date,
        p_time: time,
        p_client_name: name,
        p_client_phone: phone || null,
        p_client_email: email || null,
        p_notes: notes || null,
    })
    if (error) throw error
    return data
}

export const moveBooking = async ({ id, date, time, staffId }) => {
    const { error } = await supabase.rpc('reschedule_appointment', {
        p_appointment_id: id,
        p_date: date,
        p_time: time,
        p_staff_id: staffId || null,
    })
    if (error) throw error
}

export const getSlots = async ({ businessId, serviceId, date, staffId }) => {
    const { data, error } = await supabase.rpc('get_available_slots', {
        p_business_id: businessId,
        p_service_id: serviceId,
        p_date: date,
        p_staff_id: staffId || null,
    })
    if (error) throw error
    return data || []
}

export const bookingStart = (booking) => {
    const [hours, minutes] = booking.appointment_time.split(':').map(Number)
    return hours * 60 + minutes
}

export const whatsappLink = (phone, text = '') => {
    const digits = (phone || '').replace(/[^\\d]/g, '').replace(/^00/, '')
    if (!digits) return null
    return \`https://wa.me/\${digits}\${text ? \`?text=\${encodeURIComponent(text)}\` : ''}\`
}
` },
    { path: 'src/styles/business/calendar.css', content: `.biz-datenav {
    display: flex;
    align-items: center;
    gap: var(--space-2);
}

.biz-datenav__pick {
    margin-left: auto;
}

.biz-datenav__pick .biz-input {
    min-height: 44px;
    width: auto;
}

.biz-week {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
}

.biz-week__day {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
    padding: var(--space-3);
    border: 1px solid var(--border-subtle);
    border-radius: var(--radius-md);
    background: var(--surface-1);
}

.biz-week__day.is-today {
    border-color: var(--signal);
}

.biz-week__head {
    display: flex;
    align-items: baseline;
    gap: var(--space-2);
    padding: 0;
    border: 0;
    background: none;
    color: var(--text-primary);
    font-family: var(--font-body);
    text-align: left;
    cursor: pointer;
}

.biz-week__head:focus-visible,
.biz-week__item:focus-visible,
.biz-week__add:focus-visible {
    outline: 2px solid var(--azure);
    outline-offset: 2px;
}

.biz-week__dow {
    color: var(--text-secondary);
    font-size: var(--text-sm);
}

.biz-week__date {
    font-size: var(--text-lg);
}

.biz-week__count {
    margin-left: auto;
    color: var(--text-muted);
    font-family: var(--font-mono);
    font-size: var(--text-xs);
}

.biz-week__list {
    display: flex;
    flex-direction: column;
    gap: var(--space-1);
    margin: 0;
    padding: 0;
    list-style: none;
}

.biz-week__item {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    width: 100%;
    min-height: 40px;
    padding: 0 var(--space-2);
    border: 0;
    border-left: 3px solid var(--azure);
    border-radius: var(--radius-xs);
    background: var(--surface-2);
    color: var(--text-primary);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    text-align: left;
    cursor: pointer;
}

.biz-week__item--pending { border-left-color: var(--signal); }
.biz-week__item--completed { border-left-color: var(--success); color: var(--text-secondary); }
.biz-week__item--no_show { border-left-color: var(--danger); color: var(--text-muted); }

.biz-week__client {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.biz-week__add {
    align-self: flex-start;
    min-height: 36px;
    padding: 0 var(--space-3);
    border: 1px dashed var(--border-strong);
    border-radius: var(--radius-sm);
    background: none;
    color: var(--text-secondary);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    cursor: pointer;
}

@media (min-width: 1024px) {
    .biz-week {
        display: grid;
        grid-template-columns: repeat(7, minmax(0, 1fr));
        align-items: start;
    }

    .biz-week__day {
        min-height: 320px;
    }
}
` },
    { path: 'src/styles/business/day.css', content: `.biz-setup {
    padding: var(--space-4);
    border: 1px solid var(--border-medium);
    border-left: 3px solid var(--signal);
    border-radius: var(--radius-md);
    background: var(--surface-1);
}

.biz-setup__list {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
    margin: 0;
    padding: 0;
    list-style: none;
    font-size: var(--text-sm);
}

.biz-setup__list li {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    min-height: 32px;
}

.biz-setup__list li.is-done {
    color: var(--text-muted);
}

.biz-setup__list li.is-done svg {
    color: var(--success);
}

.biz-setup__list a {
    color: var(--azure-link);
}

.biz-setup__dot {
    width: 16px;
    height: 16px;
    border: 1px solid var(--text-muted);
    border-radius: var(--radius-full);
}

.biz-daysum {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-2) var(--space-5);
    margin: 0;
    color: var(--text-secondary);
    font-size: var(--text-sm);
}

.biz-daysum strong {
    color: var(--text-primary);
    font-weight: var(--font-weight-medium);
}

.biz-daysum__warn strong {
    color: var(--signal);
}

.biz-next {
    display: grid;
    grid-template-columns: auto 1fr;
    grid-template-areas:
        "label label"
        "time who"
        "time what";
    column-gap: var(--space-4);
    align-items: center;
    width: 100%;
    padding: var(--space-4);
    border: 1px solid var(--border-medium);
    border-radius: var(--radius-lg);
    background: var(--surface-2);
    color: var(--text-primary);
    font-family: var(--font-body);
    text-align: left;
    cursor: pointer;
}

.biz-next:focus-visible {
    outline: 2px solid var(--azure);
    outline-offset: 2px;
}

.biz-next__label {
    grid-area: label;
    margin-bottom: var(--space-2);
    color: var(--text-secondary);
    font-size: var(--text-sm);
}

.biz-next__time {
    grid-area: time;
    font-size: var(--text-3xl);
    line-height: 1;
}

.biz-next__who {
    grid-area: who;
    font-family: var(--font-display);
    font-size: var(--text-lg);
    font-weight: var(--font-weight-semibold);
}

.biz-next__what {
    grid-area: what;
    color: var(--text-secondary);
    font-size: var(--text-sm);
}

.biz-share {
    padding-top: var(--space-4);
    border-top: 1px solid var(--border-subtle);
}

.biz-share__link {
    margin: 0 0 var(--space-3);
    color: var(--text-secondary);
    font-family: var(--font-mono);
    font-size: var(--text-sm);
    word-break: break-all;
}

.biz-share__actions {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-2);
}

.biz-rail {
    overflow-x: auto;
    border: 1px solid var(--border-subtle);
    border-radius: var(--radius-lg);
    background: var(--surface-0);
}

.biz-rail__heads {
    position: sticky;
    top: 0;
    z-index: 3;
    display: flex;
    background: var(--surface-1);
    border-bottom: 1px solid var(--border-subtle);
}

.biz-rail__head {
    flex: 1 0 160px;
    padding: var(--space-2) var(--space-3);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
}

.biz-rail__body {
    position: relative;
    display: flex;
    box-sizing: content-box;
    padding: var(--space-3) 0;
}

.biz-rail__gutter {
    position: relative;
    flex: none;
    width: 52px;
}

.biz-rail__hour {
    position: absolute;
    right: var(--space-2);
    transform: translateY(-50%);
    color: var(--text-muted);
    font-family: var(--font-mono);
    font-size: 11px;
}

.biz-rail__col {
    position: relative;
    flex: 1 0 auto;
    min-width: 0;
    border-left: 1px solid var(--border-subtle);
    cursor: copy;
}

.biz-rail--multi .biz-rail__col {
    flex: 1 0 160px;
}

.biz-rail__line {
    position: absolute;
    left: 0;
    right: 0;
    height: 1px;
    background: var(--border-subtle);
    pointer-events: none;
}

.biz-rail__open {
    position: absolute;
    left: 0;
    right: 0;
    background: var(--surface-1);
    pointer-events: none;
}

.biz-rail__block {
    position: absolute;
    left: 4px;
    right: 4px;
    z-index: 1;
    padding: var(--space-1) var(--space-2);
    border: 1px dashed var(--border-strong);
    border-radius: var(--radius-sm);
    background: var(--surface-0);
    color: var(--text-muted);
    font-size: var(--text-xs);
    pointer-events: none;
    overflow: hidden;
}

.biz-booking {
    position: absolute;
    left: 4px;
    right: 4px;
    z-index: 2;
    display: flex;
    flex-direction: column;
    gap: 2px;
    padding: var(--space-2) var(--space-3);
    overflow: hidden;
    border: 1px solid var(--border-medium);
    border-left: 3px solid var(--azure);
    border-radius: var(--radius-sm);
    background: var(--surface-3);
    color: var(--text-primary);
    font-family: var(--font-body);
    text-align: left;
    cursor: pointer;
}

.biz-booking:focus-visible {
    outline: 2px solid var(--azure);
    outline-offset: 1px;
}

.biz-booking--pending { border-left-color: var(--signal); }
.biz-booking--completed { border-left-color: var(--success); background: var(--surface-2); color: var(--text-secondary); }
.biz-booking--no_show { border-left-color: var(--danger); background: var(--surface-2); color: var(--text-muted); }
.biz-booking--no_show .biz-booking__who { text-decoration: line-through; }

.biz-booking__time {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    color: var(--text-secondary);
    font-family: var(--font-mono);
    font-size: 11px;
}

.biz-booking__flag {
    color: var(--signal);
    font-family: var(--font-body);
}

.biz-booking__who {
    font-size: var(--text-sm);
    font-weight: var(--font-weight-semibold);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.biz-booking__what {
    color: var(--text-secondary);
    font-size: var(--text-xs);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.biz-booking--compact {
    flex-direction: row;
    align-items: center;
    gap: var(--space-2);
    padding-top: 0;
    padding-bottom: 0;
}

.biz-booking--compact .biz-booking__what,
.biz-booking--compact .biz-booking__flag {
    display: none;
}

.biz-rail__now {
    position: absolute;
    left: 52px;
    right: 0;
    z-index: 4;
    height: 2px;
    background: var(--signal);
    pointer-events: none;
}

.biz-rail__now-label {
    position: absolute;
    left: -50px;
    top: -9px;
    padding: 1px var(--space-1);
    border-radius: var(--radius-xs);
    background: var(--signal);
    color: var(--surface-0);
    font-family: var(--font-mono);
    font-size: 11px;
    font-weight: var(--font-weight-medium);
}
` },
    { path: 'src/styles/business/shell.css', content: `.biz-shell,
.biz-bare {
    min-height: 100vh;
    min-height: 100dvh;
    background: var(--surface-0);
    color: var(--text-primary);
    font-family: var(--font-body);
}

.biz-wordmark {
    font-family: var(--font-display);
    font-weight: var(--font-weight-semibold);
    font-size: var(--text-lg);
    letter-spacing: var(--tracking-tight);
}

.biz-wordmark__accent {
    color: var(--azure);
}

.biz-num {
    font-family: var(--font-mono);
    font-variant-numeric: tabular-nums;
}

.biz-muted {
    color: var(--text-muted);
}

.biz-visually-hidden {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip: rect(0 0 0 0);
    white-space: nowrap;
}

.biz-sidebar {
    display: none;
}

.biz-topbar {
    position: sticky;
    top: 0;
    z-index: var(--z-header);
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--space-3);
    height: 56px;
    padding: 0 var(--space-4);
    padding-top: env(safe-area-inset-top, 0px);
    box-sizing: content-box;
    background: var(--surface-0);
    border-bottom: 1px solid var(--border-subtle);
}

.biz-topbar__name {
    font-family: var(--font-display);
    font-weight: var(--font-weight-semibold);
    font-size: var(--text-base);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.biz-topbar__new {
    display: none;
}

.biz-content {
    padding: var(--space-4) var(--space-4) calc(96px + env(safe-area-inset-bottom, 0px));
}

.biz-page {
    max-width: 960px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    gap: var(--space-4);
}

.biz-page__head {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: var(--space-3);
}

.biz-page__title {
    margin: 0;
    font-family: var(--font-display);
    font-size: var(--text-3xl);
    font-weight: var(--font-weight-semibold);
    letter-spacing: var(--tracking-tight);
    line-height: var(--leading-tight);
}

.biz-page__sub {
    margin: var(--space-1) 0 0;
    color: var(--text-secondary);
    font-size: var(--text-sm);
}

.biz-subhead {
    margin: 0 0 var(--space-2);
    font-family: var(--font-display);
    font-size: var(--text-base);
    font-weight: var(--font-weight-semibold);
}

.biz-state {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: var(--space-3);
    min-height: 40vh;
    color: var(--text-secondary);
    font-size: var(--text-sm);
}

.biz-empty {
    margin: 0;
    color: var(--text-secondary);
    font-size: var(--text-sm);
}

.biz-error {
    margin: 0;
    padding: var(--space-3);
    border: 1px solid var(--danger);
    border-radius: var(--radius-md);
    color: var(--text-primary);
    font-size: var(--text-sm);
}

.biz-hint {
    margin: 0;
    color: var(--text-muted);
    font-size: var(--text-sm);
}

.biz-tabbar {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: var(--z-header);
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    padding-bottom: env(safe-area-inset-bottom, 0px);
    background: var(--surface-1);
    border-top: 1px solid var(--border-medium);
}

.biz-tab {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 2px;
    min-height: 56px;
    padding: var(--space-1) 0;
    border: 0;
    background: none;
    color: var(--text-muted);
    font-family: var(--font-body);
    font-size: 11px;
    font-weight: var(--font-weight-medium);
    text-decoration: none;
    cursor: pointer;
}

.biz-tab.active {
    color: var(--text-primary);
}

.biz-tab.active svg {
    color: var(--azure);
}

.biz-tab:focus-visible,
.biz-navlink:focus-visible,
.biz-icon-btn:focus-visible,
.biz-fab:focus-visible,
.biz-chip:focus-visible,
.biz-slot:focus-visible,
.biz-seg__btn:focus-visible,
.biz-textbtn:focus-visible {
    outline: 2px solid var(--azure);
    outline-offset: 2px;
}

.biz-fab {
    position: fixed;
    right: var(--space-4);
    bottom: calc(72px + env(safe-area-inset-bottom, 0px));
    z-index: var(--z-header);
    display: grid;
    place-items: center;
    width: 56px;
    height: 56px;
    border: 0;
    border-radius: var(--radius-full);
    background: var(--azure);
    color: var(--text-primary);
    box-shadow: var(--shadow-md);
    cursor: pointer;
}

.biz-fab:active {
    background: var(--azure-soft);
}

.biz-navlink {
    display: flex;
    align-items: center;
    gap: var(--space-3);
    width: 100%;
    min-height: 44px;
    padding: 0 var(--space-3);
    border: 0;
    border-radius: var(--radius-md);
    background: none;
    color: var(--text-secondary);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
    text-align: left;
    text-decoration: none;
    cursor: pointer;
}

.biz-navlink:hover {
    background: var(--surface-2);
    color: var(--text-primary);
}

.biz-navlink.active {
    background: var(--surface-2);
    color: var(--text-primary);
}

.biz-navlink.active svg {
    color: var(--azure);
}

.biz-morelist {
    display: flex;
    flex-direction: column;
    gap: var(--space-1);
}

.biz-icon-btn {
    display: grid;
    place-items: center;
    width: 44px;
    height: 44px;
    border: 1px solid var(--border-medium);
    border-radius: var(--radius-full);
    background: var(--surface-1);
    color: var(--text-primary);
    cursor: pointer;
}

.biz-icon-btn:hover {
    background: var(--surface-2);
}

.biz-textbtn {
    align-self: flex-start;
    padding: var(--space-2) 0;
    border: 0;
    background: none;
    color: var(--azure-link);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    text-decoration: none;
    cursor: pointer;
}

.biz-chips {
    display: flex;
    gap: var(--space-2);
    overflow-x: auto;
    padding-bottom: var(--space-1);
}

.biz-chip {
    flex: none;
    min-height: 36px;
    padding: 0 var(--space-4);
    border: 1px solid var(--border-medium);
    border-radius: var(--radius-full);
    background: var(--surface-1);
    color: var(--text-secondary);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    cursor: pointer;
}

.biz-chip.is-selected {
    border-color: var(--azure);
    color: var(--text-primary);
}

.biz-seg {
    display: inline-flex;
    padding: 3px;
    border: 1px solid var(--border-medium);
    border-radius: var(--radius-full);
    background: var(--surface-1);
}

.biz-seg__btn {
    min-height: 36px;
    min-width: 64px;
    padding: 0 var(--space-3);
    border: 0;
    border-radius: var(--radius-full);
    background: none;
    color: var(--text-secondary);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
    cursor: pointer;
}

.biz-seg__btn.is-selected {
    background: var(--surface-3);
    color: var(--text-primary);
}

.biz-form {
    display: flex;
    flex-direction: column;
    gap: var(--space-4);
}

.biz-field {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
    min-width: 0;
    margin: 0;
    padding: 0;
    border: 0;
}

.biz-field__label {
    padding: 0;
    color: var(--text-secondary);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
}

.biz-optional {
    color: var(--text-muted);
    font-weight: var(--font-weight-normal);
}

.biz-field-row {
    display: grid;
    grid-template-columns: 1fr;
    gap: var(--space-4);
}

.biz-input {
    width: 100%;
    min-height: 48px;
    padding: 0 var(--space-3);
    border: 1px solid var(--border-medium);
    border-radius: var(--radius-md);
    background: var(--surface-1);
    color: var(--text-primary);
    font-family: var(--font-body);
    font-size: 16px;
    color-scheme: dark;
}

.biz-input:focus {
    outline: none;
    border-color: var(--azure);
}

.biz-input--area {
    min-height: 72px;
    padding: var(--space-3);
    resize: vertical;
}

.biz-slots {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(72px, 1fr));
    gap: var(--space-2);
    max-height: 212px;
    overflow-y: auto;
}

.biz-slot {
    min-height: 44px;
    border: 1px solid var(--border-medium);
    border-radius: var(--radius-md);
    background: var(--surface-1);
    color: var(--text-primary);
    font-family: var(--font-mono);
    font-size: var(--text-sm);
    cursor: pointer;
}

.biz-slot.is-selected {
    border-color: var(--azure);
    background: var(--surface-3);
}

.biz-sheet {
    position: fixed;
    inset: 0;
    z-index: var(--z-modal);
    display: flex;
    align-items: flex-end;
    background: rgba(8, 9, 12, 0.72);
}

.biz-sheet__panel {
    display: flex;
    flex-direction: column;
    width: 100%;
    max-height: 92dvh;
    background: var(--surface-1);
    border-top: 1px solid var(--border-medium);
    border-radius: var(--radius-xl) var(--radius-xl) 0 0;
    animation: biz-sheet-up var(--transition-base);
}

.biz-sheet__panel:focus {
    outline: none;
}

.biz-sheet__head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--space-3);
    padding: var(--space-4) var(--space-4) var(--space-2);
}

.biz-sheet__title {
    margin: 0;
    font-family: var(--font-display);
    font-size: var(--text-xl);
    font-weight: var(--font-weight-semibold);
}

.biz-sheet__body {
    flex: 1;
    overflow-y: auto;
    padding: var(--space-2) var(--space-4) var(--space-4);
    display: flex;
    flex-direction: column;
    gap: var(--space-4);
}

.biz-sheet__foot {
    padding: var(--space-3) var(--space-4) calc(var(--space-3) + env(safe-area-inset-bottom, 0px));
    border-top: 1px solid var(--border-subtle);
}

@keyframes biz-sheet-up {
    from { transform: translateY(24px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

.biz-facts {
    display: flex;
    flex-direction: column;
    gap: var(--space-3);
    margin: 0;
}

.biz-facts div {
    display: grid;
    grid-template-columns: 72px 1fr;
    gap: var(--space-3);
}

.biz-facts dt {
    color: var(--text-muted);
    font-size: var(--text-sm);
}

.biz-facts dd {
    margin: 0;
    font-size: var(--text-sm);
}

.biz-status {
    display: inline-flex;
    align-items: center;
    gap: var(--space-2);
}

.biz-status::before {
    content: '';
    width: 8px;
    height: 8px;
    border-radius: var(--radius-full);
    background: var(--text-subtle);
}

.biz-status--pending::before { background: var(--signal); }
.biz-status--confirmed::before { background: var(--azure); }
.biz-status--completed::before { background: var(--success); }
.biz-status--no_show::before { background: var(--danger); }

.biz-contact {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(96px, 1fr));
    gap: var(--space-2);
}

.biz-contact__btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: var(--space-2);
    min-height: 48px;
    border: 1px solid var(--border-medium);
    border-radius: var(--radius-md);
    background: var(--surface-2);
    color: var(--text-primary);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
    text-decoration: none;
}

.biz-actions {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: var(--space-2);
}

.biz-actions .btn:first-child {
    grid-column: 1 / -1;
}

.biz-move {
    padding-top: var(--space-4);
    border-top: 1px solid var(--border-subtle);
}

.biz-toast {
    position: fixed;
    left: 50%;
    bottom: calc(140px + env(safe-area-inset-bottom, 0px));
    z-index: var(--z-tooltip);
    transform: translateX(-50%);
    pointer-events: none;
}

.biz-toast__msg {
    display: block;
    padding: var(--space-3) var(--space-5);
    border: 1px solid var(--border-strong);
    border-radius: var(--radius-full);
    background: var(--surface-3);
    color: var(--text-primary);
    font-size: var(--text-sm);
    white-space: nowrap;
}

@media (min-width: 640px) {
    .biz-field-row {
        grid-template-columns: 1fr 1fr;
    }
}

@media (min-width: 768px) {
    .biz-sheet {
        align-items: stretch;
        justify-content: flex-end;
    }

    .biz-sheet__panel {
        width: 440px;
        max-height: none;
        border-top: 0;
        border-left: 1px solid var(--border-medium);
        border-radius: 0;
        animation-name: biz-sheet-in;
    }

    @keyframes biz-sheet-in {
        from { transform: translateX(24px); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
}

@media (min-width: 1024px) {
    .biz-shell {
        display: grid;
        grid-template-columns: 248px 1fr;
    }

    .biz-sidebar {
        position: sticky;
        top: 0;
        display: flex;
        flex-direction: column;
        gap: var(--space-6);
        height: 100vh;
        padding: var(--space-5) var(--space-3);
        background: var(--surface-1);
        border-right: 1px solid var(--border-subtle);
    }

    .biz-sidebar__brand {
        display: flex;
        flex-direction: column;
        gap: var(--space-1);
        padding: 0 var(--space-3);
    }

    .biz-sidebar__business {
        color: var(--text-secondary);
        font-size: var(--text-sm);
    }

    .biz-sidebar__nav {
        display: flex;
        flex-direction: column;
        gap: var(--space-1);
    }

    .biz-sidebar__foot {
        margin-top: auto;
        display: flex;
        flex-direction: column;
        gap: var(--space-1);
    }

    .biz-sidebar__who {
        margin: var(--space-3) 0 0;
        padding: var(--space-3) var(--space-3) 0;
        border-top: 1px solid var(--border-subtle);
        font-size: var(--text-sm);
        display: flex;
        flex-direction: column;
    }

    .biz-sidebar__who span {
        color: var(--text-muted);
        font-size: var(--text-xs);
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .biz-main {
        min-width: 0;
    }

    .biz-topbar__new {
        display: inline-flex;
    }

    .biz-tabbar,
    .biz-fab {
        display: none;
    }

    .biz-content {
        padding: var(--space-8) var(--space-8) var(--space-12);
    }

    .biz-toast {
        bottom: var(--space-8);
    }
}

@media (prefers-reduced-motion: reduce) {
    .biz-sheet__panel {
        animation: none;
    }
}
` },
]

const PATCHES = [
    {
        file: 'src/BookingApp.jsx',
        edits: [
            { desc: "Business shell and new screens replace the old portal layout", find: `import PortalLayout from './pages/portal/PortalLayout'
import PortalDashboard from './pages/portal/Dashboard'
import PortalProfile from './pages/portal/Profile'
import PortalServices from './pages/portal/Services'
import PortalAvailability from './pages/portal/Availability'
import PortalAppointments from './pages/portal/Appointments'
import PortalSettings from './pages/portal/Settings'
`, replace: `import BusinessShell from './components/business/BusinessShell'
import Today from './pages/business/Today'
import Calendar from './pages/business/Calendar'
import PortalProfile from './pages/portal/Profile'
import PortalServices from './pages/portal/Services'
import PortalAvailability from './pages/portal/Availability'
import PortalSettings from './pages/portal/Settings'
` },
            { desc: "Business routes", find: `                            <PortalLayout />
                        </ProtectedRoute>
                    }
                >
                    <Route index element={<PortalDashboard />} />
                    <Route path="profile" element={<PortalProfile />} />
                    <Route path="services" element={<PortalServices />} />
                    <Route path="availability" element={<PortalAvailability />} />
                    <Route path="appointments" element={<PortalAppointments />} />
                    <Route path="settings" element={<PortalSettings />} />
                </Route>`, replace: `                            <BusinessShell />
                        </ProtectedRoute>
                    }
                >
                    <Route index element={<Today />} />
                    <Route path="calendar" element={<Calendar />} />
                    <Route path="services" element={<PortalServices />} />
                    <Route path="hours" element={<PortalAvailability />} />
                    <Route path="page" element={<PortalProfile />} />
                    <Route path="settings" element={<PortalSettings />} />
                    <Route path="appointments" element={<Navigate to="/portal/calendar" replace />} />
                    <Route path="availability" element={<Navigate to="/portal/hours" replace />} />
                    <Route path="profile" element={<Navigate to="/portal/page" replace />} />
                    <Route path="*" element={<Navigate to="/portal" replace />} />
                </Route>` },
        ],
    },
]

const RETIRES = ['src/pages/portal/PortalLayout.jsx', 'src/pages/portal/Dashboard.jsx', 'src/pages/portal/Appointments.jsx', 'src/styles/portal/portal.css', 'src/styles/portal/appointments.css']

let failed = false

for (const nf of NEW_FILES) {
    const full = path.join(REPO, nf.path)
    if (fs.existsSync(full)) { console.error(`[FAIL] Already exists: ${nf.path}`); failed = true }
    if (!fs.existsSync(path.join(REPO, 'src'))) { console.error(`[FAIL] No src folder for: ${nf.path}`); failed = true }
}

const fileChanges = new Map()
for (const group of PATCHES) {
    const fullPath = path.join(REPO, group.file)
    if (!fs.existsSync(fullPath)) { console.error(`[FAIL] Missing: ${group.file}`); failed = true; continue }
    let content = fs.readFileSync(fullPath, 'utf8')
    const original = content
    const crlf = (content.match(/\r\n/g) || []).length
    const lf = (content.match(/\n/g) || []).length - crlf
    const eol = crlf > lf ? '\r\n' : '\n'
    let ok = true
    for (const edit of group.edits) {
        // Anchors accept CRLF or LF; replacements follow the file's dominant ending.
        const pattern = edit.find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\n/g, '\\r?\\n')
        const matches = (content.match(new RegExp(pattern, 'g')) || []).length
        if (matches !== 1) {
            console.error(`[FAIL] ${group.file}: ${matches} matches for "${edit.desc}" (expected 1)`)
            failed = true; ok = false; break
        }
        const replace = edit.replace.replace(/\n/g, eol)
        content = content.replace(new RegExp(pattern), () => replace)
    }
    if (ok) fileChanges.set(fullPath, { original, modified: content, edits: group.edits })
}

const retirePaths = []
for (const rel of RETIRES) {
    const full = path.join(REPO, rel)
    if (!fs.existsSync(full)) { console.error(`[FAIL] Retire target missing: ${rel}`); failed = true; continue }
    if (fs.existsSync(`${full}.mistake`)) { console.error(`[FAIL] Already retired: ${rel}.mistake`); failed = true; continue }
    retirePaths.push({ full, rel })
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const nf of NEW_FILES) {
    fs.mkdirSync(path.dirname(path.join(REPO, nf.path)), { recursive: true })
    fs.writeFileSync(path.join(REPO, nf.path), nf.content)
    console.log(`[NEW] ${nf.path}`)
}
for (const [fullPath, change] of fileChanges) {
    fs.writeFileSync(`${fullPath}.backup`, change.original)
    fs.writeFileSync(fullPath, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, fullPath)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}
for (const { full, rel } of retirePaths) {
    fs.renameSync(full, `${full}.mistake`)
    console.log(`[RETIRE] ${rel} -> .mistake`)
}

console.log('\n[DONE]')
