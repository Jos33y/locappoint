// LocAppoint notification sender. Deployed from the dashboard as the "notify" Edge Function.
// Source of truth: supabase/functions/notify/index.ts in the repo. The dashboard keeps no history.
//
// Sends account emails from accounts@ and booking emails from bookings@relay.locappoint.com.
// Secrets (Edge Functions, Secrets): RESEND_API_KEY, NOTIFY_SECRET, and optionally SITE_URL.
// Turn off "Verify JWT" for this function. It checks NOTIFY_SECRET instead.

import { createClient } from 'npm:@supabase/supabase-js@2'

const SITE = (Deno.env.get('SITE_URL') || 'https://locappoint.com').replace(/\/$/, '')
const FROM_ACCOUNTS = 'LocAppoint <accounts@relay.locappoint.com>'
const REPLY_TO = 'hello@locappoint.com'
const MAX_ATTEMPTS = 5

const db = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, {
    auth: { persistSession: false },
})

type Row = {
    id: string
    kind: string
    channel: string
    recipient_email: string | null
    appointment_id: string | null
    payload: Record<string, unknown>
    attempts: number
}

type Day = {
    title: string
    preheader: string
    h1: string
    sub: string
    email: string
    done: string
    slotTitle: string
    slotSub: string
    button: string
    buttonWidth: number
    href: string
    next: string
    small: string
}

type Message = { from: string; to: string; subject: string; html: string; text: string }

const esc = (value: unknown) =>
    String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!)

const dayEmail = (o: Day) => `<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="x-apple-disable-message-reformatting">
    <meta name="format-detection" content="telephone=no, date=no, address=no, email=no, url=no">
    <meta name="color-scheme" content="light">
    <meta name="supported-color-schemes" content="light">
    <title>${o.title}</title>
    <!--[if mso]>
    <noscript><xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml></noscript>
    <style>table, td, p, a, h1, div, span { font-family: Arial, sans-serif !important; }</style>
    <![endif]-->
    <style>
        :root { color-scheme: light; supported-color-schemes: light; }
        body { margin:0; padding:0; background-color:#FAFBFC; -webkit-font-smoothing:antialiased; -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; }
        table { border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; }
        img { border:0; outline:none; text-decoration:none; -ms-interpolation-mode:bicubic; }
        a { text-decoration:none; }
        u + #body a, #MessageViewBody a { color:inherit; text-decoration:none; font-size:inherit; font-family:inherit; font-weight:inherit; line-height:inherit; }

        @media only screen and (max-width: 600px) {
            .outer { padding:28px 0 !important; }
            .container { width:100% !important; max-width:100% !important; }
            .pad { padding-left:20px !important; padding-right:20px !important; }
            .h1 { font-size:30px !important; }
            .day { padding:18px 14px 20px !important; }
            .gutter { width:48px !important; }
            .slot-pad { padding:18px 16px !important; }
            .slot-title { font-size:17px !important; }
            .slot-text { display:block !important; width:100% !important; }
            .cta-cell { display:block !important; width:100% !important; padding:14px 0 0 !important; text-align:left !important; }
            .cta-table { width:100% !important; }
            .cta-link { display:block !important; text-align:center !important; }
            .foot-right { display:block !important; text-align:left !important; padding-top:10px !important; }
            .foot-left { display:block !important; width:100% !important; }
        }
    </style>
</head>
<body id="body" style="margin:0; padding:0; background-color:#FAFBFC; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">

<div style="display:none; max-height:0; overflow:hidden; mso-hide:all; font-size:1px; line-height:1px; color:#FAFBFC; opacity:0;">
    ${o.preheader}&#8199;&#65279;&#847;&#8199;&#65279;&#847;&#8199;&#65279;&#847;&#8199;&#65279;&#847;&#8199;&#65279;&#847;&#8199;&#65279;&#847;&#8199;&#65279;&#847;&#8199;&#65279;&#847;
</div>

<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#FAFBFC" style="background-color:#FAFBFC;">
    <tr>
        <td class="outer" align="center" style="padding:52px 16px;">

            <table role="presentation" class="container" width="560" cellpadding="0" cellspacing="0" border="0" style="width:560px; max-width:560px;">

                <!-- Masthead -->
                <tr>
                    <td class="pad" style="padding:0 8px 28px;">
                        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                            <tr>
                                <td align="left" valign="middle">
                                    <a href="https://locappoint.com" target="_blank" style="display:inline-block; line-height:0;">
                                        <img src="https://locappoint.com/loca-lockup-light.png" alt="LocAppoint" width="140" style="display:block; width:140px; max-width:140px; height:auto; border:0; font-family:Arial, sans-serif; font-size:20px; font-weight:700; color:#0B1530;" />
                                    </a>
                                </td>
                                <td align="right" valign="middle" style="font-family:'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size:12px; line-height:1.5; color:#4A5468; text-align:right;">
                                    38.7223&deg;N<br>9.1393&deg;W
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>

                <!-- Headline -->
                <tr>
                    <td class="pad" style="padding:0 8px 12px;">
                        <h1 class="h1" style="margin:0; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:36px; font-weight:700; letter-spacing:-0.035em; line-height:1.08; color:#0B1530;">
                            ${o.h1}
                        </h1>
                    </td>
                </tr>
                <tr>
                    <td class="pad" style="padding:0 8px 32px;">
                        <p style="margin:0; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:17px; line-height:1.55; color:#3D4660;">
                            ${o.sub}
                        </p>
                    </td>
                </tr>

                <!-- The day -->
                <tr>
                    <td class="pad" style="padding:0 8px;">
                        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#0B1530" style="background-color:#0B1530; border-radius:18px; border-collapse:separate;">
                            <tr>
                                <td class="day" style="padding:22px 24px 26px;">

                                    <!-- Day header -->
                                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                                        <tr>
                                            <td align="left" style="font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:13px; font-weight:600; color:#FFFFFF; padding-bottom:18px;">
                                                Today
                                            </td>
                                            <td align="right" style="font-family:'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size:12px; color:#A9B7D6; padding-bottom:18px; padding-left:12px; overflow-wrap:anywhere; word-break:break-word;">
                                                ${o.email}
                                            </td>
                                        </tr>
                                    </table>

                                    <!-- Done -->
                                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                                        <tr>
                                            <td class="gutter" width="58" valign="top" style="width:58px; padding-top:13px; font-family:'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size:12px; color:#A9B7D6;">
                                                done
                                            </td>
                                            <td valign="top" style="padding-bottom:10px;">
                                                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#16213F" style="background-color:#16213F; border-left:3px solid #3A4B75; border-radius:8px; border-collapse:separate;">
                                                    <tr>
                                                        <td style="padding:12px 14px; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:14px; line-height:1.3; color:#B4C1DD;">
                                                            ${o.done}
                                                        </td>
                                                        <td align="right" style="padding:12px 14px; font-family:Arial, sans-serif; font-size:14px; font-weight:700; color:#B4C1DD;">
                                                            &#10003;
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>

                                    <!-- Now line -->
                                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                                        <tr>
                                            <td class="gutter" width="58" valign="middle" style="width:58px; font-family:'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size:12px; font-weight:600; color:#E89A3E; line-height:12px;">
                                                now
                                            </td>
                                            <td valign="middle" style="padding:0;">
                                                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                                                    <tr>
                                                        <td width="10" height="10" bgcolor="#E89A3E" style="width:10px; height:10px; border-radius:5px; background-color:#E89A3E; font-size:0; line-height:0;">&nbsp;</td>
                                                        <td valign="middle" style="padding:0;">
                                                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                                                                <tr><td height="2" bgcolor="#E89A3E" style="height:2px; background-color:#E89A3E; font-size:0; line-height:0;">&nbsp;</td></tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>

                                    <!-- Your slot -->
                                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                                        <tr>
                                            <td class="gutter" width="58" style="width:58px; font-size:0; line-height:0;">&nbsp;</td>
                                            <td valign="top" style="padding:10px 0 10px;">
                                                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#184BA3" style="background-color:#184BA3; border-radius:12px; border-collapse:separate;">
                                                    <tr>
                                                        <td class="slot-pad" style="padding:20px 20px;">
                                                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                                                                <tr>
                                                                    <td class="slot-text" valign="middle">
                                                                        <p class="slot-title" style="margin:0 0 4px; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:19px; font-weight:700; letter-spacing:-0.01em; line-height:1.2; color:#FFFFFF;">
                                                                            ${o.slotTitle}
                                                                        </p>
                                                                        <p style="margin:0; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:13px; line-height:1.45; color:#EAF1FD;">
                                                                            ${o.slotSub}
                                                                        </p>
                                                                    </td>
                                                                    <td class="cta-cell" align="right" valign="middle" style="padding-left:14px;">
                                                                        <table role="presentation" class="cta-table" cellpadding="0" cellspacing="0" border="0" style="border-collapse:separate;">
                                                                            <tr>
                                                                                <td align="center" bgcolor="#FFFFFF" style="background-color:#FFFFFF; border-radius:999px;">
                                                                                    <!--[if mso]><v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" href="${o.href}" style="height:44px; v-text-anchor:middle; width:${o.buttonWidth}px;" arcsize="50%" stroke="f" fillcolor="#FFFFFF"><w:anchorlock/><center style="color:#0B1530; font-family:Arial, sans-serif; font-size:15px; font-weight:bold;">${o.button}</center></v:roundrect><![endif]-->
                                                                                    <!--[if !mso]><!-->
                                                                                    <a class="cta-link" href="${o.href}" target="_blank" style="display:inline-block; padding:13px 22px; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:15px; font-weight:700; line-height:18px; color:#0B1530; text-decoration:none; border-radius:999px; white-space:nowrap;">
                                                                                        ${o.button}
                                                                                    </a>
                                                                                    <!--<![endif]-->
                                                                                </td>
                                                                            </tr>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>

                                    <!-- Next -->
                                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                                        <tr>
                                            <td class="gutter" width="58" valign="top" style="width:58px; padding-top:13px; font-family:'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size:12px; color:#A9B7D6;">
                                                next
                                            </td>
                                            <td valign="top">
                                                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="border:1px dashed #33436A; border-radius:8px; border-collapse:separate;">
                                                    <tr>
                                                        <td style="padding:12px 14px; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:14px; line-height:1.3; color:#A9B7D6;">
                                                            ${o.next}
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>

                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>

                <!-- Small print -->
                <tr>
                    <td class="pad" style="padding:22px 8px 36px;">
                        <p style="margin:0; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:13px; line-height:1.6; color:#4A5468;">
                            ${o.small}
                        </p>
                    </td>
                </tr>

                <tr>
                    <td class="pad" style="padding:0 8px;">
                        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                            <tr><td style="border-top:1px solid rgba(11,21,48,0.10); font-size:0; line-height:0; height:1px;">&nbsp;</td></tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td class="pad" style="padding:22px 8px 32px;">
                        <p style="margin:0 0 10px; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:12px; font-weight:600; letter-spacing:0.08em; text-transform:uppercase; color:#4A5468;">
                            Button not working
                        </p>
                        <p style="margin:0; font-family:'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size:12px; line-height:1.55; word-break:break-all;">
                            <a href="${o.href}" target="_blank" style="color:#1A50AD; text-decoration:none;">${o.href}</a>
                        </p>
                    </td>
                </tr>
                <tr>
                    <td class="pad" style="padding:0 8px;">
                        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                            <tr><td style="border-top:1px solid rgba(11,21,48,0.10); font-size:0; line-height:0; height:1px;">&nbsp;</td></tr>
                        </table>
                    </td>
                </tr>

                <!-- Footer -->
                <tr>
                    <td class="pad" style="padding:26px 8px 0;">
                        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                            <tr>
                                <td class="foot-left" align="left" valign="top">
                                    <p style="margin:0 0 6px; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:12px; font-weight:600; letter-spacing:0.08em; text-transform:uppercase; color:#4A5468;">
                                        Lisbon &middot; Porto &middot; Lagos
                                    </p>
                                    <p style="margin:0; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:13px; line-height:1.5;">
                                        <a href="mailto:support@locappoint.com" style="color:#3D4660; text-decoration:none;">support@locappoint.com</a>
                                    </p>
                                </td>
                                <td class="foot-right" align="right" valign="top" style="font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:13px; line-height:1.5; color:#4A5468;">
                                    <a href="https://locappoint.com/terms" style="color:#4A5468; text-decoration:none;">Terms</a>
                                    &nbsp;<span style="color:#4A5468;">&middot;</span>&nbsp;
                                    <a href="https://locappoint.com/privacy" style="color:#4A5468; text-decoration:none;">Privacy</a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td class="pad" style="padding:22px 8px 0;">
                        <p style="margin:0; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:12px; line-height:1.5; color:#4A5468;">
                            &copy; 2026 LocAppoint. The booking platform for local businesses.
                        </p>
                    </td>
                </tr>

            </table>

        </td>
    </tr>
</table>

</body>
</html>
`

const plain = (o: Day, lines: string[]) =>
    [o.h1.replace(/&rsquo;/g, "'"), '', ...lines, '', `${o.button}: ${o.href.replace(/&amp;/g, '&')}`, '', 'LocAppoint, Lisbon, Porto and Lagos', 'support@locappoint.com'].join('\n')

const RENDER: Record<string, (row: Row) => Message | null> = {
    welcome_client: (row) => {
        const name = esc(row.payload.name)
        const o: Day = {
            title: 'Welcome in',
            preheader: 'Your LocAppoint account is confirmed. Find a place and book in under a minute.',
            h1: 'Welcome in.',
            sub: `${name ? `${name}, your` : 'Your'} LocAppoint account is confirmed. Here is your day so far.`,
            email: esc(row.recipient_email),
            done: 'Email confirmed',
            slotTitle: 'Find a place',
            slotSub: 'Barbers, salons and clinics taking bookings near you.',
            button: 'Find a place',
            buttonWidth: 150,
            href: `${SITE}/client/search`,
            next: 'Your first booking',
            small: 'You are getting this because you created a LocAppoint account. Questions? Reply to this email and a person reads it.',
        }
        return {
            from: FROM_ACCOUNTS,
            to: row.recipient_email!,
            subject: 'Welcome to LocAppoint',
            html: dayEmail(o),
            text: plain(o, ['Your LocAppoint account is confirmed.', 'Barbers, salons and clinics are taking bookings near you.']),
        }
    },
    welcome_business: (row) => {
        const name = esc(row.payload.name)
        const o: Day = {
            title: 'Welcome in',
            preheader: 'Your LocAppoint account is confirmed. Your booking page is next, about ten minutes.',
            h1: 'Welcome in.',
            sub: `${name ? `${name}, your` : 'Your'} LocAppoint account is confirmed. Here is your day so far.`,
            email: esc(row.recipient_email),
            done: 'Email confirmed',
            slotTitle: 'Set up your booking page',
            slotSub: 'Services, opening hours and a photo. About ten minutes.',
            button: 'Set up my page',
            buttonWidth: 170,
            href: `${SITE}/portal`,
            next: 'Your first booking',
            small: 'You are getting this because you created a LocAppoint business account. Stuck on anything? Reply to this email and a person reads it.',
        }
        return {
            from: FROM_ACCOUNTS,
            to: row.recipient_email!,
            subject: 'Welcome to LocAppoint. Your page is next.',
            html: dayEmail(o),
            text: plain(o, ['Your LocAppoint account is confirmed.', 'Next: services, opening hours and a photo. About ten minutes.']),
        }
    },
    business_live: (row) => {
        const name = esc(row.payload.name)
        const business = esc(row.payload.business_name) || 'Your business'
        const slug = String(row.payload.slug || '').replace(/[^a-z0-9-]/gi, '')
        const page = `${SITE}/${slug}`
        const shown = `${SITE.replace(/^https?:\/\//, '')}/${slug}`
        const auto = row.payload.auto_confirm !== false
        const o: Day = {
            title: 'You are live',
            preheader: `${business} is taking bookings on LocAppoint. Share your link and the first one can land today.`,
            h1: 'You&rsquo;re live.',
            sub: `${name ? `${name}, ` : ''}${business} is now taking bookings on LocAppoint. Here is your day so far.`,
            email: esc(shown),
            done: 'Booking page set up',
            slotTitle: 'Share your page',
            slotSub: `${esc(shown)} is ready for WhatsApp, Instagram and Google.`,
            button: 'View my page',
            buttonWidth: 160,
            href: page,
            next: 'Your first booking',
            small: `${auto ? 'New bookings are confirmed straight away and land in your calendar.' : 'New bookings wait in your calendar for you to confirm.'} Put the link in your Instagram bio and WhatsApp status, and print the QR code from <span style="color:#0B1530; font-weight:600;">Channels</span> for your counter. Questions? Reply to this email and a person reads it.`,
        }
        return {
            from: FROM_ACCOUNTS,
            to: row.recipient_email!,
            subject: `${String(row.payload.business_name || 'Your business')} is live on LocAppoint`,
            html: dayEmail(o),
            text: plain(o, [`${String(row.payload.business_name || 'Your business')} is now taking bookings on LocAppoint.`, `Your page: ${page}`, 'Put the link in your Instagram bio and WhatsApp status, and print the QR code from Channels for your counter.']),
        }
    },
}

// Booking emails. Same calendar-day idea as the account emails, but the day is the day of the
// booking and the slot is the booking itself: the time in the gutter, the service in the slot.

const BOOKINGS_ADDRESS = 'bookings@relay.locappoint.com'
const SANS = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif"
const MONO = "'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace"

type Slot = {
    state: 'booked' | 'waiting' | 'cancelled'
    time: string
    title: string
    sub: string
    flag?: string
    button?: { label: string; href: string; width: number }
}

type Booking = {
    title: string
    preheader: string
    h1: string
    sub: string
    day: string
    place: string
    was?: string
    slot: Slot
    where?: string
    small: string
}

const gutter = (label: string, style: string) =>
    `<td class="gutter" width="58" valign="top" style="width:58px; ${style} font-family:${MONO};">${label}</td>`

const wasRow = (text: string) => `
                                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                                        <tr>
                                            ${gutter('was', 'padding-top:13px; font-size:12px; color:#A9B7D6;')}
                                            <td valign="top" style="padding-bottom:10px;">
                                                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#16213F" style="background-color:#16213F; border-left:3px solid #3A4B75; border-radius:8px; border-collapse:separate;">
                                                    <tr>
                                                        <td style="padding:12px 14px; font-family:${SANS}; font-size:14px; line-height:1.3; color:#B4C1DD; text-decoration:line-through;">
                                                            ${text}
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>`

const pill = (b: NonNullable<Slot['button']>) => `
                                                                    <td class="cta-cell" align="right" valign="middle" style="padding-left:14px;">
                                                                        <table role="presentation" class="cta-table" cellpadding="0" cellspacing="0" border="0" style="border-collapse:separate;">
                                                                            <tr>
                                                                                <td align="center" bgcolor="#FFFFFF" style="background-color:#FFFFFF; border-radius:999px;">
                                                                                    <!--[if mso]><v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" href="${b.href}" style="height:44px; v-text-anchor:middle; width:${b.width}px;" arcsize="50%" stroke="f" fillcolor="#FFFFFF"><w:anchorlock/><center style="color:#0B1530; font-family:Arial, sans-serif; font-size:15px; font-weight:bold;">${b.label}</center></v:roundrect><![endif]-->
                                                                                    <!--[if !mso]><!-->
                                                                                    <a class="cta-link" href="${b.href}" target="_blank" style="display:inline-block; padding:13px 22px; font-family:${SANS}; font-size:15px; font-weight:700; line-height:18px; color:#0B1530; text-decoration:none; border-radius:999px; white-space:nowrap;">
                                                                                        ${b.label}
                                                                                    </a>
                                                                                    <!--<![endif]-->
                                                                                </td>
                                                                            </tr>
                                                                        </table>
                                                                    </td>`

const SLOT_LOOK = {
    booked: { box: 'bgcolor="#184BA3" style="background-color:#184BA3;', title: '#FFFFFF', sub: '#EAF1FD', flag: '#FFFFFF', strike: '', time: '#FFFFFF' },
    waiting: { box: 'style="border:2px dashed #E89A3E;', title: '#FFFFFF', sub: '#B4C1DD', flag: '#E89A3E', strike: '', time: '#E89A3E' },
    cancelled: { box: 'style="border:1px dashed #33436A;', title: '#B4C1DD', sub: '#A9B7D6', flag: '#B4C1DD', strike: ' text-decoration:line-through;', time: '#A9B7D6' },
}

const slotRow = (s: Slot) => {
    const look = SLOT_LOOK[s.state]
    return `
                                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                                        <tr>
                                            ${gutter(s.time, `padding-top:22px; font-size:15px; font-weight:700; color:${look.time};${look.strike}`)}
                                            <td valign="top" style="padding:0 0 10px;">
                                                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" ${look.box} border-radius:12px; border-collapse:separate;">
                                                    <tr>
                                                        <td class="slot-pad" style="padding:20px 20px;">
                                                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                                                                <tr>
                                                                    <td class="slot-text" valign="middle">
                                                                        ${s.flag ? `<p style="margin:0 0 8px; font-family:${MONO}; font-size:12px; font-weight:700; line-height:1.4; color:${look.flag};">${s.flag}</p>` : ''}
                                                                        <p class="slot-title" style="margin:0 0 4px; font-family:${SANS}; font-size:19px; font-weight:700; letter-spacing:-0.01em; line-height:1.2; color:${look.title};${look.strike}">
                                                                            ${s.title}
                                                                        </p>
                                                                        <p style="margin:0; font-family:${SANS}; font-size:13px; line-height:1.45; color:${look.sub};">
                                                                            ${s.sub}
                                                                        </p>
                                                                    </td>${s.button ? pill(s.button) : ''}
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>`
}

const whereRow = (text: string) => `
                                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                                        <tr>
                                            ${gutter('where', 'padding-top:13px; font-size:12px; color:#A9B7D6;')}
                                            <td valign="top">
                                                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="border:1px dashed #33436A; border-radius:8px; border-collapse:separate;">
                                                    <tr>
                                                        <td style="padding:12px 14px; font-family:${SANS}; font-size:14px; line-height:1.4; color:#B4C1DD;">
                                                            ${text}
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>`

const bookingEmail = (o: Booking) => `<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="x-apple-disable-message-reformatting">
    <meta name="format-detection" content="telephone=no, date=no, address=no, email=no, url=no">
    <meta name="color-scheme" content="light">
    <meta name="supported-color-schemes" content="light">
    <title>${o.title}</title>
    <!--[if mso]>
    <noscript><xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml></noscript>
    <style>table, td, p, a, h1, div, span { font-family: Arial, sans-serif !important; }</style>
    <![endif]-->
    <style>
        :root { color-scheme: light; supported-color-schemes: light; }
        body { margin:0; padding:0; background-color:#FAFBFC; -webkit-font-smoothing:antialiased; -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; }
        table { border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; }
        img { border:0; outline:none; text-decoration:none; -ms-interpolation-mode:bicubic; }
        a { text-decoration:none; }
        u + #body a, #MessageViewBody a { color:inherit; text-decoration:none; font-size:inherit; font-family:inherit; font-weight:inherit; line-height:inherit; }

        @media only screen and (max-width: 600px) {
            .outer { padding:28px 0 !important; }
            .container { width:100% !important; max-width:100% !important; }
            .pad { padding-left:20px !important; padding-right:20px !important; }
            .h1 { font-size:30px !important; }
            .day { padding:18px 14px 20px !important; }
            .gutter { width:48px !important; }
            .slot-pad { padding:18px 16px !important; }
            .slot-title { font-size:17px !important; }
            .slot-text { display:block !important; width:100% !important; }
            .cta-cell { display:block !important; width:100% !important; padding:14px 0 0 !important; text-align:left !important; }
            .cta-table { width:100% !important; }
            .cta-link { display:block !important; text-align:center !important; }
            .foot-right { display:block !important; text-align:left !important; padding-top:10px !important; }
            .foot-left { display:block !important; width:100% !important; }
        }
    </style>
</head>
<body id="body" style="margin:0; padding:0; background-color:#FAFBFC; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">

<div style="display:none; max-height:0; overflow:hidden; mso-hide:all; font-size:1px; line-height:1px; color:#FAFBFC; opacity:0;">
    ${o.preheader}&#8199;&#65279;&#847;&#8199;&#65279;&#847;&#8199;&#65279;&#847;&#8199;&#65279;&#847;&#8199;&#65279;&#847;&#8199;&#65279;&#847;&#8199;&#65279;&#847;&#8199;&#65279;&#847;
</div>

<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#FAFBFC" style="background-color:#FAFBFC;">
    <tr>
        <td class="outer" align="center" style="padding:52px 16px;">

            <table role="presentation" class="container" width="560" cellpadding="0" cellspacing="0" border="0" style="width:560px; max-width:560px;">

                <!-- Masthead -->
                <tr>
                    <td class="pad" style="padding:0 8px 28px;">
                        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                            <tr>
                                <td align="left" valign="middle">
                                    <a href="https://locappoint.com" target="_blank" style="display:inline-block; line-height:0;">
                                        <img src="https://locappoint.com/loca-lockup-light.png" alt="LocAppoint" width="140" style="display:block; width:140px; max-width:140px; height:auto; border:0; font-family:Arial, sans-serif; font-size:20px; font-weight:700; color:#0B1530;" />
                                    </a>
                                </td>
                                <td align="right" valign="middle" style="font-family:'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size:12px; line-height:1.5; color:#4A5468; text-align:right;">
                                    38.7223&deg;N<br>9.1393&deg;W
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>

                <!-- Headline -->
                <tr>
                    <td class="pad" style="padding:0 8px 12px;">
                        <h1 class="h1" style="margin:0; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:36px; font-weight:700; letter-spacing:-0.035em; line-height:1.08; color:#0B1530;">
                            ${o.h1}
                        </h1>
                    </td>
                </tr>
                <tr>
                    <td class="pad" style="padding:0 8px 32px;">
                        <p style="margin:0; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:17px; line-height:1.55; color:#3D4660;">
                            ${o.sub}
                        </p>
                    </td>
                </tr>

                <!-- The day -->
                <tr>
                    <td class="pad" style="padding:0 8px;">
                        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#0B1530" style="background-color:#0B1530; border-radius:18px; border-collapse:separate;">
                            <tr>
                                <td class="day" style="padding:22px 24px 26px;">

                                    <!-- Day header -->
                                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                                        <tr>
                                            <td align="left" style="font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:13px; font-weight:600; color:#FFFFFF; padding-bottom:18px;">
                                                ${o.day}
                                            </td>
                                            <td align="right" style="font-family:'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size:12px; color:#A9B7D6; padding-bottom:18px; padding-left:12px; overflow-wrap:anywhere; word-break:break-word;">
                                                ${o.place}
                                            </td>
                                        </tr>
                                    </table>

${o.was ? wasRow(o.was) : ''}${slotRow(o.slot)}${o.where ? whereRow(o.where) : ''}

                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>

                <!-- Small print -->
                <tr>
                    <td class="pad" style="padding:22px 8px 36px;">
                        <p style="margin:0; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:13px; line-height:1.6; color:#4A5468;">
                            ${o.small}
                        </p>
                    </td>
                </tr>

                <tr>
                    <td class="pad" style="padding:0 8px;">
                        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                            <tr><td style="border-top:1px solid rgba(11,21,48,0.10); font-size:0; line-height:0; height:1px;">&nbsp;</td></tr>
                        </table>
                    </td>
                </tr>
                <!-- Footer -->
                <tr>
                    <td class="pad" style="padding:26px 8px 0;">
                        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                            <tr>
                                <td class="foot-left" align="left" valign="top">
                                    <p style="margin:0 0 6px; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:12px; font-weight:600; letter-spacing:0.08em; text-transform:uppercase; color:#4A5468;">
                                        Lisbon &middot; Porto &middot; Lagos
                                    </p>
                                    <p style="margin:0; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:13px; line-height:1.5;">
                                        <a href="mailto:support@locappoint.com" style="color:#3D4660; text-decoration:none;">support@locappoint.com</a>
                                    </p>
                                </td>
                                <td class="foot-right" align="right" valign="top" style="font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:13px; line-height:1.5; color:#4A5468;">
                                    <a href="https://locappoint.com/terms" style="color:#4A5468; text-decoration:none;">Terms</a>
                                    &nbsp;<span style="color:#4A5468;">&middot;</span>&nbsp;
                                    <a href="https://locappoint.com/privacy" style="color:#4A5468; text-decoration:none;">Privacy</a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td class="pad" style="padding:22px 8px 0;">
                        <p style="margin:0; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:12px; line-height:1.5; color:#4A5468;">
                            &copy; 2026 LocAppoint. The booking platform for local businesses.
                        </p>
                    </td>
                </tr>

            </table>

        </td>
    </tr>
</table>

</body>
</html>
`

// Formatting. Dates arrive as the business's local date and time, so they are shown as they are.

const dateOf = (iso: string) => new Date(`${iso.slice(0, 10)}T12:00:00Z`)
const longDay = (iso: string) =>
    new Intl.DateTimeFormat('en-GB', { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'UTC' }).format(dateOf(iso))
const shortDay = (iso: string) =>
    new Intl.DateTimeFormat('en-GB', { weekday: 'short', day: 'numeric', month: 'short', timeZone: 'UTC' }).format(dateOf(iso)).replace('Sept', 'Sep')

const localToday = (tz: string, offsetDays = 0) => {
    const d = new Date(Date.now() + offsetDays * 86_400_000)
    try {
        return new Intl.DateTimeFormat('en-CA', { timeZone: tz }).format(d)
    } catch {
        return d.toISOString().slice(0, 10)
    }
}

const relativeDay = (iso: string, tz: string) => {
    if (iso === localToday(tz)) return 'today'
    if (iso === localToday(tz, 1)) return 'tomorrow'
    return `on ${longDay(iso)}`
}

const duration = (minutes: number) => {
    const h = Math.floor(minutes / 60)
    const m = minutes % 60
    return h ? `${h} h${m ? ` ${m} min` : ''}` : `${m} min`
}

const priceText = (price: unknown, country: unknown) => {
    if (price === null || price === undefined || price === '') return ''
    const n = Number(price)
    if (!Number.isFinite(n)) return ''
    if (n === 0) return 'Free'
    const nigeria = country === 'NG'
    return new Intl.NumberFormat(nigeria ? 'en-NG' : 'en-IE', {
        style: 'currency',
        currency: nigeria ? 'NGN' : 'EUR',
        minimumFractionDigits: Number.isInteger(n) ? 0 : 2,
    }).format(n)
}

const cutoffText = (minutes: number) => {
    if (!minutes) return 'any time before it starts'
    if (minutes % 60) return `up to ${minutes} minutes before`
    const h = minutes / 60
    return `up to ${h} hour${h === 1 ? '' : 's'} before`
}

const plainText = (value: string) => value.replace(/<[^>]+>/g, '').replace(/&middot;/g, '|').replace(/&rsquo;/g, "'").replace(/&amp;/g, '&').replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
const oneLine = (value: unknown) => String(value ?? '').replace(/[\r\n]+/g, ' ').trim()
const senderName = (value: string) => `"${value.replace(/["<>\\]/g, '').slice(0, 60)} via LocAppoint" <${BOOKINGS_ADDRESS}>`

const bookingFacts = (row: Row) => {
    const p = row.payload as Record<string, any>
    const date = String(p.date || '')
    const time = String(p.time || '')
    const bizRaw = oneLine(p.business_name) || 'the business'
    const clientRaw = oneLine(p.client_name) || 'A client'
    const serviceRaw = oneLine(p.service_name) || 'Booking'
    const price = priceText(p.price, p.country)
    const staff = oneLine(p.staff_name)
    const place = [oneLine(p.address), oneLine(p.city)].filter(Boolean)
    const contact = oneLine(p.business_whatsapp) || oneLine(p.business_phone)
    const movedFrom = p.moved_from ? String(p.moved_from) : ''
    return {
        p,
        date,
        time,
        tz: String(p.timezone || 'Europe/Lisbon'),
        bizRaw,
        clientRaw,
        serviceRaw,
        biz: esc(bizRaw),
        client: esc(clientRaw),
        service: esc(serviceRaw),
        short: `${shortDay(date)}, ${time}`,
        long: `${longDay(date)} at ${time}`,
        dayLabel: longDay(date),
        clientDetails: [duration(Number(p.duration_minutes) || 0), staff ? `with ${esc(staff)}` : '', price].filter(Boolean).join(' &middot; '),
        businessDetails: [esc(serviceRaw), duration(Number(p.duration_minutes) || 0), price, staff ? `with ${esc(staff)}` : ''].filter(Boolean).join(' &middot; '),
        where: place.length ? esc(place.join(', ')) : '',
        was: movedFrom ? `${shortDay(movedFrom)}, ${movedFrom.slice(11, 16)}` : '',
        contact: contact ? esc(contact) : '',
        cutoff: cutoffText(Number(p.cancel_cutoff_minutes) || 0),
        mine: `${SITE}/client/appointments?booking=${row.appointment_id}`,
        calendar: `${SITE}/portal/calendar?booking=${row.appointment_id}`,
        page: `${SITE}/${String(p.slug || '').replace(/[^a-z0-9-]/gi, '')}`,
    }
}

type Facts = ReturnType<typeof bookingFacts>

const bookingMessage = (row: Row, f: Facts, forClient: boolean, subject: string, o: Booking, lines: string[]): Message => ({
    from: forClient ? senderName(f.bizRaw) : `LocAppoint <${BOOKINGS_ADDRESS}>`,
    to: row.recipient_email!,
    subject,
    html: bookingEmail(o),
    text: [
        plainText(o.h1),
        '',
        ...lines,
        '',
        ...(o.slot.button ? [`${o.slot.button.label}: ${o.slot.button.href}`, ''] : []),
        plainText(o.small),
        '',
        'LocAppoint, Lisbon, Porto and Lagos',
        'support@locappoint.com',
    ].join('\n'),
})

const clientSmall = (f: Facts, lead: string) =>
    `${lead}${f.contact ? ` Need to reach ${f.biz}? Message them on ${f.contact}.` : ''}`

const VIEW = (f: Facts) => ({ label: 'View booking', href: f.mine, width: 150 })
const CALENDAR = (f: Facts) => ({ label: 'Open calendar', href: f.calendar, width: 160 })
const BOOK_AGAIN = (f: Facts) => ({ label: 'Pick a new time', href: f.page, width: 170 })

const forClient = (row: Row) => row.payload.audience !== 'business'

const BOOKING_RENDER: Record<string, (row: Row) => Message | null> = {
    booking_confirmed: (row) => {
        const f = bookingFacts(row)
        const o: Booking = {
            title: 'You are booked',
            preheader: `${f.service} at ${f.biz}, ${f.long}.`,
            h1: 'You&rsquo;re booked.',
            sub: `${f.biz} has you down for ${f.long}. Here is your day.`,
            day: f.dayLabel,
            place: f.biz,
            slot: { state: 'booked', time: f.time, title: f.service, sub: f.clientDetails, button: VIEW(f) },
            where: f.where,
            small: clientSmall(f, `Plans change. You can move or cancel it from your bookings ${f.cutoff}.`),
        }
        return bookingMessage(row, f, true, `Booked: ${f.serviceRaw} at ${f.bizRaw}, ${f.short}`, o,
            [`${f.serviceRaw} at ${f.bizRaw}`, `${f.long}`, plainText(f.clientDetails), f.where ? plainText(f.where) : ''].filter(Boolean))
    },

    booking_requested: (row) => {
        const f = bookingFacts(row)
        const o: Booking = {
            title: 'Request sent',
            preheader: `${f.biz} confirms bookings themselves. We will email you the moment they do.`,
            h1: 'Request sent.',
            sub: `${f.biz} confirms each booking themselves. We will email you the moment they do.`,
            day: f.dayLabel,
            place: f.biz,
            slot: { state: 'waiting', time: f.time, flag: `Waiting for ${f.biz}`, title: f.service, sub: f.clientDetails, button: VIEW(f) },
            where: f.where,
            small: clientSmall(f, 'The time is held for you while they decide.'),
        }
        return bookingMessage(row, f, true, `Request sent to ${f.bizRaw} for ${f.short}`, o,
            [`${f.serviceRaw} at ${f.bizRaw}`, f.long, `Waiting for ${f.bizRaw} to confirm.`])
    },

    booking_declined: (row) => {
        const f = bookingFacts(row)
        const o: Booking = {
            title: 'Not this time',
            preheader: `${f.biz} could not take your booking for ${f.short}. Other times are open.`,
            h1: 'Not this time.',
            sub: `${f.biz} could not take your booking for ${f.long}. Other times are open on their page.`,
            day: f.dayLabel,
            place: f.biz,
            slot: { state: 'cancelled', time: f.time, flag: 'Not accepted', title: f.service, sub: f.clientDetails, button: BOOK_AGAIN(f) },
            small: clientSmall(f, 'There is nothing else you need to do.'),
        }
        return bookingMessage(row, f, true, `${f.bizRaw} could not take your booking for ${f.short}`, o,
            [`${f.bizRaw} could not take your booking for ${f.long}.`, `Other times: ${f.page}`])
    },

    booking_cancelled: (row) => {
        const f = bookingFacts(row)
        if (forClient(row)) {
            const o: Booking = {
                title: 'Booking cancelled',
                preheader: `${f.biz} cancelled your booking for ${f.short}.`,
                h1: 'Booking cancelled.',
                sub: `${f.biz} cancelled your booking for ${f.long}. Sorry about that.`,
                day: f.dayLabel,
                place: f.biz,
                slot: { state: 'cancelled', time: f.time, flag: `Cancelled by ${f.biz}`, title: f.service, sub: f.clientDetails, button: BOOK_AGAIN(f) },
                small: clientSmall(f, 'There is nothing else you need to do.'),
            }
            return bookingMessage(row, f, true, `${f.bizRaw} cancelled your booking for ${f.short}`, o,
                [`${f.bizRaw} cancelled your booking for ${f.long}.`, `Pick a new time: ${f.page}`])
        }
        const o: Booking = {
            title: 'Booking cancelled',
            preheader: `${f.client} cancelled ${f.short}. The time is open again.`,
            h1: 'A slot opened up.',
            sub: `${f.client} cancelled ${f.service} for ${f.long}. The time is open for other clients again.`,
            day: f.dayLabel,
            place: f.biz,
            slot: { state: 'cancelled', time: f.time, flag: 'Cancelled by the client', title: f.client, sub: f.businessDetails, button: CALENDAR(f) },
            small: 'You do not need to do anything.',
        }
        return bookingMessage(row, f, false, `Cancelled: ${f.clientRaw}, ${f.short}`, o,
            [`${f.clientRaw} cancelled ${f.serviceRaw} for ${f.long}.`, 'The time is open again.'])
    },

    booking_moved: (row) => {
        const f = bookingFacts(row)
        if (forClient(row)) {
            const o: Booking = {
                title: 'New time',
                preheader: `${f.biz} moved your booking to ${f.long}.`,
                h1: 'New time.',
                sub: `${f.biz} moved your booking to ${f.long}.`,
                day: f.dayLabel,
                place: f.biz,
                was: f.was,
                slot: { state: 'booked', time: f.time, title: f.service, sub: f.clientDetails, button: VIEW(f) },
                where: f.where,
                small: clientSmall(f, `Does the new time not work? You can change or cancel it from your bookings ${f.cutoff}.`),
            }
            return bookingMessage(row, f, true, `New time: ${f.short} at ${f.bizRaw}`, o,
                [`${f.bizRaw} moved your booking.`, f.was ? `Was: ${f.was}` : '', `Now: ${f.long}`].filter(Boolean))
        }
        const o: Booking = {
            title: 'Booking moved',
            preheader: `${f.client} moved their booking to ${f.short}.`,
            h1: 'Booking moved.',
            sub: `${f.client} moved ${f.service} to ${f.long}.`,
            day: f.dayLabel,
            place: f.biz,
            was: f.was,
            slot: { state: 'booked', time: f.time, title: f.client, sub: f.businessDetails, button: CALENDAR(f) },
            small: 'It is already in your calendar. You do not need to do anything.',
        }
        return bookingMessage(row, f, false, `Moved: ${f.clientRaw} to ${f.short}`, o,
            [`${f.clientRaw} moved ${f.serviceRaw}.`, f.was ? `Was: ${f.was}` : '', `Now: ${f.long}`].filter(Boolean))
    },

    booking_reminder: (row) => {
        const f = bookingFacts(row)
        const when = relativeDay(f.date, f.tz)
        const o: Booking = {
            title: 'See you soon',
            preheader: `${f.service} at ${f.biz}, ${when} at ${f.time}.`,
            h1: when === 'tomorrow' ? 'See you tomorrow.' : when === 'today' ? 'See you today.' : 'See you soon.',
            sub: `${f.service} at ${f.biz}, ${when} at ${f.time}.`,
            day: f.dayLabel,
            place: f.biz,
            slot: { state: 'booked', time: f.time, title: f.service, sub: f.clientDetails, button: VIEW(f) },
            where: f.where,
            small: clientSmall(f, `Cannot make it? Cancel from your bookings ${f.cutoff}, so someone else can take the time.`),
        }
        const lead = when === 'tomorrow' ? 'Tomorrow' : when === 'today' ? 'Today' : shortDay(f.date)
        return bookingMessage(row, f, true, `${lead} at ${f.time}: ${f.serviceRaw} at ${f.bizRaw}`, o,
            [`${f.serviceRaw} at ${f.bizRaw}`, f.long, f.where ? plainText(f.where) : ''].filter(Boolean))
    },

    booking_new: (row) => {
        const f = bookingFacts(row)
        const o: Booking = {
            title: 'New booking',
            preheader: `${f.client} booked ${f.service} for ${f.long}.`,
            h1: 'New booking.',
            sub: `${f.client} booked ${f.service} for ${f.long}. It is confirmed and in your calendar.`,
            day: f.dayLabel,
            place: f.biz,
            slot: { state: 'booked', time: f.time, title: f.client, sub: f.businessDetails, button: CALENDAR(f) },
            small: f.p.client_phone ? `Their number is ${esc(f.p.client_phone)}, if you need to reach them.` : 'You do not need to do anything.',
        }
        return bookingMessage(row, f, false, `New booking: ${f.clientRaw}, ${f.short}`, o,
            [`${f.clientRaw} booked ${f.serviceRaw}.`, f.long, plainText(f.businessDetails)])
    },

    booking_request: (row) => {
        const f = bookingFacts(row)
        const moved = Boolean(f.was)
        const o: Booking = {
            title: 'Request to confirm',
            preheader: `${f.client} wants ${f.short}. Confirm or decline.`,
            h1: moved ? 'New time to confirm.' : 'New request.',
            sub: moved
                ? `${f.client} moved ${f.service} to ${f.long}. It needs your OK.`
                : `${f.client} wants ${f.service} on ${f.long}. The time is held until you answer.`,
            day: f.dayLabel,
            place: f.biz,
            was: f.was,
            slot: { state: 'waiting', time: f.time, flag: 'Waiting for you', title: f.client, sub: f.businessDetails, button: { label: 'Confirm or decline', href: f.calendar, width: 200 } },
            small: 'Answer soon. Clients book elsewhere when they wait too long. You can switch to automatic confirmation in Business page, Bookings.',
        }
        return bookingMessage(row, f, false, `${moved ? 'New time to confirm' : 'Request to confirm'}: ${f.clientRaw}, ${f.short}`, o,
            [moved ? `${f.clientRaw} moved ${f.serviceRaw} and it needs your OK.` : `${f.clientRaw} wants ${f.serviceRaw}.`, f.was ? `Was: ${f.was}` : '', f.long, `Confirm or decline: ${f.calendar}`].filter(Boolean))
    },
}

Object.assign(RENDER, BOOKING_RENDER)

const sendEmail = async (row: Row, msg: Message) => {
    const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
            Authorization: `Bearer ${Deno.env.get('RESEND_API_KEY')}`,
            'Content-Type': 'application/json',
            'Idempotency-Key': `notification-${row.id}`,
        },
        body: JSON.stringify({ ...msg, reply_to: REPLY_TO, tags: [{ name: 'kind', value: row.kind }] }),
    })
    const body = await res.json().catch(() => ({}))
    if (!res.ok) throw new Error(`Resend ${res.status}: ${JSON.stringify(body).slice(0, 300)}`)
    return body.id as string
}

const finish = (id: string, patch: Record<string, unknown>) => db.from('notification_queue').update(patch).eq('id', id)

Deno.serve(async (req) => {
    if (!Deno.env.get('NOTIFY_SECRET') || req.headers.get('x-notify-secret') !== Deno.env.get('NOTIFY_SECRET')) {
        return new Response('Forbidden', { status: 403 })
    }

    const { data, error } = await db.rpc('claim_notifications', { p_limit: 20 })
    if (error) return Response.json({ error: error.message }, { status: 500 })

    const result = { sent: 0, skipped: 0, retry: 0, failed: 0 }
    for (const row of (data || []) as Row[]) {
        const render = row.channel === 'email' ? RENDER[row.kind] : undefined
        if (!render || !row.recipient_email) {
            await finish(row.id, { status: 'skipped', last_error: render ? 'No recipient email' : `No template for ${row.channel}/${row.kind}`, locked_at: null })
            result.skipped++
            continue
        }
        try {
            const providerId = await sendEmail(row, render(row)!)
            await finish(row.id, { status: 'sent', provider_id: providerId, sent_at: new Date().toISOString(), last_error: null, locked_at: null })
            result.sent++
        } catch (err) {
            const last = row.attempts >= MAX_ATTEMPTS
            await finish(row.id, {
                status: last ? 'failed' : 'pending',
                last_error: String(err instanceof Error ? err.message : err).slice(0, 500),
                send_after: new Date(Date.now() + row.attempts * row.attempts * 60_000).toISOString(),
                locked_at: null,
            })
            last ? result.failed++ : result.retry++
        }
    }
    return Response.json(result)
})
