import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const SPEC = {
  "name": "push",
  "backup": ".backup-push",
  "prefixes": [],
  "newFiles": [
    "android/app/src/main/res/drawable/ic_stat_locappoint.xml",
    "src/components/common/PushSetup.jsx",
    "src/services/push.js",
    "supabase/functions/notify/fcm.ts",
    "supabase/functions/notify/push.ts",
    "supabase/migrations/push.sql",
    "supabase/queries/push-verify.sql",
    "tests/suites/push.mjs"
  ],
  "replaceFiles": [],
  "patches": [
    {
      "file": "android/app/capacitor.build.gradle",
      "find": "    implementation project(':capacitor-filesystem')\n    implementation project(':capacitor-share')",
      "replace": "    implementation project(':capacitor-filesystem')\n    implementation project(':capacitor-push-notifications')\n    implementation project(':capacitor-share')"
    },
    {
      "file": "android/app/src/main/AndroidManifest.xml",
      "find": "\n        <provider",
      "replace": "\n        <!-- Notifications: our pin in the status bar, and the Bookings channel the app creates on first start. -->\n        <meta-data android:name=\"com.google.firebase.messaging.default_notification_icon\" android:resource=\"@drawable/ic_stat_locappoint\" />\n        <meta-data android:name=\"com.google.firebase.messaging.default_notification_channel_id\" android:value=\"bookings\" />\n\n        <provider"
    },
    {
      "file": "android/app/src/main/AndroidManifest.xml",
      "find": "    <uses-permission android:name=\"android.permission.INTERNET\" />\n</manifest>",
      "replace": "    <uses-permission android:name=\"android.permission.INTERNET\" />\n    <uses-permission android:name=\"android.permission.POST_NOTIFICATIONS\" />\n</manifest>"
    },
    {
      "file": "android/capacitor.settings.gradle",
      "find": "\ninclude ':capacitor-share'",
      "replace": "\ninclude ':capacitor-push-notifications'\nproject(':capacitor-push-notifications').projectDir = new File('../node_modules/@capacitor/push-notifications/android')\n\ninclude ':capacitor-share'"
    },
    {
      "file": "codemagic.yaml",
      "find": "    scripts:\n      - name: Android SDK location",
      "replace": "    scripts:\n      - name: Firebase file for notifications\n        script: |\n          # Without it the app has no Firebase and notifications cannot start. Firebase console, Project settings, Your apps.\n          test -f android/app/google-services.json || { echo \"android/app/google-services.json is missing. Download it from Firebase and commit it.\"; exit 1; }\n      - name: Android SDK location"
    },
    {
      "file": "ios/App/CapApp-SPM/Package.swift",
      "find": "        .package(name: \"CapacitorFilesystem\", path: \"../../../node_modules/@capacitor/filesystem\"),\n        .package(name: \"CapacitorShare\", path: \"../../../node_modules/@capacitor/share\"),",
      "replace": "        .package(name: \"CapacitorFilesystem\", path: \"../../../node_modules/@capacitor/filesystem\"),\n        .package(name: \"CapacitorPushNotifications\", path: \"../../../node_modules/@capacitor/push-notifications\"),\n        .package(name: \"CapacitorShare\", path: \"../../../node_modules/@capacitor/share\"),"
    },
    {
      "file": "ios/App/CapApp-SPM/Package.swift",
      "find": "                .product(name: \"CapacitorFilesystem\", package: \"CapacitorFilesystem\"),\n                .product(name: \"CapacitorShare\", package: \"CapacitorShare\"),",
      "replace": "                .product(name: \"CapacitorFilesystem\", package: \"CapacitorFilesystem\"),\n                .product(name: \"CapacitorPushNotifications\", package: \"CapacitorPushNotifications\"),\n                .product(name: \"CapacitorShare\", package: \"CapacitorShare\"),"
    },
    {
      "file": "package-lock.json",
      "find": "        \"@capacitor/ios\": \"^8.5.2\",\n        \"@capacitor/share\": \"^8.0.2\",",
      "replace": "        \"@capacitor/ios\": \"^8.5.2\",\n        \"@capacitor/push-notifications\": \"^8.1.2\",\n        \"@capacitor/share\": \"^8.0.2\","
    },
    {
      "file": "package-lock.json",
      "find": "      \"license\": \"MIT\",\n      \"peerDependencies\": {\n        \"@capacitor/core\": \"^8.5.0\"\n      }\n    },\n    \"node_modules/@capacitor/share\": {",
      "replace": "      \"license\": \"MIT\",\n      \"peerDependencies\": {\n        \"@capacitor/core\": \"^8.5.0\"\n      }\n    },\n    \"node_modules/@capacitor/push-notifications\": {\n      \"version\": \"8.1.2\",\n      \"resolved\": \"https://registry.npmjs.org/@capacitor/push-notifications/-/push-notifications-8.1.2.tgz\",\n      \"integrity\": \"sha512-TQl4XxqJfNF+KbSYBFMXYYT5WXUaleVKXlByhh/8+KySMVNjp+l5OqAUoGe/sY1IAnGXEuUeCjA/WLZEVvGwrA==\",\n      \"license\": \"MIT\",\n      \"peerDependencies\": {\n        \"@capacitor/core\": \">=8.0.0\"\n      }\n    },\n    \"node_modules/@capacitor/share\": {"
    },
    {
      "file": "package.json",
      "find": "    \"@capacitor/ios\": \"^8.5.2\",\n    \"@capacitor/share\": \"^8.0.2\",",
      "replace": "    \"@capacitor/ios\": \"^8.5.2\",\n    \"@capacitor/push-notifications\": \"^8.1.2\",\n    \"@capacitor/share\": \"^8.0.2\","
    },
    {
      "file": "src/StatusApp.jsx",
      "find": "                                    <div className=\"detail__item detail__item--active\">Delete account inside the app</div>\n                                    <div className=\"detail__item detail__item--active\">Push notifications</div>\n                                </div>",
      "replace": "                                    <div className=\"detail__item detail__item--active\">Delete account inside the app</div>\n                                    <div className=\"detail__item detail__item--active\">Push notifications: Android now, iPhone with the App Store</div>\n                                </div>"
    },
    {
      "file": "src/components/business/AccountSheets.jsx",
      "find": "import { checkDeletion, deleteAccount } from '../../services/account'\nimport '../../styles/business/settings-page.css'",
      "replace": "import { checkDeletion, deleteAccount } from '../../services/account'\nimport { forgetPush } from '../../services/push'\nimport '../../styles/business/settings-page.css'"
    },
    {
      "file": "src/components/business/AccountSheets.jsx",
      "find": "        try {\n            const { error: signOutError } = await supabase.auth.signOut({ scope: 'global' })",
      "replace": "        try {\n            await forgetPush({ everywhere: true })\n            const { error: signOutError } = await supabase.auth.signOut({ scope: 'global' })"
    },
    {
      "file": "src/components/business/BusinessShell.jsx",
      "find": "import HubNav from './HubNav'\nimport AccountMenu from './AccountMenu'",
      "replace": "import HubNav from './HubNav'\nimport PushSetup from '../common/PushSetup'\nimport AccountMenu from './AccountMenu'"
    },
    {
      "file": "src/components/business/BusinessShell.jsx",
      "find": "                        <Tour open={tourOpen} onClose={closeTour} />\n                        <CommandPalette open={cmdOpen} onClose={() => setCmdOpen(false)} actions={paletteActions} businessId={businessId} staff={staffOnly} />",
      "replace": "                        <Tour open={tourOpen} onClose={closeTour} />\n                        <PushSetup audience=\"business\" hold={tourOpen || (!staffOnly && !tourSeen())} />\n                        <CommandPalette open={cmdOpen} onClose={() => setCmdOpen(false)} actions={paletteActions} businessId={businessId} staff={staffOnly} />"
    },
    {
      "file": "src/contexts/AuthContext.jsx",
      "find": "import { appOrigin, isNative, nativeOAuth } from '../services/native'\n",
      "replace": "import { appOrigin, isNative, nativeOAuth } from '../services/native'\nimport { forgetPush } from '../services/push'\n"
    },
    {
      "file": "src/contexts/AuthContext.jsx",
      "find": "        try {\n            const { error } = await supabase.auth.signOut()",
      "replace": "        try {\n            // This phone stops getting the account's notifications before the session ends.\n            await forgetPush()\n            const { error } = await supabase.auth.signOut()"
    },
    {
      "file": "src/pages/business/SettingsPage.jsx",
      "find": "import { EmailSheet } from '../../components/client/EmailSheet'\nimport '../../styles/business/settings-page.css'",
      "replace": "import { EmailSheet } from '../../components/client/EmailSheet'\nimport { PushRow } from '../../components/common/PushSetup'\nimport '../../styles/business/settings-page.css'"
    },
    {
      "file": "src/pages/business/SettingsPage.jsx",
      "find": "                    <div className=\"biz-st__rule\" />\n                    <Row title=\"WhatsApp alerts\" detail=\"The same alerts on WhatsApp, once Locappoint is on WhatsApp.\">",
      "replace": "                    <div className=\"biz-st__rule\" />\n                    <PushRow Row={Row} />\n                    <div className=\"biz-st__rule\" />\n                    <Row title=\"WhatsApp alerts\" detail=\"The same alerts on WhatsApp, once Locappoint is on WhatsApp.\">"
    },
    {
      "file": "src/pages/client/ClientLayout.jsx",
      "find": "import { loadNextBooking } from '../../services/booking'\nimport '../../styles/business/shell.css'",
      "replace": "import { loadNextBooking } from '../../services/booking'\nimport PushSetup from '../../components/common/PushSetup'\nimport '../../styles/business/shell.css'"
    },
    {
      "file": "src/pages/client/ClientLayout.jsx",
      "find": "            </div>\n        </InboxProvider>",
      "replace": "            </div>\n            <PushSetup audience=\"client\" />\n        </InboxProvider>"
    },
    {
      "file": "src/pages/client/Profile.jsx",
      "find": "import { SUPPORT } from '../../constants/support'\nimport '../../styles/business/settings-page.css'",
      "replace": "import { SUPPORT } from '../../constants/support'\nimport { PushRow } from '../../components/common/PushSetup'\nimport '../../styles/business/settings-page.css'"
    },
    {
      "file": "src/pages/client/Profile.jsx",
      "find": "                    <div className=\"biz-st__rule\" />\n                    <Row title=\"WhatsApp reminders\" detail=\"The same reminders on WhatsApp, for people who live there more than in email.\">",
      "replace": "                    <div className=\"biz-st__rule\" />\n                    <PushRow Row={Row} />\n                    <div className=\"biz-st__rule\" />\n                    <Row title=\"WhatsApp reminders\" detail=\"The same reminders on WhatsApp, for people who live there more than in email.\">"
    },
    {
      "file": "src/styles/system.css",
      "find": "    color: var(--lc-ink-3);\n}\n",
      "replace": "    color: var(--lc-ink-3);\n}\n\n/* Notifications: the ask before the phone's own prompt, and the Settings row */\n.lc-sys-push {\n    display: flex;\n    flex-direction: column;\n    align-items: flex-start;\n    gap: var(--space-3);\n}\n\n.lc-sys-push__icon {\n    display: grid;\n    place-items: center;\n    width: 56px;\n    height: 56px;\n    border-radius: var(--lc-r-lg);\n    background: var(--lc-info-tint);\n    color: var(--azure-link);\n}\n\n.lc-sys-push__text {\n    margin: 0;\n    color: var(--lc-ink-1);\n    font-size: 1rem;\n    line-height: var(--lc-lh-body);\n}\n\n.lc-sys-push__note {\n    margin: 0;\n    color: var(--lc-ink-3);\n    font-size: var(--lc-t-label);\n}\n\n.lc-sys-push__note a,\n.lc-sys-push__get {\n    color: var(--azure-link);\n    font-weight: var(--font-weight-semibold);\n}\n\n.lc-sys-push__get {\n    font-size: var(--lc-t-label);\n    white-space: nowrap;\n}\n\n.lc-sys-push__error {\n    color: var(--lc-danger);\n}\n\n.lc-sys-push__acts {\n    display: flex;\n    justify-content: flex-end;\n    gap: var(--space-2);\n    width: 100%;\n}\n"
    },
    {
      "file": "supabase/functions/notify/index.ts",
      "find": "// LocAppoint notification sender, the \"notify\" Edge Function.\n// Claims rows from public.notification_queue and sends them through Resend.\n// Templates: emails/ (what each email says), layout.ts and blocks.ts (how every email looks).\n//\n// Deploy from the repo root: npx supabase functions deploy notify --no-verify-jwt\n// Secrets (Edge Functions, Secrets): RESEND_API_KEY, NOTIFY_SECRET, and optionally SITE_URL.\n// It checks NOTIFY_SECRET itself, which is why JWT verification is off.",
      "replace": "// LocAppoint notification sender, the \"notify\" Edge Function.\n// Claims rows from public.notification_queue and sends emails through Resend, pushes through Firebase.\n// Templates: emails/ (what each email says), layout.ts and blocks.ts (how every email looks).\n//\n// Deploy from the repo root: npx supabase functions deploy notify --no-verify-jwt\n// Secrets (Edge Functions, Secrets): RESEND_API_KEY, NOTIFY_SECRET, FCM_SERVICE_ACCOUNT, and optionally SITE_URL.\n// It checks NOTIFY_SECRET itself, which is why JWT verification is off."
    },
    {
      "file": "supabase/functions/notify/index.ts",
      "find": "import { RENDER } from './emails/index.ts'\nimport type { Message, Row } from './types.ts'",
      "replace": "import { RENDER } from './emails/index.ts'\nimport { renderPush } from './push.ts'\nimport { fcmAccount, sendPush } from './fcm.ts'\nimport type { Message, Row } from './types.ts'"
    },
    {
      "file": "supabase/functions/notify/index.ts",
      "find": "const MAX_ATTEMPTS = 5\n",
      "replace": "const MAX_ATTEMPTS = 5\n// News about a booking is stale after a few hours; the email already carried it.\nconst PUSH_FRESH_MS = 6 * 3_600_000\n"
    },
    {
      "file": "supabase/functions/notify/index.ts",
      "find": "\nDeno.serve(async (req) => {",
      "replace": "\n// Every phone the person has. Phones Firebase no longer knows are forgotten on the spot.\nconst deliverPush = async (row: Row) => {\n    const account = fcmAccount()\n    if (!account) return { skip: 'Push is not set up (FCM_SERVICE_ACCOUNT)' }\n    if (row.created_at && Date.now() - new Date(row.created_at).getTime() > PUSH_FRESH_MS) return { skip: 'Too late to push' }\n    const push = renderPush(row)\n    if (!push) return { skip: `No push for ${row.kind}` }\n    const { data: phones, error } = await db.from('push_tokens').select('token').eq('user_id', row.recipient_user)\n    if (error) throw new Error(error.message)\n    if (!phones?.length) return { skip: 'No phone' }\n    const ids: string[] = []\n    const errors: string[] = []\n    for (const { token } of phones) {\n        const sent = await sendPush(account, token, push, { kind: row.kind, tag: row.appointment_id || row.id })\n        if (sent.ok) ids.push(sent.id)\n        else if (sent.gone) await db.from('push_tokens').delete().eq('token', token)\n        else errors.push(sent.error)\n    }\n    if (ids.length) return { id: ids[0] }\n    if (errors.length) throw new Error(errors[0])\n    return { skip: 'Every phone was gone' }\n}\n\nDeno.serve(async (req) => {"
    },
    {
      "file": "supabase/functions/notify/index.ts",
      "find": "    for (const row of (data || []) as Row[]) {\n        const render = row.channel === 'email' ? RENDER[row.kind] : undefined",
      "replace": "    for (const row of (data || []) as Row[]) {\n        if (row.channel === 'push') {\n            try {\n                const out = await deliverPush(row)\n                if ('skip' in out) {\n                    await finish(row.id, { status: 'skipped', last_error: out.skip, locked_at: null })\n                    result.skipped++\n                } else {\n                    await finish(row.id, { status: 'sent', provider_id: out.id, sent_at: new Date().toISOString(), last_error: null, locked_at: null })\n                    result.sent++\n                }\n            } catch (err) {\n                const last = row.attempts >= 3\n                await finish(row.id, {\n                    status: last ? 'failed' : 'pending',\n                    last_error: String(err instanceof Error ? err.message : err).slice(0, 500),\n                    send_after: new Date(Date.now() + row.attempts * 60_000).toISOString(),\n                    locked_at: null,\n                })\n                last ? result.failed++ : result.retry++\n            }\n            continue\n        }\n        const render = row.channel === 'email' ? RENDER[row.kind] : undefined"
    },
    {
      "file": "supabase/functions/notify/types.ts",
      "find": "    channel: string\n    recipient_email: string | null",
      "replace": "    channel: string\n    recipient_user?: string | null\n    recipient_email: string | null"
    },
    {
      "file": "supabase/functions/notify/types.ts",
      "find": "    attempts: number\n}",
      "replace": "    attempts: number\n    created_at?: string\n}"
    },
    {
      "file": "tests/harness/main.jsx",
      "find": "import BusinessShell from '@src/components/business/BusinessShell'\nimport Today from '@src/pages/business/Today'",
      "replace": "import BusinessShell from '@src/components/business/BusinessShell'\nimport PushSetup from '@src/components/common/PushSetup'\nimport Today from '@src/pages/business/Today'"
    },
    {
      "file": "tests/harness/main.jsx",
      "find": "if (params.get('device')) window.__locaDevice = params.get('device')\nif (params.has('installed')) window.__locaAppVersion = params.get('installed')",
      "replace": "if (params.get('device')) window.__locaDevice = params.get('device')\n// ?push=prompt|granted|denied stands in for the phone's notification permission; ?pushanswer= is what the person picks.\nif (params.get('push')) {\n  const handlers = {}\n  let state = params.get('push')\n  window.__pushCalls = []\n  window.__locaPush = {\n    checkPermissions: async () => ({ receive: state }),\n    requestPermissions: async () => { window.__pushCalls.push('request'); state = params.get('pushanswer') || 'granted'; return { receive: state } },\n    register: async () => { window.__pushCalls.push('register'); handlers.registration?.({ value: 'fake-fcm-token-0123456789abcdef' }) },\n    createChannel: async (c) => { window.__pushCalls.push(`channel:${c.id}`) },\n    addListener: async (name, fn) => { handlers[name] = fn; return { remove() {} } },\n  }\n  window.__pushTap = (link) => handlers.pushNotificationActionPerformed?.({ notification: { data: { link } } })\n  try { if (params.get('asked') === '1') localStorage.setItem('locappoint_push_asked', '1'); else localStorage.removeItem('locappoint_push_asked') } catch { /* noop */ }\n}\nif (params.has('installed')) window.__locaAppVersion = params.get('installed')"
    },
    {
      "file": "tests/harness/main.jsx",
      "find": "    user: params.has('guest') ? null : { id: 'u1', email: params.get('email') || 'milesfarra@gmail.com' },\n    userProfile: params.has('guest') ? null : { id: 'u1', email: params.get('email') || 'milesfarra@gmail.com', full_name: params.has('noname') ? '' : 'Miles Farra', created_at: '2026-03-14T10:00:00Z' },\n    business: params.has('nobiz') ? null : params.get('staff') === '1' ? { ...DATA.businesses[0], staff: true } : DATA.businesses[0],",
      "replace": "    user: params.has('guest') ? null : { id: 'u1', email: params.get('email') || 'milesfarra@gmail.com' },\n    userProfile: params.has('guest') ? null : { id: 'u1', email: params.get('email') || 'milesfarra@gmail.com', full_name: params.has('noname') ? '' : 'Miles Farra', created_at: '2026-03-14T10:00:00Z', ...(params.get('pushoff') === '1' ? { push_enabled: false } : {}) },\n    business: params.has('nobiz') ? null : params.get('staff') === '1' ? { ...DATA.businesses[0], staff: true } : DATA.businesses[0],"
    },
    {
      "file": "tests/harness/main.jsx",
      "find": "        </Route>\n        <Route path=\"/client\" element={<ClientHome />} />\n        <Route path=\"/client/appointments\" element={<ClientAppointments />} />",
      "replace": "        </Route>\n        <Route path=\"/client\" element={<><ClientHome /><PushSetup audience=\"client\" /></>} />\n        <Route path=\"/client/appointments\" element={<ClientAppointments />} />"
    },
    {
      "file": "tests/run.mjs",
      "find": "import account from './suites/account.mjs'\n\nconst here = path.dirname(fileURLToPath(import.meta.url))\nconst [target = 'quick', filter] = process.argv.slice(2)\nconst SUITES = { layout: [['layout', layout]], flows: [['shell', shell], ['business page', businessPage], ['services and hours', servicesHours], ['settings', settings], ['notifications', notifications], ['insights', insights], ['rebooking', rebook], ['reviews', reviews], ['business audit', audit], ['overview', overview], ['client home', clientHome], ['referrals', referrals], ['clients', clients], ['team', team], ['time', time], ['addons', addons], ['money', money], ['hardening', hardening], ['apps', apps], ['account', account]] }\nSUITES.emails = [['emails', emails]]",
      "replace": "import account from './suites/account.mjs'\nimport push from './suites/push.mjs'\n\nconst here = path.dirname(fileURLToPath(import.meta.url))\nconst [target = 'quick', filter] = process.argv.slice(2)\nconst SUITES = { layout: [['layout', layout]], flows: [['shell', shell], ['business page', businessPage], ['services and hours', servicesHours], ['settings', settings], ['notifications', notifications], ['insights', insights], ['rebooking', rebook], ['reviews', reviews], ['business audit', audit], ['overview', overview], ['client home', clientHome], ['referrals', referrals], ['clients', clients], ['team', team], ['time', time], ['addons', addons], ['money', money], ['hardening', hardening], ['apps', apps], ['account', account], ['push', push]] }\nSUITES.emails = [['emails', emails]]"
    }
  ],
  "retires": []
}

const here = path.dirname(fileURLToPath(import.meta.url))
const root = process.cwd()
const check = process.argv.includes('--check')
const problems = []
const plan = []

const abs = (rel) => path.join(root, ...rel.split('/'))
const source = (rel) => path.join(here, 'files', ...rel.split('/'))
const read = (p) => fs.readFileSync(p, 'utf8')
const eolOf = (text) => (text.includes('\r\n') ? '\r\n' : '\n')
const toEol = (text, eol) => text.replace(/\r\n/g, '\n').replace(/\n/g, eol)
const sha = (text) => crypto.createHash('sha256').update(text.replace(/\r\n/g, '\n')).digest('hex')
const count = (hay, needle) => (needle ? hay.split(needle).length - 1 : 0)

const pkg = JSON.parse(read(abs('package.json')))
if (pkg.name !== 'locappoint') {
    console.error('  [ABORT] This is not the locappoint repo.')
    process.exit(1)
}

for (const rel of SPEC.newFiles) {
    if (fs.existsSync(abs(rel))) problems.push(`${rel} already exists (patch already applied?)`)
    else if (!fs.existsSync(source(rel))) problems.push(`payload is missing ${rel}`)
    else plan.push(['NEW', rel])
}

for (const { file, sha: expected } of SPEC.replaceFiles) {
    if (!fs.existsSync(abs(file))) { problems.push(`${file} is missing`); continue }
    if (sha(read(abs(file))) !== expected) { problems.push(`${file} changed since this patch was built (or it is already applied)`); continue }
    plan.push(['REPLACE', file])
}

const srcFiles = () => {
    const out = []
    const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const full = path.join(dir, entry.name)
            if (entry.isDirectory()) { if (entry.name !== 'node_modules') walk(full) }
            else if (/\.(jsx?|css)$/.test(entry.name)) out.push(full)
        }
    }
    walk(abs('src'))
    return out
}

for (const prefix of SPEC.prefixes || []) {
    const owners = srcFiles().filter((full) => read(full).includes(prefix)).map((full) => path.relative(root, full))
    if (owners.length) problems.push(`class prefix ${prefix} is already used in ${owners.join(', ')}`)
}

const edits = new Map()
for (const p of SPEC.patches) {
    if (!fs.existsSync(abs(p.file))) { problems.push(`${p.file} is missing`); continue }
    if (!edits.has(p.file)) edits.set(p.file, read(abs(p.file)))
    const current = edits.get(p.file)
    const eol = eolOf(current)
    const find = toEol(p.find, eol)
    const hits = count(current, find)
    if (hits !== 1) { problems.push(`${p.file}: anchor matched ${hits} times, expected 1: ${JSON.stringify(p.find.slice(0, 60))}`); continue }
    edits.set(p.file, current.replace(find, () => toEol(p.replace, eol)))
}
for (const file of edits.keys()) plan.push(['EDIT', file])

for (const rel of SPEC.retires) {
    if (!fs.existsSync(abs(rel))) { problems.push(`${rel} is missing`); continue }
    const base = path.basename(rel)
    const stem = /\.(jsx?)$/.test(base) ? base.replace(/\.(jsx?)$/, '') : base
    const pattern = new RegExp(`[\\/'"]${stem.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\.jsx?)?['"]`)
    const planned = (full) => {
        const key = path.relative(root, full).split(path.sep).join('/')
        if (SPEC.replaceFiles.some((f) => f.file === key)) return read(source(key))
        return edits.has(key) ? edits.get(key) : read(full)
    }
    const users = srcFiles().filter((full) => full !== abs(rel) && pattern.test(planned(full))).map((full) => path.relative(root, full))
    if (users.length) problems.push(`${rel} is still imported by ${users.join(', ')}`)
    else plan.push(['RETIRE', rel])
}

if (problems.length) {
    console.error('  [ABORT] Nothing was written:')
    for (const p of problems) console.error(`    ${p}`)
    process.exit(1)
}

if (check) {
    for (const [kind, rel] of plan) console.log(`  [${kind}] ${rel}`)
    console.log('  Checks passed.')
    process.exit(0)
}

for (const [kind, rel] of plan) {
    const target = abs(rel)
    if (kind === 'NEW') {
        fs.mkdirSync(path.dirname(target), { recursive: true })
        fs.copyFileSync(source(rel), target)
    } else if (kind === 'REPLACE') {
        const eol = eolOf(read(target))
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, toEol(read(source(rel)), eol))
    } else if (kind === 'EDIT') {
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, edits.get(rel))
    } else if (kind === 'RETIRE') {
        fs.renameSync(target, target + '.mistake')
    }
    console.log(`  [${kind}] ${rel}`)
}
console.log('  Patch applied.')
