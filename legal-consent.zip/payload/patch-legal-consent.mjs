import fs from 'fs'
import path from 'path'

const REPO = process.cwd()

const NEW_FILES = [
    { path: 'src/components/common/CookieBanner.jsx', content: `import { useEffect, useRef, useState } from 'react'
import { CONSENT_OPEN_EVENT, getConsent, setConsent } from '../../services/consent'
import '../../styles/consent.css'

const COPY = {
    en: {
        label: 'Privacy choices',
        body: 'We use essential storage to run this site. With your permission, we also measure visits (pages viewed, device, and approximate location from your IP address) so we can improve it.',
        policy: 'Cookie policy',
        reject: 'Essential only',
        accept: 'Allow analytics',
    },
    pt: {
        label: 'Escolhas de privacidade',
        body: 'Usamos armazenamento essencial para o funcionamento deste site. Com a sua autorização, também medimos visitas (páginas vistas, dispositivo e localização aproximada a partir do seu endereço IP) para o melhorar.',
        policy: 'Política de cookies',
        reject: 'Apenas essenciais',
        accept: 'Permitir análise',
    },
}

const pickLanguage = () => {
    try {
        const saved = localStorage.getItem('locappoint-landing-lang')
        if (saved === 'en' || saved === 'pt') return saved
    } catch { /* noop */ }
    return navigator.language?.toLowerCase().startsWith('pt') ? 'pt' : 'en'
}

const CookieBanner = ({ policyHref }) => {
    const [open, setOpen] = useState(() => getConsent() === null)
    const firstButton = useRef(null)
    const copy = COPY[pickLanguage()]

    useEffect(() => {
        const reopen = () => {
            setOpen(true)
            requestAnimationFrame(() => firstButton.current?.focus())
        }
        window.addEventListener(CONSENT_OPEN_EVENT, reopen)
        return () => window.removeEventListener(CONSENT_OPEN_EVENT, reopen)
    }, [])

    if (!open) return null

    const decide = (analytics) => {
        setConsent(analytics)
        setOpen(false)
    }

    return (
        <section className="consent" aria-label={copy.label}>
            <p className="consent__body">
                {copy.body}{' '}
                <a className="consent__link" href={policyHref}>{copy.policy}</a>
            </p>
            <div className="consent__actions">
                <button ref={firstButton} type="button" className="consent__btn" onClick={() => decide(false)}>
                    {copy.reject}
                </button>
                <button type="button" className="consent__btn" onClick={() => decide(true)}>
                    {copy.accept}
                </button>
            </div>
        </section>
    )
}

export default CookieBanner
` },
    { path: 'src/constants/legalEntity.js', content: `export const LEGAL_UPDATED = '24 September 2026'

export const PENDING = 'Published before public launch'

export const LEGAL_ENTITY = {
    tradingName: 'Locappoint',
    legalName: null,
    registeredAddress: null,
    registry: null,
    registrationNumber: null,
    taxId: null,
    city: 'Lisbon, Portugal',
    email: 'hello@locappoint.com',
    languages: 'English and Portuguese',
}

export const orPending = (value) => value ?? PENDING

export const SUBPROCESSORS = [
    {
        name: 'Supabase',
        purpose: 'Database, authentication and file storage for the platform',
        data: 'Account, business profile and booking data',
        location: null,
        status: 'Active',
    },
    {
        name: 'Hosting provider (Coolify server)',
        purpose: 'Serves the website and records server access logs',
        data: 'IP address, request logs',
        location: null,
        status: 'Active',
    },
    {
        name: 'Email delivery',
        purpose: 'Sign-up confirmation, password reset and booking emails',
        data: 'Name, email address, email content',
        location: null,
        status: 'Active',
    },
    {
        name: 'ipapi.co (Kloudend, Inc.)',
        purpose: 'Approximate location for waitlist site analytics, only after consent',
        data: 'IP address',
        location: 'United States',
        status: 'Active, consent only',
    },
    {
        name: 'country.is',
        purpose: 'Fallback for the location lookup above, only after consent',
        data: 'IP address',
        location: 'Not stated by provider',
        status: 'Active, consent only',
    },
    {
        name: 'Meta Platforms (WhatsApp Business API)',
        purpose: 'Booking confirmations and reminders on WhatsApp',
        data: 'Phone number, name, booking details',
        location: 'European Union and United States',
        status: 'Planned, not yet active',
    },
]
` },
    { path: 'src/pages/app/legal/Cookies.jsx', content: `import { Link } from 'react-router-dom'
import LegalLayout from './LegalLayout'
import { LEGAL_ENTITY } from '../../../constants/legalEntity'

const StorageTable = ({ rows }) => (
    <div className="legal__table-wrap">
        <table className="legal__table">
            <thead>
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Type</th>
                    <th scope="col">Purpose</th>
                    <th scope="col">Kept for</th>
                </tr>
            </thead>
            <tbody>
                {rows.map((row) => (
                    <tr key={row.name}>
                        <td><code>{row.name}</code></td>
                        <td>{row.type}</td>
                        <td>{row.purpose}</td>
                        <td>{row.kept}</td>
                    </tr>
                ))}
            </tbody>
        </table>
    </div>
)

const ESSENTIAL_APP = [
    { name: 'sb-[project]-auth-token', type: 'Local storage', purpose: 'Keeps you signed in', kept: 'Until you sign out' },
    { name: 'pendingBooking', type: 'Session storage', purpose: 'Holds a booking you started while you sign in to finish it', kept: 'Until you close the tab' },
    { name: 'i18nextLng', type: 'Local storage', purpose: 'Remembers the language you chose', kept: 'Until you clear it' },
]

const ESSENTIAL_WAITLIST = [
    { name: 'locappoint-landing-lang', type: 'Local storage', purpose: 'Remembers the language you chose', kept: 'Until you clear it' },
    { name: 'locappoint_consent', type: 'Local storage', purpose: 'Remembers your privacy choice', kept: '12 months, then we ask again' },
]

const ANALYTICS_WAITLIST = [
    { name: 'locappoint_session_id', type: 'Session storage', purpose: 'Groups the pages you view in one visit', kept: 'Until you close the tab' },
    { name: 'locappoint_session_data', type: 'Session storage', purpose: 'Marks that the visit has been counted', kept: 'Until you close the tab' },
]

const sections = [
    {
        id: 'what',
        label: 'What this covers',
        body: (
            <>
                <p>Websites can store small pieces of information on your device, in cookies or in similar places such as your browser&apos;s local storage. The law treats them the same way. We use the word &ldquo;storage&rdquo; for all of them.</p>
                <p>We do not use advertising cookies, and we do not let other companies track you across sites.</p>
            </>
        ),
    },
    {
        id: 'main-site',
        label: 'locappoint.com',
        body: (
            <>
                <p>The main site uses essential storage only. It is needed for the site to work, so we do not ask for consent.</p>
                <StorageTable rows={ESSENTIAL_APP} />
                <p>If you choose to sign in with Google or Apple, you are taken to that provider, which applies its own cookie policy.</p>
            </>
        ),
    },
    {
        id: 'waitlist-site',
        label: 'waitlist.locappoint.com',
        body: (
            <>
                <p>The waitlist site uses the essential storage below:</p>
                <StorageTable rows={ESSENTIAL_WAITLIST} />
                <p>With your consent only, it also measures visits:</p>
                <StorageTable rows={ANALYTICS_WAITLIST} />
                <p>When you allow analytics, your IP address is sent once per visit to ipapi.co (or, if that fails, to country.is) to look up your approximate location. We keep the country, region, city and time zone, not the IP address. Without your consent, none of this happens.</p>
            </>
        ),
    },
    {
        id: 'fonts',
        label: 'Fonts',
        body: (
            <p>Our fonts are served from our own servers, so loading a page does not send your IP address to a font provider.</p>
        ),
    },
    {
        id: 'choices',
        label: 'Changing your choice',
        body: (
            <>
                <p>On the waitlist site, use <strong>Cookie settings</strong> in the footer to change your choice at any time. Refusing is as easy as accepting, and the site works the same either way.</p>
                <p>You can also clear stored data in your browser settings. If you clear essential storage, you will be signed out and your language choice will be reset.</p>
                <p>Questions: <a href={\`mailto:\${LEGAL_ENTITY.email}\`}>{LEGAL_ENTITY.email}</a>. More about how we handle data is in our <Link to="/privacy">Privacy Policy</Link>.</p>
            </>
        ),
    },
]

const Cookies = () => (
    <LegalLayout
        title="Cookie Policy"
        lede="Every piece of information our sites store on your device, what it does, and how long it stays."
        sections={sections}
    />
)

export default Cookies
` },
    { path: 'src/pages/app/legal/Dpa.jsx', content: `import { Link } from 'react-router-dom'
import LegalLayout from './LegalLayout'
import { LEGAL_ENTITY, orPending } from '../../../constants/legalEntity'

const sections = [
    {
        id: 'parties',
        label: 'Parties and scope',
        body: (
            <>
                <p>This agreement is between the business that holds a Locappoint business account (the <strong>controller</strong>) and {orPending(LEGAL_ENTITY.legalName)}, operator of Locappoint (the <strong>processor</strong>). It meets the requirements of Article 28 of the GDPR and forms part of our <Link to="/terms">Terms of Service</Link>.</p>
                <p>It covers personal data about the controller&apos;s clients and staff that we process to provide Locappoint. It does not cover data we control ourselves, such as the business owner&apos;s own account, which our <Link to="/privacy">Privacy Policy</Link> covers.</p>
            </>
        ),
    },
    {
        id: 'details',
        label: 'Details of the processing',
        body: (
            <ul className="legal__list">
                <li><strong>Subject and purpose.</strong> Taking, storing, displaying and managing appointments, and sending booking confirmations, reminders and related messages.</li>
                <li><strong>Duration.</strong> While the business account is open, then until deletion under the section on ending the agreement.</li>
                <li><strong>Data subjects.</strong> The controller&apos;s clients and, where added, its staff.</li>
                <li><strong>Types of data.</strong> Name, email address, phone number, booking details (service, date, time, status) and notes attached to a booking.</li>
                <li><strong>Special categories.</strong> None. The controller must not enter health data or other special categories of data in Locappoint.</li>
            </ul>
        ),
    },
    {
        id: 'instructions',
        label: 'Instructions',
        body: (
            <p>We process the data only on the controller&apos;s documented instructions. The Terms, this agreement and the controller&apos;s use of Locappoint&apos;s settings are those instructions. If the law requires us to process data otherwise, we tell the controller first unless the law forbids it. If we believe an instruction breaks data protection law, we tell the controller.</p>
        ),
    },
    {
        id: 'confidentiality',
        label: 'Confidentiality',
        body: (
            <p>Everyone we authorise to process the data is bound by confidentiality, and has access only as far as their work needs.</p>
        ),
    },
    {
        id: 'security',
        label: 'Security',
        body: (
            <>
                <p>We keep technical and organisational measures appropriate to the risk, as required by Article 32 of the GDPR, including:</p>
                <ul className="legal__list">
                    <li>encryption of data in transit</li>
                    <li>database access rules that limit each account to its own data</li>
                    <li>limited, logged staff access to production systems</li>
                    <li>backups maintained by our database provider</li>
                    <li>reviewing these measures as the platform changes</li>
                </ul>
            </>
        ),
    },
    {
        id: 'subprocessors',
        label: 'Sub-processors',
        body: (
            <p>The controller gives general authorisation for us to use the providers on our <Link to="/legal/subprocessors">Sub-processors</Link> page. We give at least 30 days&apos; notice of any addition or replacement, and the controller may object as that page describes. Each sub-processor is bound by data protection obligations equivalent to this agreement, and we remain responsible for its performance.</p>
        ),
    },
    {
        id: 'assistance',
        label: 'Helping the controller',
        body: (
            <ul className="legal__list">
                <li><strong>Data subject requests.</strong> If a client asks us directly to exercise their rights, we pass the request to the controller without undue delay and help it respond, as far as the nature of the processing allows.</li>
                <li><strong>Security and assessments.</strong> We help the controller meet its duties on security, breach notification, impact assessments and prior consultation, taking into account the information available to us.</li>
            </ul>
        ),
    },
    {
        id: 'breaches',
        label: 'Personal data breaches',
        body: (
            <p>We notify the controller without undue delay, and in any case within 48 hours, after becoming aware of a personal data breach affecting its data. We include what we know about the nature of the breach, the likely consequences and the measures taken, and add details as we learn them.</p>
        ),
    },
    {
        id: 'transfers',
        label: 'International transfers',
        body: (
            <p>We transfer data outside the European Economic Area only where an adequacy decision applies or the European Commission&apos;s Standard Contractual Clauses are in place.</p>
        ),
    },
    {
        id: 'ending',
        label: 'Ending the agreement',
        body: (
            <p>When the business account closes, the controller can ask for an export of its booking data. We delete the data within 90 days of closure, unless the law requires us to keep it, in which case we keep it only for that purpose and for that time.</p>
        ),
    },
    {
        id: 'audits',
        label: 'Information and audits',
        body: (
            <p>We make available the information needed to show we meet this agreement. The controller, or an auditor it appoints who is bound by confidentiality, may carry out an audit once a year with at least 30 days&apos; written notice, at the controller&apos;s cost, and without disrupting the service to other businesses.</p>
        ),
    },
    {
        id: 'general',
        label: 'General',
        body: (
            <p>Liability under this agreement follows the Terms of Service. If this agreement conflicts with the Terms on data protection, this agreement prevails.</p>
        ),
    },
]

const Dpa = () => (
    <LegalLayout
        title="Data Processing Agreement"
        lede="How we handle your clients' data on your behalf. Applies automatically to every business account."
        sections={sections}
    />
)

export default Dpa
` },
    { path: 'src/pages/app/legal/LegalLayout.jsx', content: `import { Link, useLocation } from 'react-router-dom'
import AppHeader from '../../../components/common/AppHeader'
import AppFooter from '../../../components/common/Appfooter'
import { LEGAL_UPDATED } from '../../../constants/legalEntity'
import '../../../styles/app/home.css'
import '../../../styles/app/legal.css'

export const LEGAL_PAGES = [
    { to: '/privacy', label: 'Privacy Policy' },
    { to: '/terms', label: 'Terms of Service' },
    { to: '/legal/cookies', label: 'Cookie Policy' },
    { to: '/legal/notice', label: 'Legal Notice' },
    { to: '/legal/dpa', label: 'Data Processing Agreement' },
    { to: '/legal/subprocessors', label: 'Sub-processors' },
    { to: '/legal/ranking', label: 'How Browse ranks businesses' },
]

const LegalLayout = ({ title, lede, sections }) => {
    const { pathname } = useLocation()
    const related = LEGAL_PAGES.filter((page) => page.to !== pathname)

    return (
        <div className="legal-page">
            <AppHeader />

            <main>
                <section className="loca-section loca-section--s0 legal__hero">
                    <div className="container container--legal">
                        <span className="loca-eyebrow">Legal</span>
                        <h1 className="legal__title">{title}</h1>
                        <p className="legal__meta">Last updated: {LEGAL_UPDATED}</p>
                        <p className="legal__lede">{lede}</p>
                    </div>
                </section>

                <section className="loca-section loca-section--s0 legal__body">
                    <div className="container container--legal">
                        {sections.length > 2 && (
                            <nav className="legal__toc" aria-label="Table of contents">
                                <p className="legal__toc-label">On this page</p>
                                <ol className="legal__toc-list">
                                    {sections.map((section, i) => (
                                        <li key={section.id}>
                                            <a href={\`#\${section.id}\`}>
                                                <span className="legal__toc-num">{String(i + 1).padStart(2, '0')}</span>
                                                <span>{section.label}</span>
                                            </a>
                                        </li>
                                    ))}
                                </ol>
                            </nav>
                        )}

                        <article className="legal__article">
                            {sections.map((section, i) => (
                                <section key={section.id} id={section.id} className="legal__section">
                                    <h2 className="legal__h2">
                                        <span className="legal__num">{String(i + 1).padStart(2, '0')}</span>
                                        {section.label}
                                    </h2>
                                    {section.body}
                                </section>
                            ))}
                        </article>

                        <nav className="legal__related" aria-label="Other legal documents">
                            <p className="legal__toc-label">Other legal documents</p>
                            <ul className="legal__related-list">
                                {related.map((page) => (
                                    <li key={page.to}><Link to={page.to}>{page.label}</Link></li>
                                ))}
                            </ul>
                        </nav>
                    </div>
                </section>
            </main>

            <AppFooter />
        </div>
    )
}

export default LegalLayout
` },
    { path: 'src/pages/app/legal/LegalNotice.jsx', content: `import LegalLayout from './LegalLayout'
import { LEGAL_ENTITY, orPending } from '../../../constants/legalEntity'

const Row = ({ label, value }) => (
    <tr>
        <th scope="row">{label}</th>
        <td>{value}</td>
    </tr>
)

const sections = [
    {
        id: 'operator',
        label: 'Operator',
        body: (
            <div className="legal__table-wrap">
                <table className="legal__table legal__table--pairs">
                    <tbody>
                        <Row label="Service" value={\`\${LEGAL_ENTITY.tradingName}, locappoint.com\`} />
                        <Row label="Company" value={orPending(LEGAL_ENTITY.legalName)} />
                        <Row label="Registered address" value={orPending(LEGAL_ENTITY.registeredAddress)} />
                        <Row label="Registry" value={orPending(LEGAL_ENTITY.registry)} />
                        <Row label="Registration number" value={orPending(LEGAL_ENTITY.registrationNumber)} />
                        <Row label="Tax number" value={orPending(LEGAL_ENTITY.taxId)} />
                        <Row label="Based in" value={LEGAL_ENTITY.city} />
                        <Row label="Email" value={<a href={\`mailto:\${LEGAL_ENTITY.email}\`}>{LEGAL_ENTITY.email}</a>} />
                    </tbody>
                </table>
            </div>
        ),
    },
    {
        id: 'contact-point',
        label: 'Point of contact',
        body: (
            <p>Users and public authorities, including under the EU Digital Services Act, can reach us at <a href={\`mailto:\${LEGAL_ENTITY.email}\`}>{LEGAL_ENTITY.email}</a>. We handle messages in {LEGAL_ENTITY.languages}.</p>
        ),
    },
    {
        id: 'content',
        label: 'Business content',
        body: (
            <p>Each business page is written and maintained by the business it describes. The business is responsible for its content, services and prices. To report content you believe is illegal, follow section 5 of our Terms of Service.</p>
        ),
    },
]

const LegalNotice = () => (
    <LegalLayout
        title="Legal Notice"
        lede="Who runs Locappoint and how to reach us."
        sections={sections}
    />
)

export default LegalNotice
` },
    { path: 'src/pages/app/legal/Privacy.jsx', content: `import { Link } from 'react-router-dom'
import LegalLayout from './LegalLayout'
import { LEGAL_ENTITY, orPending } from '../../../constants/legalEntity'

const sections = [
    {
        id: 'who-we-are',
        label: 'Who we are',
        body: (
            <>
                <p>Locappoint is a booking platform for local service businesses, based in {LEGAL_ENTITY.city}. The operating company is <strong>{orPending(LEGAL_ENTITY.legalName)}</strong>. Full company details are on the <Link to="/legal/notice">Legal Notice</Link>.</p>
                <p>We have two roles, depending on the data:</p>
                <ul className="legal__list">
                    <li><strong>Controller</strong> for your account, your business profile, anything you send us through the waitlist, partnership or contact forms, and analytics on our waitlist site.</li>
                    <li><strong>Processor</strong> for the booking records a business keeps about its own clients. The business decides why that data is used; we handle it on its behalf under our <Link to="/legal/dpa">Data Processing Agreement</Link>.</li>
                </ul>
            </>
        ),
    },
    {
        id: 'what-we-collect',
        label: 'What we collect',
        body: (
            <>
                <ul className="legal__list">
                    <li><strong>Account.</strong> Name, email address, phone number, password (stored hashed by our authentication provider), account type (business or client) and preferred language. If you sign in with Google or Apple, we receive your name, email address and an account identifier from that provider.</li>
                    <li><strong>Business profile.</strong> Business name, public web address, category, city, address, description, services, prices, working hours, contact details you choose to show, and images you upload. This information is public on your business page.</li>
                    <li><strong>Bookings.</strong> The business, service, date and time, the client&apos;s name and contact details, and any notes added to the booking.</li>
                    <li><strong>Forms.</strong> Waitlist: email address, whether you are a business or a client, business type, city and name if you give them. Partnership application: name, email, phone, category, business name, city, country and your message. Contact form: name, email, phone if given, subject and message.</li>
                    <li><strong>Waitlist site analytics, only with your consent.</strong> A random session identifier, pages and sections viewed, clicks, scroll depth, time on page, device type, browser, operating system, screen size, referring site, campaign tags and browser language. Approximate location (country, region, city and time zone) is looked up from your IP address. We store the location result, not the IP address.</li>
                    <li><strong>Server logs.</strong> Our hosting server records IP addresses and requests to keep the service secure and working.</li>
                </ul>
            </>
        ),
    },
    {
        id: 'how-we-use',
        label: 'How we use it, and why we are allowed to',
        body: (
            <>
                <p>Each use has a legal basis under Article 6 of the GDPR:</p>
                <ul className="legal__list">
                    <li><strong>Running your account and bookings</strong>, including confirmations and reminders by email, and by WhatsApp once that channel is live. Basis: performing our contract with you.</li>
                    <li><strong>Publishing business pages.</strong> Basis: our contract with the business.</li>
                    <li><strong>Following up on waitlist and partnership applications.</strong> Basis: steps you asked us to take before a contract.</li>
                    <li><strong>Replying to contact messages.</strong> Basis: our legitimate interest in answering people who write to us.</li>
                    <li><strong>Waitlist site analytics.</strong> Basis: your consent, which you can withdraw at any time.</li>
                    <li><strong>Security, fraud and abuse prevention</strong>, including server logs. Basis: our legitimate interest in keeping the platform safe.</li>
                    <li><strong>Meeting legal duties</strong>, such as tax records once billing starts or lawful requests from authorities. Basis: legal obligation.</li>
                </ul>
                <p>We do not sell personal data, we do not show advertising, and we do not make decisions about you by automated means that have legal or similarly significant effects.</p>
            </>
        ),
    },
    {
        id: 'bookings',
        label: 'When you book a business',
        body: (
            <>
                <p>When you book an appointment, the business you book with receives your name, contact details and booking details so it can provide the service. That business is responsible for how it uses them. We keep and process the booking on its behalf.</p>
                <p>For questions about a specific booking, contact the business first. You can also write to us and we will pass your request on.</p>
            </>
        ),
    },
    {
        id: 'sharing',
        label: 'Who we share data with',
        body: (
            <>
                <ul className="legal__list">
                    <li><strong>Service providers</strong> who host and run the platform for us. Each one is listed, with its purpose and location, on the <Link to="/legal/subprocessors">Sub-processors</Link> page.</li>
                    <li><strong>The businesses you book with</strong>, as described above.</li>
                    <li><strong>Sign-in providers</strong> (Google, Apple) when you choose to sign in with them.</li>
                    <li><strong>Authorities</strong> when the law requires it.</li>
                </ul>
            </>
        ),
    },
    {
        id: 'transfers',
        label: 'International transfers',
        body: (
            <p>Some providers process data outside the European Economic Area, for example in the United States. Where that happens we rely on an adequacy decision from the European Commission, such as the EU-US Data Privacy Framework where the provider is certified, or on the Commission&apos;s Standard Contractual Clauses. The location of each provider is on the <Link to="/legal/subprocessors">Sub-processors</Link> page.</p>
        ),
    },
    {
        id: 'retention',
        label: 'How long we keep data',
        body: (
            <ul className="legal__list">
                <li><strong>Accounts.</strong> While the account is open. After you close it, we delete it within 90 days, except records the law requires us to keep longer, such as billing records (10 years under Portuguese tax law).</li>
                <li><strong>Bookings.</strong> While the business account is open, or until the business deletes them.</li>
                <li><strong>Waitlist signups.</strong> 24 months from signup, unless you create an account.</li>
                <li><strong>Partnership and contact messages.</strong> 24 months from your last message.</li>
                <li><strong>Waitlist analytics.</strong> 13 months.</li>
                <li><strong>Server logs.</strong> 90 days.</li>
            </ul>
        ),
    },
    {
        id: 'rights',
        label: 'Your rights',
        body: (
            <>
                <p>You can ask us to give you a copy of your data, correct it, delete it, restrict or object to how we use it, or send it to another service in a machine-readable format. Where we rely on consent, you can withdraw it at any time without affecting what happened before.</p>
                <p>Write to <a href={\`mailto:\${LEGAL_ENTITY.email}\`}>{LEGAL_ENTITY.email}</a>. We reply within one month. We may ask you to confirm your identity first.</p>
            </>
        ),
    },
    {
        id: 'cookies',
        label: 'Cookies and device storage',
        body: (
            <p>The main site uses essential storage only, for example to keep you signed in. The waitlist site also uses analytics storage, but only if you allow it. The full list is in our <Link to="/legal/cookies">Cookie Policy</Link>.</p>
        ),
    },
    {
        id: 'security',
        label: 'Security',
        body: (
            <p>Data travels over encrypted connections. Access to the database is restricted by row-level security rules, so each account can reach only its own data, and staff access is limited to what the work needs. No system is perfectly secure; if a breach affects you, we will tell you as the law requires.</p>
        ),
    },
    {
        id: 'children',
        label: 'Children',
        body: (
            <p>Locappoint is not directed at children under 16, and we do not knowingly collect their data. If you believe a child has given us personal data, contact us and we will delete it.</p>
        ),
    },
    {
        id: 'changes',
        label: 'Changes to this policy',
        body: (
            <p>The date at the top shows the latest version. For significant changes, we tell account holders by email or in the platform before the change takes effect.</p>
        ),
    },
    {
        id: 'complaints',
        label: 'Complaints',
        body: (
            <>
                <p>If you think we have handled your data wrongly, please tell us first so we can fix it. You also have the right to complain to the Portuguese data protection authority:</p>
                <p className="legal__address">
                    <strong>CNPD</strong> (Comissão Nacional de Proteção de Dados)<br />
                    Av. D. Carlos I, nº 134, 1º<br />
                    1200-651 Lisboa, Portugal<br />
                    <a href="https://www.cnpd.pt" target="_blank" rel="noopener noreferrer">cnpd.pt</a>
                </p>
            </>
        ),
    },
]

const Privacy = () => (
    <LegalLayout
        title="Privacy Policy"
        lede="What we collect, why, who sees it, and how to control it. Written to be read, not skimmed past."
        sections={sections}
    />
)

export default Privacy
` },
    { path: 'src/pages/app/legal/Ranking.jsx', content: `import LegalLayout from './LegalLayout'
import { LEGAL_ENTITY } from '../../../constants/legalEntity'

const sections = [
    {
        id: 'parameters',
        label: 'What decides the order',
        body: (
            <>
                <p>This page explains, as required by EU Regulation 2019/1150, the main factors that decide where a business appears on Browse and in search.</p>
                <ul className="legal__list">
                    <li><strong>City.</strong> Businesses are grouped by the city they operate in, starting with our launch city.</li>
                    <li><strong>Filters you choose.</strong> Category, city and search words narrow the list to businesses that match.</li>
                    <li><strong>Date the business went live.</strong> Within a city, businesses appear in the order they started taking bookings on Locappoint.</li>
                </ul>
            </>
        ),
    },
    {
        id: 'no-payment',
        label: 'What does not affect it',
        body: (
            <p>Nobody can pay for a higher position. Paying businesses and businesses in their free period are treated the same. We do not rank businesses according to any relationship with us.</p>
        ),
    },
    {
        id: 'changes',
        label: 'Changes',
        body: (
            <p>As Locappoint grows we expect to add factors such as availability and client reviews. We will update this page before any change takes effect. Questions or complaints about ranking: <a href={\`mailto:\${LEGAL_ENTITY.email}\`}>{LEGAL_ENTITY.email}</a>.</p>
        ),
    },
]

const Ranking = () => (
    <LegalLayout
        title="How Browse ranks businesses"
        lede="Why businesses appear in the order they do. No paid placement."
        sections={sections}
    />
)

export default Ranking
` },
    { path: 'src/pages/app/legal/Subprocessors.jsx', content: `import LegalLayout from './LegalLayout'
import { LEGAL_ENTITY, SUBPROCESSORS, orPending } from '../../../constants/legalEntity'

const sections = [
    {
        id: 'list',
        label: 'Current list',
        body: (
            <div className="legal__table-wrap">
                <table className="legal__table">
                    <thead>
                        <tr>
                            <th scope="col">Provider</th>
                            <th scope="col">Purpose</th>
                            <th scope="col">Data</th>
                            <th scope="col">Location</th>
                            <th scope="col">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {SUBPROCESSORS.map((provider) => (
                            <tr key={provider.name}>
                                <td>{provider.name}</td>
                                <td>{provider.purpose}</td>
                                <td>{provider.data}</td>
                                <td>{orPending(provider.location)}</td>
                                <td>{provider.status}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        ),
    },
    {
        id: 'changes',
        label: 'Changes',
        body: (
            <p>We tell business account holders by email at least 30 days before adding or replacing a provider that processes their clients&apos; data. A business can object within that period by writing to <a href={\`mailto:\${LEGAL_ENTITY.email}\`}>{LEGAL_ENTITY.email}</a>. If we cannot resolve the objection, the business can close its account before the change takes effect.</p>
        ),
    },
    {
        id: 'safeguards',
        label: 'Safeguards',
        body: (
            <p>Each provider is bound by a written agreement that requires it to protect the data and use it only to provide its service to us. For providers outside the European Economic Area, we rely on an adequacy decision or on the European Commission&apos;s Standard Contractual Clauses.</p>
        ),
    },
]

const Subprocessors = () => (
    <LegalLayout
        title="Sub-processors"
        lede="The companies that help us run Locappoint, what each one does, and where it processes data."
        sections={sections}
    />
)

export default Subprocessors
` },
    { path: 'src/pages/app/legal/Terms.jsx', content: `import { Link } from 'react-router-dom'
import LegalLayout from './LegalLayout'
import { LEGAL_ENTITY, orPending } from '../../../constants/legalEntity'

const sections = [
    {
        id: 'about',
        label: 'About these terms',
        body: (
            <>
                <p>These terms are an agreement between you and <strong>{orPending(LEGAL_ENTITY.legalName)}</strong>, which operates Locappoint (&ldquo;we&rdquo;, &ldquo;us&rdquo;). Company details are on the <Link to="/legal/notice">Legal Notice</Link>.</p>
                <p>Sections 1 to 11 apply to everyone. Sections 12 to 17 apply only to businesses. Sections 18 to 20 apply only to clients who book appointments. By creating an account or using Locappoint you accept the parts that apply to you. If you act for a business, you confirm you have authority to accept them on its behalf.</p>
                <p>Locappoint is currently in a closed beta. Features may change, and we may pause parts of the service while we improve them.</p>
            </>
        ),
    },
    {
        id: 'service',
        label: 'What Locappoint does',
        body: (
            <>
                <p>Locappoint gives businesses tools to publish their services, prices and opening hours on a public page at locappoint.com/their-name, and to take bookings. It lets clients find those businesses and book with them, and it sends confirmations and reminders.</p>
                <p>We provide the platform. We are not a party to the appointment itself. The service is provided by the business, under an agreement between the business and the client.</p>
            </>
        ),
    },
    {
        id: 'accounts',
        label: 'Accounts',
        body: (
            <ul className="legal__list">
                <li>Give accurate information and keep it up to date.</li>
                <li>Keep your password private. You are responsible for activity on your account.</li>
                <li>You must be at least 16 to create a client account and at least 18 to create a business account.</li>
                <li>Tell us straight away if you think someone else has accessed your account.</li>
            </ul>
        ),
    },
    {
        id: 'acceptable-use',
        label: 'Acceptable use',
        body: (
            <>
                <p>You must not:</p>
                <ul className="legal__list">
                    <li>use Locappoint for anything illegal, or to offer illegal services</li>
                    <li>impersonate another person or business, or publish false or misleading information</li>
                    <li>enter health information or other special categories of personal data in booking notes or messages</li>
                    <li>send spam, malware or harmful content</li>
                    <li>scrape, copy or mirror the platform, or try to access other accounts or systems without permission</li>
                    <li>interfere with how the platform runs</li>
                </ul>
            </>
        ),
    },
    {
        id: 'reporting',
        label: 'Reporting illegal content',
        body: (
            <>
                <p>If you see content on Locappoint that you believe is illegal, such as a business page, image or review, email <a href={\`mailto:\${LEGAL_ENTITY.email}\`}>{LEGAL_ENTITY.email}</a> with the page address, what the problem is, and why you believe it is illegal. Include your name and email unless the report concerns child sexual abuse material.</p>
                <p>We confirm receipt, review the report carefully and without undue delay, and tell you what we decided. If we remove or restrict content, we tell the person who posted it why and how to challenge the decision.</p>
            </>
        ),
    },
    {
        id: 'availability',
        label: 'Availability',
        body: (
            <p>We work to keep Locappoint available and accurate, but we cannot promise it will always be uninterrupted or error-free. We may carry out maintenance, and we may change or remove features. If a change significantly affects paying businesses, we give notice as described in section 9.</p>
        ),
    },
    {
        id: 'ip',
        label: 'Intellectual property',
        body: (
            <>
                <p><strong>Your content.</strong> You keep all rights to the content you upload, such as your business name, descriptions, logo and photos. You give us a non-exclusive licence to host and display it through Locappoint, for as long as it is on the platform, so we can run your page.</p>
                <p><strong>Our platform.</strong> The Locappoint software, brand and design belong to us. Using Locappoint does not give you rights in them beyond using the service.</p>
            </>
        ),
    },
    {
        id: 'liability',
        label: 'Liability',
        body: (
            <>
                <p>Nothing in these terms limits liability for death or personal injury caused by negligence, for fraud, for gross negligence or wilful misconduct, or for anything else that cannot be limited by law.</p>
                <p><strong>If you are a client (consumer)</strong>, your statutory rights are not affected by these terms.</p>
                <p><strong>If you are a business</strong>, our total liability for any claim related to Locappoint is limited to the fees you paid us in the twelve months before the claim. We are not liable to businesses for indirect or consequential loss, such as lost profits or lost bookings.</p>
            </>
        ),
    },
    {
        id: 'changes',
        label: 'Changes to these terms',
        body: (
            <p>We may update these terms. For material changes, we tell account holders by email or in the platform at least 30 days before they take effect, unless a change is needed sooner to comply with the law or to address an unforeseen danger. Businesses may end their account before the change takes effect. If you keep using Locappoint after that date, the new terms apply.</p>
        ),
    },
    {
        id: 'law',
        label: 'Law and disputes',
        body: (
            <>
                <p>These terms are governed by Portuguese law. Courts in Lisbon, Portugal, have jurisdiction, except that as a consumer you can also bring proceedings in the country where you live, and you keep the protection of that country&apos;s mandatory consumer law.</p>
                <p>If you have a complaint, please contact us first. Most problems can be fixed quickly.</p>
            </>
        ),
    },
    {
        id: 'contact',
        label: 'Contact',
        body: (
            <p>Email <a href={\`mailto:\${LEGAL_ENTITY.email}\`}>{LEGAL_ENTITY.email}</a>. Postal address: {orPending(LEGAL_ENTITY.registeredAddress)}.</p>
        ),
    },
    {
        id: 'pricing',
        label: 'Businesses: pricing and payment',
        body: (
            <>
                <p><strong>Cohort 1 (current).</strong> Free for the first twelve (12) months from account creation, for the first 100 businesses in our launch cities (Lisbon, Porto, Lagos).</p>
                <p><strong>After the free period.</strong> Nineteen euros (€19) per month per business, flat. We do not charge commission on bookings. Payment is processed monthly in advance. We will tell you before billing starts and confirm whether VAT applies.</p>
                <p><strong>Cancellation.</strong> You can cancel your subscription at any time. Cancellation takes effect at the end of the current billing period. No refunds for partial months unless required by law.</p>
                <p><strong>Price changes.</strong> We will notify you at least 30 days before any price changes take effect. You can cancel before the new price applies.</p>
            </>
        ),
    },
    {
        id: 'business-page',
        label: 'Businesses: your page and listing',
        body: (
            <>
                <p>You are responsible for everything on your business page: that your services, prices, opening hours and photos are accurate and lawful, that you hold any licences your services need, and that you meet your own obligations to your clients, including consumer law and price display rules.</p>
                <p>How businesses are ordered on Browse is explained on <Link to="/legal/ranking">How Browse ranks businesses</Link>. Nobody can pay for a higher position.</p>
            </>
        ),
    },
    {
        id: 'client-data',
        label: 'Businesses: client data',
        body: (
            <p>For the personal data of your clients, you are the controller and we are your processor. Our <Link to="/legal/dpa">Data Processing Agreement</Link> forms part of these terms and applies automatically when you create a business account. You are responsible for having a lawful basis to use your clients&apos; data and for answering their requests, with our help where the agreement says so.</p>
        ),
    },
    {
        id: 'suspension',
        label: 'Businesses: suspension and closing an account',
        body: (
            <>
                <p>You can close your business account at any time. Your page is removed from public view within 24 hours. You can ask us for an export of your bookings before you close.</p>
                <p>We may restrict or suspend a business account if it breaks these terms or the law, or puts clients or the platform at risk. We tell you the reasons when we do, unless the law prevents it. We give at least 30 days&apos; notice before ending a business account for good, except where we must act sooner because of a legal obligation or repeated serious breaches. You can ask us to reconsider any decision by replying to our notice.</p>
            </>
        ),
    },
    {
        id: 'business-complaints',
        label: 'Businesses: complaints',
        body: (
            <p>Send complaints about how we run the platform, including suspensions and ranking, to <a href={\`mailto:\${LEGAL_ENTITY.email}\`}>{LEGAL_ENTITY.email}</a> with &ldquo;Business complaint&rdquo; in the subject line. We acknowledge it, look into it, and reply with our decision and reasons.</p>
        ),
    },
    {
        id: 'indemnity',
        label: 'Businesses: responsibility for claims',
        body: (
            <p>If a client or anyone else brings a claim against us because of the services you provided, the content of your page, or your breach of these terms or the law, you will cover the reasonable costs and losses that result, including legal fees.</p>
        ),
    },
    {
        id: 'booking',
        label: 'Clients: booking an appointment',
        body: (
            <>
                <p>When you book, you make an agreement with the business, not with us. The business sets its services, prices and cancellation rules, and shows them on its page before you confirm. Locappoint does not currently take payments: you pay the business directly, as it tells you.</p>
                <p>After booking you receive a confirmation. Check the details and contact the business if anything is wrong.</p>
            </>
        ),
    },
    {
        id: 'cancelling',
        label: 'Clients: cancelling or changing',
        body: (
            <p>You can cancel or change a booking from your account or from the link in your confirmation, within the rules the business has set. If you cannot attend, please cancel as early as you can so someone else can take the slot.</p>
        ),
    },
    {
        id: 'consumer-rights',
        label: 'Clients: your rights and complaints',
        body: (
            <p>Nothing in these terms affects your rights as a consumer. Complaints about an appointment or service go to the business that provided it. If something went wrong with Locappoint itself, such as a booking that did not reach the business, write to us and we will help.</p>
        ),
    },
]

const Terms = () => (
    <LegalLayout
        title="Terms of Service"
        lede="The agreement between Locappoint and the people who use it. Part of it covers everyone, part only businesses, part only clients."
        sections={sections}
    />
)

export default Terms
` },
    { path: 'src/services/consent.js', content: `const STORAGE_KEY = 'locappoint_consent'
const VERSION = 1
const MAX_AGE_MS = 365 * 24 * 60 * 60 * 1000

export const CONSENT_OPEN_EVENT = 'locappoint:consent-open'

const listeners = new Set()

export const getConsent = () => {
    try {
        const stored = JSON.parse(localStorage.getItem(STORAGE_KEY))
        if (!stored || stored.version !== VERSION) return null
        if (Date.now() - new Date(stored.decidedAt).getTime() > MAX_AGE_MS) return null
        return stored
    } catch {
        return null
    }
}

export const hasAnalyticsConsent = () => getConsent()?.analytics === true

export const setConsent = (analytics) => {
    const record = { version: VERSION, analytics, decidedAt: new Date().toISOString() }
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(record)) } catch { /* noop */ }
    listeners.forEach((listener) => listener(analytics))
}

export const onConsentChange = (listener) => {
    listeners.add(listener)
    return () => listeners.delete(listener)
}

export const openConsentPreferences = () => {
    window.dispatchEvent(new Event(CONSENT_OPEN_EVENT))
}
` },
    { path: 'src/styles/consent.css', content: `.consent {
    position: fixed;
    left: 12px;
    right: 12px;
    bottom: calc(12px + env(safe-area-inset-bottom, 0px));
    max-width: 520px;
    margin: 0 auto;
    z-index: calc(var(--z-floating) + 10);
    background: var(--surface-2);
    border: 1px solid var(--border-medium);
    border-radius: var(--radius-lg);
    padding: 16px;
    font-family: var(--font-body);
}

.consent__body {
    margin: 0 0 14px;
    font-size: 14px;
    line-height: 1.55;
    color: var(--text-secondary);
}

.consent__link {
    color: var(--azure-link);
    text-decoration: underline;
    text-underline-offset: 2px;
}

.consent__actions {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
}

.consent__btn {
    min-height: 44px;
    padding: 0 12px;
    font-family: var(--font-body);
    font-size: 14px;
    font-weight: 500;
    color: var(--text-primary);
    background: var(--surface-3);
    border: 1px solid var(--border-medium);
    border-radius: var(--radius-md);
    cursor: pointer;
    transition: background var(--transition-fast), border-color var(--transition-fast);
}

.consent__btn:hover {
    background: var(--surface-4);
    border-color: var(--border-strong);
}

.consent__btn:focus-visible,
.consent__link:focus-visible {
    outline: 2px solid var(--azure);
    outline-offset: 2px;
}
` },
]

const PATCHES = [
    {
        file: 'src/BookingApp.jsx',
        edits: [
            { desc: "Swap legal page imports", find: `import PrivacyPolicy from './pages/app/legal/PrivacyPolicy'
import TermsOfService from './pages/app/legal/TermsOfService'
`, replace: `import Privacy from './pages/app/legal/Privacy'
import Terms from './pages/app/legal/Terms'
import Cookies from './pages/app/legal/Cookies'
import LegalNotice from './pages/app/legal/LegalNotice'
import Dpa from './pages/app/legal/Dpa'
import Subprocessors from './pages/app/legal/Subprocessors'
import Ranking from './pages/app/legal/Ranking'
` },
            { desc: "Legal routes", find: `                <Route path="/privacy" element={<PrivacyPolicy />} />
                <Route path="/terms" element={<TermsOfService />} />
`, replace: `                <Route path="/privacy" element={<Privacy />} />
                <Route path="/terms" element={<Terms />} />
                <Route path="/legal" element={<Navigate to="/legal/notice" replace />} />
                <Route path="/legal/cookies" element={<Cookies />} />
                <Route path="/legal/notice" element={<LegalNotice />} />
                <Route path="/legal/dpa" element={<Dpa />} />
                <Route path="/legal/subprocessors" element={<Subprocessors />} />
                <Route path="/legal/ranking" element={<Ranking />} />
` },
        ],
    },
    {
        file: 'src/WaitlistApp.jsx',
        edits: [
            { desc: "Import useLocation", find: `import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'`, replace: `import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom'` },
            { desc: "Swap legal page imports for CookieBanner", find: `import TermsOfService from './pages/app/legal/TermsOfService'
import PrivacyPolicy from './pages/app/legal/PrivacyPolicy'
`, replace: `import CookieBanner from './components/common/CookieBanner'
` },
            { desc: "Add AppRedirect for legal paths", find: `    return null
}

const WaitlistApp = () => (`, replace: `    return null
}

const toApp = (path) => (import.meta.env.DEV ? \`\${path}?app\` : \`https://locappoint.com\${path}\`)

// Legal pages live on the main site so there is one version to maintain.
const AppRedirect = () => {
    const { pathname } = useLocation()
    useEffect(() => { window.location.replace(toApp(pathname)) }, [pathname])
    return null
}

const WaitlistApp = () => (` },
            { desc: "Legal routes redirect to the main site", find: `                <Route path="/terms" element={<TermsOfService />} />
                <Route path="/privacy" element={<PrivacyPolicy />} />
`, replace: `                <Route path="/terms" element={<AppRedirect />} />
                <Route path="/privacy" element={<AppRedirect />} />
                <Route path="/legal/*" element={<AppRedirect />} />
` },
            { desc: "Mount CookieBanner", find: `        </BrowserRouter>
    </AuthProvider>`, replace: `        </BrowserRouter>
        <CookieBanner policyHref={toApp('/legal/cookies')} />
    </AuthProvider>` },
        ],
    },
    {
        file: 'src/services/analytics.js',
        edits: [
            { desc: "Consent-gated tracking, strip header comment", find: `// analytics.js - Tracking service for sessions, events, conversions.
// Tracking is enabled in production. For local verification set
// VITE_ANALYTICS_FORCE=true in .env.local then restart the dev server.

import { supabaseAnon as supabase } from '../config/supabaseAnon'

// ============ ENVIRONMENT ============

const isProduction = import.meta.env.PROD
const forceTracking = import.meta.env.VITE_ANALYTICS_FORCE === 'true'
const trackingEnabled = isProduction || forceTracking
`, replace: `import { supabaseAnon as supabase } from '../config/supabaseAnon'
import { hasAnalyticsConsent, onConsentChange } from './consent'

const isProduction = import.meta.env.PROD
// VITE_ANALYTICS_FORCE=true in .env.local turns tracking on in dev.
const trackingAllowed = isProduction || import.meta.env.VITE_ANALYTICS_FORCE === 'true'
const isTracking = () => trackingAllowed && hasAnalyticsConsent()
const pendingStart = new Set()
` },
            { desc: "Strip SESSION MANAGEMENT marker", find: `// ============ SESSION MANAGEMENT ============

`, replace: `` },
            { desc: "Strip DEVICE DETECTION marker", find: `// ============ DEVICE DETECTION ============

`, replace: `` },
            { desc: "Strip UTM & REFERRER marker", find: `// ============ UTM & REFERRER ============

`, replace: `` },
            { desc: "Strip GEO marker", find: `// ============ GEO ============

`, replace: `` },
            { desc: "Strip SESSION INITIALIZATION marker", find: `// ============ SESSION INITIALIZATION ============

`, replace: `` },
            { desc: "Strip SESSION UPDATES marker", find: `// ============ SESSION UPDATES ============

`, replace: `` },
            { desc: "Strip EVENT TRACKING marker", find: `// ============ EVENT TRACKING ============

`, replace: `` },
            { desc: "Strip SPECIFIC TRACKERS marker", find: `// ============ SPECIFIC TRACKERS ============

`, replace: `` },
            { desc: "Strip TIME TRACKING marker", find: `// ============ TIME TRACKING ============

`, replace: `` },
            { desc: "Strip INTERSECTION OBSERVER marker", find: `// ============ INTERSECTION OBSERVER ============

`, replace: `` },
            { desc: "Strip SCROLL DEPTH marker", find: `// ============ SCROLL DEPTH ============

`, replace: `` },
            { desc: "initSession waits for consent, no session id before it", find: `export const initSession = async () => {
    const sessionId = getSessionId()

    if (!trackingEnabled) {
        devLog('initSession skipped. Set VITE_ANALYTICS_FORCE=true in .env.local to enable in dev.')
        return sessionId
    }
`, replace: `export const initSession = async () => {
    if (!isTracking()) {
        pendingStart.add('session')
        devLog('initSession deferred until consent')
        return null
    }

    const sessionId = getSessionId()
` },
            { desc: "Gate updateSession on consent", find: `if (!trackingEnabled) {
        devLog('updateSession skipped', updates`, replace: `if (!isTracking()) {
        devLog('updateSession skipped', updates` },
            { desc: "Gate trackPageView on consent", find: `if (!trackingEnabled) {
        devLog('trackPageView skipped'`, replace: `if (!isTracking()) {
        devLog('trackPageView skipped'` },
            { desc: "Gate trackEvent on consent", find: `if (!trackingEnabled) {
        devLog('trackEvent skipped'`, replace: `if (!isTracking()) {
        devLog('trackEvent skipped'` },
            { desc: "Gate trackFormSubmit on consent", find: `if (!trackingEnabled) {
        devLog('trackFormSubmit skipped'`, replace: `if (!isTracking()) {
        devLog('trackFormSubmit skipped'` },
            { desc: "Gate trackWhatsAppClick on consent", find: `    if (!trackingEnabled) return
    await updateSession({ whatsapp_clicked`, replace: `    if (!isTracking()) return
    await updateSession({ whatsapp_clicked` },
            { desc: "Drop restating comment on interaction events", find: `// Events that signal real engagement (vs passive page/section views).
// Firing any of these flips is_bounce to false.
`, replace: `` },
            { desc: "Drop restating comment in trackEvent", find: `        // Real interaction implies not a bounce.
`, replace: `` },
            { desc: "Drop restating comment on form submit", find: `// Recognize waitlist_step1, waitlist_step2, waitlist as waitlist conversions.
// Same prefix logic for partnership.
`, replace: `` },
            { desc: "Track unload listener binding", find: `let totalTimeInterval = null
`, replace: `let totalTimeInterval = null
let unloadBound = false
` },
            { desc: "startTimeTracking waits for consent", find: `export const startTimeTracking = () => {
    if (!trackingEnabled) {
        devLog('startTimeTracking skipped')
        return
    }
`, replace: `export const startTimeTracking = () => {
    if (!isTracking()) {
        pendingStart.add('time')
        devLog('startTimeTracking deferred until consent')
        return
    }
` },
            { desc: "Bind unload once, skip it without consent", find: `    // Unload: fetch keepalive + PATCH (sendBeacon only supports POST, PostgREST update needs PATCH).
    window.addEventListener('beforeunload', () => {
        const elapsed`, replace: `    if (unloadBound) return
    unloadBound = true

    // Unload: fetch keepalive + PATCH (sendBeacon only supports POST, PostgREST update needs PATCH).
    window.addEventListener('beforeunload', () => {
        if (!isTracking()) return
        const elapsed` },
            { desc: "Start on consent, stop and clear on withdrawal", find: `export const isAnalyticsEnabled = () => trackingEnabled
`, replace: `onConsentChange((granted) => {
    if (granted) {
        if (pendingStart.delete('session')) initSession()
        if (pendingStart.delete('time')) startTimeTracking()
        return
    }
    stopTimeTracking()
    try {
        sessionStorage.removeItem(SESSION_KEY)
        sessionStorage.removeItem(SESSION_DATA_KEY)
    } catch { /* noop */ }
})

export const isAnalyticsEnabled = () => isTracking()
` },
        ],
    },
    {
        file: 'src/components/common/Appfooter.jsx',
        edits: [
            { desc: "Legal column adds Cookies and Legal notice", find: `                            <li><Link to="/privacy">Privacy</Link></li>
                            <li><Link to="/terms">Terms</Link></li>
`, replace: `                            <li><Link to="/privacy">Privacy</Link></li>
                            <li><Link to="/terms">Terms</Link></li>
                            <li><Link to="/legal/cookies">Cookies</Link></li>
                            <li><Link to="/legal/notice">Legal notice</Link></li>
` },
        ],
    },
    {
        file: 'src/components/Footer.jsx',
        edits: [
            { desc: "Strip header comment, import consent", find: `// Footer - Three columns per Phase 1 spec. Brand + cities, links, initiative + social.

import { Heart } from 'lucide-react'
`, replace: `import { Heart } from 'lucide-react'
import { openConsentPreferences } from '../services/consent'
` },
            { desc: "Cookie settings link", find: `                            <a href="/privacy" className="footer__link">{t('footer.privacy', 'Privacy')}</a>
`, replace: `                            <a href="/privacy" className="footer__link">{t('footer.privacy', 'Privacy')}</a>
                            <button type="button" className="footer__link" onClick={openConsentPreferences}>{t('footer.cookieSettings', 'Cookie settings')}</button>
` },
        ],
    },
    {
        file: 'src/styles/app/legal.css',
        edits: [
            { desc: "Tables and related-documents styles", find: `/* Responsive */
`, replace: `/* Tables */

.legal__table-wrap {
    overflow-x: auto;
    margin: 0 0 14px;
    border: 1px solid var(--border-subtle);
    border-radius: 10px;
}

.legal__table {
    width: 100%;
    min-width: 560px;
    border-collapse: collapse;
    font-size: 14px;
    line-height: 1.55;
}

.legal__table th,
.legal__table td {
    text-align: left;
    vertical-align: top;
    padding: 12px 14px;
    border-bottom: 1px solid var(--border-subtle);
    color: var(--text-secondary);
}

.legal__table thead th {
    font-family: var(--font-mono);
    font-size: 10px;
    font-weight: 500;
    letter-spacing: 0.14em;
    text-transform: uppercase;
    color: var(--text-muted);
    background: var(--surface-1);
}

.legal__table tbody tr:last-child th,
.legal__table tbody tr:last-child td {
    border-bottom: 0;
}

.legal__table--pairs {
    min-width: 0;
}

.legal__table--pairs th {
    width: 38%;
    font-weight: 500;
    color: var(--text-muted);
}

.legal__table--pairs td {
    color: var(--text-primary);
}


/* Related documents */

.legal__related {
    margin-top: 64px;
    padding-top: 28px;
    border-top: 1px solid var(--border-subtle);
}

.legal__related-list {
    list-style: none;
    padding: 0;
    margin: 0;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 0 24px;
}

.legal__related-list a {
    display: flex;
    align-items: center;
    min-height: 44px;
    font-size: 14px;
    color: var(--text-secondary);
    text-decoration: none;
    transition: color 180ms ease;
}

.legal__related-list a:hover {
    color: var(--azure-link);
}

@media (max-width: 720px) {
    .legal__related-list {
        grid-template-columns: 1fr;
    }
}


/* Responsive */
` },
        ],
    },
    {
        file: 'index.html',
        edits: [
            { desc: "Remove third-party font loading", find: `  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="preconnect" href="https://api.fontshare.com" crossorigin>
  <link href="https://api.fontshare.com/v2/css?f[]=switzer@400,500,600,700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">

`, replace: `` },
        ],
    },
    {
        file: 'src/main.jsx',
        edits: [
            { desc: "Self-hosted Inter and JetBrains Mono", find: `import './styles/tokens.css'
`, replace: `import '@fontsource/inter/400.css'
import '@fontsource/inter/500.css'
import '@fontsource/inter/600.css'
import '@fontsource/jetbrains-mono/400.css'
import '@fontsource/jetbrains-mono/500.css'
import './styles/tokens.css'
` },
        ],
    },
    {
        file: 'public/sitemap.xml',
        edits: [
            { desc: "Add legal pages", find: `</urlset>`, replace: `  <url>
    <loc>https://locappoint.com/legal/cookies</loc>
    <lastmod>2026-09-24</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.2</priority>
  </url>
  <url>
    <loc>https://locappoint.com/legal/notice</loc>
    <lastmod>2026-09-24</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.2</priority>
  </url>
  <url>
    <loc>https://locappoint.com/legal/dpa</loc>
    <lastmod>2026-09-24</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.2</priority>
  </url>
  <url>
    <loc>https://locappoint.com/legal/subprocessors</loc>
    <lastmod>2026-09-24</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.2</priority>
  </url>
  <url>
    <loc>https://locappoint.com/legal/ranking</loc>
    <lastmod>2026-09-24</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.2</priority>
  </url>
</urlset>` },
        ],
    },
]

const RETIRES = [
    'src/pages/app/legal/PrivacyPolicy.jsx',
    'src/pages/app/legal/TermsOfService.jsx'
]

let failed = false

for (const nf of NEW_FILES) {
    const full = path.join(REPO, nf.path)
    if (fs.existsSync(full)) { console.error(`[FAIL] Already exists: ${nf.path}`); failed = true }
    if (!fs.existsSync(path.dirname(full))) { console.error(`[FAIL] Parent dir missing: ${nf.path}`); failed = true }
}

const fileChanges = new Map()
for (const group of PATCHES) {
    const fullPath = path.join(REPO, group.file)
    if (!fs.existsSync(fullPath)) { console.error(`[FAIL] Missing: ${group.file}`); failed = true; continue }
    let content = fs.readFileSync(fullPath, 'utf8')
    const original = content
    const crlf = (content.match(/\r\n/g) || []).length
    const lf = (content.match(/\n/g) || []).length - crlf
    const eol = crlf > lf ? '\r\n' : '\n'
    let ok = true
    for (const edit of group.edits) {
        // Anchors accept CRLF or LF; replacements follow the file's dominant ending.
        const pattern = edit.find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\n/g, '\\r?\\n')
        const matches = (content.match(new RegExp(pattern, 'g')) || []).length
        if (matches !== 1) {
            console.error(`[FAIL] ${group.file}: ${matches} matches for "${edit.desc}" (expected 1)`)
            failed = true; ok = false; break
        }
        const replace = edit.replace.replace(/\n/g, eol)
        content = content.replace(new RegExp(pattern), () => replace)
    }
    if (ok) fileChanges.set(fullPath, { original, modified: content, edits: group.edits })
}

const retirePaths = []
for (const rel of RETIRES) {
    const full = path.join(REPO, rel)
    if (!fs.existsSync(full)) { console.error(`[FAIL] Retire target missing: ${rel}`); failed = true; continue }
    if (fs.existsSync(`${full}.mistake`)) { console.error(`[FAIL] Already retired: ${rel}.mistake`); failed = true; continue }
    retirePaths.push({ full, rel })
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const nf of NEW_FILES) {
    fs.writeFileSync(path.join(REPO, nf.path), nf.content)
    console.log(`[NEW] ${nf.path}`)
}
for (const [fullPath, change] of fileChanges) {
    fs.writeFileSync(`${fullPath}.backup`, change.original)
    fs.writeFileSync(fullPath, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, fullPath)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}
for (const { full, rel } of retirePaths) {
    fs.renameSync(full, `${full}.mistake`)
    console.log(`[RETIRE] ${rel} -> .mistake`)
}

console.log('\n[DONE]')
