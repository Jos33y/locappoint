$ErrorActionPreference = 'Stop'

Write-Host ""
Write-Host "  Locappoint - Legal pages, cookie consent, self-hosted fonts" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path 'package.json')) { Write-Host "  [ABORT] No package.json. Run from repo root." -ForegroundColor Red; exit 1 }
$pkg = Get-Content 'package.json' -Raw | ConvertFrom-Json
if ($pkg.name -ne 'locappoint') { Write-Host "  [ABORT] Wrong package: $($pkg.name)" -ForegroundColor Red; exit 1 }
try { $null = & node --version } catch { Write-Host "  [ABORT] Node.js not found." -ForegroundColor Red; exit 1 }

Write-Host "  What this does:" -ForegroundColor White
Write-Host ""
Write-Host "    [NEW]     src/constants/legalEntity.js  (entity details + sub-processors, one place)" -ForegroundColor Green
Write-Host "    [NEW]     src/services/consent.js" -ForegroundColor Green
Write-Host "    [NEW]     src/components/common/CookieBanner.jsx + src/styles/consent.css" -ForegroundColor Green
Write-Host "    [NEW]     src/pages/app/legal/  LegalLayout, Privacy, Terms, Cookies, LegalNotice, Dpa, Subprocessors, Ranking" -ForegroundColor Green
Write-Host "    [EDIT]    src/BookingApp.jsx  (2 edits: legal routes)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/WaitlistApp.jsx  (5 edits: legal paths go to main site, cookie banner)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/services/analytics.js  (23 edits: consent gate, comment cleanup)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/components/common/Appfooter.jsx  (1 edit: Cookies, Legal notice)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/components/Footer.jsx  (2 edits: Cookie settings)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/styles/app/legal.css  (1 edit: tables, related documents)" -ForegroundColor Yellow
Write-Host "    [EDIT]    index.html  (1 edit: Google Fonts and Fontshare removed)" -ForegroundColor Yellow
Write-Host "    [EDIT]    src/main.jsx  (1 edit: self-hosted Inter, JetBrains Mono)" -ForegroundColor Yellow
Write-Host "    [EDIT]    public/sitemap.xml  (1 edit: legal pages)" -ForegroundColor Yellow
Write-Host "    [RETIRE]  src/pages/app/legal/PrivacyPolicy.jsx  -> .mistake" -ForegroundColor Magenta
Write-Host "    [RETIRE]  src/pages/app/legal/TermsOfService.jsx  -> .mistake" -ForegroundColor Magenta
Write-Host ""
Write-Host "  Backups saved as *.backup." -ForegroundColor Gray
Write-Host ""

$confirm = Read-Host "  Apply? (y/n)"
if ($confirm -ne 'y' -and $confirm -ne 'Y') { Write-Host "  [CANCELLED]" -ForegroundColor Yellow; exit 0 }
Write-Host ""

& node (Join-Path $PSScriptRoot 'patch-legal-consent.mjs')
if ($LASTEXITCODE -ne 0) { Write-Host "  [FAIL] Exit code $LASTEXITCODE" -ForegroundColor Red; exit $LASTEXITCODE }

$payloadDir = $PSScriptRoot
if ((Split-Path $payloadDir -Leaf) -eq 'payload') {
    Set-Location (Split-Path $payloadDir -Parent)
    Remove-Item $payloadDir -Recurse -Force
}

Write-Host ""
Write-Host "  Done. Next: npm install @fontsource/inter @fontsource/jetbrains-mono, then npm run build." -ForegroundColor Green
Write-Host ""
