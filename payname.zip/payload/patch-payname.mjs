import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const SPEC = {
  "name": "payname",
  "backup": ".backup-payname",
  "prefixes": [],
  "newFiles": [],
  "replaceFiles": [
    {
      "file": "src/components/business/BusinessShell.jsx",
      "sha": "723c1bc38fdf126591f2502db00c352a3e8c7801264a40fe172aa75142b107ce"
    },
    {
      "file": "src/components/common/Appfooter.jsx",
      "sha": "d2fa0fa18385f71d13f17aa988b9693fbc94a0e6c992ee87cddda67bd1f467fd"
    },
    {
      "file": "src/pages/business/PaymentsPage.jsx",
      "sha": "b8c78a16d9ac163457ce5c6ed3348b87e42fbadb75e9af719f0a91ca5a08d828"
    },
    {
      "file": "src/styles/business/shell.css",
      "sha": "ec567a387e0cd2cc5ba0d54a1d62ff46dd1cad3db375fae3cd17a2d4739c95ab"
    },
    {
      "file": "supabase/functions/payouts/index.ts",
      "sha": "fd661c49d637caa5f419e06a5b1e648ff8463c2678c19ce685a7eb63965c96a7"
    },
    {
      "file": "supabase/functions/payouts/providers.ts",
      "sha": "fef36f0fbaeaf147cfd7866e76e37220b3a262ce6f221955aae91551bdbad63a"
    }
  ],
  "patches": [
    {
      "file": "tests/suites/payouts.mjs",
      "find": "    await wait(200)\n    await p.type('.biz-pay__nuban', '01234-56789')",
      "replace": "    await wait(200)\n    await p.type('.biz-pay__nuban', '0987654321')\n    await wait(900)\n    v = await view(p)\n    check(/in the name of CHIDI EZE/.test(v.text) && /your name \\(Adebayo Oluwaseun\\)/.test(v.text) && await p.evaluate(() => [...document.querySelectorAll('.biz-pay button')].find((b) => /Pay me here/.test(b.textContent))?.disabled), `an account in someone else's name is refused before saving: ${v.text.match(/This account[^.]*\\./)?.[0]}`)\n    await p.evaluate(() => { const i = document.querySelector('.biz-pay__nuban'); const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set; set.call(i, ''); i.dispatchEvent(new Event('input', { bubbles: true })) })\n    await wait(200)\n    await p.type('.biz-pay__nuban', '01234-56789')"
    },
    {
      "file": "tests/suites/payouts.mjs",
      "find": "    check(prov.bankCode('044') === '044' && prov.bankCode('044; drop') === null, 'bank codes are checked before use')\n    const acct = prov.newStripeAccount({ country: 'PT', currency: 'EUR', email: 'a@b.pt', name: 'Femtos', url: 'https://locappoint.com/femtos', businessId: 'b1' })",
      "replace": "    check(prov.bankCode('044') === '044' && prov.bankCode('044; drop') === null, 'bank codes are checked before use')\n    check(prov.nameMatches('ABIOLA SAMUEL OLUWASEUN', 'Abiola Samuel', 'Trimline Grooming Studio'), 'the owner\\'s own account, with a middle name, is accepted')\n    check(prov.nameMatches('SAMUEL ABIOLA', 'Abiola Samuel', 'Trimline'), 'names in another order are accepted')\n    check(prov.nameMatches('TRIMLINE GROOMING ENT', 'Abiola Samuel', 'Trimline Grooming Studio'), 'the business\\'s own account is accepted')\n    check(prov.nameMatches('\u00c1b\u00ed\u1ecd\u0301l\u00e1 Samuel', 'Abiola Samuel', 'X'), 'accents do not matter')\n    check(!prov.nameMatches('SAMUEL OKAFOR', 'Abiola Samuel', 'Trimline Grooming Studio'), 'one shared first name is not enough for the owner')\n    check(!prov.nameMatches('CHIDI EZE', 'Abiola Samuel', 'Trimline Grooming Studio'), 'someone else\\'s account is refused')\n    check(!prov.nameMatches('BEST STUDIO ENTERPRISES LTD', '', 'Best Studio Enterprises'.replace('Best', 'Prime')), 'filler words like STUDIO, ENTERPRISES and LTD do not count')\n    check(prov.nameMatches('OKAFOR NGOZI', 'Ngozi', 'X'), 'a one-word owner name needs that one word')\n    const acct = prov.newStripeAccount({ country: 'PT', currency: 'EUR', email: 'a@b.pt', name: 'Femtos', url: 'https://locappoint.com/femtos', businessId: 'b1' })"
    },
    {
      "file": "tests/suites/brand.mjs",
      "find": "    check(/fillText\\('Loc'/.test(posterImage) && /fillText\\('Appoint'/.test(posterImage), 'the saved poster image carries the two-tone wordmark')\n}",
      "replace": "    check(/fillText\\('Loc'/.test(posterImage) && /fillText\\('Appoint'/.test(posterImage), 'the saved poster image carries the two-tone wordmark')\n    check(/business\\.logo_url\\s*\\? <span className=\"biz-avatar biz-avatar--business biz-avatar--logo\"><img src=\\{business\\.logo_url\\}/.test(read('src/components/business/BusinessShell.jsx')), 'the sidebar card shows the business logo once there is one')\n    check(!/Porto, Portugal/.test(read('src/components/common/Appfooter.jsx')), 'the footer gives no city that differs from the registered address')\n}"
    },
    {
      "file": "tests/harness/fakeSupabase.js",
      "find": "  if (body.action === 'banks') return { data: { banks: [{ code: '044', name: 'Access Bank' }, { code: '058', name: 'GTBank' }] }, error: null }\n  if (body.action === 'resolve') return body.account_number === '0123456789' ? { data: { account_name: 'ADEBAYO OLUWASEUN' }, error: null } : failed('We could not find that account. Check the number and the bank.')\n  if (body.action === 'connect') return { data: { ...PAYOUT_ROWS['paystack-active'], test: true, account_name: 'ADEBAYO OLUWASEUN' }, error: null }",
      "replace": "  if (body.action === 'banks') return { data: { banks: [{ code: '044', name: 'Access Bank' }, { code: '058', name: 'GTBank' }] }, error: null }\n  if (body.action === 'resolve') {\n    if (body.account_number === '0123456789') return { data: { account_name: 'ADEBAYO OLUWASEUN', matches: true, owner_name: 'Adebayo Oluwaseun', business_name: 'Femtos Barbearia' }, error: null }\n    if (body.account_number === '0987654321') return { data: { account_name: 'CHIDI EZE', matches: false, owner_name: 'Adebayo Oluwaseun', business_name: 'Femtos Barbearia' }, error: null }\n    return failed('We could not find that account. Check the number and the bank.')\n  }\n  if (body.action === 'connect') return { data: { ...PAYOUT_ROWS['paystack-active'], test: true, account_name: 'ADEBAYO OLUWASEUN' }, error: null }"
    }
  ],
  "retires": []
}

const here = path.dirname(fileURLToPath(import.meta.url))
const root = process.cwd()
const check = process.argv.includes('--check')
const problems = []
const plan = []

const abs = (rel) => path.join(root, ...rel.split('/'))
const source = (rel) => path.join(here, 'files', ...rel.split('/'))
const read = (p) => fs.readFileSync(p, 'utf8')
const eolOf = (text) => (text.includes('\r\n') ? '\r\n' : '\n')
const toEol = (text, eol) => text.replace(/\r\n/g, '\n').replace(/\n/g, eol)
const sha = (text) => crypto.createHash('sha256').update(text.replace(/\r\n/g, '\n')).digest('hex')
const count = (hay, needle) => (needle ? hay.split(needle).length - 1 : 0)

const pkg = JSON.parse(read(abs('package.json')))
if (pkg.name !== 'locappoint') {
    console.error('  [ABORT] This is not the locappoint repo.')
    process.exit(1)
}

for (const rel of SPEC.newFiles) {
    if (fs.existsSync(abs(rel))) problems.push(`${rel} already exists (patch already applied?)`)
    else if (!fs.existsSync(source(rel))) problems.push(`payload is missing ${rel}`)
    else plan.push(['NEW', rel])
}

for (const { file, sha: expected } of SPEC.replaceFiles) {
    if (!fs.existsSync(abs(file))) { problems.push(`${file} is missing`); continue }
    if (sha(read(abs(file))) !== expected) { problems.push(`${file} is not as expected: this patch is already applied, or travelfee is not installed`); continue }
    plan.push(['REPLACE', file])
}

const srcFiles = () => {
    const out = []
    const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const full = path.join(dir, entry.name)
            if (entry.isDirectory()) { if (entry.name !== 'node_modules') walk(full) }
            else if (/\.(jsx?|css)$/.test(entry.name)) out.push(full)
        }
    }
    walk(abs('src'))
    return out
}

for (const prefix of SPEC.prefixes || []) {
    const owners = srcFiles().filter((full) => read(full).includes(prefix)).map((full) => path.relative(root, full))
    if (owners.length) problems.push(`class prefix ${prefix} is already used in ${owners.join(', ')}`)
}

const edits = new Map()
for (const p of SPEC.patches) {
    if (!fs.existsSync(abs(p.file))) { problems.push(`${p.file} is missing`); continue }
    if (!edits.has(p.file)) edits.set(p.file, read(abs(p.file)))
    const current = edits.get(p.file)
    const eol = eolOf(current)
    const find = toEol(p.find, eol)
    const hits = count(current, find)
    if (hits !== 1) { problems.push(`${p.file}: anchor matched ${hits} times, expected 1: ${JSON.stringify(p.find.slice(0, 60))}`); continue }
    edits.set(p.file, current.replace(find, () => toEol(p.replace, eol)))
}
for (const file of edits.keys()) plan.push(['EDIT', file])

for (const rel of SPEC.retires) {
    if (!fs.existsSync(abs(rel))) { problems.push(`${rel} is missing`); continue }
    const base = path.basename(rel)
    const stem = /\.(jsx?)$/.test(base) ? base.replace(/\.(jsx?)$/, '') : base
    const pattern = new RegExp(`[\\/'"]${stem.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\.jsx?)?['"]`)
    const planned = (full) => {
        const key = path.relative(root, full).split(path.sep).join('/')
        if (SPEC.replaceFiles.some((f) => f.file === key)) return read(source(key))
        return edits.has(key) ? edits.get(key) : read(full)
    }
    const users = srcFiles().filter((full) => full !== abs(rel) && pattern.test(planned(full))).map((full) => path.relative(root, full))
    if (users.length) problems.push(`${rel} is still imported by ${users.join(', ')}`)
    else plan.push(['RETIRE', rel])
}

if (problems.length) {
    console.error('  [ABORT] Nothing was written:')
    for (const p of problems) console.error(`    ${p}`)
    process.exit(1)
}

if (check) {
    for (const [kind, rel] of plan) console.log(`  [${kind}] ${rel}`)
    console.log('  Checks passed.')
    process.exit(0)
}

for (const [kind, rel] of plan) {
    const target = abs(rel)
    if (kind === 'NEW') {
        fs.mkdirSync(path.dirname(target), { recursive: true })
        fs.copyFileSync(source(rel), target)
    } else if (kind === 'REPLACE') {
        const eol = eolOf(read(target))
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, toEol(read(source(rel)), eol))
    } else if (kind === 'EDIT') {
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, edits.get(rel))
    } else if (kind === 'RETIRE') {
        fs.renameSync(target, target + '.mistake')
    }
    console.log(`  [${kind}] ${rel}`)
}
console.log('  Patch applied.')
