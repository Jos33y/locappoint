import fs from 'fs'
import path from 'path'
import crypto from 'crypto'
import { fileURLToPath } from 'url'

const REPO = process.cwd()
const HERE = path.dirname(fileURLToPath(import.meta.url))
const SPEC = {
 "new": [
  "src/components/ui/TimePicker.jsx"
 ],
 "replace": [
  {
   "path": "src/components/business/HoursEditor.jsx",
   "sha256": "10fcaafabe817fdbb1e61a0c7a300fc6efd9eefbf45efcb44220fb423da5fc44"
  },
  {
   "path": "src/styles/business/editors.css",
   "sha256": "c99ffeaacad8562e1a0fb35bf7df345e2026f744838e7f51929216130328a758"
  },
  {
   "path": "src/styles/ui-kit.css",
   "sha256": "c560a88989820f5d8cc7d0a0133fa014d50db746710f2ef5e06edb8c7f5dfa31"
  },
  {
   "path": "src/styles/business/setup.css",
   "sha256": "af5285741a6252989c6e60ca19e014ed8a52b4ddf9a79ce52f297f14e5b4abf5"
  },
  {
   "path": "src/pages/business/Setup.jsx",
   "sha256": "7f6a79cfece9f907e5edf86b5d28cbd578dfcbedb45720faf469ea11116ad2cd"
  },
  {
   "path": "src/components/ui/Picker.jsx",
   "sha256": "10056205da73c1d943102c4fb47083a8037d9206f273191db26205f9160cf5c1"
  }
 ],
 "patches": [
  {
   "file": "src/components/ui/index.js",
   "edits": [
    {
     "desc": "Export TimePicker in place of the native TimeField",
     "find": "export { TimeField } from './TimeField'",
     "replace": "export { TimePicker } from './TimePicker'"
    }
   ]
  }
 ],
 "retires": [
  "src/components/ui/TimeField.jsx"
 ],
 "backupSuffix": ".backup-hours"
}
const BACKUP = SPEC.backupSuffix

let failed = false
const fail = (msg) => { console.error(`[FAIL] ${msg}`); failed = true }
const sha = (buf) => crypto.createHash('sha256').update(buf).digest('hex')
const toCrlf = (text) => text.replace(/\r?\n/g, '\r\n')
const count = (haystack, needle) => (needle === '' ? 0 : haystack.split(needle).length - 1)

for (const rel of SPEC.new) {
    if (fs.existsSync(path.join(REPO, rel))) fail(`Already exists: ${rel}`)
    if (!fs.existsSync(path.join(HERE, 'files', rel))) fail(`Missing in payload: ${rel}`)
}

for (const item of SPEC.replace) {
    const full = path.join(REPO, item.path)
    if (!fs.existsSync(full)) { fail(`Missing: ${item.path}`); continue }
    const current = fs.readFileSync(full)
    if (sha(current) !== item.sha256) fail(`${item.path} differs from the version this patch expects (edited locally, or already replaced). Not overwriting.`)
    if (fs.existsSync(`${full}${BACKUP}`)) fail(`Backup already exists: ${item.path}${BACKUP}`)
}

const fileChanges = new Map()
for (const group of SPEC.patches) {
    const full = path.join(REPO, group.file)
    if (!fs.existsSync(full)) { fail(`Missing: ${group.file}`); continue }
    if (fs.existsSync(`${full}${BACKUP}`)) fail(`Backup already exists: ${group.file}${BACKUP}`)
    const original = fs.readFileSync(full, 'utf8')
    let content = original
    let ok = true
    for (const edit of group.edits) {
        const lf = count(content, edit.find)
        const crlf = count(content, toCrlf(edit.find))
        let find = edit.find
        let replace = edit.replace
        if (lf !== 1 && crlf === 1) { find = toCrlf(edit.find); replace = toCrlf(edit.replace) }
        else if (lf !== 1) { fail(`${group.file}: ${lf || crlf} matches for "${edit.desc}" (expected 1)`); ok = false; break }
        content = content.replace(find, () => replace)
    }
    if (ok) fileChanges.set(full, { original, modified: content, edits: group.edits })
}

const retirePaths = []
for (const rel of SPEC.retires) {
    const full = path.join(REPO, rel)
    if (!fs.existsSync(full)) { fail(`Retire target missing: ${rel}`); continue }
    if (fs.existsSync(`${full}.mistake`)) { fail(`Already retired: ${rel}.mistake`); continue }
    retirePaths.push({ full, rel })
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const rel of SPEC.new) {
    fs.mkdirSync(path.dirname(path.join(REPO, rel)), { recursive: true })
    fs.copyFileSync(path.join(HERE, 'files', rel), path.join(REPO, rel))
    console.log(`[NEW] ${rel}`)
}
for (const item of SPEC.replace) {
    const full = path.join(REPO, item.path)
    fs.copyFileSync(full, `${full}${BACKUP}`)
    fs.copyFileSync(path.join(HERE, 'files', item.path), full)
    console.log(`[REPLACE] ${item.path}`)
}
for (const [full, change] of fileChanges) {
    fs.writeFileSync(`${full}${BACKUP}`, change.original)
    fs.writeFileSync(full, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, full)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}

for (const { full, rel } of retirePaths) {
    fs.renameSync(full, `${full}.mistake`)
    console.log(`[RETIRE] ${rel} -> .mistake`)
}

console.log('\n[DONE]')
