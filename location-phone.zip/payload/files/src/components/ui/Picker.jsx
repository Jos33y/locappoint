import { useEffect, useId, useMemo, useRef, useState } from 'react'
import { Check, ChevronDown, Search } from 'lucide-react'
import { Sheet } from './Sheet'
import '../../styles/ui-kit.css'

const fold = (text) => (text || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase()

const prefersSheet = () =>
    typeof window !== 'undefined' && typeof window.matchMedia === 'function' &&
    (window.matchMedia('(pointer: coarse)').matches || window.matchMedia('(max-width: 767px)').matches)

export const Picker = ({
    id, value, onChange, options, placeholder = 'Choose one', title, popular = [], searchable = false, compact = false,
    searchPlaceholder = 'Search', emptyText = 'Nothing matches', 'aria-invalid': invalid, 'aria-describedby': describedBy,
}) => {
    const autoId = useId()
    const listId = `${id || autoId}-list`
    const triggerRef = useRef(null)
    const wrapRef = useRef(null)
    const searchRef = useRef(null)
    const listRef = useRef(null)
    const [open, setOpen] = useState(false)
    const [asSheet, setAsSheet] = useState(false)
    const [above, setAbove] = useState(false)
    const [maxHeight, setMaxHeight] = useState(340)
    const [query, setQuery] = useState('')
    const [active, setActive] = useState(0)

    const selected = options.find((o) => o.value === value)

    const sections = useMemo(() => {
        const q = fold(query.trim())
        const match = (o) => !q || fold(o.label).includes(q) || fold(o.keywords).includes(q)
        const found = options.filter(match)
        const out = []
        if (!q && popular.length > 0) {
            const top = popular.map((v) => options.find((o) => o.value === v)).filter(Boolean)
            if (top.length) out.push({ name: 'Popular', items: top })
        }
        const groups = []
        for (const o of found) {
            const name = q ? null : o.group || null
            let g = groups.find((x) => x.name === name)
            if (!g) { g = { name, items: [] }; groups.push(g) }
            g.items.push(o)
        }
        return out.concat(groups)
    }, [options, popular, query])

    const flat = useMemo(() => sections.flatMap((s, si) => s.items.map((o, i) => ({ ...o, key: `${si}-${i}` }))), [sections])

    const openPicker = () => {
        const sheet = prefersSheet()
        setAsSheet(sheet)
        if (!sheet && triggerRef.current) {
            const r = triggerRef.current.getBoundingClientRect()
            const below = window.innerHeight - r.bottom - 16
            const over = r.top - 16
            const flip = below < 280 && over > below
            setAbove(flip)
            setMaxHeight(Math.max(160, Math.min(340, flip ? over : below)))
        }
        setQuery('')
        setOpen(true)
    }

    const close = (refocus = true) => {
        setOpen(false)
        if (refocus) requestAnimationFrame(() => triggerRef.current?.focus({ preventScroll: true }))
    }

    const choose = (option) => {
        onChange(option.value)
        close()
    }

    useEffect(() => {
        if (!open) return
        const current = flat.findIndex((o) => o.value === value)
        setActive(current >= 0 && !query ? current : 0)
    }, [open, query, flat, value])

    useEffect(() => {
        if (!open) return undefined
        const focusTarget = searchable && !asSheet ? searchRef.current : listRef.current
        requestAnimationFrame(() => focusTarget?.focus({ preventScroll: true }))
        if (asSheet) return undefined
        const onDown = (event) => { if (!wrapRef.current?.contains(event.target)) close(false) }
        document.addEventListener('mousedown', onDown)
        return () => document.removeEventListener('mousedown', onDown)
    }, [open, asSheet, searchable])

    useEffect(() => {
        if (!open) return
        listRef.current?.querySelector(`[data-index="${active}"]`)?.scrollIntoView({ block: 'nearest' })
    }, [active, open])

    const onKeyDown = (event) => {
        if (event.key === 'ArrowDown') { event.preventDefault(); setActive((a) => Math.min(flat.length - 1, a + 1)) }
        else if (event.key === 'ArrowUp') { event.preventDefault(); setActive((a) => Math.max(0, a - 1)) }
        else if (event.key === 'Home') { event.preventDefault(); setActive(0) }
        else if (event.key === 'End') { event.preventDefault(); setActive(flat.length - 1) }
        else if (event.key === 'Enter') { event.preventDefault(); if (flat[active]) choose(flat[active]) }
        else if (event.key === 'Escape' && !asSheet) { event.preventDefault(); close() }
        else if (event.key === 'Tab' && !asSheet) close(false)
    }

    const activeId = flat[active] ? `${listId}-${flat[active].key}` : undefined
    let index = -1

    const panel = (
        <div
            className={`ui-picker-panel${asSheet ? ' ui-picker-panel--sheet' : ''}`}
            style={asSheet ? undefined : { maxHeight }}
            onKeyDown={onKeyDown}
        >
            {searchable && (
                <label className="ui-picker-search">
                    <Search size={16} aria-hidden="true" />
                    <input
                        ref={searchRef}
                        type="search"
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        placeholder={searchPlaceholder}
                        aria-label={searchPlaceholder}
                        role="combobox"
                        aria-expanded="true"
                        aria-controls={listId}
                        aria-activedescendant={activeId}
                        autoComplete="off"
                        spellCheck={false}
                    />
                </label>
            )}
            <div
                ref={listRef}
                id={listId}
                className="ui-picker-list"
                role="listbox"
                aria-label={title}
                tabIndex={searchable ? -1 : 0}
                aria-activedescendant={searchable ? undefined : activeId}
            >
                {flat.length === 0 && <p className="ui-picker-empty">{emptyText}</p>}
                {sections.map((section, si) => (
                    <div key={`${section.name}-${si}`} role="group" aria-label={section.name || undefined} className="ui-picker-group">
                        {section.name && <p className="ui-picker-grouplabel" aria-hidden="true">{section.name}</p>}
                        {section.items.map((option, i) => {
                            index += 1
                            const at = index
                            const isSelected = option.value === value
                            return (
                                <div
                                    key={`${si}-${i}`}
                                    id={`${listId}-${si}-${i}`}
                                    data-index={at}
                                    role="option"
                                    aria-selected={isSelected}
                                    className={`ui-picker-option${at === active && !asSheet ? ' is-active' : ''}${isSelected ? ' is-selected' : ''}`}
                                    onMouseMove={() => setActive(at)}
                                    onClick={() => choose(option)}
                                >
                                    {option.prefix}
                                    <span className="ui-picker-optlabel">{option.label}</span>
                                    {option.meta && <span className="ui-picker-meta">{option.meta}</span>}
                                    {isSelected && <Check size={16} aria-hidden="true" />}
                                </div>
                            )
                        })}
                    </div>
                ))}
            </div>
        </div>
    )

    return (
        <div ref={wrapRef} className="ui-picker-wrap">
            <button
                ref={triggerRef}
                id={id}
                type="button"
                className={`ui-picker-trigger${selected ? '' : ' is-placeholder'}${invalid ? ' is-invalid' : ''}${compact ? ' ui-picker-trigger--compact' : ''}`}
                aria-label={compact && selected ? `${title}: ${selected.label}` : undefined}
                aria-haspopup="listbox"
                aria-expanded={open}
                aria-invalid={invalid}
                aria-describedby={describedBy}
                onClick={() => (open ? close() : openPicker())}
                onKeyDown={(e) => { if ((e.key === 'ArrowDown' || e.key === 'ArrowUp') && !open) { e.preventDefault(); openPicker() } }}
            >
                {selected?.prefix}
                <span className="ui-picker-value">{selected ? (compact ? selected.meta || selected.label : selected.label) : placeholder}</span>
                <ChevronDown size={18} aria-hidden="true" />
            </button>
            {open && !asSheet && <div className={`ui-picker-pop${above ? ' is-above' : ''}`}>{panel}</div>}
            {asSheet && <Sheet open={open} onClose={() => close()} title={title}>{panel}</Sheet>}
        </div>
    )
}
