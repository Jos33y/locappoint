import fs from 'fs'
import path from 'path'
import crypto from 'crypto'
import { fileURLToPath } from 'url'

const REPO = process.cwd()
const HERE = path.dirname(fileURLToPath(import.meta.url))
const SPEC = {
 "new": [
  "src/constants/locations.js",
  "src/components/ui/Flag.jsx",
  "src/components/ui/PhoneField.jsx",
  "supabase/migrations/onboarding-d.sql",
  "supabase/migrations/onboarding-d-verify.sql"
 ],
 "replace": [
  {
   "path": "src/pages/business/Setup.jsx",
   "sha256": "2b1c5aed20a68250d0ecc71983a9ced09459c4809eb6ae82673147c5e50381a6"
  },
  {
   "path": "src/styles/business/setup.css",
   "sha256": "02ca236bd0ffb3ab998b50c490d40981a9d3b54718fc988d0334a02cdae96592"
  },
  {
   "path": "src/styles/ui-kit.css",
   "sha256": "7dc025dfa62d03b5690e3464ca49f7fbace0f862f46970460b573613b9dc133e"
  },
  {
   "path": "src/components/ui/Picker.jsx",
   "sha256": "3928e9d7d97de2c434ef72cd449868e8862ae9d0ce8a325264083e554464ff94"
  },
  {
   "path": "src/constants/categories.js",
   "sha256": "9c410a0aa3f920d0e9b626cb24006a6e351ef3b2c7144f2275899261b7dd02ab"
  },
  {
   "path": "src/services/setup.js",
   "sha256": "186ca7d82d854595c7a1dff3ae3f4e948ac57877c3ce2d76f8605c396633328e"
  },
  {
   "path": "src/components/business/PublicPageView.jsx",
   "sha256": "6fc818badddcbc5add7636b75fdc79f239450c2aa4a16a93e8b1c656bcaf90b7"
  },
  {
   "path": "src/pages/app/PublicBusinessPage.jsx",
   "sha256": "2f91e23357135d6fa01c5f7e276cc27f1c9515d2c1b11491f5c6e371e055f2cd"
  }
 ],
 "patches": [
  {
   "file": "src/components/ui/index.js",
   "edits": [
    {
     "desc": "Export the phone and flag primitives",
     "find": "export { Picker } from './Picker'",
     "replace": "export { Picker } from './Picker'\nexport { PhoneField } from './PhoneField'\nexport { Flag } from './Flag'"
    }
   ]
  },
  {
   "file": "package.json",
   "edits": [
    {
     "desc": "Add phone and flag libraries",
     "find": "    \"lucide-react\": \"^0.553.0\",\n",
     "replace": "    \"country-flag-icons\": \"^1.6.20\",\n    \"libphonenumber-js\": \"^1.13.14\",\n    \"lucide-react\": \"^0.553.0\",\n"
    }
   ]
  }
 ],
 "retires": [],
 "backupSuffix": ".backup-location"
}
const BACKUP = SPEC.backupSuffix

let failed = false
const fail = (msg) => { console.error(`[FAIL] ${msg}`); failed = true }
const sha = (buf) => crypto.createHash('sha256').update(buf).digest('hex')
const toCrlf = (text) => text.replace(/\r?\n/g, '\r\n')
const count = (haystack, needle) => (needle === '' ? 0 : haystack.split(needle).length - 1)

for (const rel of SPEC.new) {
    if (fs.existsSync(path.join(REPO, rel))) fail(`Already exists: ${rel}`)
    if (!fs.existsSync(path.join(HERE, 'files', rel))) fail(`Missing in payload: ${rel}`)
}

for (const item of SPEC.replace) {
    const full = path.join(REPO, item.path)
    if (!fs.existsSync(full)) { fail(`Missing: ${item.path}`); continue }
    const current = fs.readFileSync(full)
    if (sha(current) !== item.sha256) fail(`${item.path} differs from the version this patch expects (edited locally, or already replaced). Not overwriting.`)
    if (fs.existsSync(`${full}${BACKUP}`)) fail(`Backup already exists: ${item.path}${BACKUP}`)
}

const fileChanges = new Map()
for (const group of SPEC.patches) {
    const full = path.join(REPO, group.file)
    if (!fs.existsSync(full)) { fail(`Missing: ${group.file}`); continue }
    if (fs.existsSync(`${full}${BACKUP}`)) fail(`Backup already exists: ${group.file}${BACKUP}`)
    const original = fs.readFileSync(full, 'utf8')
    let content = original
    let ok = true
    for (const edit of group.edits) {
        const lf = count(content, edit.find)
        const crlf = count(content, toCrlf(edit.find))
        let find = edit.find
        let replace = edit.replace
        if (lf !== 1 && crlf === 1) { find = toCrlf(edit.find); replace = toCrlf(edit.replace) }
        else if (lf !== 1) { fail(`${group.file}: ${lf || crlf} matches for "${edit.desc}" (expected 1)`); ok = false; break }
        content = content.replace(find, () => replace)
    }
    if (ok) fileChanges.set(full, { original, modified: content, edits: group.edits })
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const rel of SPEC.new) {
    fs.mkdirSync(path.dirname(path.join(REPO, rel)), { recursive: true })
    fs.copyFileSync(path.join(HERE, 'files', rel), path.join(REPO, rel))
    console.log(`[NEW] ${rel}`)
}
for (const item of SPEC.replace) {
    const full = path.join(REPO, item.path)
    fs.copyFileSync(full, `${full}${BACKUP}`)
    fs.copyFileSync(path.join(HERE, 'files', item.path), full)
    console.log(`[REPLACE] ${item.path}`)
}
for (const [full, change] of fileChanges) {
    fs.writeFileSync(`${full}${BACKUP}`, change.original)
    fs.writeFileSync(full, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, full)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}

console.log('\n[DONE]')
