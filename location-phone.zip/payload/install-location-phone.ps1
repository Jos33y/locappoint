$ErrorActionPreference = 'Stop'

Write-Host ""
Write-Host "  Locappoint - Location and phone" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path 'package.json')) {
    Write-Host "  [ABORT] No package.json. Run from repo root." -ForegroundColor Red
    exit 1
}
$pkg = Get-Content 'package.json' -Raw | ConvertFrom-Json
if ($pkg.name -ne 'locappoint') {
    Write-Host "  [ABORT] Wrong package: $($pkg.name)" -ForegroundColor Red
    exit 1
}
try { $null = & node --version } catch {
    Write-Host "  [ABORT] Node.js not found." -ForegroundColor Red
    exit 1
}

Write-Host "  What this does:" -ForegroundColor White
Write-Host ""
Write-Host "    [NEW]     src/constants/locations.js" -ForegroundColor Green
Write-Host "    [NEW]     src/components/ui/Flag.jsx" -ForegroundColor Green
Write-Host "    [NEW]     src/components/ui/PhoneField.jsx" -ForegroundColor Green
Write-Host "    [NEW]     supabase/migrations/onboarding-d.sql" -ForegroundColor Green
Write-Host "    [NEW]     supabase/migrations/onboarding-d-verify.sql" -ForegroundColor Green
Write-Host "    [REPLACE] src/pages/business/Setup.jsx" -ForegroundColor Cyan
Write-Host "    [REPLACE] src/styles/business/setup.css" -ForegroundColor Cyan
Write-Host "    [REPLACE] src/styles/ui-kit.css" -ForegroundColor Cyan
Write-Host "    [REPLACE] src/components/ui/Picker.jsx" -ForegroundColor Cyan
Write-Host "    [REPLACE] src/constants/categories.js" -ForegroundColor Cyan
Write-Host "    [REPLACE] src/services/setup.js" -ForegroundColor Cyan
Write-Host "    [REPLACE] src/components/business/PublicPageView.jsx" -ForegroundColor Cyan
Write-Host "    [REPLACE] src/pages/app/PublicBusinessPage.jsx" -ForegroundColor Cyan
Write-Host "    [EDIT]    src/components/ui/index.js  (1 edit)" -ForegroundColor Yellow
Write-Host "    [EDIT]    package.json  (1 edit)" -ForegroundColor Yellow
Write-Host ""
Write-Host "  Run onboarding-d.sql in Supabase BEFORE this patch." -ForegroundColor Yellow
Write-Host "  Then runs npm install for libphonenumber-js and country-flag-icons." -ForegroundColor White
Write-Host "  Backups saved as *.backup-location." -ForegroundColor Gray
Write-Host ""

$confirm = Read-Host "  Apply? (y/n)"
if ($confirm -ne 'y' -and $confirm -ne 'Y') { Write-Host "  [CANCELLED]" -ForegroundColor Yellow; exit 0 }
Write-Host ""

& node (Join-Path $PSScriptRoot 'patch-location-phone.mjs')
if ($LASTEXITCODE -ne 0) { Write-Host "  [FAIL] Exit code $LASTEXITCODE" -ForegroundColor Red; exit $LASTEXITCODE }

Write-Host ""
Write-Host ""
Write-Host "  Installing libraries..." -ForegroundColor White
& npm install --no-audit --no-fund
if ($LASTEXITCODE -ne 0) {
    Write-Host "  [WARN] npm install failed. Files are patched; run npm install yourself before building." -ForegroundColor Yellow
}

$payloadDir = $PSScriptRoot
if ((Split-Path $payloadDir -Leaf) -eq 'payload') {
    Set-Location (Split-Path $payloadDir -Parent)
    Remove-Item $payloadDir -Recurse -Force
}

Write-Host ""
Write-Host "  Done. npm run build, redeploy." -ForegroundColor Green
Write-Host ""
