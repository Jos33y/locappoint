$ErrorActionPreference = 'Stop'

Write-Host ""
Write-Host "  Locappoint - Business shell v2: sidebar, top bar, planned sections, loaders" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path 'package.json')) { Write-Host "  [ABORT] No package.json. Run from repo root." -ForegroundColor Red; exit 1 }
$pkg = Get-Content 'package.json' -Raw | ConvertFrom-Json
if ($pkg.name -ne 'locappoint') { Write-Host "  [ABORT] Wrong package: $($pkg.name)" -ForegroundColor Red; exit 1 }
try { $null = & node --version } catch { Write-Host "  [ABORT] Node.js not found." -ForegroundColor Red; exit 1 }

Write-Host "  Applies on top of batch4a2-redesign (already installed)." -ForegroundColor Magenta
Write-Host ""
Write-Host "  What this does:" -ForegroundColor White
Write-Host ""
Write-Host "    [NEW]      src/styles/business/foundation.css  (tokens: elevation, tints, data colours, motion)" -ForegroundColor Green
Write-Host "    [NEW]      src/components/business/  Brand.jsx (mark, ring, loader), nav.js" -ForegroundColor Green
Write-Host "    [NEW]      src/pages/business/Planned.jsx + src/styles/business/planned.css" -ForegroundColor Green
Write-Host "    [REPLACE]  BusinessShell, ShareLink, Today, Calendar, business.js, shell/day/calendar css" -ForegroundColor Yellow
Write-Host "    [EDIT]     src/BookingApp.jsx  (routes for Assistant, Clients, Team, Insights, Notifications)" -ForegroundColor Yellow
Write-Host "    [EDIT]     index.html  (boot loader: ring around the mark)" -ForegroundColor Yellow
Write-Host ""
Write-Host "  Everything replaced or edited is saved as *.backup first." -ForegroundColor Gray
Write-Host ""

$confirm = Read-Host "  Apply? (y/n)"
if ($confirm -ne 'y' -and $confirm -ne 'Y') { Write-Host "  [CANCELLED]" -ForegroundColor Yellow; exit 0 }
Write-Host ""

& node (Join-Path $PSScriptRoot 'patch-business-shell-v2.mjs')
if ($LASTEXITCODE -ne 0) { Write-Host "  [FAIL] Exit code $LASTEXITCODE" -ForegroundColor Red; exit $LASTEXITCODE }

$payloadDir = $PSScriptRoot
if ((Split-Path $payloadDir -Leaf) -eq 'payload') {
    Set-Location (Split-Path $payloadDir -Parent)
    Remove-Item $payloadDir -Recurse -Force
}

Write-Host ""
Write-Host "  Done. npm run build, then look at /portal at phone and desktop widths." -ForegroundColor Green
Write-Host ""
