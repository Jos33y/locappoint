import fs from 'fs'
import path from 'path'

const REPO = process.cwd()

const NEW_FILES = [
    { path: 'src/components/business/Brand.jsx', content: `import { useId } from 'react'

export const Mark = ({ size = 28 }) => (
    <img src="/brand/loca-mark.svg" alt="" width={size} height={size} className="lc-mark" draggable="false" />
)

export const Wordmark = () => (
    <span className="lc-wordmark" aria-label="LocAppoint">
        <span>Loc</span><span className="lc-wordmark__accent">Appoint</span>
    </span>
)

export const Ring = ({ value, size = 40, stroke = 4, label }) => {
    const gradientId = useId()
    const radius = (size - stroke) / 2
    const circumference = 2 * Math.PI * radius
    const clamped = Math.max(0, Math.min(1, value))
    return (
        <svg width={size} height={size} viewBox={\`0 0 \${size} \${size}\`} role="img" aria-label={label} className="lc-ring">
            <defs>
                <linearGradient id={gradientId} x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="var(--azure)" />
                    <stop offset="100%" stopColor="var(--signal)" />
                </linearGradient>
            </defs>
            <circle className="lc-ring__track" cx={size / 2} cy={size / 2} r={radius} strokeWidth={stroke} />
            <circle
                className="lc-ring__value"
                cx={size / 2}
                cy={size / 2}
                r={radius}
                strokeWidth={stroke}
                stroke={\`url(#\${gradientId})\`}
                strokeDasharray={circumference}
                strokeDashoffset={circumference * (1 - clamped)}
                transform={\`rotate(-90 \${size / 2} \${size / 2})\`}
            />
        </svg>
    )
}

export const BrandLoader = ({ label = 'Loading' }) => (
    <div className="lc-loader" role="status" aria-label={label}>
        <svg className="lc-loader__ring" viewBox="0 0 72 72" aria-hidden="true">
            <defs>
                <linearGradient id="lc-ring-gradient" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="var(--azure)" />
                    <stop offset="100%" stopColor="var(--signal)" />
                </linearGradient>
            </defs>
            <circle className="lc-loader__track" cx="36" cy="36" r="30" />
            <circle className="lc-loader__arc" cx="36" cy="36" r="30" />
        </svg>
        <Mark size={32} />
    </div>
)

export const initials = (name = '') =>
    name.split(/\\s+/).filter(Boolean).slice(0, 2).map((part) => part[0].toUpperCase()).join('') || 'L'
` },
    { path: 'src/components/business/nav.js', content: `import { Bell, CalendarDays, ChartColumn, Clock, MessagesSquare, Scissors, Store, Sun, Users, UsersRound } from 'lucide-react'

export const NAV_GROUPS = [
    {
        label: 'Run the day',
        items: [
            { to: '/portal', label: 'Today', icon: Sun, end: true, tab: true },
            { to: '/portal/calendar', label: 'Calendar', icon: CalendarDays, tab: true },
            { to: '/portal/assistant', label: 'Assistant', icon: MessagesSquare, tab: true, planned: 'assistant' },
            { to: '/portal/clients', label: 'Clients', icon: Users, tab: true, planned: 'clients' },
        ],
    },
    {
        label: 'Set up',
        items: [
            { to: '/portal/services', label: 'Services', icon: Scissors },
            { to: '/portal/team', label: 'Team', icon: UsersRound, planned: 'team' },
            { to: '/portal/hours', label: 'Hours', icon: Clock },
            { to: '/portal/page', label: 'Business page', icon: Store },
        ],
    },
    {
        label: 'Grow',
        items: [
            { to: '/portal/insights', label: 'Insights', icon: ChartColumn, planned: 'insights' },
            { to: '/portal/notifications', label: 'Notifications', icon: Bell, planned: 'notifications' },
        ],
    },
]

export const NAV_ITEMS = NAV_GROUPS.flatMap((group) => group.items)

export const PLANNED = {
    assistant: {
        title: 'Assistant',
        promise: 'Run your day in a sentence. Ask what is next, book a caller, block an hour, and it is done.',
        points: [
            'Ask "What is my day?" or "Who is next?" and get the answer in a line',
            'Book, confirm, move and cancel by chat, always with a confirm step first',
            'See every conversation the WhatsApp assistant has with your clients',
            'Decide what it may answer, and when it hands the chat over to you',
        ],
        preview: 'chat',
    },
    clients: {
        title: 'Clients',
        promise: 'Everyone who books you, in one place, with the history that matters.',
        points: [
            'Everyone who booked online, by phone or walked in, searchable',
            'Visits, last visit and total spent on every client',
            'Reliability at a glance: kept, cancelled and no-show counts',
            'Private notes, and book again in one tap',
        ],
        preview: 'list',
    },
    team: {
        title: 'Team',
        promise: 'Add the people who take bookings, each with their own calendar.',
        points: [
            'Invite by email or phone; they join with their own account',
            'Owner and staff roles: staff see their own day, you see everyone',
            'Each person has their own hours and the services they do',
            'Clients pick a person, or anyone who is free',
        ],
        preview: 'list',
    },
    insights: {
        title: 'Insights',
        promise: 'See what your time is worth, week by week.',
        points: [
            'Money this week against last, earned and still to come',
            'Lost to no-shows, and saved by reminders',
            'Your busiest days and hours, and your most booked services',
            'A weekly recap, ready to share on WhatsApp or Instagram',
        ],
        preview: 'chart',
    },
    notifications: {
        title: 'Notifications',
        promise: 'Everything that changed, the moment it changes.',
        points: [
            'New bookings, cancellations and moves, as they happen',
            'An unread count on the bell, so nothing slips',
            'Email and WhatsApp alerts with your reminders',
        ],
        preview: 'list',
    },
}

export const titleFor = (pathname) => {
    const match = [...NAV_ITEMS]
        .sort((a, b) => b.to.length - a.to.length)
        .find((item) => (item.end ? pathname === item.to : pathname.startsWith(item.to)))
    if (match) return match.label
    if (pathname.startsWith('/portal/settings')) return 'Settings'
    return 'Today'
}
` },
    { path: 'src/pages/business/Planned.jsx', content: `import { Check } from 'lucide-react'
import { NAV_ITEMS, PLANNED } from '../../components/business/nav'
import '../../styles/business/planned.css'

const Preview = ({ kind }) => {
    if (kind === 'chart') {
        return (
            <div className="lc-preview lc-preview--chart" aria-hidden="true">
                {[38, 52, 44, 70, 62, 88, 56].map((height, i) => (
                    <span key={i} style={{ height: \`\${height}%\` }} />
                ))}
            </div>
        )
    }
    if (kind === 'chat') {
        return (
            <div className="lc-preview lc-preview--chat" aria-hidden="true">
                <span className="lc-bubble lc-bubble--me">What is my day?</span>
                <span className="lc-bubble">Six bookings, two free gaps. Next is Jameson at 10:00.</span>
                <span className="lc-bubble lc-bubble--me">Block 14:00 to 15:00</span>
                <span className="lc-bubble">Blocked. Confirm?</span>
            </div>
        )
    }
    return (
        <div className="lc-preview lc-preview--list" aria-hidden="true">
            {[0, 1, 2, 3].map((i) => (
                <span key={i} className="lc-ghostrow">
                    <span className="lc-ghostrow__dot" />
                    <span className="lc-ghostrow__line" style={{ width: \`\${60 - i * 8}%\` }} />
                    <span className="lc-ghostrow__tag" />
                </span>
            ))}
        </div>
    )
}

const Planned = ({ section }) => {
    const plan = PLANNED[section]
    const nav = NAV_ITEMS.find((item) => item.planned === section)
    const Icon = nav?.icon

    return (
        <div className="biz-page lc-planned">
            <header className="lc-planned__head">
                <span className="lc-planned__icon">{Icon && <Icon size={22} aria-hidden="true" />}</span>
                <div>
                    <p className="lc-planned__status">In build</p>
                    <h1 className="biz-page__title">{plan.title}</h1>
                </div>
            </header>

            <p className="lc-planned__promise">{plan.promise}</p>

            <div className="lc-planned__grid">
                <Preview kind={plan.preview} />
                <ul className="lc-planned__points">
                    {plan.points.map((point) => (
                        <li key={point}>
                            <Check size={16} aria-hidden="true" />
                            <span>{point}</span>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    )
}

export default Planned
` },
    { path: 'src/styles/business/foundation.css', content: `:root {
    --lc-canvas: #08090C;
    --lc-well: #050608;
    --lc-card: #10131A;
    --lc-raised: #171B25;
    --lc-raised-hover: #1D2230;
    --lc-overlay: #1B202B;
    --lc-line: rgba(244, 246, 251, 0.07);
    --lc-line-strong: rgba(244, 246, 251, 0.12);
    --lc-highlight: rgba(255, 255, 255, 0.05);

    --lc-shadow-raised: inset 0 1px 0 var(--lc-highlight), 0 1px 2px rgba(3, 8, 24, 0.5), 0 8px 24px -12px rgba(3, 8, 24, 0.8);
    --lc-shadow-overlay: inset 0 1px 0 var(--lc-highlight), 0 24px 64px -16px rgba(3, 8, 24, 0.9);
    --lc-shadow-accent: 0 8px 24px -8px rgba(45, 127, 240, 0.55);

    --lc-glass: rgba(8, 9, 12, 0.72);
    --lc-glass-blur: saturate(160%) blur(18px);

    --lc-ink-1: #F4F6FB;
    --lc-ink-2: #B8C0D0;
    --lc-ink-3: #8892A4;
    --lc-ink-4: #5A6272;

    --lc-success: #4CC38A;
    --lc-success-tint: rgba(43, 140, 90, 0.16);
    --lc-warning: #F0B254;
    --lc-warning-tint: rgba(232, 154, 62, 0.16);
    --lc-danger: #F07A6E;
    --lc-danger-tint: rgba(180, 62, 51, 0.2);
    --lc-info: #5BA0FF;
    --lc-info-tint: rgba(45, 127, 240, 0.16);

    --lc-data-1: #2D7FF0;
    --lc-data-2: #E89A3E;
    --lc-data-3: #3FB68B;
    --lc-data-4: #E0607E;
    --lc-data-5: #6BA5F5;
    --lc-data-6: #C9A66B;

    --lc-ease: cubic-bezier(0.22, 1, 0.36, 1);
    --lc-fast: 120ms;
    --lc-base: 280ms;
    --lc-slow: 900ms;

    --lc-r-sm: 8px;
    --lc-r-md: 12px;
    --lc-r-lg: 16px;
    --lc-r-xl: 24px;
}

.lc-skel {
    display: block;
    border-radius: var(--lc-r-sm);
    background: var(--lc-raised);
    animation: lc-pulse 1.4s var(--lc-ease) infinite;
}

@keyframes lc-pulse {
    0%, 100% { opacity: 0.55; }
    50% { opacity: 1; }
}

.lc-loader {
    position: relative;
    display: grid;
    place-items: center;
    width: 72px;
    height: 72px;
}

.lc-loader__ring {
    position: absolute;
    inset: 0;
    animation: lc-spin 1.6s linear infinite;
}

.lc-loader__track {
    fill: none;
    stroke: var(--lc-line-strong);
    stroke-width: 2.5;
}

.lc-loader__arc {
    fill: none;
    stroke: url(#lc-ring-gradient);
    stroke-width: 2.5;
    stroke-linecap: round;
    stroke-dasharray: 60 176;
}

.lc-loader img {
    width: 32px;
    height: 32px;
}

@keyframes lc-spin {
    to { transform: rotate(360deg); }
}

.lc-ring__track {
    fill: none;
    stroke: var(--lc-line-strong);
}

.lc-ring__value {
    fill: none;
    stroke-linecap: round;
    transition: stroke-dashoffset var(--lc-slow) var(--lc-ease);
}

@media (prefers-reduced-motion: reduce) {
    .lc-skel,
    .lc-loader__ring {
        animation: none;
    }

    .lc-ring__value {
        transition: none;
    }
}
` },
    { path: 'src/styles/business/planned.css', content: `.lc-planned__head {
    display: flex;
    align-items: center;
    gap: var(--space-4);
}

.lc-planned__icon {
    display: grid;
    place-items: center;
    width: 52px;
    height: 52px;
    border-radius: var(--lc-r-lg);
    background: var(--lc-raised);
    box-shadow: var(--lc-shadow-raised);
    color: var(--azure);
}

.lc-planned__status {
    margin: 0 0 2px;
    color: var(--lc-warning);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
}

.lc-planned__promise {
    max-width: 34ch;
    margin: 0;
    font-family: var(--font-display);
    font-size: var(--text-2xl);
    font-weight: var(--font-weight-medium);
    letter-spacing: var(--tracking-tight);
    line-height: 1.25;
}

.lc-planned__grid {
    display: grid;
    gap: var(--space-5);
}

.lc-planned__points {
    display: flex;
    flex-direction: column;
    gap: var(--space-3);
    margin: 0;
    padding: 0;
    list-style: none;
}

.lc-planned__points li {
    display: flex;
    align-items: flex-start;
    gap: var(--space-3);
    color: var(--lc-ink-2);
    font-size: var(--text-base);
    line-height: 1.5;
}

.lc-planned__points svg {
    flex: none;
    margin-top: 4px;
    color: var(--lc-success);
}

.lc-preview {
    position: relative;
    min-height: 220px;
    padding: var(--space-5);
    border-radius: var(--lc-r-xl);
    background: var(--lc-card);
    box-shadow: inset 0 0 0 1px var(--lc-line);
    overflow: hidden;
}

.lc-preview--chart {
    display: flex;
    align-items: flex-end;
    gap: var(--space-3);
}

.lc-preview--chart span {
    flex: 1;
    border-radius: 6px 6px 2px 2px;
    background: var(--lc-raised);
    box-shadow: inset 0 1px 0 var(--lc-highlight);
}

.lc-preview--chart span:nth-child(6) {
    background: var(--azure);
    box-shadow: var(--lc-shadow-accent);
}

.lc-preview--chat {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
}

.lc-bubble {
    align-self: flex-start;
    max-width: 80%;
    padding: var(--space-2) var(--space-3);
    border-radius: var(--lc-r-md) var(--lc-r-md) var(--lc-r-md) 4px;
    background: var(--lc-raised);
    color: var(--lc-ink-2);
    font-size: var(--text-sm);
}

.lc-bubble--me {
    align-self: flex-end;
    border-radius: var(--lc-r-md) var(--lc-r-md) 4px var(--lc-r-md);
    background: var(--azure);
    color: var(--lc-ink-1);
}

.lc-preview--list {
    display: flex;
    flex-direction: column;
    gap: var(--space-3);
}

.lc-ghostrow {
    display: flex;
    align-items: center;
    gap: var(--space-3);
    height: 40px;
    padding: 0 var(--space-3);
    border-radius: var(--lc-r-md);
    background: var(--lc-raised);
}

.lc-ghostrow__dot {
    width: 24px;
    height: 24px;
    border-radius: var(--radius-full);
    background: var(--lc-raised-hover);
}

.lc-ghostrow__line {
    height: 8px;
    border-radius: var(--radius-full);
    background: var(--lc-raised-hover);
}

.lc-ghostrow__tag {
    width: 44px;
    height: 16px;
    margin-left: auto;
    border-radius: var(--radius-full);
    background: var(--lc-success-tint);
}

@media (min-width: 1024px) {
    .lc-planned__grid {
        grid-template-columns: 1.1fr 1fr;
        align-items: center;
        gap: var(--space-10);
    }
}
` },
]

// Files from the earlier 4a-2 patches, rewritten for the new shell, so replaced whole.
const REPLACE_FILES = [
    { path: 'src/components/business/BusinessShell.jsx', content: `import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Link, NavLink, Navigate, Outlet, useLocation } from 'react-router-dom'
import { ArrowLeftRight, Bell, ChevronRight, LogOut, Menu, Plus, Search, Settings, Share2 } from 'lucide-react'
import { useAuth } from '../../hooks/useAuth'
import { loadWorkspace, pageStrength } from '../../services/business'
import { WorkspaceContext } from './WorkspaceContext'
import { NAV_GROUPS, NAV_ITEMS, titleFor } from './nav'
import { BrandLoader, Mark, Ring, Wordmark, initials } from './Brand'
import Sheet from './Sheet'
import NewBookingSheet from './NewBookingSheet'
import BookingDetailSheet from './BookingDetailSheet'
import ShareLink from './ShareLink'
import '../../styles/business/foundation.css'
import '../../styles/business/shell.css'

const NavItem = ({ item, onClick, compact = false }) => {
    const Icon = item.icon
    return (
        <NavLink to={item.to} end={item.end} className="biz-navlink" onClick={onClick}>
            <Icon size={compact ? 20 : 18} aria-hidden="true" />
            <span className="biz-navlink__label">{item.label}</span>
            {item.planned && <span className="biz-soon">Soon</span>}
        </NavLink>
    )
}

const ShellSkeleton = () => (
    <div className="biz-page" aria-hidden="true">
        <span className="lc-skel" style={{ width: 120, height: 16 }} />
        <span className="lc-skel" style={{ width: '55%', height: 40 }} />
        <span className="lc-skel" style={{ width: '100%', height: 72 }} />
        {[0, 1, 2].map((i) => <span key={i} className="lc-skel" style={{ width: '100%', height: 84 }} />)}
    </div>
)

const BusinessShell = () => {
    const { user, userProfile, business: ownedBusiness, signOut, setMode } = useAuth()
    const location = useLocation()
    const [workspace, setWorkspace] = useState(null)
    const [loadError, setLoadError] = useState('')
    const [bookingsVersion, setBookingsVersion] = useState(0)
    const [newBooking, setNewBooking] = useState(null)
    const [openBookingRow, setOpenBookingRow] = useState(null)
    const [moreOpen, setMoreOpen] = useState(false)
    const [shareOpen, setShareOpen] = useState(false)
    const [toast, setToast] = useState(null)
    const toastTimer = useRef(null)

    useEffect(() => { setMode('business') }, [setMode])

    const reloadWorkspace = useCallback(async () => {
        if (!ownedBusiness?.id) return
        try {
            setLoadError('')
            setWorkspace(await loadWorkspace(ownedBusiness.id))
        } catch (err) {
            console.error('Workspace load failed:', err)
            setLoadError('We could not load your business. Check your connection, then reload the page.')
        }
    }, [ownedBusiness?.id])

    useEffect(() => { reloadWorkspace() }, [reloadWorkspace])
    useEffect(() => () => clearTimeout(toastTimer.current), [])

    const notify = useCallback((message) => {
        clearTimeout(toastTimer.current)
        setToast({ message, key: Date.now() })
        toastTimer.current = setTimeout(() => setToast(null), 3200)
    }, [])

    const refreshBookings = useCallback(() => setBookingsVersion((v) => v + 1), [])
    const openNewBooking = useCallback((prefill = {}) => setNewBooking(prefill), [])
    const closeNewBooking = useCallback(() => setNewBooking(null), [])
    const openBooking = useCallback((booking) => setOpenBookingRow(booking), [])
    const closeBooking = useCallback(() => setOpenBookingRow(null), [])

    const value = useMemo(() => {
        if (!workspace) return null
        const me = workspace.members.find((m) => m.user_id === user?.id) || null
        return {
            ...workspace,
            me,
            isOwner: me?.role === 'owner',
            bookableMembers: workspace.members.filter((m) => m.is_bookable),
            activeServices: workspace.services.filter((s) => s.is_active),
            strength: pageStrength(workspace),
            reloadWorkspace,
            bookingsVersion,
            refreshBookings,
            openNewBooking,
            openBooking,
            notify,
        }
    }, [workspace, user?.id, reloadWorkspace, bookingsVersion, refreshBookings, openNewBooking, openBooking, notify])

    if (!ownedBusiness) {
        if (location.pathname !== '/portal/page') return <Navigate to="/portal/page" replace />
        return (
            <div className="biz-bare">
                <header className="biz-topbar">
                    <span className="biz-topbar__brand"><Mark size={26} /><Wordmark /></span>
                    <Link to="/client" className="biz-textbtn">Back to Booking</Link>
                </header>
                <main className="biz-content"><Outlet /></main>
            </div>
        )
    }

    const business = value?.business || ownedBusiness
    const title = titleFor(location.pathname)
    const tabs = NAV_ITEMS.filter((item) => item.tab)
    const moreActive = !tabs.some((item) => (item.end ? location.pathname === item.to : location.pathname.startsWith(item.to)))
    const strength = value?.strength
    const name = userProfile?.full_name || user?.email || ''

    return (
        <div className="biz-shell">
            <aside className="biz-sidebar" aria-label="Business navigation">
                <div className="biz-brand">
                    <Mark size={28} />
                    <Wordmark />
                </div>

                <Link to="/portal/page" className="biz-bizcard">
                    <span className="biz-avatar biz-avatar--business">{initials(business.business_name)}</span>
                    <span className="biz-bizcard__text">
                        <strong>{business.business_name}</strong>
                        <small className={business.is_active === false ? 'is-paused' : ''}>
                            {business.is_active === false ? 'Bookings paused' : 'Taking bookings'}
                        </small>
                    </span>
                    <ChevronRight size={16} aria-hidden="true" className="biz-bizcard__chevron" />
                </Link>

                <nav className="biz-sidebar__nav">
                    {NAV_GROUPS.map((group) => (
                        <div key={group.label} className="biz-navgroup">
                            <p className="biz-navgroup__label">{group.label}</p>
                            {group.items.map((item) => <NavItem key={item.to} item={item} />)}
                        </div>
                    ))}
                </nav>

                <div className="biz-sidebar__foot">
                    {strength && strength.percent < 100 && (
                        <Link to={strength.next?.to || '/portal/page'} className="biz-strength">
                            <Ring value={strength.value} size={34} stroke={3.5} label={\`Page strength \${strength.percent}%\`} />
                            <span className="biz-strength__text">
                                <strong>Page strength <span className="biz-num">{strength.percent}%</span></strong>
                                <small>{strength.next?.label}</small>
                            </span>
                        </Link>
                    )}
                    <Link to="/client" className="biz-navlink">
                        <ArrowLeftRight size={18} aria-hidden="true" />
                        <span className="biz-navlink__label">Switch to Booking</span>
                    </Link>
                    <div className="biz-account">
                        <span className="biz-avatar">{initials(name)}</span>
                        <span className="biz-account__text">
                            <strong>{userProfile?.full_name}</strong>
                            <small>{user?.email}</small>
                        </span>
                        <NavLink to="/portal/settings" className="biz-iconbtn biz-iconbtn--quiet" aria-label="Settings">
                            <Settings size={16} aria-hidden="true" />
                        </NavLink>
                        <button type="button" className="biz-iconbtn biz-iconbtn--quiet" onClick={signOut} aria-label="Sign out">
                            <LogOut size={16} aria-hidden="true" />
                        </button>
                    </div>
                </div>
            </aside>

            <div className="biz-main">
                <header className="biz-topbar">
                    <span className="biz-topbar__brand">
                        <Mark size={26} />
                        <span className="biz-topbar__name">{business.business_name}</span>
                    </span>
                    <span className="biz-topbar__title">{title}</span>
                    <button type="button" className="biz-search" onClick={() => notify('Search arrives with Clients')}>
                        <Search size={16} aria-hidden="true" />
                        <span>Search clients and bookings</span>
                        <kbd>Ctrl K</kbd>
                    </button>
                    <div className="biz-topbar__actions">
                        <NavLink to="/portal/notifications" className="biz-iconbtn" aria-label="Notifications">
                            <Bell size={18} aria-hidden="true" />
                        </NavLink>
                        <button type="button" className="biz-iconbtn biz-topbar__share" onClick={() => setShareOpen(true)} aria-label="Share your booking link">
                            <Share2 size={18} aria-hidden="true" />
                        </button>
                        <button type="button" className="btn btn--primary biz-topbar__new" onClick={() => openNewBooking()} disabled={!value}>
                            <Plus size={18} aria-hidden="true" /> New booking
                        </button>
                    </div>
                </header>

                <main className="biz-content">
                    {loadError ? (
                        <div className="biz-state" role="alert">
                            <BrandLoader label="Could not load" />
                            <p>{loadError}</p>
                            <button type="button" className="btn btn--secondary" onClick={reloadWorkspace}>Try again</button>
                        </div>
                    ) : value ? (
                        <WorkspaceContext.Provider value={value}>
                            <Outlet />
                        </WorkspaceContext.Provider>
                    ) : (
                        <ShellSkeleton />
                    )}
                </main>
            </div>

            <nav className="biz-tabbar" aria-label="Business">
                {tabs.map((item) => {
                    const Icon = item.icon
                    return (
                        <NavLink key={item.to} to={item.to} end={item.end} className="biz-tab">
                            <Icon size={22} aria-hidden="true" />
                            <span>{item.label}</span>
                        </NavLink>
                    )
                })}
                <button type="button" className={\`biz-tab\${moreActive ? ' active' : ''}\`} onClick={() => setMoreOpen(true)} aria-haspopup="dialog">
                    <Menu size={22} aria-hidden="true" />
                    <span>More</span>
                </button>
            </nav>

            {value && (
                <button type="button" className="biz-fab" onClick={() => openNewBooking()} aria-label="New booking">
                    <Plus size={26} aria-hidden="true" />
                </button>
            )}

            <Sheet open={moreOpen} onClose={() => setMoreOpen(false)} title="More">
                <div className="biz-more">
                    {strength && strength.percent < 100 && (
                        <Link to={strength.next?.to || '/portal/page'} className="biz-strength" onClick={() => setMoreOpen(false)}>
                            <Ring value={strength.value} size={40} stroke={4} label={\`Page strength \${strength.percent}%\`} />
                            <span className="biz-strength__text">
                                <strong>Page strength <span className="biz-num">{strength.percent}%</span></strong>
                                <small>{strength.next?.label}</small>
                            </span>
                        </Link>
                    )}
                    {NAV_GROUPS.map((group) => {
                        const items = group.items.filter((item) => !item.tab)
                        if (!items.length) return null
                        return (
                            <div key={group.label} className="biz-navgroup">
                                <p className="biz-navgroup__label">{group.label}</p>
                                {items.map((item) => <NavItem key={item.to} item={item} compact onClick={() => setMoreOpen(false)} />)}
                            </div>
                        )
                    })}
                    <div className="biz-navgroup">
                        <p className="biz-navgroup__label">Account</p>
                        <NavLink to="/portal/settings" className="biz-navlink" onClick={() => setMoreOpen(false)}>
                            <Settings size={20} aria-hidden="true" />
                            <span className="biz-navlink__label">Settings</span>
                        </NavLink>
                        <Link to="/client" className="biz-navlink" onClick={() => setMoreOpen(false)}>
                            <ArrowLeftRight size={20} aria-hidden="true" />
                            <span className="biz-navlink__label">Switch to Booking</span>
                        </Link>
                        <button type="button" className="biz-navlink" onClick={signOut}>
                            <LogOut size={20} aria-hidden="true" />
                            <span className="biz-navlink__label">Sign out</span>
                        </button>
                    </div>
                </div>
            </Sheet>

            {value && (
                <WorkspaceContext.Provider value={value}>
                    <Sheet open={shareOpen} onClose={() => setShareOpen(false)} title="Your booking link">
                        <ShareLink business={value.business} />
                    </Sheet>
                    <NewBookingSheet open={Boolean(newBooking)} prefill={newBooking} onClose={closeNewBooking} />
                    <BookingDetailSheet booking={openBookingRow} onClose={closeBooking} />
                </WorkspaceContext.Provider>
            )}

            <div className="biz-toast" role="status" aria-live="polite">
                {toast && <span key={toast.key} className="biz-toast__msg">{toast.message}</span>}
            </div>
        </div>
    )
}

export default BusinessShell
` },
    { path: 'src/components/business/ShareLink.jsx', content: `import { useState } from 'react'
import { Check, Copy, MessageCircle } from 'lucide-react'

const ShareLink = ({ business }) => {
    const [copied, setCopied] = useState(false)
    const link = \`\${window.location.origin}/\${business.slug}\`

    const copy = async () => {
        try {
            await navigator.clipboard.writeText(link)
            setCopied(true)
            setTimeout(() => setCopied(false), 2000)
        } catch {
            setCopied(false)
        }
    }

    return (
        <div className="biz-share">
            <p className="biz-share__intro">Clients book you at</p>
            <p className="biz-share__link" title={link}>
                <span className="biz-share__host">{window.location.host}/</span>
                <span className="biz-share__slug">{business.slug}</span>
            </p>
            <div className="biz-share__actions">
                <button type="button" className="btn btn--secondary" onClick={copy}>
                    {copied ? <Check size={16} aria-hidden="true" /> : <Copy size={16} aria-hidden="true" />}
                    {copied ? 'Copied' : 'Copy link'}
                </button>
                <a
                    className="btn btn--secondary"
                    href={\`https://wa.me/?text=\${encodeURIComponent(\`Book with \${business.business_name}: \${link}\`)}\`}
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    <MessageCircle size={16} aria-hidden="true" /> Send on WhatsApp
                </a>
            </div>
        </div>
    )
}

export default ShareLink
` },
    { path: 'src/pages/business/Calendar.jsx', content: `import { useEffect, useMemo, useState } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { useWorkspace } from '../../components/business/WorkspaceContext'
import DayRail from '../../components/business/DayRail'
import Agenda from '../../components/business/Agenda'
import { useIsDesktop } from '../../components/business/useIsDesktop'
import StaffFilter from '../../components/business/StaffFilter'
import {
    STATUS_LABEL,
    addDays,
    formatDay,
    friendlyError,
    minutesToLabel,
    setBookingStatus,
    loadBlocks,
    loadBookings,
    shortTime,
    startOfWeek,
    zonedNow,
} from '../../services/business'
import '../../styles/business/day.css'
import '../../styles/business/calendar.css'

const Calendar = () => {
    const { business, bookableMembers, hours, me, isOwner, bookingsVersion, refreshBookings, openNewBooking, openBooking, notify } = useWorkspace()
    const isDesktop = useIsDesktop()
    const today = zonedNow(business.timezone)
    const [view, setView] = useState('day')
    const [anchor, setAnchor] = useState(today.dateKey)
    const [staffFilter, setStaffFilter] = useState(isOwner ? 'all' : me?.id)
    const [bookings, setBookings] = useState([])
    const [blocks, setBlocks] = useState([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState('')

    const range = useMemo(() => {
        if (view === 'day') return [anchor, anchor]
        const from = startOfWeek(anchor)
        return [from, addDays(from, 6)]
    }, [view, anchor])

    useEffect(() => {
        let cancelled = false
        setLoading(true)
        Promise.all([loadBookings(business.id, range[0], range[1]), loadBlocks(business.id, range[0], range[1])])
            .then(([rows, blockRows]) => {
                if (cancelled) return
                setBookings(rows)
                setBlocks(blockRows)
                setError('')
            })
            .catch(() => { if (!cancelled) setError('Could not load the calendar. Reload to try again.') })
            .finally(() => { if (!cancelled) setLoading(false) })
        return () => { cancelled = true }
    }, [business.id, range, bookingsVersion])

    const columns = useMemo(
        () => (staffFilter === 'all' ? bookableMembers : bookableMembers.filter((m) => m.id === staffFilter)),
        [staffFilter, bookableMembers]
    )
    const visible = useMemo(
        () => bookings.filter((b) => columns.some((c) => c.id === b.staff_id)),
        [bookings, columns]
    )

    const step = view === 'day' ? 1 : 7
    const title = view === 'day'
        ? formatDay(anchor)
        : \`\${formatDay(range[0], { day: 'numeric', month: 'short' })} to \${formatDay(range[1], { day: 'numeric', month: 'short' })}\`

    const days = view === 'week' ? Array.from({ length: 7 }, (_, i) => addDays(range[0], i)) : []

    return (
        <div className="biz-page">
            <header className="biz-page__head">
                <div>
                    <h1 className="biz-page__title">Calendar</h1>
                    <p className="biz-page__sub">{title}</p>
                </div>
                <div className="biz-seg" role="radiogroup" aria-label="View">
                    {['day', 'week'].map((option) => (
                        <button
                            key={option}
                            type="button"
                            role="radio"
                            aria-checked={view === option}
                            className={\`biz-seg__btn\${view === option ? ' is-selected' : ''}\`}
                            onClick={() => setView(option)}
                        >
                            {option === 'day' ? 'Day' : 'Week'}
                        </button>
                    ))}
                </div>
            </header>

            <div className="biz-datenav">
                <button type="button" className="biz-icon-btn" aria-label={view === 'day' ? 'Previous day' : 'Previous week'} onClick={() => setAnchor(addDays(anchor, -step))}>
                    <ChevronLeft size={20} />
                </button>
                <button type="button" className="btn btn--ghost btn--sm" onClick={() => setAnchor(today.dateKey)} disabled={anchor === today.dateKey}>
                    Today
                </button>
                <button type="button" className="biz-icon-btn" aria-label={view === 'day' ? 'Next day' : 'Next week'} onClick={() => setAnchor(addDays(anchor, step))}>
                    <ChevronRight size={20} />
                </button>
                <label className="biz-datenav__pick">
                    <span className="biz-visually-hidden">Go to date</span>
                    <input className="biz-input" type="date" value={anchor} onChange={(event) => event.target.value && setAnchor(event.target.value)} />
                </label>
            </div>

            <StaffFilter members={isOwner ? bookableMembers : []} value={staffFilter} onChange={setStaffFilter} />

            {error && <p className="biz-error" role="alert">{error}</p>}
            {loading && bookings.length === 0 && (
                <div className="biz-agenda-skel" aria-hidden="true">
                    {[0, 1, 2].map((i) => <span key={i} className="lc-skel" style={{ height: 76 }} />)}
                </div>
            )}

            {view === 'day' && !(loading && bookings.length === 0) && !isDesktop && (
                <Agenda
                    dateKey={anchor}
                    bookings={visible}
                    blocks={blocks}
                    hours={hours}
                    staff={staffFilter === 'all' ? null : bookableMembers.find((m) => m.id === staffFilter) || null}
                    members={bookableMembers}
                    nowMinutes={anchor === today.dateKey ? today.minutes : null}
                    past={anchor < today.dateKey}
                    onBook={(minutes, staffId) => openNewBooking({ staffId, date: anchor, time: minutesToLabel(minutes) })}
                    onOpen={openBooking}
                    onConfirm={async (booking) => {
                        try {
                            await setBookingStatus(booking.id, 'confirmed')
                            refreshBookings()
                            notify(\`\${booking.client_name} confirmed\`)
                        } catch (err) {
                            notify(friendlyError(err))
                        }
                    }}
                />
            )}

            {view === 'day' && !(loading && bookings.length === 0) && isDesktop && (
                <DayRail
                    dateKey={anchor}
                    columns={columns}
                    bookings={visible}
                    blocks={blocks}
                    hours={hours}
                    nowMinutes={anchor === today.dateKey ? today.minutes : null}
                    onSlotTap={(staffId, minutes) => openNewBooking({
                        staffId,
                        date: anchor,
                        time: \`\${String(Math.floor(minutes / 60)).padStart(2, '0')}:\${String(minutes % 60).padStart(2, '0')}\`,
                    })}
                    onBookingTap={openBooking}
                />
            )}

            {view === 'week' && (
                <div className="biz-week">
                    {days.map((dateKey) => {
                        const dayBookings = visible
                            .filter((b) => b.appointment_date === dateKey && b.status !== 'cancelled')
                            .sort((a, b) => a.appointment_time.localeCompare(b.appointment_time))
                        const isToday = dateKey === today.dateKey
                        return (
                            <section key={dateKey} className={\`biz-week__day\${isToday ? ' is-today' : ''}\`} aria-label={formatDay(dateKey)}>
                                <button
                                    type="button"
                                    className="biz-week__head"
                                    onClick={() => { setAnchor(dateKey); setView('day') }}
                                >
                                    <span className="biz-week__dow">{formatDay(dateKey, { weekday: 'short' })}</span>
                                    <span className="biz-num biz-week__date">{formatDay(dateKey, { day: 'numeric' })}</span>
                                    <span className="biz-week__count">{dayBookings.length || ''}</span>
                                </button>
                                <ul className="biz-week__list">
                                    {dayBookings.map((booking) => (
                                        <li key={booking.id}>
                                            <button
                                                type="button"
                                                className={\`biz-week__item biz-week__item--\${booking.status}\`}
                                                onClick={() => openBooking(booking)}
                                                aria-label={\`\${shortTime(booking.appointment_time)} \${booking.client_name}, \${STATUS_LABEL[booking.status]}\`}
                                            >
                                                <span className="biz-num">{shortTime(booking.appointment_time)}</span>
                                                <span className="biz-week__client">{booking.client_name}</span>
                                            </button>
                                        </li>
                                    ))}
                                </ul>
                                <button
                                    type="button"
                                    className="biz-week__add"
                                    onClick={() => openNewBooking({ date: dateKey, staffId: staffFilter !== 'all' ? staffFilter : undefined })}
                                    aria-label={\`Add a booking on \${formatDay(dateKey)}\`}
                                >
                                    Add
                                </button>
                            </section>
                        )
                    })}
                </div>
            )}
        </div>
    )
}

export default Calendar
` },
    { path: 'src/pages/business/Today.jsx', content: `import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { Check } from 'lucide-react'
import { useWorkspace } from '../../components/business/WorkspaceContext'
import Agenda from '../../components/business/Agenda'
import ShareLink from '../../components/business/ShareLink'
import StaffFilter from '../../components/business/StaffFilter'
import {
    formatMoney,
    friendlyError,
    loadBlocks,
    loadBookings,
    minutesToLabel,
    setBookingStatus,
    windowsFor,
    zonedNow,
} from '../../services/business'
import { parseDateKey } from '../../services/dates'
import '../../styles/business/day.css'

const Today = () => {
    const { business, bookableMembers, activeServices, hours, me, isOwner, bookingsVersion, refreshBookings, openNewBooking, openBooking, notify } = useWorkspace()
    const [now, setNow] = useState(() => zonedNow(business.timezone))
    const [staffFilter, setStaffFilter] = useState(isOwner ? 'all' : me?.id)
    const [bookings, setBookings] = useState([])
    const [blocks, setBlocks] = useState([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState('')

    useEffect(() => {
        const timer = setInterval(() => setNow(zonedNow(business.timezone)), 60000)
        return () => clearInterval(timer)
    }, [business.timezone])

    useEffect(() => {
        let cancelled = false
        Promise.all([loadBookings(business.id, now.dateKey, now.dateKey), loadBlocks(business.id, now.dateKey, now.dateKey)])
            .then(([rows, blockRows]) => {
                if (cancelled) return
                setBookings(rows)
                setBlocks(blockRows)
                setError('')
            })
            .catch(() => { if (!cancelled) setError('Could not load today. Check your connection and reload.') })
            .finally(() => { if (!cancelled) setLoading(false) })
        return () => { cancelled = true }
    }, [business.id, now.dateKey, bookingsVersion])

    const staff = staffFilter === 'all' ? null : bookableMembers.find((m) => m.id === staffFilter) || null
    const visible = useMemo(
        () => (staff ? bookings.filter((b) => b.staff_id === staff.id) : bookings),
        [bookings, staff]
    )

    const counted = visible.filter((b) => b.status !== 'cancelled')
    const expected = counted
        .filter((b) => b.status !== 'no_show')
        .reduce((sum, b) => sum + Number(b.services?.price || 0), 0)
    const pending = visible.filter((b) => b.status === 'pending')

    const hasService = activeServices.length > 0
    const hasHours = hours.some((h) => !h.staff_id)
    const setupDone = hasService && hasHours && business.is_active

    const todayWindows = windowsFor(hours, staff?.id, parseDateKey(now.dateKey).getDay())
    const closedNow = todayWindows.length === 0 || now.minutes >= todayWindows[todayWindows.length - 1][1]
    const opensAt = todayWindows.length ? minutesToLabel(todayWindows[0][0]) : null

    const date = parseDateKey(now.dateKey)
    const weekday = date.toLocaleDateString('en-GB', { weekday: 'long' })
    const dayMonth = date.toLocaleDateString('en-GB', { day: 'numeric', month: 'long' })

    const confirm = async (booking) => {
        try {
            await setBookingStatus(booking.id, 'confirmed')
            refreshBookings()
            notify(\`\${booking.client_name} confirmed\`)
        } catch (err) {
            notify(friendlyError(err))
        }
    }

    const book = (minutes, staffId) => openNewBooking({ staffId, date: now.dateKey, time: minutesToLabel(minutes) })

    return (
        <div className="biz-page biz-today">
            <header className="biz-dayhead">
                <h1 className="biz-dayhead__date">
                    <span className="biz-dayhead__weekday">{weekday}</span>
                    {dayMonth}
                </h1>
                <dl className="biz-stats">
                    <div>
                        <dt>Bookings</dt>
                        <dd className="biz-num">{counted.length}</dd>
                    </div>
                    <div>
                        <dt>Expected</dt>
                        <dd className="biz-num">{formatMoney(expected)}</dd>
                    </div>
                    <div className={pending.length ? 'is-warn' : ''}>
                        <dt>To confirm</dt>
                        <dd className="biz-num">{pending.length}</dd>
                    </div>
                </dl>
            </header>

            {!setupDone && (
                <section className="biz-setup" aria-labelledby="setup-title">
                    <h2 id="setup-title" className="biz-subhead">Finish setting up to take bookings</h2>
                    <ol className="biz-setup__list">
                        <li className="is-done"><Check size={16} aria-hidden="true" /> Business page created</li>
                        <li className={hasService ? 'is-done' : ''}>
                            {hasService ? <Check size={16} aria-hidden="true" /> : <span className="biz-setup__dot" />}
                            {hasService ? 'Services added' : <Link to="/portal/services">Add your first service</Link>}
                        </li>
                        <li className={hasHours ? 'is-done' : ''}>
                            {hasHours ? <Check size={16} aria-hidden="true" /> : <span className="biz-setup__dot" />}
                            {hasHours ? 'Opening hours set' : <Link to="/portal/hours">Set your opening hours</Link>}
                        </li>
                        {!business.is_active && (
                            <li>
                                <span className="biz-setup__dot" />
                                <Link to="/portal/page">Bookings are paused. Turn them back on</Link>
                            </li>
                        )}
                    </ol>
                </section>
            )}

            <div className="biz-today__grid">
                <section className="biz-today__main" aria-label="Today's schedule">
                    <StaffFilter members={isOwner ? bookableMembers : []} value={staffFilter} onChange={setStaffFilter} />
                    {error && <p className="biz-error" role="alert">{error}</p>}
                    {loading ? (
                        <div className="biz-agenda-skel" aria-hidden="true">
                            {[0, 1, 2].map((i) => <span key={i} className="lc-skel" style={{ height: 76 }} />)}
                        </div>
                    ) : (
                        <>
                            {counted.length === 0 && closedNow && (
                                <div className="biz-closed">
                                    <strong>{todayWindows.length === 0 ? 'Closed today' : 'Closed for the day'}</strong>
                                    <span>No bookings today. Share your link so tomorrow fills up.</span>
                                </div>
                            )}
                            {counted.length === 0 && !closedNow && (
                                <p className="biz-empty">
                                    Nothing booked yet{opensAt && now.minutes < todayWindows[0][0] ? \`. You open at \${opensAt}\` : ''}. Your free time is below, ready to book.
                                </p>
                            )}
                            <Agenda
                                dateKey={now.dateKey}
                                bookings={visible}
                                blocks={blocks}
                                hours={hours}
                                staff={staff}
                                members={bookableMembers}
                                nowMinutes={now.minutes}
                                onBook={book}
                                onOpen={openBooking}
                                onConfirm={confirm}
                            />
                        </>
                    )}
                </section>

                <aside className="biz-today__side">
                    {pending.length > 0 && (
                        <section className="biz-panel" aria-labelledby="pending-title">
                            <h2 id="pending-title" className="biz-subhead">Waiting for you</h2>
                            <ul className="biz-pending">
                                {pending.map((b) => (
                                    <li key={b.id}>
                                        <button type="button" className="biz-pending__open" onClick={() => openBooking(b)}>
                                            <span className="biz-num">{b.appointment_time.slice(0, 5)}</span>
                                            <span>{b.client_name}</span>
                                        </button>
                                        <button type="button" className="btn btn--secondary btn--sm" onClick={() => confirm(b)}>Confirm</button>
                                    </li>
                                ))}
                            </ul>
                        </section>
                    )}
                    <section className="biz-panel" aria-label="Your booking link">
                        <ShareLink business={business} />
                    </section>
                </aside>
            </div>
        </div>
    )
}

export default Today
` },
    { path: 'src/services/business.js', content: `import { supabase } from '../config/supabase'
import { parseDateKey, toDateKey } from './dates'

export const ACTIVE_STATUSES = ['pending', 'confirmed']

export const STATUS_LABEL = {
    pending: 'Needs confirming',
    confirmed: 'Confirmed',
    completed: 'Completed',
    cancelled: 'Cancelled',
    no_show: 'No-show',
}

const KNOWN_ERRORS = ['23P01', '22023', 'P0002', '42501', '28000']

export const friendlyError = (error) =>
    KNOWN_ERRORS.includes(error?.code) ? error.message : 'Something went wrong. Try again.'

export const zonedNow = (timeZone) => {
    const parts = Object.fromEntries(
        new Intl.DateTimeFormat('en-GB', {
            timeZone,
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            hourCycle: 'h23',
        }).formatToParts(new Date()).map((part) => [part.type, part.value])
    )
    return {
        dateKey: \`\${parts.year}-\${parts.month}-\${parts.day}\`,
        minutes: Number(parts.hour) * 60 + Number(parts.minute),
    }
}

export const addDays = (dateKey, days) => {
    const date = parseDateKey(dateKey)
    date.setDate(date.getDate() + days)
    return toDateKey(date)
}

export const startOfWeek = (dateKey) => {
    const date = parseDateKey(dateKey)
    const offset = (date.getDay() + 6) % 7
    date.setDate(date.getDate() - offset)
    return toDateKey(date)
}

export const formatDay = (dateKey, options = { weekday: 'long', day: 'numeric', month: 'long' }) =>
    parseDateKey(dateKey).toLocaleDateString('en-GB', options)

export const shortTime = (time) => (time || '').slice(0, 5)

export const minutesToLabel = (total) =>
    \`\${String(Math.floor(total / 60)).padStart(2, '0')}:\${String(total % 60).padStart(2, '0')}\`

const money = new Intl.NumberFormat('en-IE', { style: 'currency', currency: 'EUR' })
export const formatMoney = (value) => money.format(Number(value) || 0)

export const loadWorkspace = async (businessId) => {
    const [business, members, services, hours] = await Promise.all([
        supabase.from('businesses')
            .select('id, business_name, slug, timezone, is_active, city, phone, whatsapp, description, address, logo_url, banner_url')
            .eq('id', businessId)
            .single(),
        supabase.from('business_members')
            .select('id, user_id, role, display_name, status, is_bookable, sort_order')
            .eq('business_id', businessId)
            .eq('status', 'active')
            .order('sort_order')
            .order('created_at'),
        supabase.from('services')
            .select('id, service_name, duration_minutes, price, is_active')
            .eq('business_id', businessId)
            .order('service_name'),
        supabase.from('availability')
            .select('id, staff_id, day_of_week, start_time, end_time')
            .eq('business_id', businessId)
            .eq('is_active', true),
    ])
    for (const result of [business, members, services, hours]) {
        if (result.error) throw result.error
    }
    return {
        business: business.data,
        members: members.data,
        services: services.data,
        hours: hours.data,
    }
}

export const loadBookings = async (businessId, fromKey, toKey) => {
    const { data, error } = await supabase
        .from('appointments')
        .select('id, staff_id, service_id, appointment_date, appointment_time, duration_minutes, status, source, client_name, client_phone, client_email, notes, services(service_name, price)')
        .eq('business_id', businessId)
        .gte('appointment_date', fromKey)
        .lte('appointment_date', toKey)
        .order('appointment_date')
        .order('appointment_time')
    if (error) throw error
    return data
}

export const loadBlocks = async (businessId, fromKey, toKey) => {
    const { data, error } = await supabase
        .from('time_blocks')
        .select('id, staff_id, starts_at, ends_at, reason')
        .eq('business_id', businessId)
        .lt('starts_at', \`\${addDays(toKey, 1)}T00:00:00\`)
        .gt('ends_at', \`\${fromKey}T00:00:00\`)
    if (error) throw error
    return data
}

export const setBookingStatus = async (id, status) => {
    const { data, error } = await supabase
        .from('appointments')
        .update({ status })
        .eq('id', id)
        .select('id')
    if (error) throw error
    if (!data || data.length === 0) throw new Error('Update returned 0 rows for booking ' + id)
}

export const addBooking = async ({ businessId, serviceId, staffId, date, time, name, phone, email, notes }) => {
    const { data, error } = await supabase.rpc('owner_book_appointment', {
        p_business_id: businessId,
        p_service_id: serviceId,
        p_staff_id: staffId,
        p_date: date,
        p_time: time,
        p_client_name: name,
        p_client_phone: phone || null,
        p_client_email: email || null,
        p_notes: notes || null,
    })
    if (error) throw error
    return data
}

export const moveBooking = async ({ id, date, time, staffId }) => {
    const { error } = await supabase.rpc('reschedule_appointment', {
        p_appointment_id: id,
        p_date: date,
        p_time: time,
        p_staff_id: staffId || null,
    })
    if (error) throw error
}

export const getSlots = async ({ businessId, serviceId, date, staffId }) => {
    const { data, error } = await supabase.rpc('get_available_slots', {
        p_business_id: businessId,
        p_service_id: serviceId,
        p_date: date,
        p_staff_id: staffId || null,
    })
    if (error) throw error
    return data || []
}

export const bookingStart = (booking) => {
    const [hours, minutes] = booking.appointment_time.split(':').map(Number)
    return hours * 60 + minutes
}

export const whatsappLink = (phone, text = '') => {
    const digits = (phone || '').replace(/[^\\d]/g, '').replace(/^00/, '')
    if (!digits) return null
    return \`https://wa.me/\${digits}\${text ? \`?text=\${encodeURIComponent(text)}\` : ''}\`
}

export const windowsFor = (hours, memberId, weekday) => {
    const own = memberId ? hours.filter((h) => h.staff_id === memberId) : []
    const source = own.length > 0 ? own : hours.filter((h) => !h.staff_id)
    return source
        .filter((h) => h.day_of_week === weekday)
        .map((h) => {
            const [sh, sm] = h.start_time.split(':').map(Number)
            const [eh, em] = h.end_time.split(':').map(Number)
            return [sh * 60 + sm, eh * 60 + em]
        })
        .sort((a, b) => a[0] - b[0])
}

export const blockMinutes = (block, dateKey) => {
    const dayStart = new Date(\`\${dateKey}T00:00:00\`).getTime()
    const from = Math.max(0, (new Date(block.starts_at).getTime() - dayStart) / 60000)
    const to = Math.min(24 * 60, (new Date(block.ends_at).getTime() - dayStart) / 60000)
    return [from, to]
}

export const durationLabel = (minutes) => {
    const h = Math.floor(minutes / 60)
    const m = minutes % 60
    if (!h) return \`\${m} min\`
    return m ? \`\${h} h \${m} min\` : \`\${h} h\`
}

export const pageStrength = ({ business, services, hours }) => {
    const steps = [
        { done: true, label: 'Business details' },
        { done: Boolean(business.description?.trim()), label: 'Add a description', to: '/portal/page' },
        { done: Boolean(business.address?.trim()), label: 'Add your address', to: '/portal/page' },
        { done: Boolean(business.whatsapp?.trim()), label: 'Add your WhatsApp', to: '/portal/page' },
        { done: Boolean(business.logo_url), label: 'Add a logo', to: '/portal/page' },
        { done: Boolean(business.banner_url), label: 'Add a cover photo', to: '/portal/page' },
        { done: services.some((s) => s.is_active), label: 'Add a service', to: '/portal/services' },
        { done: hours.some((h) => !h.staff_id), label: 'Set your opening hours', to: '/portal/hours' },
    ]
    const done = steps.filter((step) => step.done).length
    return { value: done / steps.length, percent: Math.round((done / steps.length) * 100), next: steps.find((step) => !step.done) }
}
` },
    { path: 'src/styles/business/calendar.css', content: `.biz-datenav {
    display: flex;
    align-items: center;
    gap: var(--space-2);
}

.biz-datenav__pick {
    margin-left: auto;
}

.biz-datenav__pick .biz-input {
    min-height: 44px;
    width: auto;
}

.biz-week {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
}

.biz-week__day {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
    padding: var(--space-3);
    border: 1px solid var(--lc-line);
    border-radius: var(--radius-md);
    background: var(--lc-card);
}

.biz-week__day.is-today {
    border-color: var(--signal);
}

.biz-week__head {
    display: flex;
    align-items: baseline;
    gap: var(--space-2);
    padding: 0;
    border: 0;
    background: none;
    color: var(--lc-ink-1);
    font-family: var(--font-body);
    text-align: left;
    cursor: pointer;
}

.biz-week__head:focus-visible,
.biz-week__item:focus-visible,
.biz-week__add:focus-visible {
    outline: 2px solid var(--azure);
    outline-offset: 2px;
}

.biz-week__dow {
    color: var(--lc-ink-2);
    font-size: var(--text-sm);
}

.biz-week__date {
    font-size: var(--text-lg);
}

.biz-week__count {
    margin-left: auto;
    color: var(--lc-ink-3);
    font-family: var(--font-mono);
    font-size: var(--text-xs);
}

.biz-week__list {
    display: flex;
    flex-direction: column;
    gap: var(--space-1);
    margin: 0;
    padding: 0;
    list-style: none;
}

.biz-week__item {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    width: 100%;
    min-height: 40px;
    padding: 0 var(--space-2);
    border: 0;
    border-left: 3px solid var(--azure);
    border-radius: var(--radius-xs);
    background: var(--lc-raised);
    color: var(--lc-ink-1);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    text-align: left;
    cursor: pointer;
}

.biz-week__item--pending { border-left-color: var(--signal); }
.biz-week__item--completed { border-left-color: var(--lc-success); color: var(--lc-ink-2); }
.biz-week__item--no_show { border-left-color: var(--lc-danger); color: var(--lc-ink-3); }

.biz-week__client {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.biz-week__add {
    align-self: flex-start;
    min-height: 36px;
    padding: 0 var(--space-3);
    border: 1px dashed var(--lc-line-strong);
    border-radius: var(--radius-sm);
    background: none;
    color: var(--lc-ink-2);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    cursor: pointer;
}

@media (min-width: 1024px) {
    .biz-week {
        display: grid;
        grid-template-columns: repeat(7, minmax(0, 1fr));
        align-items: start;
    }

    .biz-week__day {
        min-height: 320px;
    }

    .biz-week__item {
        flex-direction: column;
        align-items: flex-start;
        justify-content: center;
        gap: 0;
        min-height: 48px;
        padding: var(--space-1) var(--space-2);
    }

    .biz-week__item .biz-num {
        color: var(--lc-ink-2);
        font-size: var(--text-xs);
    }

    .biz-week__client {
        width: 100%;
    }
}
` },
    { path: 'src/styles/business/day.css', content: `.biz-dayhead {
    display: flex;
    flex-direction: column;
    gap: var(--space-4);
}

.biz-dayhead__date {
    margin: 0;
    display: flex;
    flex-direction: column;
    font-family: var(--font-display);
    font-size: var(--text-4xl);
    font-weight: var(--font-weight-semibold);
    letter-spacing: var(--tracking-tight);
    line-height: var(--leading-tight);
}

.biz-dayhead__weekday {
    color: var(--lc-ink-2);
    font-size: var(--text-base);
    font-weight: var(--font-weight-medium);
    letter-spacing: 0;
}

.biz-stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    margin: 0;
    border-top: 1px solid var(--lc-line);
    border-bottom: 1px solid var(--lc-line);
}

.biz-stats div {
    padding: var(--space-3) 0;
}

.biz-stats div + div {
    padding-left: var(--space-4);
    border-left: 1px solid var(--lc-line);
}

.biz-stats dt {
    color: var(--lc-ink-3);
    font-size: var(--text-xs);
}

.biz-stats dd {
    margin: var(--space-1) 0 0;
    font-size: var(--text-xl);
    font-weight: var(--font-weight-medium);
}

.biz-stats .is-warn dd {
    color: var(--signal);
}

.biz-setup {
    padding: var(--space-5);
    border-radius: var(--lc-r-lg);
    background: var(--lc-warning-tint);
    box-shadow: inset 0 0 0 1px rgba(232, 154, 62, 0.35);
}

.biz-setup__list {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
    margin: 0;
    padding: 0;
    list-style: none;
    font-size: var(--text-sm);
}

.biz-setup__list li {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    min-height: 32px;
}

.biz-setup__list li.is-done {
    color: var(--lc-ink-3);
}

.biz-setup__list li.is-done svg {
    color: var(--lc-success);
}

.biz-setup__list a {
    color: var(--azure-link);
}

.biz-setup__dot {
    width: 16px;
    height: 16px;
    border: 1px solid var(--lc-ink-3);
    border-radius: var(--radius-full);
}

.biz-today__grid {
    display: grid;
    gap: var(--space-6);
}

.biz-today__main {
    display: flex;
    flex-direction: column;
    gap: var(--space-4);
    min-width: 0;
}

.biz-today__side {
    display: none;
}

.biz-panel {
    padding: var(--space-5);
    border-radius: var(--lc-r-lg);
    background: var(--lc-card);
    box-shadow: inset 0 0 0 1px var(--lc-line);
}

.biz-pending {
    display: flex;
    flex-direction: column;
    margin: 0;
    padding: 0;
    list-style: none;
}

.biz-pending li {
    display: flex;
    align-items: center;
    gap: var(--space-3);
    padding: var(--space-2) 0;
    border-top: 1px solid var(--lc-line);
}

.biz-pending__open {
    flex: 1;
    display: flex;
    gap: var(--space-3);
    min-height: 40px;
    align-items: center;
    padding: 0;
    border: 0;
    background: none;
    color: var(--lc-ink-1);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    text-align: left;
    cursor: pointer;
}

.biz-share__intro {
    margin: 0;
    color: var(--lc-ink-2);
    font-size: var(--text-sm);
}

.biz-share__link {
    display: flex;
    flex-direction: column;
    margin: var(--space-1) 0 var(--space-4);
    min-width: 0;
}

.biz-share__host {
    color: var(--lc-ink-3);
    font-family: var(--font-mono);
    font-size: var(--text-xs);
}

.biz-share__slug {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-family: var(--font-display);
    font-size: var(--text-lg);
    font-weight: var(--font-weight-semibold);
}

.biz-closed {
    display: flex;
    flex-direction: column;
    gap: var(--space-1);
    padding: var(--space-5);
    border-radius: var(--lc-r-lg);
    background: var(--lc-card);
    box-shadow: inset 0 0 0 1px var(--lc-line);
}

.biz-closed strong {
    font-family: var(--font-display);
    font-size: var(--text-lg);
    font-weight: var(--font-weight-semibold);
}

.biz-closed span {
    color: var(--lc-ink-2);
    font-size: var(--text-sm);
}

.biz-share__actions {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-2);
}


.biz-agenda {
    display: flex;
    flex-direction: column;
    margin: 0;
    padding: 0;
    list-style: none;
}

.biz-agenda__row {
    display: grid;
    grid-template-columns: 56px 1fr;
    gap: var(--space-3);
    padding: var(--space-1) 0;
}

.biz-agenda__time {
    display: flex;
    flex-direction: column;
    padding-top: var(--space-3);
    font-size: var(--text-base);
    font-weight: var(--font-weight-medium);
}

.biz-agenda__end {
    color: var(--lc-ink-3);
    font-size: var(--text-xs);
    font-weight: var(--font-weight-normal);
}

.biz-agenda__card {
    display: flex;
    align-items: stretch;
    min-width: 0;
    border-left: 3px solid var(--azure);
    border-radius: var(--lc-r-md);
    background: var(--lc-raised);
    box-shadow: var(--lc-shadow-raised);
    transition: background var(--lc-fast) var(--lc-ease), transform var(--lc-fast) var(--lc-ease);
}

.biz-agenda__card:hover {
    background: var(--lc-raised-hover);
}

.biz-agenda__card:active {
    transform: scale(0.99);
}

.biz-agenda__card--pending { border-left-color: var(--signal); }
.biz-agenda__card--completed { border-left-color: var(--lc-success); background: var(--lc-card); box-shadow: inset 0 0 0 1px var(--lc-line); }
.biz-agenda__card--no_show { border-left-color: var(--lc-danger); background: var(--lc-card); box-shadow: inset 0 0 0 1px var(--lc-line); }

.biz-agenda__open {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
    padding: var(--space-3) var(--space-4);
    border: 0;
    background: none;
    color: var(--lc-ink-1);
    font-family: var(--font-body);
    text-align: left;
    cursor: pointer;
}

.biz-agenda__who {
    font-family: var(--font-display);
    font-size: var(--text-lg);
    font-weight: var(--font-weight-semibold);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.biz-agenda__what {
    color: var(--lc-ink-2);
    font-size: var(--text-sm);
}

.biz-agenda__state {
    margin-top: var(--space-1);
    font-size: var(--text-xs);
    font-weight: var(--font-weight-medium);
}

.biz-agenda__state--pending { color: var(--lc-warning); }
.biz-agenda__state--completed { color: var(--lc-success); }
.biz-agenda__state--no_show { color: var(--lc-danger); }

.biz-agenda__confirm {
    align-self: center;
    margin-right: var(--space-3);
    min-height: 40px;
    padding: 0 var(--space-4);
    border: 0;
    border-radius: var(--radius-full);
    background: var(--lc-warning-tint);
    box-shadow: inset 0 0 0 1px var(--signal);
    transition: background var(--lc-fast) var(--lc-ease), transform var(--lc-fast) var(--lc-ease);
    color: var(--lc-ink-1);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
    cursor: pointer;
}

.biz-agenda__confirm:hover {
    background: var(--signal);
    color: var(--lc-canvas);
}

.biz-agenda__confirm:active {
    transform: scale(0.95);
}

.biz-agenda__row.is-past .biz-agenda__time,
.biz-agenda__row.is-past .biz-agenda__who {
    color: var(--lc-ink-3);
}

.biz-agenda__row--gap .biz-agenda__time {
    color: var(--lc-ink-3);
    font-weight: var(--font-weight-normal);
}

.biz-agenda__gap {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--space-3);
    min-height: 48px;
    padding: 0 var(--space-2) 0 var(--space-4);
    border: 1px dashed var(--lc-line-strong);
    border-radius: var(--radius-md);
    color: var(--lc-ink-2);
    font-size: var(--text-sm);
}

.biz-agenda__len {
    margin-left: var(--space-2);
    color: var(--lc-ink-3);
    font-size: var(--text-xs);
}

.biz-agenda__book {
    min-height: 36px;
    padding: 0 var(--space-4);
    border: 0;
    border-radius: var(--radius-full);
    background: var(--lc-raised-hover);
    color: var(--lc-ink-1);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
    cursor: pointer;
}

.biz-agenda__book:hover {
    background: var(--lc-raised-hover);
}

.biz-agenda__block {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 0.25em;
    min-height: 44px;
    padding: 0 var(--space-4);
    border-radius: var(--radius-md);
    background: var(--lc-card);
    color: var(--lc-ink-3);
    font-size: var(--text-sm);
}

.biz-agenda__now {
    position: relative;
    display: flex;
    align-items: center;
    height: 24px;
    margin: var(--space-1) 0;
}

.biz-agenda__now::after {
    content: '';
    flex: 1;
    height: 2px;
    margin-left: var(--space-2);
    background: var(--signal);
}

.biz-agenda__now span {
    padding: 2px var(--space-2);
    border-radius: var(--radius-xs);
    background: var(--signal);
    color: var(--lc-canvas);
    font-size: var(--text-xs);
    font-weight: var(--font-weight-medium);
}

.biz-agenda__open:focus-visible,
.biz-agenda__confirm:focus-visible,
.biz-agenda__book:focus-visible,
.biz-pending__open:focus-visible {
    outline: 2px solid var(--azure);
    outline-offset: 2px;
}


.biz-rail {
    max-height: calc(100vh - 280px);
    min-height: 360px;
    overflow-y: auto;
    border: 1px solid var(--lc-line);
    border-radius: var(--radius-lg);
    background: var(--lc-canvas);
}

.biz-rail__heads {
    position: sticky;
    top: 0;
    z-index: 3;
    display: flex;
    background: var(--lc-card);
    border-bottom: 1px solid var(--lc-line-strong);
}

.biz-rail__heads .biz-rail__gutter {
    width: 64px;
}

.biz-rail__head {
    flex: 1 1 0;
    min-width: 0;
    padding: var(--space-3);
    border-left: 1px solid var(--lc-line);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-semibold);
}

.biz-rail__body {
    position: relative;
    display: flex;
    box-sizing: content-box;
    padding: var(--space-3) 0;
}

.biz-rail__gutter {
    position: relative;
    flex: none;
    width: 64px;
}

.biz-rail__hour {
    position: absolute;
    right: var(--space-3);
    transform: translateY(-50%);
    color: var(--lc-ink-2);
    font-family: var(--font-mono);
    font-size: var(--text-xs);
}

.biz-rail__col {
    position: relative;
    flex: 1 1 0;
    min-width: 0;
    border-left: 1px solid var(--lc-line);
    cursor: copy;
}

.biz-rail__line {
    position: absolute;
    left: 0;
    right: 0;
    height: 1px;
    background: var(--lc-line);
    pointer-events: none;
}

.biz-rail__open {
    position: absolute;
    left: 0;
    right: 0;
    background: var(--lc-raised);
    pointer-events: none;
}

.biz-rail__block {
    position: absolute;
    left: 6px;
    right: 6px;
    z-index: 1;
    padding: var(--space-1) var(--space-2);
    border: 1px dashed var(--lc-line-strong);
    border-radius: var(--radius-sm);
    background: var(--lc-canvas);
    color: var(--lc-ink-3);
    font-size: var(--text-xs);
    pointer-events: none;
    overflow: hidden;
}

.biz-booking {
    position: absolute;
    left: 6px;
    right: 6px;
    z-index: 2;
    display: flex;
    flex-direction: column;
    gap: 2px;
    padding: var(--space-2) var(--space-3);
    overflow: hidden;
    border: 1px solid var(--lc-line-strong);
    border-left: 3px solid var(--azure);
    border-radius: var(--radius-sm);
    background: var(--lc-raised-hover);
    color: var(--lc-ink-1);
    font-family: var(--font-body);
    text-align: left;
    cursor: pointer;
}

.biz-booking:focus-visible {
    outline: 2px solid var(--azure);
    outline-offset: 1px;
}

.biz-booking--pending { border-left-color: var(--signal); }
.biz-booking--completed { border-left-color: var(--lc-success); background: var(--lc-raised-hover); color: var(--lc-ink-2); }
.biz-booking--no_show { border-left-color: var(--lc-danger); background: var(--lc-raised-hover); color: var(--lc-ink-3); }
.biz-booking--no_show .biz-booking__who { text-decoration: line-through; }

.biz-booking__time {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    color: var(--lc-ink-2);
    font-family: var(--font-mono);
    font-size: var(--text-xs);
}

.biz-booking__flag {
    color: var(--signal);
    font-family: var(--font-body);
}

.biz-booking__who {
    font-size: var(--text-sm);
    font-weight: var(--font-weight-semibold);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.biz-booking__what {
    color: var(--lc-ink-2);
    font-size: var(--text-xs);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.biz-booking--compact {
    flex-direction: row;
    align-items: center;
    gap: var(--space-2);
    padding-top: 0;
    padding-bottom: 0;
}

.biz-booking--compact .biz-booking__what,
.biz-booking--compact .biz-booking__flag {
    display: none;
}

.biz-rail__now {
    position: absolute;
    left: 64px;
    right: 0;
    z-index: 4;
    height: 2px;
    background: var(--signal);
    pointer-events: none;
}

.biz-rail__now-label {
    position: absolute;
    left: -60px;
    top: -10px;
    padding: 2px var(--space-1);
    border-radius: var(--radius-xs);
    background: var(--signal);
    color: var(--lc-canvas);
    font-family: var(--font-mono);
    font-size: var(--text-xs);
    font-weight: var(--font-weight-medium);
}

@media (min-width: 1024px) {
    .biz-dayhead {
        flex-direction: row;
        align-items: flex-end;
        justify-content: space-between;
    }

    .biz-stats {
        min-width: 420px;
        border: 0;
    }

    .biz-today__grid {
        grid-template-columns: minmax(0, 1fr) 320px;
        align-items: start;
    }

    .biz-today__side {
        position: sticky;
        top: calc(56px + var(--space-6));
        display: flex;
        flex-direction: column;
        gap: var(--space-4);
    }
}

.biz-agenda-skel {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
}
` },
    { path: 'src/styles/business/shell.css', content: `.biz-shell,
.biz-bare {
    min-height: 100vh;
    min-height: 100dvh;
    background: var(--lc-canvas);
    color: var(--lc-ink-1);
    font-family: var(--font-body);
    -webkit-font-smoothing: antialiased;
}

.lc-wordmark {
    font-family: var(--font-display);
    font-weight: var(--font-weight-semibold);
    font-size: 17px;
    letter-spacing: var(--tracking-tight);
}

.lc-wordmark__accent {
    color: var(--azure);
}

.lc-mark {
    display: block;
    flex: none;
}

.biz-num {
    font-family: var(--font-mono);
    font-variant-numeric: tabular-nums;
}

.biz-muted {
    color: var(--lc-ink-3);
}

.biz-visually-hidden {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip: rect(0 0 0 0);
    white-space: nowrap;
}

.biz-avatar {
    display: grid;
    place-items: center;
    flex: none;
    width: 32px;
    height: 32px;
    border-radius: var(--radius-full);
    background: var(--lc-raised);
    box-shadow: inset 0 0 0 1px var(--lc-line-strong);
    color: var(--lc-ink-1);
    font-size: 12px;
    font-weight: var(--font-weight-semibold);
    letter-spacing: 0.02em;
}

.biz-avatar--business {
    width: 40px;
    height: 40px;
    border-radius: var(--lc-r-md);
    background: var(--azure);
    box-shadow: var(--lc-shadow-accent);
    font-family: var(--font-display);
    font-size: 15px;
}


.biz-sidebar {
    display: none;
}

.biz-brand {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 0 var(--space-2);
}

.biz-bizcard {
    display: flex;
    align-items: center;
    gap: var(--space-3);
    padding: var(--space-3);
    border-radius: var(--lc-r-lg);
    background: var(--lc-raised);
    box-shadow: var(--lc-shadow-raised);
    color: var(--lc-ink-1);
    text-decoration: none;
    transition: background var(--lc-fast) var(--lc-ease), transform var(--lc-fast) var(--lc-ease);
}

.biz-bizcard:hover {
    background: var(--lc-raised-hover);
}

.biz-bizcard:active {
    transform: scale(0.985);
}

.biz-bizcard__text {
    display: flex;
    flex-direction: column;
    min-width: 0;
    flex: 1;
}

.biz-bizcard__text strong {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: var(--text-sm);
    font-weight: var(--font-weight-semibold);
}

.biz-bizcard__text small {
    color: var(--lc-success);
    font-size: 12px;
}

.biz-bizcard__text small.is-paused {
    color: var(--lc-warning);
}

.biz-bizcard__chevron {
    color: var(--lc-ink-3);
}

.biz-navgroup {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.biz-navgroup + .biz-navgroup {
    margin-top: var(--space-4);
}

.biz-navgroup__label {
    margin: 0 0 var(--space-1);
    padding: 0 var(--space-3);
    color: var(--lc-ink-4);
    font-size: 12px;
    font-weight: var(--font-weight-medium);
}

.biz-navlink {
    position: relative;
    display: flex;
    align-items: center;
    gap: var(--space-3);
    width: 100%;
    min-height: 38px;
    padding: 0 var(--space-3);
    border: 0;
    border-radius: var(--lc-r-sm);
    background: none;
    color: var(--lc-ink-2);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
    text-align: left;
    text-decoration: none;
    cursor: pointer;
    transition: background var(--lc-fast) var(--lc-ease), color var(--lc-fast) var(--lc-ease);
}

.biz-navlink svg {
    flex: none;
    color: var(--lc-ink-3);
    transition: color var(--lc-fast) var(--lc-ease);
}

.biz-navlink:hover {
    background: var(--lc-card);
    color: var(--lc-ink-1);
}

.biz-navlink.active {
    background: var(--lc-raised);
    box-shadow: var(--lc-shadow-raised);
    color: var(--lc-ink-1);
}

.biz-navlink.active svg {
    color: var(--azure);
}

.biz-navlink__label {
    flex: 1;
}

.biz-soon {
    padding: 2px 8px;
    border-radius: var(--radius-full);
    background: var(--lc-card);
    box-shadow: inset 0 0 0 1px var(--lc-line);
    color: var(--lc-ink-3);
    font-size: 11px;
    font-weight: var(--font-weight-medium);
}

.biz-strength {
    display: flex;
    align-items: center;
    gap: var(--space-3);
    padding: 10px var(--space-3);
    border-radius: var(--lc-r-lg);
    background: var(--lc-card);
    box-shadow: inset 0 0 0 1px var(--lc-line);
    color: var(--lc-ink-1);
    text-decoration: none;
    transition: background var(--lc-fast) var(--lc-ease);
}

.biz-strength:hover {
    background: var(--lc-raised);
}

.biz-strength__text {
    display: flex;
    flex-direction: column;
    min-width: 0;
}

.biz-strength__text strong {
    font-size: var(--text-sm);
    font-weight: var(--font-weight-semibold);
}

.biz-strength__text small {
    color: var(--lc-ink-3);
    font-size: 12px;
}

.biz-account {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    margin-top: var(--space-2);
    padding: var(--space-3) var(--space-2) 0;
    border-top: 1px solid var(--lc-line);
}

.biz-account__text {
    display: flex;
    flex-direction: column;
    flex: 1;
    min-width: 0;
}

.biz-account__text strong {
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.biz-account__text small {
    color: var(--lc-ink-3);
    font-size: 12px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}


.biz-topbar {
    position: sticky;
    top: 0;
    z-index: var(--z-header);
    display: flex;
    align-items: center;
    gap: var(--space-3);
    height: 60px;
    padding: 0 var(--space-4);
    padding-top: env(safe-area-inset-top, 0px);
    box-sizing: content-box;
    background: var(--lc-glass);
    backdrop-filter: var(--lc-glass-blur);
    -webkit-backdrop-filter: var(--lc-glass-blur);
    border-bottom: 1px solid var(--lc-line);
}

.biz-topbar__brand {
    display: flex;
    align-items: center;
    gap: 10px;
    min-width: 0;
    flex: 1;
}

.biz-topbar__name {
    font-family: var(--font-display);
    font-weight: var(--font-weight-semibold);
    font-size: var(--text-base);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.biz-topbar__title,
.biz-search,
.biz-topbar__new {
    display: none;
}

.biz-topbar__actions {
    display: flex;
    align-items: center;
    gap: var(--space-2);
}

.biz-iconbtn {
    position: relative;
    display: grid;
    place-items: center;
    flex: none;
    width: 40px;
    height: 40px;
    border: 0;
    border-radius: var(--radius-full);
    background: var(--lc-card);
    box-shadow: inset 0 0 0 1px var(--lc-line);
    color: var(--lc-ink-2);
    cursor: pointer;
    transition: background var(--lc-fast) var(--lc-ease), color var(--lc-fast) var(--lc-ease), transform var(--lc-fast) var(--lc-ease);
}

.biz-iconbtn:hover,
.biz-iconbtn.active {
    background: var(--lc-raised);
    color: var(--lc-ink-1);
}

.biz-iconbtn:active {
    transform: scale(0.94);
}

.biz-iconbtn--quiet {
    width: 32px;
    height: 32px;
    background: none;
    box-shadow: none;
}

.biz-icon-btn {
    display: grid;
    place-items: center;
    width: 44px;
    height: 44px;
    border: 0;
    border-radius: var(--radius-full);
    background: var(--lc-card);
    box-shadow: inset 0 0 0 1px var(--lc-line);
    color: var(--lc-ink-1);
    cursor: pointer;
    transition: background var(--lc-fast) var(--lc-ease), transform var(--lc-fast) var(--lc-ease);
}

.biz-icon-btn:hover {
    background: var(--lc-raised);
}

.biz-icon-btn:active {
    transform: scale(0.94);
}


.biz-content {
    padding: var(--space-5) var(--space-4) calc(112px + env(safe-area-inset-bottom, 0px));
}

.biz-page {
    max-width: 960px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    gap: var(--space-5);
    animation: lc-arrive var(--lc-base) var(--lc-ease) both;
}

@keyframes lc-arrive {
    from { opacity: 0; transform: translateY(6px); }
    to { opacity: 1; transform: none; }
}

.biz-page__head {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: var(--space-3);
}

.biz-page__title {
    margin: 0;
    font-family: var(--font-display);
    font-size: var(--text-3xl);
    font-weight: var(--font-weight-semibold);
    letter-spacing: var(--tracking-tight);
    line-height: var(--leading-tight);
}

.biz-page__sub {
    margin: var(--space-1) 0 0;
    color: var(--lc-ink-2);
    font-size: var(--text-sm);
}

.biz-subhead {
    margin: 0 0 var(--space-3);
    font-family: var(--font-display);
    font-size: var(--text-base);
    font-weight: var(--font-weight-semibold);
}

.biz-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: var(--space-4);
    min-height: 50vh;
    color: var(--lc-ink-2);
    font-size: var(--text-sm);
    text-align: center;
}

.biz-state p {
    max-width: 36ch;
    margin: 0;
}

.biz-empty {
    margin: 0;
    color: var(--lc-ink-2);
    font-size: var(--text-sm);
}

.biz-error {
    margin: 0;
    padding: var(--space-3) var(--space-4);
    border-radius: var(--lc-r-md);
    background: var(--lc-danger-tint);
    color: var(--lc-ink-1);
    font-size: var(--text-sm);
}

.biz-hint {
    margin: 0;
    color: var(--lc-ink-3);
    font-size: var(--text-sm);
}


.biz-tabbar {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: var(--z-header);
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    padding-bottom: env(safe-area-inset-bottom, 0px);
    background: var(--lc-glass);
    backdrop-filter: var(--lc-glass-blur);
    -webkit-backdrop-filter: var(--lc-glass-blur);
    border-top: 1px solid var(--lc-line);
}

.biz-tab {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 3px;
    min-height: 60px;
    border: 0;
    background: none;
    color: var(--lc-ink-3);
    font-family: var(--font-body);
    font-size: 11px;
    font-weight: var(--font-weight-medium);
    text-decoration: none;
    cursor: pointer;
    transition: color var(--lc-fast) var(--lc-ease);
}

.biz-tab svg {
    transition: transform var(--lc-fast) var(--lc-ease);
}

.biz-tab:active svg {
    transform: scale(0.9);
}

.biz-tab.active {
    color: var(--lc-ink-1);
}

.biz-tab.active svg {
    color: var(--azure);
}

.biz-fab {
    position: fixed;
    right: var(--space-4);
    bottom: calc(76px + env(safe-area-inset-bottom, 0px));
    z-index: var(--z-header);
    display: grid;
    place-items: center;
    width: 56px;
    height: 56px;
    border: 0;
    border-radius: var(--radius-full);
    background: var(--azure);
    box-shadow: var(--lc-shadow-accent), inset 0 1px 0 rgba(255, 255, 255, 0.2);
    color: var(--lc-ink-1);
    cursor: pointer;
    transition: transform var(--lc-fast) var(--lc-ease), background var(--lc-fast) var(--lc-ease);
}

.biz-fab:hover {
    background: var(--azure-soft);
}

.biz-fab:active {
    transform: scale(0.92);
}

.biz-more {
    display: flex;
    flex-direction: column;
    gap: var(--space-4);
}

.biz-more .biz-navgroup + .biz-navgroup {
    margin-top: 0;
}

.biz-more .biz-navlink {
    min-height: 48px;
}


.biz-tab:focus-visible,
.biz-navlink:focus-visible,
.biz-iconbtn:focus-visible,
.biz-icon-btn:focus-visible,
.biz-fab:focus-visible,
.biz-bizcard:focus-visible,
.biz-strength:focus-visible,
.biz-search:focus-visible,
.biz-chip:focus-visible,
.biz-option:focus-visible,
.biz-day:focus-visible,
.biz-slot:focus-visible,
.biz-seg__btn:focus-visible,
.biz-textbtn:focus-visible {
    outline: 2px solid var(--azure);
    outline-offset: 2px;
}

.biz-textbtn {
    align-self: flex-start;
    padding: var(--space-2) 0;
    border: 0;
    background: none;
    color: var(--lc-info);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    text-decoration: none;
    cursor: pointer;
}

.biz-chips {
    display: flex;
    gap: var(--space-2);
    overflow-x: auto;
    padding-bottom: 2px;
    scrollbar-width: none;
}

.biz-chip {
    flex: none;
    min-height: 36px;
    padding: 0 var(--space-4);
    border: 0;
    border-radius: var(--radius-full);
    background: var(--lc-card);
    box-shadow: inset 0 0 0 1px var(--lc-line);
    color: var(--lc-ink-2);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    cursor: pointer;
    transition: background var(--lc-fast) var(--lc-ease), color var(--lc-fast) var(--lc-ease);
}

.biz-chip:hover {
    color: var(--lc-ink-1);
}

.biz-chip.is-selected {
    background: var(--lc-ink-1);
    box-shadow: none;
    color: var(--lc-canvas);
    font-weight: var(--font-weight-medium);
}

.biz-seg {
    display: inline-flex;
    padding: 3px;
    border-radius: var(--radius-full);
    background: var(--lc-card);
    box-shadow: inset 0 0 0 1px var(--lc-line);
}

.biz-seg__btn {
    min-height: 34px;
    min-width: 64px;
    padding: 0 var(--space-3);
    border: 0;
    border-radius: var(--radius-full);
    background: none;
    color: var(--lc-ink-3);
    font-family: var(--font-body);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
    cursor: pointer;
    transition: background var(--lc-fast) var(--lc-ease), color var(--lc-fast) var(--lc-ease);
}

.biz-seg__btn.is-selected {
    background: var(--lc-raised);
    box-shadow: var(--lc-shadow-raised);
    color: var(--lc-ink-1);
}


.biz-form {
    display: flex;
    flex-direction: column;
    gap: var(--space-5);
}

.biz-field {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
    min-width: 0;
    margin: 0;
    padding: 0;
    border: 0;
}

.biz-field__label {
    padding: 0;
    color: var(--lc-ink-2);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
}

.biz-optional {
    color: var(--lc-ink-3);
    font-weight: var(--font-weight-normal);
}

.biz-field-row {
    display: grid;
    grid-template-columns: 1fr;
    gap: var(--space-2);
}

.biz-input {
    width: 100%;
    min-height: 48px;
    padding: 0 var(--space-3);
    border: 0;
    border-radius: var(--lc-r-md);
    background: var(--lc-well);
    box-shadow: inset 0 0 0 1px var(--lc-line-strong);
    color: var(--lc-ink-1);
    font-family: var(--font-body);
    font-size: 16px;
    color-scheme: dark;
    transition: box-shadow var(--lc-fast) var(--lc-ease);
}

.biz-input::placeholder {
    color: var(--lc-ink-4);
}

.biz-input:focus {
    outline: none;
    box-shadow: inset 0 0 0 1.5px var(--azure), 0 0 0 4px var(--lc-info-tint);
}

.biz-input--area {
    min-height: 72px;
    padding: var(--space-3);
    resize: vertical;
}

.biz-client {
    gap: var(--space-2);
}

.biz-options {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
}

.biz-option {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--space-3);
    min-height: 56px;
    padding: 0 var(--space-4);
    border: 0;
    border-radius: var(--lc-r-md);
    background: var(--lc-raised);
    box-shadow: var(--lc-shadow-raised);
    color: var(--lc-ink-1);
    font-family: var(--font-body);
    text-align: left;
    cursor: pointer;
    transition: background var(--lc-fast) var(--lc-ease), box-shadow var(--lc-fast) var(--lc-ease), transform var(--lc-fast) var(--lc-ease);
}

.biz-option:active {
    transform: scale(0.985);
}

.biz-option.is-selected {
    background: var(--lc-raised-hover);
    box-shadow: inset 0 0 0 1.5px var(--azure), var(--lc-shadow-raised);
}

.biz-option__name {
    font-size: var(--text-base);
    font-weight: var(--font-weight-medium);
}

.biz-option__meta {
    color: var(--lc-ink-2);
    font-size: var(--text-sm);
    white-space: nowrap;
}

.biz-days,
.biz-slotrow {
    display: flex;
    gap: var(--space-2);
    overflow-x: auto;
    margin: 0 calc(-1 * var(--space-5));
    padding: 4px var(--space-5) var(--space-1);
    scrollbar-width: none;
}

.biz-days::-webkit-scrollbar,
.biz-slotrow::-webkit-scrollbar,
.biz-chips::-webkit-scrollbar {
    display: none;
}

.biz-day {
    flex: none;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 2px;
    width: 72px;
    height: 68px;
    border: 0;
    border-radius: var(--lc-r-md);
    background: var(--lc-raised);
    box-shadow: var(--lc-shadow-raised);
    color: var(--lc-ink-1);
    font-family: var(--font-body);
    cursor: pointer;
    transition: background var(--lc-fast) var(--lc-ease), transform var(--lc-fast) var(--lc-ease);
}

.biz-day:active {
    transform: scale(0.96);
}

.biz-day__name {
    color: var(--lc-ink-2);
    font-size: 12px;
}

.biz-day__num {
    font-size: var(--text-lg);
}

.biz-day.is-selected {
    background: var(--azure);
    box-shadow: var(--lc-shadow-accent);
}

.biz-day.is-selected .biz-day__name {
    color: var(--lc-ink-1);
}

.biz-slotgroups {
    display: flex;
    flex-direction: column;
    gap: var(--space-3);
}

.biz-slotgroup__label {
    display: block;
    margin-bottom: var(--space-1);
    color: var(--lc-ink-3);
    font-size: 12px;
}

.biz-slot {
    min-height: 44px;
    border: 0;
    border-radius: var(--lc-r-md);
    background: var(--lc-raised);
    box-shadow: var(--lc-shadow-raised);
    color: var(--lc-ink-1);
    font-family: var(--font-mono);
    font-size: var(--text-sm);
    cursor: pointer;
    transition: background var(--lc-fast) var(--lc-ease), transform var(--lc-fast) var(--lc-ease);
}

.biz-slot:active {
    transform: scale(0.95);
}

.biz-slotrow .biz-slot {
    flex: none;
    width: 76px;
}

.biz-slot.is-selected {
    background: var(--azure);
    box-shadow: var(--lc-shadow-accent);
}

.biz-slots {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(76px, 1fr));
    gap: var(--space-2);
    max-height: 212px;
    overflow-y: auto;
}


.biz-sheet {
    position: fixed;
    inset: 0;
    z-index: var(--z-modal);
    display: flex;
    align-items: flex-end;
    background: rgba(5, 6, 8, 0.6);
    backdrop-filter: blur(6px);
    -webkit-backdrop-filter: blur(6px);
    animation: lc-fade var(--lc-base) var(--lc-ease);
}

@keyframes lc-fade {
    from { opacity: 0; }
}

.biz-sheet__panel {
    display: flex;
    flex-direction: column;
    width: 100%;
    max-height: 92dvh;
    background: var(--lc-overlay);
    box-shadow: var(--lc-shadow-overlay);
    border-radius: var(--lc-r-xl) var(--lc-r-xl) 0 0;
    animation: lc-sheet-up var(--lc-base) var(--lc-ease);
}

.biz-sheet__panel::before {
    content: '';
    align-self: center;
    width: 40px;
    height: 4px;
    margin-top: var(--space-2);
    border-radius: var(--radius-full);
    background: var(--lc-line-strong);
}

.biz-sheet__panel:focus {
    outline: none;
}

.biz-sheet__head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--space-3);
    padding: var(--space-3) var(--space-5) var(--space-2);
}

.biz-sheet__title {
    margin: 0;
    font-family: var(--font-display);
    font-size: var(--text-xl);
    font-weight: var(--font-weight-semibold);
    letter-spacing: var(--tracking-tight);
}

.biz-sheet__body {
    flex: 1;
    overflow-y: auto;
    padding: var(--space-2) var(--space-5) var(--space-5);
    display: flex;
    flex-direction: column;
    gap: var(--space-5);
}

.biz-sheet__foot {
    padding: var(--space-3) var(--space-5) calc(var(--space-3) + env(safe-area-inset-bottom, 0px));
    border-top: 1px solid var(--lc-line);
}

@keyframes lc-sheet-up {
    from { transform: translateY(32px); opacity: 0; }
    to { transform: none; opacity: 1; }
}


.biz-facts {
    display: flex;
    flex-direction: column;
    gap: var(--space-3);
    margin: 0;
    padding: var(--space-4);
    border-radius: var(--lc-r-lg);
    background: var(--lc-card);
    box-shadow: inset 0 0 0 1px var(--lc-line);
}

.biz-facts div {
    display: grid;
    grid-template-columns: 72px 1fr;
    gap: var(--space-3);
}

.biz-facts dt {
    color: var(--lc-ink-3);
    font-size: var(--text-sm);
}

.biz-facts dd {
    margin: 0;
    font-size: var(--text-sm);
}

.biz-status {
    display: inline-flex;
    align-items: center;
    gap: var(--space-2);
    padding: 2px 10px 2px 8px;
    border-radius: var(--radius-full);
    background: var(--lc-card);
    font-size: 12px;
    font-weight: var(--font-weight-medium);
}

.biz-status::before {
    content: '';
    width: 6px;
    height: 6px;
    border-radius: var(--radius-full);
    background: currentColor;
}

.biz-status--pending { background: var(--lc-warning-tint); color: var(--lc-warning); }
.biz-status--confirmed { background: var(--lc-info-tint); color: var(--lc-info); }
.biz-status--completed { background: var(--lc-success-tint); color: var(--lc-success); }
.biz-status--no_show { background: var(--lc-danger-tint); color: var(--lc-danger); }
.biz-status--cancelled { color: var(--lc-ink-3); }

.biz-contact {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(96px, 1fr));
    gap: var(--space-2);
}

.biz-contact__btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: var(--space-2);
    min-height: 48px;
    border-radius: var(--lc-r-md);
    background: var(--lc-raised);
    box-shadow: var(--lc-shadow-raised);
    color: var(--lc-ink-1);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
    text-decoration: none;
    transition: background var(--lc-fast) var(--lc-ease), transform var(--lc-fast) var(--lc-ease);
}

.biz-contact__btn:hover {
    background: var(--lc-raised-hover);
}

.biz-contact__btn:active {
    transform: scale(0.97);
}

.biz-actions {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: var(--space-2);
}

.biz-actions .btn:first-child {
    grid-column: 1 / -1;
}

.biz-move {
    padding-top: var(--space-5);
    border-top: 1px solid var(--lc-line);
}


.biz-toast {
    position: fixed;
    left: 50%;
    bottom: calc(148px + env(safe-area-inset-bottom, 0px));
    z-index: var(--z-tooltip);
    transform: translateX(-50%);
    pointer-events: none;
}

.biz-toast__msg {
    display: block;
    padding: var(--space-3) var(--space-5);
    border-radius: var(--radius-full);
    background: var(--lc-ink-1);
    box-shadow: var(--lc-shadow-overlay);
    color: var(--lc-canvas);
    font-size: var(--text-sm);
    font-weight: var(--font-weight-medium);
    white-space: nowrap;
    animation: lc-toast var(--lc-base) var(--lc-ease);
}

@keyframes lc-toast {
    from { opacity: 0; transform: translateY(8px) scale(0.98); }
}


@media (min-width: 640px) {
    .biz-field-row {
        grid-template-columns: 1fr 1fr;
    }
}

@media (min-width: 768px) {
    .biz-sheet {
        align-items: stretch;
        justify-content: flex-end;
        padding: var(--space-3);
    }

    .biz-sheet__panel {
        width: 460px;
        max-height: none;
        border-radius: var(--lc-r-xl);
        animation-name: lc-sheet-in;
    }

    .biz-sheet__panel::before {
        display: none;
    }

    @keyframes lc-sheet-in {
        from { transform: translateX(32px); opacity: 0; }
        to { transform: none; opacity: 1; }
    }
}

@media (min-width: 1024px) {
    .biz-shell {
        display: grid;
        grid-template-columns: 272px 1fr;
    }

    .biz-sidebar {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        z-index: var(--z-header);
        box-sizing: border-box;
        width: 272px;
        display: flex;
        flex-direction: column;
        gap: var(--space-4);
        padding: var(--space-4) var(--space-4);
        background: var(--lc-well);
        border-right: 1px solid var(--lc-line);
    }

    .biz-sidebar__nav {
        flex: 1;
        overflow-y: auto;
        margin: 0 calc(-1 * var(--space-2));
        padding: 0 var(--space-2);
        scrollbar-width: thin;
    }

    .biz-sidebar__foot {
        display: flex;
        flex-direction: column;
        gap: 2px;
    }

    .biz-sidebar__foot .biz-strength {
        margin-bottom: var(--space-2);
    }

    .biz-main {
        grid-column: 2;
        min-width: 0;
    }

    .biz-topbar {
        padding: 0 var(--space-8);
        gap: var(--space-4);
    }

    .biz-topbar__brand,
    .biz-topbar__share {
        display: none;
    }

    .biz-topbar__title {
        display: block;
        flex: 1;
        font-family: var(--font-display);
        font-size: var(--text-base);
        font-weight: var(--font-weight-semibold);
    }

    .biz-search {
        display: flex;
        align-items: center;
        gap: var(--space-2);
        width: 320px;
        height: 40px;
        padding: 0 var(--space-3);
        border: 0;
        border-radius: var(--radius-full);
        background: var(--lc-card);
        box-shadow: inset 0 0 0 1px var(--lc-line);
        color: var(--lc-ink-3);
        font-family: var(--font-body);
        font-size: var(--text-sm);
        cursor: pointer;
        transition: background var(--lc-fast) var(--lc-ease);
    }

    .biz-search:hover {
        background: var(--lc-raised);
    }

    .biz-search span {
        flex: 1;
        text-align: left;
    }

    .biz-search kbd {
        padding: 2px 6px;
        border-radius: 6px;
        background: var(--lc-raised);
        color: var(--lc-ink-3);
        font-family: var(--font-mono);
        font-size: 11px;
    }

    .biz-topbar__new {
        display: inline-flex;
        box-shadow: var(--lc-shadow-accent);
    }

    .biz-tabbar,
    .biz-fab {
        display: none;
    }

    .biz-content {
        padding: var(--space-8) var(--space-8) var(--space-12);
    }

    .biz-page {
        max-width: 1120px;
    }

    .biz-toast {
        bottom: var(--space-8);
    }
}

@media (prefers-reduced-motion: reduce) {
    .biz-page,
    .biz-sheet,
    .biz-sheet__panel,
    .biz-toast__msg {
        animation: none;
    }
}
` },
]

const PATCHES = [
    {
        file: 'src/BookingApp.jsx',
        edits: [
            { desc: "Import the planned sections page", find: `import Calendar from './pages/business/Calendar'
`, replace: `import Calendar from './pages/business/Calendar'
import Planned from './pages/business/Planned'
` },
            { desc: "Routes for every planned section", find: `                    <Route path="settings" element={<PortalSettings />} />
`, replace: `                    <Route path="settings" element={<PortalSettings />} />
                    <Route path="assistant" element={<Planned section="assistant" />} />
                    <Route path="clients" element={<Planned section="clients" />} />
                    <Route path="team" element={<Planned section="team" />} />
                    <Route path="insights" element={<Planned section="insights" />} />
                    <Route path="notifications" element={<Planned section="notifications" />} />
` },
        ],
    },
    {
        file: 'index.html',
        edits: [
            { desc: "Boot loader: ring around the mark instead of scanning bars", find: `    .loca-boot__scan {
      display: flex;
      align-items: center;
      gap: 5px;
      opacity: 0;
      animation: loca-boot-fade 360ms ease 220ms forwards;
    }
    .loca-boot__scan span {
      display: block;
      width: 12px;
      height: 4px;
      border-radius: 1px;
      background: rgba(45, 127, 240, 0.14);
      transform-origin: center;
      animation: loca-scan 1400ms cubic-bezier(0.4, 0, 0.6, 1) infinite;
    }
    .loca-boot__scan span:nth-child(1) { animation-delay: 0ms; }
    .loca-boot__scan span:nth-child(2) { animation-delay: 110ms; }
    .loca-boot__scan span:nth-child(3) { animation-delay: 220ms; }
    .loca-boot__scan span:nth-child(4) { animation-delay: 330ms; }
    .loca-boot__scan span:nth-child(5) { animation-delay: 440ms; }
    .loca-boot__scan span:nth-child(6) { animation-delay: 550ms; }
    .loca-boot__scan span:nth-child(7) { animation-delay: 660ms; }
    @keyframes loca-scan {
      0%, 100% { background: rgba(45, 127, 240, 0.14); transform: scaleY(1); }
      20%      { background: #2D7FF0; transform: scaleY(1.7); }
      60%      { background: rgba(45, 127, 240, 0.14); transform: scaleY(1); }
    }
    .loca-boot__caption {
      font-family: 'JetBrains Mono', ui-monospace, 'SF Mono', Menlo, monospace;
      font-size: 10px;
      font-weight: 500;
      letter-spacing: 0.32em;
      color: #4A5060;
      text-transform: uppercase;
      opacity: 0;
      animation: loca-boot-fade 360ms ease 340ms forwards;
    }
    @keyframes loca-boot-fade {
      to { opacity: 1; }
    }
    @media (prefers-reduced-motion: reduce) {
      .loca-boot__mark,
      .loca-boot__scan,
      .loca-boot__caption { animation: none; opacity: 1; }
      .loca-boot__scan span { animation: none; }
      .loca-boot__scan span:nth-child(4) { background: #2D7FF0; }
    }`, replace: `    .loca-boot__ring {
      position: absolute;
      inset: -18px;
      width: 92px;
      height: 92px;
      animation: loca-boot-spin 1600ms linear infinite;
    }
    .loca-boot__stage {
      position: relative;
    }
    .loca-boot__track {
      fill: none;
      stroke: rgba(244, 246, 251, 0.1);
      stroke-width: 2.5;
    }
    .loca-boot__arc {
      fill: none;
      stroke: url(#loca-boot-gradient);
      stroke-width: 2.5;
      stroke-linecap: round;
      stroke-dasharray: 70 170;
    }
    @keyframes loca-boot-spin {
      to { transform: rotate(360deg); }
    }
    @media (prefers-reduced-motion: reduce) {
      .loca-boot__mark,
      .loca-boot__ring { animation: none; }
    }` },
            { desc: "Boot markup", find: `      <img src="/brand/loca-mark.svg" alt="" class="loca-boot__mark" width="56" height="56" draggable="false" />
      <div class="loca-boot__scan" role="presentation">
        <span></span><span></span><span></span><span></span><span></span><span></span><span></span>
      </div>
      <div class="loca-boot__caption">Locappoint</div>`, replace: `      <svg class="loca-boot__ring" viewBox="0 0 92 92" aria-hidden="true">
        <defs>
          <linearGradient id="loca-boot-gradient" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#2D7FF0" />
            <stop offset="100%" stop-color="#E89A3E" />
          </linearGradient>
        </defs>
        <circle class="loca-boot__track" cx="46" cy="46" r="38" />
        <circle class="loca-boot__arc" cx="46" cy="46" r="38" />
      </svg>
      <img src="/brand/loca-mark.svg" alt="" class="loca-boot__mark" width="56" height="56" draggable="false" />` },
        ],
    },
]

let failed = false

for (const nf of NEW_FILES) {
    if (fs.existsSync(path.join(REPO, nf.path))) { console.error(`[FAIL] Already exists: ${nf.path}`); failed = true }
}
for (const rf of REPLACE_FILES) {
    if (!fs.existsSync(path.join(REPO, rf.path))) { console.error(`[FAIL] Missing, apply the 4a-2 redesign first: ${rf.path}`); failed = true }
}

const fileChanges = new Map()
for (const group of PATCHES) {
    const fullPath = path.join(REPO, group.file)
    if (!fs.existsSync(fullPath)) { console.error(`[FAIL] Missing: ${group.file}`); failed = true; continue }
    let content = fs.readFileSync(fullPath, 'utf8')
    const original = content
    const crlf = (content.match(/\r\n/g) || []).length
    const lf = (content.match(/\n/g) || []).length - crlf
    const eol = crlf > lf ? '\r\n' : '\n'
    let ok = true
    for (const edit of group.edits) {
        // Anchors accept CRLF or LF; replacements follow the file's dominant ending.
        const pattern = edit.find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\n/g, '\\r?\\n')
        const matches = (content.match(new RegExp(pattern, 'g')) || []).length
        if (matches !== 1) {
            console.error(`[FAIL] ${group.file}: ${matches} matches for "${edit.desc}" (expected 1)`)
            failed = true; ok = false; break
        }
        content = content.replace(new RegExp(pattern), () => edit.replace.replace(/\n/g, eol))
    }
    if (ok) fileChanges.set(fullPath, { original, modified: content, edits: group.edits })
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const nf of NEW_FILES) {
    fs.mkdirSync(path.dirname(path.join(REPO, nf.path)), { recursive: true })
    fs.writeFileSync(path.join(REPO, nf.path), nf.content)
    console.log(`[NEW] ${nf.path}`)
}
for (const rf of REPLACE_FILES) {
    const full = path.join(REPO, rf.path)
    fs.writeFileSync(`${full}.backup`, fs.readFileSync(full))
    fs.writeFileSync(full, rf.content)
    console.log(`[REPLACE] ${rf.path}`)
}
for (const [fullPath, change] of fileChanges) {
    fs.writeFileSync(`${fullPath}.backup`, change.original)
    fs.writeFileSync(fullPath, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, fullPath)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}

console.log('\n[DONE]')
