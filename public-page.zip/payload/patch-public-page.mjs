import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const SPEC = {
  "name": "public-page",
  "backup": ".backup-public",
  "newFiles": [
    "src/components/business/DurationDial.jsx",
    "src/styles/business/dial.css",
    "src/components/business/public/PublicStatus.jsx",
    "src/components/business/public/PublicMenu.jsx",
    "src/components/business/public/PublicHours.jsx",
    "src/components/business/public/PublicFind.jsx"
  ],
  "replaceFiles": [
    {
      "file": "src/components/business/PublicPageView.jsx",
      "sha": "f6e1ecb443c9bbd15c24fd845624196b5c4dff28d303d4707be9a323f596ca91"
    },
    {
      "file": "src/pages/app/PublicBusinessPage.jsx",
      "sha": "381edfbb71cda6595270cc53e4e64d3b692356e0df5df09b5b3e57f6d40f11d5"
    },
    {
      "file": "src/styles/public-page.css",
      "sha": "f91e24eca58effe96fd0e64dd4f3ee7da67f891d16f36962ae10e89ddd09cc9f"
    }
  ],
  "patches": [
    {
      "file": "src/services/business.js",
      "find": "export const formatMoney = (value) => money.format(Number(value) || 0)\n",
      "replace": "export const formatMoney = (value) => money.format(Number(value) || 0)\n\nconst menuFormats = new Map()\n\nexport const menuPrice = (value) => {\n    const amount = Number(String(value).replace(',', '.').trim())\n    const decimals = Number.isInteger(amount) ? 0 : 2\n    if (!menuFormats.has(decimals)) {\n        menuFormats.set(decimals, new Intl.NumberFormat('en-IE', { style: 'currency', currency: 'EUR', minimumFractionDigits: decimals, maximumFractionDigits: decimals }))\n    }\n    return menuFormats.get(decimals).format(amount)\n}\n"
    },
    {
      "file": "src/components/business/ServiceEditor.jsx",
      "find": "import { durationLabel } from '../../services/business'\n",
      "replace": "import { durationLabel, menuPrice } from '../../services/business'\nimport { DurationDial } from './DurationDial'\n"
    },
    {
      "file": "src/components/business/ServiceEditor.jsx",
      "find": "const priceFormat = new Map()\n\nexport const menuPrice = (value) => {\n    const amount = parsePrice(value)\n    const decimals = Number.isInteger(amount) ? 0 : 2\n    if (!priceFormat.has(decimals)) {\n        priceFormat.set(decimals, new Intl.NumberFormat('en-IE', { style: 'currency', currency: 'EUR', minimumFractionDigits: decimals, maximumFractionDigits: decimals }))\n    }\n    return priceFormat.get(decimals).format(amount)\n}\n\nconst sector = (fraction, r) => {\n    const angle = fraction * 2 * Math.PI\n    const x = 16 + r * Math.sin(angle)\n    const y = 16 - r * Math.cos(angle)\n    return `M16 16 L16 ${16 - r} A${r} ${r} 0 ${fraction > 0.5 ? 1 : 0} 1 ${x.toFixed(2)} ${y.toFixed(2)} Z`\n}\n\nconst arc = (fraction, r) => {\n    const angle = Math.min(fraction, 0.9999) * 2 * Math.PI\n    const x = 16 + r * Math.sin(angle)\n    const y = 16 - r * Math.cos(angle)\n    return `M16 ${16 - r} A${r} ${r} 0 ${fraction > 0.5 ? 1 : 0} 1 ${x.toFixed(2)} ${y.toFixed(2)}`\n}\n\nexport const DurationDial = ({ minutes, size = 32, className = '' }) => {\n    const m = Math.max(0, Number(minutes) || 0)\n    const first = Math.min(m, 60) / 60\n    const extra = Math.min(Math.max(m - 60, 0), 60) / 60\n    return (\n        <svg className={`biz-dial${m > 60 ? ' is-long' : ''} ${className}`.trim()} width={size} height={size} viewBox=\"0 0 32 32\" aria-hidden=\"true\">\n            <circle className=\"biz-dial__face\" cx=\"16\" cy=\"16\" r=\"12\" />\n            {[0, 90, 180, 270].map((deg) => (\n                <line key={deg} className=\"biz-dial__tick\" x1=\"16\" y1=\"5.5\" x2=\"16\" y2=\"7.5\" transform={`rotate(${deg} 16 16)`} />\n            ))}\n            {first >= 1 ? <circle className=\"biz-dial__fill\" cx=\"16\" cy=\"16\" r=\"9\" /> : first > 0 && <path className=\"biz-dial__fill\" d={sector(first, 9)} />}\n            {extra > 0 && <path className=\"biz-dial__over\" d={arc(extra, 14.75)} />}\n            <circle className=\"biz-dial__pin\" cx=\"16\" cy=\"16\" r=\"1.5\" />\n        </svg>\n    )\n}\n",
      "replace": "export { DurationDial, menuPrice }\n"
    },
    {
      "file": "src/styles/business/editors.css",
      "find": ".biz-dial { flex: none; overflow: visible; }\n.biz-dial__face { fill: var(--lc-raised); stroke: var(--lc-ink-4); stroke-width: 1.25; }\n.biz-dial__tick { stroke: var(--lc-ink-4); stroke-width: 1.25; stroke-linecap: round; }\n.biz-dial__fill { fill: var(--azure); }\n.biz-dial__over { fill: none; stroke: var(--signal); stroke-width: 2; stroke-linecap: round; }\n.biz-dial__pin { fill: var(--lc-ink-1); }\n",
      "replace": ""
    },
    {
      "file": "src/styles/business/editors.css",
      "find": ".biz-wk__today {\n    color: var(--lc-info);\n    font-size: var(--lc-t-micro);\n    font-weight: var(--font-weight-semibold);\n    letter-spacing: 0.04em;\n    text-transform: uppercase;\n}\n",
      "replace": ".biz-wk__today {\n    color: var(--lc-info);\n    font-size: 12px;\n    font-weight: var(--font-weight-semibold);\n}\n"
    },
    {
      "file": "src/styles/business/editors.css",
      "find": ".biz-wk__row.is-closed .biz-wk__day { color: var(--lc-ink-3); }\n",
      "replace": ".biz-wk__row.is-closed:not(.is-today) .biz-wk__day { color: var(--lc-ink-3); }\n"
    }
  ],
  "retires": []
}

const here = path.dirname(fileURLToPath(import.meta.url))
const root = process.cwd()
const check = process.argv.includes('--check')
const problems = []
const plan = []

const abs = (rel) => path.join(root, ...rel.split('/'))
const source = (rel) => path.join(here, 'files', ...rel.split('/'))
const read = (p) => fs.readFileSync(p, 'utf8')
const eolOf = (text) => (text.includes('\r\n') ? '\r\n' : '\n')
const toEol = (text, eol) => text.replace(/\r\n/g, '\n').replace(/\n/g, eol)
const sha = (text) => crypto.createHash('sha256').update(text.replace(/\r\n/g, '\n')).digest('hex')
const count = (hay, needle) => (needle ? hay.split(needle).length - 1 : 0)

const pkg = JSON.parse(read(abs('package.json')))
if (pkg.name !== 'locappoint') {
    console.error('  [ABORT] This is not the locappoint repo.')
    process.exit(1)
}

for (const rel of SPEC.newFiles) {
    if (fs.existsSync(abs(rel))) problems.push(`${rel} already exists (patch already applied?)`)
    else if (!fs.existsSync(source(rel))) problems.push(`payload is missing ${rel}`)
    else plan.push(['NEW', rel])
}

for (const { file, sha: expected } of SPEC.replaceFiles) {
    if (!fs.existsSync(abs(file))) { problems.push(`${file} is missing`); continue }
    if (sha(read(abs(file))) !== expected) { problems.push(`${file} changed since this patch was built (or it is already applied)`); continue }
    plan.push(['REPLACE', file])
}

const edits = new Map()
for (const p of SPEC.patches) {
    if (!fs.existsSync(abs(p.file))) { problems.push(`${p.file} is missing`); continue }
    if (!edits.has(p.file)) edits.set(p.file, read(abs(p.file)))
    const current = edits.get(p.file)
    const eol = eolOf(current)
    const find = toEol(p.find, eol)
    const hits = count(current, find)
    if (hits !== 1) { problems.push(`${p.file}: anchor matched ${hits} times, expected 1: ${JSON.stringify(p.find.slice(0, 60))}`); continue }
    edits.set(p.file, current.replace(find, () => toEol(p.replace, eol)))
}
for (const file of edits.keys()) plan.push(['EDIT', file])

for (const rel of SPEC.retires) {
    if (!fs.existsSync(abs(rel))) { problems.push(`${rel} is missing`); continue }
    const base = path.basename(rel)
    const users = []
    const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const full = path.join(dir, entry.name)
            if (entry.isDirectory()) walk(full)
            else if (/\.(jsx?|css)$/.test(entry.name) && full !== abs(rel) && read(full).includes(base)) users.push(path.relative(root, full))
        }
    }
    walk(abs('src'))
    if (users.length) problems.push(`${rel} is still imported by ${users.join(', ')}`)
    else plan.push(['RETIRE', rel])
}

if (problems.length) {
    console.error('  [ABORT] Nothing was written:')
    for (const p of problems) console.error(`    ${p}`)
    process.exit(1)
}

if (check) {
    for (const [kind, rel] of plan) console.log(`  [${kind}] ${rel}`)
    console.log('  Checks passed.')
    process.exit(0)
}

for (const [kind, rel] of plan) {
    const target = abs(rel)
    if (kind === 'NEW') {
        fs.mkdirSync(path.dirname(target), { recursive: true })
        fs.writeFileSync(target, read(source(rel)))
    } else if (kind === 'REPLACE') {
        const eol = eolOf(read(target))
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, toEol(read(source(rel)), eol))
    } else if (kind === 'EDIT') {
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, edits.get(rel))
    } else if (kind === 'RETIRE') {
        fs.renameSync(target, target + '.mistake')
    }
    console.log(`  [${kind}] ${rel}`)
}
console.log('  Patch applied.')
