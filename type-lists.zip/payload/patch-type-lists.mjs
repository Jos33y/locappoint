import fs from 'fs'
import path from 'path'
import crypto from 'crypto'
import { fileURLToPath } from 'url'

const REPO = process.cwd()
const HERE = path.dirname(fileURLToPath(import.meta.url))
const SPEC = {
 "new": [],
 "replace": [
  {
   "path": "src/constants/categories.js",
   "sha256": "69fcbe6a7191b28868aae2986f118185de6b9486e9f500548b178fdb6eb3b492"
  }
 ],
 "patches": [
  {
   "file": "src/pages/app/Businesses.jsx",
   "edits": [
    {
     "desc": "Types come from the shared list",
     "find": "import StreetGridCover from '../../components/business/StreetGridCover'\n",
     "replace": "import StreetGridCover from '../../components/business/StreetGridCover'\nimport { categoryLabel, categoryTint } from '../../constants/categories'\n"
    },
    {
     "desc": "Retire the local tint map",
     "find": "// Category -> tint family. Drives StreetGridCover accent + avatar border.\nconst CATEGORY_TINTS = {\n    // Hair / salons -> azure\n    salon: 'azure', 'hair salon': 'azure', hair: 'azure',\n    cabeleireiro: 'azure', salao: 'azure', 'sal\u00e3o': 'azure',\n    // Barbershops -> signal\n    barbershop: 'signal', barber: 'signal',\n    barbearia: 'signal', barbeiro: 'signal',\n    // Spa / wellness -> success\n    spa: 'success', wellness: 'success', massage: 'success',\n    massagem: 'success', 'bem-estar': 'success',\n    // Nail / beauty -> azure\n    nail: 'azure', manicure: 'azure', beauty: 'azure',\n    estetica: 'azure', 'est\u00e9tica': 'azure',\n    // Fitness -> signal\n    fitness: 'signal', gym: 'signal', studio: 'signal',\n    ginasio: 'signal', 'gin\u00e1sio': 'signal',\n    // Yoga / pilates -> success\n    yoga: 'success', pilates: 'success',\n    // Tattoo -> ink\n    tattoo: 'ink', tatuagem: 'ink',\n    // Medical -> success\n    clinic: 'success', clinica: 'success', 'cl\u00ednica': 'success',\n    physio: 'success', fisioterapia: 'success',\n}\n\n\nconst resolveTint = (category) => {\n    const key = (category || '').toString().toLowerCase().trim()\n    return CATEGORY_TINTS[key] || 'azure'\n}\n\n\n",
     "replace": ""
    },
    {
     "desc": "Show the type label",
     "find": "const category = fieldOf(biz, 'category', 'business_type', 'type')",
     "replace": "const category = categoryLabel(biz.category, biz.category_detail)"
    },
    {
     "desc": "Tint from the shared helper",
     "find": "const tint = resolveTint(category)",
     "replace": "const tint = categoryTint(biz.category)"
    }
   ]
  },
  {
   "file": "src/pages/client/Search.jsx",
   "edits": [
    {
     "desc": "Types come from the shared list",
     "find": "import { Search as SearchIcon, MapPin, Filter, X } from 'lucide-react'\n",
     "replace": "import { Search as SearchIcon, MapPin, Filter, X } from 'lucide-react'\nimport { CATEGORIES, CATEGORY_SECTIONS, categoryKey, categoryLabel } from '../../constants/categories'\n"
    },
    {
     "desc": "Old links map to the new keys",
     "find": "useState(searchParams.get('category') || '')",
     "replace": "useState(categoryKey(searchParams.get('category') || ''))"
    },
    {
     "desc": "Load the owner words for Something else",
     "find": "                    category,\n                    city,",
     "replace": "                    category,\n                    category_detail,\n                    city,"
    },
    {
     "desc": "Search matches type labels and Portuguese words",
     "find": "                business.category?.toLowerCase().includes(query)",
     "replace": "                categoryLabel(business.category, business.category_detail).toLowerCase().includes(query) ||\n                (CATEGORIES.find((c) => c.value === categoryKey(business.category))?.keywords || '').includes(query)"
    },
    {
     "desc": "Filter by key",
     "find": "                business.category === selectedCategory",
     "replace": "                categoryKey(business.category) === selectedCategory"
    },
    {
     "desc": "Full grouped type list",
     "find": "                        <option value=\"\">All Categories</option>\n                        <option value=\"Salon\">Salon</option>\n                        <option value=\"Spa\">Spa</option>\n                        <option value=\"Barbershop\">Barbershop</option>\n                        <option value=\"Dental\">Dental</option>\n                        <option value=\"Clinic\">Clinic</option>\n                        <option value=\"Gym\">Gym</option>\n                        <option value=\"Restaurant\">Restaurant</option>\n                        <option value=\"Other\">Other</option>\n",
     "replace": "                        <option value=\"\">All types</option>\n                        {CATEGORY_SECTIONS.map(({ group, items }) => (\n                            <optgroup key={group} label={group}>\n                                {items.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}\n                            </optgroup>\n                        ))}\n"
    },
    {
     "desc": "Card shows the label",
     "find": "                                        {business.category}\n",
     "replace": "                                        {categoryLabel(business.category, business.category_detail)}\n"
    }
   ]
  },
  {
   "file": "src/pages/client/Home.jsx",
   "edits": [
    {
     "desc": "Types come from the shared list",
     "find": "import { Search, Calendar, MapPin, Clock, ArrowRight } from 'lucide-react'\n",
     "replace": "import { Search, Calendar, MapPin, Clock, ArrowRight } from 'lucide-react'\nimport { CATEGORY_SECTIONS } from '../../constants/categories'\n"
    },
    {
     "desc": "Full grouped type list",
     "find": "                            <option value=\"\">All Categories</option>\n                            <option value=\"Salon\">Salon</option>\n                            <option value=\"Spa\">Spa</option>\n                            <option value=\"Barbershop\">Barbershop</option>\n                            <option value=\"Dental\">Dental</option>\n                            <option value=\"Clinic\">Clinic</option>\n                            <option value=\"Gym\">Gym</option>\n                            <option value=\"Restaurant\">Restaurant</option>\n                            <option value=\"Other\">Other</option>\n",
     "replace": "                            <option value=\"\">All types</option>\n                            {CATEGORY_SECTIONS.map(({ group, items }) => (\n                                <optgroup key={group} label={group}>\n                                    {items.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}\n                                </optgroup>\n                            ))}\n"
    }
   ]
  },
  {
   "file": "src/pages/portal/Profile.jsx",
   "edits": [
    {
     "desc": "Types come from the shared list",
     "find": "import { slugProblem } from '../../constants/reservedSlugs'\n",
     "replace": "import { slugProblem } from '../../constants/reservedSlugs'\nimport { CATEGORY_SECTIONS, categoryKey } from '../../constants/categories'\n"
    },
    {
     "desc": "Saved type loads as a key",
     "find": "                setFormData(data)\n",
     "replace": "                setFormData({ ...data, category: categoryKey(data.category), category_detail: data.category_detail || '' })\n"
    },
    {
     "desc": "Something else needs the owner words",
     "find": "            setError('Category is required')\n            return false\n        }",
     "replace": "            setError('Category is required')\n            return false\n        }\n        if (formData.category === 'other' && !(formData.category_detail || '').trim()) {\n            setError('Tell clients what kind of business you are')\n            return false\n        }"
    },
    {
     "desc": "Owner words kept only for Something else",
     "find": "                ...formData,\n                user_id: userProfile.id,",
     "replace": "                ...formData,\n                category_detail: formData.category === 'other' ? (formData.category_detail || '').trim() : null,\n                user_id: userProfile.id,"
    },
    {
     "desc": "Full grouped type list",
     "find": "                            <option value=\"\">Select a category</option>\n                            <option value=\"Salon\">Salon</option>\n                            <option value=\"Barbershop\">Barbershop</option>\n                            <option value=\"Spa\">Spa</option>\n                            <option value=\"Clinic\">Clinic</option>\n                            <option value=\"Dental\">Dental</option>\n                            <option value=\"Fitness\">Fitness</option>\n                            <option value=\"Beauty\">Beauty</option>\n                            <option value=\"Restaurant\">Restaurant</option>\n                            <option value=\"Cafe\">Cafe</option>\n                            <option value=\"Other\">Other</option>\n",
     "replace": "                            <option value=\"\">Select a type</option>\n                            {CATEGORY_SECTIONS.map(({ group, items }) => (\n                                <optgroup key={group} label={group}>\n                                    {items.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}\n                                </optgroup>\n                            ))}\n"
    },
    {
     "desc": "Something else field",
     "find": "                        </select>\n                    </div>\n                </div>\n\n                {/* Location */}",
     "replace": "                        </select>\n                    </div>\n                    {formData.category === 'other' && (\n                        <div className=\"form-group\">\n                            <label htmlFor=\"category_detail\">What kind of business? *</label>\n                            <input\n                                id=\"category_detail\"\n                                name=\"category_detail\"\n                                value={formData.category_detail || ''}\n                                onChange={handleInputChange}\n                                maxLength={60}\n                                placeholder=\"Surf school\"\n                            />\n                        </div>\n                    )}\n                </div>\n\n                {/* Location */}"
    }
   ]
  }
 ],
 "retires": [],
 "backupSuffix": ".backup-typelists"
}
const BACKUP = SPEC.backupSuffix

let failed = false
const fail = (msg) => { console.error(`[FAIL] ${msg}`); failed = true }
const sha = (buf) => crypto.createHash('sha256').update(buf).digest('hex')
const toCrlf = (text) => text.replace(/\r?\n/g, '\r\n')
const count = (haystack, needle) => (needle === '' ? 0 : haystack.split(needle).length - 1)

for (const rel of SPEC.new) {
    if (fs.existsSync(path.join(REPO, rel))) fail(`Already exists: ${rel}`)
    if (!fs.existsSync(path.join(HERE, 'files', rel))) fail(`Missing in payload: ${rel}`)
}

for (const item of SPEC.replace) {
    const full = path.join(REPO, item.path)
    if (!fs.existsSync(full)) { fail(`Missing: ${item.path}`); continue }
    const current = fs.readFileSync(full)
    if (sha(current) !== item.sha256) fail(`${item.path} differs from the version this patch expects (edited locally, or already replaced). Not overwriting.`)
    if (fs.existsSync(`${full}${BACKUP}`)) fail(`Backup already exists: ${item.path}${BACKUP}`)
}

const fileChanges = new Map()
for (const group of SPEC.patches) {
    const full = path.join(REPO, group.file)
    if (!fs.existsSync(full)) { fail(`Missing: ${group.file}`); continue }
    if (fs.existsSync(`${full}${BACKUP}`)) fail(`Backup already exists: ${group.file}${BACKUP}`)
    const original = fs.readFileSync(full, 'utf8')
    let content = original
    let ok = true
    for (const edit of group.edits) {
        const lf = count(content, edit.find)
        const crlf = count(content, toCrlf(edit.find))
        let find = edit.find
        let replace = edit.replace
        if (lf !== 1 && crlf === 1) { find = toCrlf(edit.find); replace = toCrlf(edit.replace) }
        else if (lf !== 1) { fail(`${group.file}: ${lf || crlf} matches for "${edit.desc}" (expected 1)`); ok = false; break }
        content = content.replace(find, () => replace)
    }
    if (ok) fileChanges.set(full, { original, modified: content, edits: group.edits })
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const rel of SPEC.new) {
    fs.mkdirSync(path.dirname(path.join(REPO, rel)), { recursive: true })
    fs.copyFileSync(path.join(HERE, 'files', rel), path.join(REPO, rel))
    console.log(`[NEW] ${rel}`)
}
for (const item of SPEC.replace) {
    const full = path.join(REPO, item.path)
    fs.copyFileSync(full, `${full}${BACKUP}`)
    fs.copyFileSync(path.join(HERE, 'files', item.path), full)
    console.log(`[REPLACE] ${item.path}`)
}
for (const [full, change] of fileChanges) {
    fs.writeFileSync(`${full}${BACKUP}`, change.original)
    fs.writeFileSync(full, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, full)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}

console.log('\n[DONE]')
