import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const SPEC = {
  "name": "audit-fixes",
  "backup": ".backup-audit",
  "prefixes": [],
  "newFiles": [
    "supabase/migrations/name-sync.sql",
    "supabase/queries/name-sync-verify.sql"
  ],
  "replaceFiles": [],
  "patches": [
    {
      "file": "src/styles/app/inbox.css",
      "find": ".lc-ibx__list {\n    display: flex;\n    flex-direction: column;\n    margin: 0;\n    padding: var(--space-1);\n    list-style: none;",
      "replace": ".lc-ibx__list {\n    display: flex;\n    flex-direction: column;\n    margin: 0;\n    padding: 0;\n    overflow: hidden;\n    list-style: none;"
    },
    {
      "file": "src/styles/app/inbox.css",
      "find": "    padding: var(--space-3);\n    border-radius: var(--lc-r-md);\n    color: inherit;",
      "replace": "    padding: var(--space-4);\n    color: inherit;"
    },
    {
      "file": "src/styles/app/inbox.css",
      "find": "    left: calc(var(--space-3) + 64px + var(--space-3));\n    right: var(--space-5);",
      "replace": "    left: calc(var(--space-4) + 64px + var(--space-3));\n    right: 0;"
    },
    {
      "file": "src/styles/app/inbox.css",
      "find": "    .lc-ibx__list > li + li::before {\n        left: calc(var(--space-3) + 52px + var(--space-2));\n    }",
      "replace": "    .lc-ibx__item {\n        padding: var(--space-3);\n    }\n\n    .lc-ibx__list > li + li::before {\n        left: calc(var(--space-3) + 52px + var(--space-2));\n    }"
    },
    {
      "file": "src/services/inbox.js",
      "find": "    const movedFrom = p.moved_from ? String(p.moved_from) : ''",
      "replace": "    const movedFrom = p.moved_from && (item.kind === 'booking_moved' || item.kind === 'booking_request') ? String(p.moved_from) : ''"
    },
    {
      "file": "src/components/inbox/InboxPage.jsx",
      "find": "    useEffect(() => { load() }, [load, version])\n",
      "replace": "    useEffect(() => { load() }, [load, version])\n\n    const [, setTick] = useState(0)\n    useEffect(() => {\n        const timer = setInterval(() => setTick((t) => t + 1), 60000)\n        return () => clearInterval(timer)\n    }, [])\n"
    },
    {
      "file": "src/pages/client/MyAppointments.jsx",
      "find": "    useEffect(() => {\n        if (focused) document.getElementById(`booking-${focused}`)?.scrollIntoView({ block: 'center', behavior: 'smooth' })\n    }, [focused, view])",
      "replace": "    useEffect(() => {\n        if (!focused) return undefined\n        document.getElementById(`booking-${focused}`)?.scrollIntoView({ block: 'center', behavior: 'smooth' })\n        const timer = setTimeout(() => setFocused(null), 2600)\n        return () => clearTimeout(timer)\n    }, [focused, view])"
    },
    {
      "file": "src/styles/client/client-bookings.css",
      "find": "    border-radius: var(--lc-r-xl);\n    scroll-margin: var(--space-20);\n}\n\n.lc-cl-bk.is-focus,\n.lc-cl-past.is-focus {\n    outline: 2px solid var(--lc-info);\n    outline-offset: var(--space-2);\n}",
      "replace": "    border-radius: var(--lc-r-xl);\n    scroll-margin: var(--space-20);\n    outline: 2px solid transparent;\n    outline-offset: var(--space-2);\n    transition: outline-color var(--lc-slow) var(--lc-ease);\n}\n\n.lc-cl-past {\n    outline: 2px solid transparent;\n    transition: outline-color var(--lc-slow) var(--lc-ease);\n}\n\n.lc-cl-bk.is-focus,\n.lc-cl-past.is-focus {\n    outline-color: var(--lc-info);\n    transition-duration: var(--lc-fast);\n}"
    },
    {
      "file": "src/services/business.js",
      "find": "const money = new Intl.NumberFormat('en-IE', { style: 'currency', currency: 'EUR' })\nexport const formatMoney = (value) => money.format(Number(value) || 0)\n",
      "replace": "const money = new Intl.NumberFormat('en-IE', { style: 'currency', currency: 'EUR' })\nconst wholeMoney = new Intl.NumberFormat('en-IE', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 })\nexport const formatMoney = (value) => {\n    const amount = Number(value) || 0\n    return (Number.isInteger(amount) ? wholeMoney : money).format(amount)\n}\n"
    },
    {
      "file": "src/components/client/bookings/PastBooking.jsx",
      "find": "<span>{business.business_name} at {(booking.appointment_time || '').slice(0, 5)}, {date.getFullYear()}</span>",
      "replace": "<span>{business.business_name} at {(booking.appointment_time || '').slice(0, 5)}{date.getFullYear() !== new Date().getFullYear() ? `, ${date.getFullYear()}` : ''}</span>"
    },
    {
      "file": "tests/harness/fakeSupabase.js",
      "find": "payload: { client_name: 'Ana Maria dos Santos Ferreira', service_name: 'Haircut and beard trim with hot towel', duration_minutes: 75, price: 30, country: 'PT', date: key, time: '17:45' } },",
      "replace": "payload: { client_name: 'Ana Maria dos Santos Ferreira', service_name: 'Haircut and beard trim with hot towel', duration_minutes: 75, price: 30, country: 'PT', date: key, time: '17:45', moved_from: `${key}T09:00` } },"
    },
    {
      "file": "tests/suites/notifications.mjs",
      "find": "    check(rows[2]?.link === null, 'an item without a booking is not a link')",
      "replace": "    check(rows[2]?.link === null, 'an item without a booking is not a link')\n    check(rows[2]?.was === '', 'a cancellation does not show an old time, even if the booking was moved before')\n    check(await p.evaluate(() => {\n        const list = document.querySelector('.lc-ibx__list')\n        const item = list.querySelector('.lc-ibx__item')\n        return getComputedStyle(list).overflow === 'hidden' && getComputedStyle(item).borderRadius === '0px'\n    }), 'highlighted rows fill the list edge to edge')"
    },
    {
      "file": "tests/harness/fakeSupabase.js",
      "find": "read_at: '2026-09-01T10:00:00Z', created_at: new Date(Date.now() - 30 * 3600000).toISOString(),",
      "replace": "read_at: '2026-09-01T10:00:00Z', created_at: new Date(today.getFullYear(), today.getMonth(), today.getDate() - 1, 12).toISOString(),"
    }
  ],
  "retires": []
}

const here = path.dirname(fileURLToPath(import.meta.url))
const root = process.cwd()
const check = process.argv.includes('--check')
const problems = []
const plan = []

const abs = (rel) => path.join(root, ...rel.split('/'))
const source = (rel) => path.join(here, 'files', ...rel.split('/'))
const read = (p) => fs.readFileSync(p, 'utf8')
const eolOf = (text) => (text.includes('\r\n') ? '\r\n' : '\n')
const toEol = (text, eol) => text.replace(/\r\n/g, '\n').replace(/\n/g, eol)
const sha = (text) => crypto.createHash('sha256').update(text.replace(/\r\n/g, '\n')).digest('hex')
const count = (hay, needle) => (needle ? hay.split(needle).length - 1 : 0)

const pkg = JSON.parse(read(abs('package.json')))
if (pkg.name !== 'locappoint') {
    console.error('  [ABORT] This is not the locappoint repo.')
    process.exit(1)
}

for (const rel of SPEC.newFiles) {
    if (fs.existsSync(abs(rel))) problems.push(`${rel} already exists (patch already applied?)`)
    else if (!fs.existsSync(source(rel))) problems.push(`payload is missing ${rel}`)
    else plan.push(['NEW', rel])
}

for (const { file, sha: expected } of SPEC.replaceFiles) {
    if (!fs.existsSync(abs(file))) { problems.push(`${file} is missing`); continue }
    if (sha(read(abs(file))) !== expected) { problems.push(`${file} changed since this patch was built (or it is already applied)`); continue }
    plan.push(['REPLACE', file])
}

const srcFiles = () => {
    const out = []
    const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const full = path.join(dir, entry.name)
            if (entry.isDirectory()) { if (entry.name !== 'node_modules') walk(full) }
            else if (/\.(jsx?|css)$/.test(entry.name)) out.push(full)
        }
    }
    walk(abs('src'))
    return out
}

for (const prefix of SPEC.prefixes || []) {
    const owners = srcFiles().filter((full) => read(full).includes(prefix)).map((full) => path.relative(root, full))
    if (owners.length) problems.push(`class prefix ${prefix} is already used in ${owners.join(', ')}`)
}

const edits = new Map()
for (const p of SPEC.patches) {
    if (!fs.existsSync(abs(p.file))) { problems.push(`${p.file} is missing`); continue }
    if (!edits.has(p.file)) edits.set(p.file, read(abs(p.file)))
    const current = edits.get(p.file)
    const eol = eolOf(current)
    const find = toEol(p.find, eol)
    const hits = count(current, find)
    if (hits !== 1) { problems.push(`${p.file}: anchor matched ${hits} times, expected 1: ${JSON.stringify(p.find.slice(0, 60))}`); continue }
    edits.set(p.file, current.replace(find, () => toEol(p.replace, eol)))
}
for (const file of edits.keys()) plan.push(['EDIT', file])

for (const rel of SPEC.retires) {
    if (!fs.existsSync(abs(rel))) { problems.push(`${rel} is missing`); continue }
    const base = path.basename(rel)
    const stem = /\.(jsx?)$/.test(base) ? base.replace(/\.(jsx?)$/, '') : base
    const pattern = new RegExp(`[\\/'"]${stem.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\.jsx?)?['"]`)
    const planned = (full) => {
        const key = path.relative(root, full).split(path.sep).join('/')
        if (SPEC.replaceFiles.some((f) => f.file === key)) return read(source(key))
        return edits.has(key) ? edits.get(key) : read(full)
    }
    const users = srcFiles().filter((full) => full !== abs(rel) && pattern.test(planned(full))).map((full) => path.relative(root, full))
    if (users.length) problems.push(`${rel} is still imported by ${users.join(', ')}`)
    else plan.push(['RETIRE', rel])
}

if (problems.length) {
    console.error('  [ABORT] Nothing was written:')
    for (const p of problems) console.error(`    ${p}`)
    process.exit(1)
}

if (check) {
    for (const [kind, rel] of plan) console.log(`  [${kind}] ${rel}`)
    console.log('  Checks passed.')
    process.exit(0)
}

for (const [kind, rel] of plan) {
    const target = abs(rel)
    if (kind === 'NEW') {
        fs.mkdirSync(path.dirname(target), { recursive: true })
        fs.writeFileSync(target, read(source(rel)))
    } else if (kind === 'REPLACE') {
        const eol = eolOf(read(target))
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, toEol(read(source(rel)), eol))
    } else if (kind === 'EDIT') {
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, edits.get(rel))
    } else if (kind === 'RETIRE') {
        fs.renameSync(target, target + '.mistake')
    }
    console.log(`  [${kind}] ${rel}`)
}
console.log('  Patch applied.')
