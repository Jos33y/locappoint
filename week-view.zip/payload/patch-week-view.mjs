import fs from 'fs'
import path from 'path'
import crypto from 'crypto'
import { fileURLToPath } from 'url'

const REPO = process.cwd()
const HERE = path.dirname(fileURLToPath(import.meta.url))
const SPEC = {
 "new": [],
 "replace": [
  {
   "path": "src/components/business/HoursEditor.jsx",
   "sha256": "d8d4a46aee177fa90340f3cbc80ca65f5f76a81b5f3d9496cf2577ccae8f06b9"
  },
  {
   "path": "src/styles/business/editors.css",
   "sha256": "83981d8a8dfb00540cf5c5c3d304cdb57adfe4b4fce2af75e71cf15587cc40b7"
  },
  {
   "path": "src/styles/business/setup.css",
   "sha256": "23737ef994a82a7434c0bf026840539491af04d9ce0d5760ecd38c4d61113856"
  }
 ],
 "patches": [],
 "retires": [],
 "backupSuffix": ".backup-week"
}
const BACKUP = SPEC.backupSuffix

let failed = false
const fail = (msg) => { console.error(`[FAIL] ${msg}`); failed = true }
const sha = (buf) => crypto.createHash('sha256').update(buf).digest('hex')
const toCrlf = (text) => text.replace(/\r?\n/g, '\r\n')
const count = (haystack, needle) => (needle === '' ? 0 : haystack.split(needle).length - 1)

for (const rel of SPEC.new) {
    if (fs.existsSync(path.join(REPO, rel))) fail(`Already exists: ${rel}`)
    if (!fs.existsSync(path.join(HERE, 'files', rel))) fail(`Missing in payload: ${rel}`)
}

for (const item of SPEC.replace) {
    const full = path.join(REPO, item.path)
    if (!fs.existsSync(full)) { fail(`Missing: ${item.path}`); continue }
    const current = fs.readFileSync(full)
    if (sha(current) !== item.sha256) fail(`${item.path} differs from the version this patch expects (edited locally, or already replaced). Not overwriting.`)
    if (fs.existsSync(`${full}${BACKUP}`)) fail(`Backup already exists: ${item.path}${BACKUP}`)
}

const fileChanges = new Map()
for (const group of SPEC.patches) {
    const full = path.join(REPO, group.file)
    if (!fs.existsSync(full)) { fail(`Missing: ${group.file}`); continue }
    if (fs.existsSync(`${full}${BACKUP}`)) fail(`Backup already exists: ${group.file}${BACKUP}`)
    const original = fs.readFileSync(full, 'utf8')
    let content = original
    let ok = true
    for (const edit of group.edits) {
        const lf = count(content, edit.find)
        const crlf = count(content, toCrlf(edit.find))
        let find = edit.find
        let replace = edit.replace
        if (lf !== 1 && crlf === 1) { find = toCrlf(edit.find); replace = toCrlf(edit.replace) }
        else if (lf !== 1) { fail(`${group.file}: ${lf || crlf} matches for "${edit.desc}" (expected 1)`); ok = false; break }
        content = content.replace(find, () => replace)
    }
    if (ok) fileChanges.set(full, { original, modified: content, edits: group.edits })
}

const retirePaths = []
for (const rel of SPEC.retires) {
    const full = path.join(REPO, rel)
    if (!fs.existsSync(full)) { fail(`Retire target missing: ${rel}`); continue }
    if (fs.existsSync(`${full}.mistake`)) { fail(`Already retired: ${rel}.mistake`); continue }
    retirePaths.push({ full, rel })
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const rel of SPEC.new) {
    fs.mkdirSync(path.dirname(path.join(REPO, rel)), { recursive: true })
    fs.copyFileSync(path.join(HERE, 'files', rel), path.join(REPO, rel))
    console.log(`[NEW] ${rel}`)
}
for (const item of SPEC.replace) {
    const full = path.join(REPO, item.path)
    fs.copyFileSync(full, `${full}${BACKUP}`)
    fs.copyFileSync(path.join(HERE, 'files', item.path), full)
    console.log(`[REPLACE] ${item.path}`)
}
for (const [full, change] of fileChanges) {
    fs.writeFileSync(`${full}${BACKUP}`, change.original)
    fs.writeFileSync(full, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, full)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}

for (const { full, rel } of retirePaths) {
    fs.renameSync(full, `${full}.mistake`)
    console.log(`[RETIRE] ${rel} -> .mistake`)
}

console.log('\n[DONE]')
