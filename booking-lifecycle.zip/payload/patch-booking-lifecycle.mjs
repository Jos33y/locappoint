import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const SPEC = {
  "name": "booking-lifecycle",
  "backup": ".backup-lifecycle",
  "prefixes": [],
  "newFiles": [
    "supabase/migrations/booking-lifecycle.sql",
    "supabase/queries/booking-lifecycle-verify.sql"
  ],
  "replaceFiles": [
    {
      "file": "src/services/booking.js",
      "sha": "2133b09fa74c4c577a8b54c08976ef955ea3c28180a16e1ff58c6b64461574e6"
    },
    {
      "file": "src/components/booking/BookingSheet.jsx",
      "sha": "1e7f0f1d956969bcbdfd2d468ab512d3ea7dbc15125c79a48dc7f98c44142694"
    },
    {
      "file": "src/styles/client/booking-sheet.css",
      "sha": "ccc2005ea451650999d322c04e5e257129227d16dbfff7467730986e7a4d1f43"
    },
    {
      "file": "src/pages/app/PublicBusinessPage.jsx",
      "sha": "0a731f71ee4b3337538ab9c3c2e4956cf0c2f5829ec2c9755c62256983ba8023"
    },
    {
      "file": "src/components/client/bookings/PastBooking.jsx",
      "sha": "2fbbd112ffa1d86e73e8ddd9a1131d397c2e0999d7e998621756c59f19fbcb4d"
    },
    {
      "file": "src/components/client/bookings/UpcomingBooking.jsx",
      "sha": "0c9adfd3b9226a95cb33d9bb1567c28c4fcc3f06a05350de4d766d512e7b9351"
    },
    {
      "file": "src/components/client/bookings/useMyBookings.js",
      "sha": "c4d4f118bcf7ab8323beb4779cd71bcb89fe9a3537d0256364da40ada6360e5b"
    },
    {
      "file": "src/pages/client/MyAppointments.jsx",
      "sha": "36501ea610ce0f2f60924a25184899c64297d0a16f865f9cc049325e240d03d4"
    },
    {
      "file": "src/styles/client/client-bookings.css",
      "sha": "d7c5796880f89c31d6b5c3434c38c6d422cbf40aee6c2f9a6b481f1d91ad34b9"
    },
    {
      "file": "src/services/business.js",
      "sha": "92be6a122b4fa9ad862041a0a40a465ef117421f281ae6e6c76d79ab70f3e4ee"
    },
    {
      "file": "src/pages/business/Today.jsx",
      "sha": "c3c889fbc6d05406ca4a1c29ac4a53725c710b220e6b21ebe6bcd9989c08400e"
    },
    {
      "file": "src/components/business/BookingDetailSheet.jsx",
      "sha": "6c7a3ba406acab8368a19fc43af324d8bf76fd97f955c65fe54d4f994779ba7f"
    },
    {
      "file": "src/styles/foundation.css",
      "sha": "b812dae4d65758147f8361ecee0ab9c6c740a015a71caf06e5ba4e8e38fc5345"
    },
    {
      "file": "src/pages/app/Businesses.jsx",
      "sha": "f3c1c3c2f0c1e935e76d27a23ccc1ae7e39681116efa1074454b219a48c43d83"
    }
  ],
  "patches": [],
  "retires": []
}

const here = path.dirname(fileURLToPath(import.meta.url))
const root = process.cwd()
const check = process.argv.includes('--check')
const problems = []
const plan = []

const abs = (rel) => path.join(root, ...rel.split('/'))
const source = (rel) => path.join(here, 'files', ...rel.split('/'))
const read = (p) => fs.readFileSync(p, 'utf8')
const eolOf = (text) => (text.includes('\r\n') ? '\r\n' : '\n')
const toEol = (text, eol) => text.replace(/\r\n/g, '\n').replace(/\n/g, eol)
const sha = (text) => crypto.createHash('sha256').update(text.replace(/\r\n/g, '\n')).digest('hex')
const count = (hay, needle) => (needle ? hay.split(needle).length - 1 : 0)

const pkg = JSON.parse(read(abs('package.json')))
if (pkg.name !== 'locappoint') {
    console.error('  [ABORT] This is not the locappoint repo.')
    process.exit(1)
}

for (const rel of SPEC.newFiles) {
    if (fs.existsSync(abs(rel))) problems.push(`${rel} already exists (patch already applied?)`)
    else if (!fs.existsSync(source(rel))) problems.push(`payload is missing ${rel}`)
    else plan.push(['NEW', rel])
}

for (const { file, sha: expected } of SPEC.replaceFiles) {
    if (!fs.existsSync(abs(file))) { problems.push(`${file} is missing`); continue }
    if (sha(read(abs(file))) !== expected) { problems.push(`${file} changed since this patch was built (or it is already applied)`); continue }
    plan.push(['REPLACE', file])
}

const srcFiles = () => {
    const out = []
    const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const full = path.join(dir, entry.name)
            if (entry.isDirectory()) { if (entry.name !== 'node_modules') walk(full) }
            else if (/\.(jsx?|css)$/.test(entry.name)) out.push(full)
        }
    }
    walk(abs('src'))
    return out
}

for (const prefix of SPEC.prefixes || []) {
    const owners = srcFiles().filter((full) => read(full).includes(prefix)).map((full) => path.relative(root, full))
    if (owners.length) problems.push(`class prefix ${prefix} is already used in ${owners.join(', ')}`)
}

const edits = new Map()
for (const p of SPEC.patches) {
    if (!fs.existsSync(abs(p.file))) { problems.push(`${p.file} is missing`); continue }
    if (!edits.has(p.file)) edits.set(p.file, read(abs(p.file)))
    const current = edits.get(p.file)
    const eol = eolOf(current)
    const find = toEol(p.find, eol)
    const hits = count(current, find)
    if (hits !== 1) { problems.push(`${p.file}: anchor matched ${hits} times, expected 1: ${JSON.stringify(p.find.slice(0, 60))}`); continue }
    edits.set(p.file, current.replace(find, () => toEol(p.replace, eol)))
}
for (const file of edits.keys()) plan.push(['EDIT', file])

for (const rel of SPEC.retires) {
    if (!fs.existsSync(abs(rel))) { problems.push(`${rel} is missing`); continue }
    const base = path.basename(rel)
    const stem = /\.(jsx?)$/.test(base) ? base.replace(/\.(jsx?)$/, '') : base
    const pattern = new RegExp(`[\\/'"]${stem.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\.jsx?)?['"]`)
    const planned = (full) => {
        const key = path.relative(root, full).split(path.sep).join('/')
        if (SPEC.replaceFiles.some((f) => f.file === key)) return read(source(key))
        return edits.has(key) ? edits.get(key) : read(full)
    }
    const users = srcFiles().filter((full) => full !== abs(rel) && pattern.test(planned(full))).map((full) => path.relative(root, full))
    if (users.length) problems.push(`${rel} is still imported by ${users.join(', ')}`)
    else plan.push(['RETIRE', rel])
}

if (problems.length) {
    console.error('  [ABORT] Nothing was written:')
    for (const p of problems) console.error(`    ${p}`)
    process.exit(1)
}

if (check) {
    for (const [kind, rel] of plan) console.log(`  [${kind}] ${rel}`)
    console.log('  Checks passed.')
    process.exit(0)
}

for (const [kind, rel] of plan) {
    const target = abs(rel)
    if (kind === 'NEW') {
        fs.mkdirSync(path.dirname(target), { recursive: true })
        fs.writeFileSync(target, read(source(rel)))
    } else if (kind === 'REPLACE') {
        const eol = eolOf(read(target))
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, toEol(read(source(rel)), eol))
    } else if (kind === 'EDIT') {
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, edits.get(rel))
    } else if (kind === 'RETIRE') {
        fs.renameSync(target, target + '.mistake')
    }
    console.log(`  [${kind}] ${rel}`)
}
console.log('  Patch applied.')
