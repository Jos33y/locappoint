import { useState } from 'react'
import { RotateCw } from 'lucide-react'
import { useAuth } from '../../hooks/useAuth'
import { Button, Segmented } from '../../components/ui'
import { UpcomingBooking } from '../../components/client/bookings/UpcomingBooking'
import { PastBooking } from '../../components/client/bookings/PastBooking'
import { CancelSheet } from '../../components/client/bookings/CancelSheet'
import { EmptyTicket } from '../../components/client/bookings/EmptyTicket'
import { BookingToast } from '../../components/client/bookings/BookingToast'
import { useMyBookings } from '../../components/client/bookings/useMyBookings'
import '../../styles/client/client-bookings.css'

const ClientAppointments = () => {
    const { user, userProfile } = useAuth()
    const email = userProfile?.email || user?.email || ''
    const { state, groups, load, cancelling, busy, cancelError, toast, askCancel, keep, confirmCancel } = useMyBookings(email)
    const [view, setView] = useState('upcoming')

    const options = [
        { value: 'upcoming', label: `Upcoming ${groups.upcoming.length}` },
        { value: 'past', label: `Past ${groups.past.length}` },
        { value: 'cancelled', label: `Cancelled ${groups.cancelled.length}` },
    ]

    return (
        <div className="biz-page lc-cl-bookings">
            <header className="lc-cl-bookings__head">
                <h1 className="biz-page__title">Your bookings</h1>
                {state.status === 'ready' && state.rows.length > 0 && (
                    <Segmented options={options} value={view} onChange={setView} label="Show" />
                )}
            </header>

            {state.status === 'loading' && (
                <div className="lc-cl-bk is-lead" aria-hidden="true">
                    <span className="lc-skel" style={{ width: 140, height: 18 }} />
                    <span className="lc-skel" style={{ width: '100%', height: 190, borderRadius: 16 }} />
                </div>
            )}

            {state.status === 'error' && (
                <div className="lc-cl-bookings__error" role="alert">
                    <p>We could not load your bookings. Check your connection and try again.</p>
                    <Button variant="secondary" icon={RotateCw} onClick={load}>Try again</Button>
                </div>
            )}

            {state.status === 'ready' && view === 'upcoming' && (
                groups.upcoming.length === 0 ? <EmptyTicket /> : (
                    <div className="lc-cl-bookings__list">
                        {groups.upcoming.map((b, i) => (
                            <UpcomingBooking key={b.id} booking={b} lead={i === 0} onCancel={askCancel} />
                        ))}
                    </div>
                )
            )}

            {state.status === 'ready' && view !== 'upcoming' && (
                groups[view].length === 0 ? (
                    <p className="lc-cl-bookings__none">{view === 'past' ? 'No past bookings yet.' : 'Nothing cancelled.'}</p>
                ) : (
                    <ul className="lc-cl-pastlist">
                        {groups[view].map((b) => <PastBooking key={b.id} booking={b} />)}
                    </ul>
                )
            )}

            <CancelSheet booking={cancelling} busy={busy} error={cancelError} onKeep={keep} onConfirm={confirmCancel} />
            <BookingToast message={toast} />
        </div>
    )
}

export default ClientAppointments
