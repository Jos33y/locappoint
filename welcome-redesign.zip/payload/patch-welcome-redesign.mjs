import fs from 'fs'
import path from 'path'
import crypto from 'crypto'
import { fileURLToPath } from 'url'

const REPO = process.cwd()
const HERE = path.dirname(fileURLToPath(import.meta.url))
const SPEC = {
 "new": [
  "src/constants/sampleBusiness.js"
 ],
 "replace": [
  {
   "path": "src/pages/business/Setup.jsx",
   "sha256": "438730f5d0953696d265ab0fe3f41bebe2445f5276a6430a21a62b86e4e20668"
  },
  {
   "path": "src/styles/business/setup.css",
   "sha256": "04f70a76fe431550a5aad737c86481e93e906526690f9762fcf8c1b86d8ca7da"
  },
  {
   "path": "src/components/business/PublicPageView.jsx",
   "sha256": "96d375031c8c4d458b36b66aeb03090ac65df02ecda8a4988d65b2f48e1116ba"
  },
  {
   "path": "src/styles/public-page.css",
   "sha256": "00f970e9234229c3d5ba7dea556485c3e6696002505cf1b63003f924f206f92e"
  }
 ],
 "patches": [
  {
   "file": "src/styles/foundation.css",
   "edits": [
    {
     "desc": "Lift the surface ramp",
     "find": "    --lc-canvas: #08090C;\n    --lc-well: #050608;\n    --lc-panel: #0E1118;\n    --lc-card: #10131A;\n    --lc-raised: #171B25;\n    --lc-raised-hover: #1D2230;\n    --lc-overlay: #1B202B;",
     "replace": "    --lc-canvas: #10141D;\n    --lc-well: #0B0E15;\n    --lc-panel: #151A25;\n    --lc-card: #181E2A;\n    --lc-raised: #1F2634;\n    --lc-raised-hover: #262E3E;\n    --lc-overlay: #242B3A;"
    },
    {
     "desc": "Glass follows the new canvas",
     "find": "    --lc-glass: rgba(8, 9, 12, 0.72);",
     "replace": "    --lc-glass: rgba(16, 20, 29, 0.72);"
    },
    {
     "desc": "Faintest ink readable on inputs",
     "find": "    --lc-ink-4: #5A6272;",
     "replace": "    --lc-ink-4: #737C8D;"
    },
    {
     "desc": "Button azure that passes 4.5:1 with white",
     "find": "    --lc-on-accent: #FFFFFF;\n    --lc-azure-hover: #3B8BFF;",
     "replace": "    --lc-on-accent: #FFFFFF;\n    --lc-azure-button: #2571E0;\n    --lc-azure-hover: #1F6AD4;"
    }
   ]
  },
  {
   "file": "src/styles/ui.css",
   "edits": [
    {
     "desc": "Primary button uses the accessible azure",
     "find": ".ui-btn--primary {\n    background: var(--azure);",
     "replace": ".ui-btn--primary {\n    background: var(--lc-azure-button);"
    },
    {
     "desc": "Optional label at readable contrast",
     "find": ".ui-field__optional {\n    color: var(--lc-ink-4);",
     "replace": ".ui-field__optional {\n    color: var(--lc-ink-3);"
    }
   ]
  },
  {
   "file": "index.html",
   "edits": [
    {
     "desc": "Tile colour matches the canvas",
     "find": "<meta name=\"msapplication-TileColor\" content=\"#08090C\">",
     "replace": "<meta name=\"msapplication-TileColor\" content=\"#10141D\">"
    },
    {
     "desc": "Page background matches the canvas",
     "find": "    html, body {\n      background: #08090C;",
     "replace": "    html, body {\n      background: #10141D;"
    },
    {
     "desc": "Root background matches the canvas",
     "find": "    #root {\n      background: #08090C;",
     "replace": "    #root {\n      background: #10141D;"
    },
    {
     "desc": "Boot screen matches the canvas",
     "find": "      inset: 0;\n      background: #08090C;",
     "replace": "      inset: 0;\n      background: #10141D;"
    }
   ]
  }
 ],
 "retires": [],
 "backupSuffix": ".backup-redesign"
}
const BACKUP = SPEC.backupSuffix

let failed = false
const fail = (msg) => { console.error(`[FAIL] ${msg}`); failed = true }
const sha = (buf) => crypto.createHash('sha256').update(buf).digest('hex')
const toCrlf = (text) => text.replace(/\r?\n/g, '\r\n')
const count = (haystack, needle) => (needle === '' ? 0 : haystack.split(needle).length - 1)

for (const rel of SPEC.new) {
    if (fs.existsSync(path.join(REPO, rel))) fail(`Already exists: ${rel}`)
    if (!fs.existsSync(path.join(HERE, 'files', rel))) fail(`Missing in payload: ${rel}`)
}

for (const item of SPEC.replace) {
    const full = path.join(REPO, item.path)
    if (!fs.existsSync(full)) { fail(`Missing: ${item.path}`); continue }
    const current = fs.readFileSync(full)
    if (sha(current) !== item.sha256) fail(`${item.path} differs from the onboarding version (edited locally, or already replaced). Not overwriting.`)
    if (fs.existsSync(`${full}${BACKUP}`)) fail(`Backup already exists: ${item.path}${BACKUP}`)
}

const fileChanges = new Map()
for (const group of SPEC.patches) {
    const full = path.join(REPO, group.file)
    if (!fs.existsSync(full)) { fail(`Missing: ${group.file}`); continue }
    if (fs.existsSync(`${full}${BACKUP}`)) fail(`Backup already exists: ${group.file}${BACKUP}`)
    const original = fs.readFileSync(full, 'utf8')
    let content = original
    let ok = true
    for (const edit of group.edits) {
        const lf = count(content, edit.find)
        const crlf = count(content, toCrlf(edit.find))
        let find = edit.find
        let replace = edit.replace
        if (lf !== 1 && crlf === 1) { find = toCrlf(edit.find); replace = toCrlf(edit.replace) }
        else if (lf !== 1) { fail(`${group.file}: ${lf || crlf} matches for "${edit.desc}" (expected 1)`); ok = false; break }
        content = content.replace(find, () => replace)
    }
    if (ok) fileChanges.set(full, { original, modified: content, edits: group.edits })
}

if (failed) { console.error('\n[ABORT] Validation failed. No files written.'); process.exit(1) }

for (const rel of SPEC.new) {
    fs.copyFileSync(path.join(HERE, 'files', rel), path.join(REPO, rel))
    console.log(`[NEW] ${rel}`)
}
for (const item of SPEC.replace) {
    const full = path.join(REPO, item.path)
    fs.copyFileSync(full, `${full}${BACKUP}`)
    fs.copyFileSync(path.join(HERE, 'files', item.path), full)
    console.log(`[REPLACE] ${item.path}`)
}
for (const [full, change] of fileChanges) {
    fs.writeFileSync(`${full}${BACKUP}`, change.original)
    fs.writeFileSync(full, change.modified)
    console.log(`[EDIT] ${path.relative(REPO, full)}`)
    for (const e of change.edits) console.log(`     - ${e.desc}`)
}

console.log('\n[DONE]')
