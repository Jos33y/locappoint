import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const SPEC = {
  "name": "inbox-bell",
  "backup": ".backup-inbox",
  "prefixes": [
    "lc-ibx"
  ],
  "newFiles": [
    "src/services/inbox.js",
    "src/components/inbox/InboxContext.jsx",
    "src/components/inbox/InboxBell.jsx",
    "src/components/inbox/InboxPage.jsx",
    "src/styles/app/inbox.css",
    "tests/suites/notifications.mjs"
  ],
  "replaceFiles": [
    {
      "file": "src/components/business/BusinessShell.jsx",
      "sha": "adf3595c78b920ef4498eeea932179ef47b9a5b80fdbc267171116309b96b18d"
    },
    {
      "file": "src/pages/client/ClientLayout.jsx",
      "sha": "878aabc36a7df774f91b673702b790478d34a51ca8c8d41e073d5741a35796d8"
    }
  ],
  "patches": [
    {
      "file": "src/services/business.js",
      "find": "export const loadBlocks = async",
      "replace": "export const loadBooking = async (businessId, id) => {\n    const { data, error } = await supabase\n        .from('appointments')\n        .select('id, staff_id, service_id, appointment_date, appointment_time, duration_minutes, status, source, client_name, client_phone, client_email, notes, price, cancelled_by, rescheduled_from, services(service_name, price)')\n        .eq('business_id', businessId)\n        .eq('id', id)\n        .maybeSingle()\n    if (error) throw error\n    return data\n}\n\nexport const loadBlocks = async"
    },
    {
      "file": "src/BookingApp.jsx",
      "find": "const Planned = lazy(() => import('./pages/business/Planned'))\n",
      "replace": "const Planned = lazy(() => import('./pages/business/Planned'))\nconst InboxPage = lazy(() => import('./components/inbox/InboxPage'))\n"
    },
    {
      "file": "src/BookingApp.jsx",
      "find": "<Route path=\"notifications\" element={inShell(<Planned section=\"notifications\" />)} />",
      "replace": "<Route path=\"notifications\" element={inShell(<InboxPage audience=\"business\" />)} />"
    },
    {
      "file": "src/BookingApp.jsx",
      "find": "                        <Route path=\"profile\" element={inShell(<ClientProfile />)} />\n",
      "replace": "                        <Route path=\"profile\" element={inShell(<ClientProfile />)} />\n                        <Route path=\"notifications\" element={inShell(<InboxPage audience=\"client\" />)} />\n"
    },
    {
      "file": "src/pages/client/MyAppointments.jsx",
      "find": "import { useState } from 'react'\n",
      "replace": "import { useEffect, useState } from 'react'\nimport { useSearchParams } from 'react-router-dom'\n"
    },
    {
      "file": "src/pages/client/MyAppointments.jsx",
      "find": "    const [view, setView] = useState('upcoming')\n",
      "replace": "    const [view, setView] = useState('upcoming')\n    const [params, setParams] = useSearchParams()\n    const [focused, setFocused] = useState(null)\n    const linked = params.get('booking')\n\n    // Links from emails and notifications carry ?booking=<id>: show its tab and bring it into view.\n    useEffect(() => {\n        if (!linked || state.status !== 'ready') return\n        const tab = ['upcoming', 'past', 'cancelled'].find((key) => groups[key].some((b) => b.id === linked))\n        if (tab) {\n            setView(tab)\n            setFocused(linked)\n        }\n        setParams((prev) => { const next = new URLSearchParams(prev); next.delete('booking'); return next }, { replace: true })\n    }, [linked, state.status, groups, setParams])\n\n    useEffect(() => {\n        if (focused) document.getElementById(`booking-${focused}`)?.scrollIntoView({ block: 'center', behavior: 'smooth' })\n    }, [focused, view])\n"
    },
    {
      "file": "src/pages/client/MyAppointments.jsx",
      "find": "<UpcomingBooking key={b.id} booking={b} lead={i === 0} onCancel={askCancel} onMove={askMove} />",
      "replace": "<UpcomingBooking key={b.id} booking={b} lead={i === 0} focused={b.id === focused} onCancel={askCancel} onMove={askMove} />"
    },
    {
      "file": "src/pages/client/MyAppointments.jsx",
      "find": "{groups[view].map((b) => <PastBooking key={b.id} booking={b} />)}",
      "replace": "{groups[view].map((b) => <PastBooking key={b.id} booking={b} focused={b.id === focused} />)}"
    },
    {
      "file": "src/components/client/bookings/UpcomingBooking.jsx",
      "find": "export const UpcomingBooking = ({ booking, lead = false, onCancel, onMove }) => {",
      "replace": "export const UpcomingBooking = ({ booking, lead = false, focused = false, onCancel, onMove }) => {"
    },
    {
      "file": "src/components/client/bookings/UpcomingBooking.jsx",
      "find": "        <article className={`lc-cl-bk${lead ? ' is-lead' : ''}`}>",
      "replace": "        <article id={`booking-${booking.id}`} className={`lc-cl-bk${lead ? ' is-lead' : ''}${focused ? ' is-focus' : ''}`}>"
    },
    {
      "file": "src/components/client/bookings/PastBooking.jsx",
      "find": "export const PastBooking = ({ booking }) => {",
      "replace": "export const PastBooking = ({ booking, focused = false }) => {"
    },
    {
      "file": "src/components/client/bookings/PastBooking.jsx",
      "find": "        <li className=\"lc-cl-past\">",
      "replace": "        <li id={`booking-${booking.id}`} className={`lc-cl-past${focused ? ' is-focus' : ''}`}>"
    },
    {
      "file": "src/styles/client/client-bookings.css",
      "find": ".lc-cl-bk {\n    display: flex;\n    flex-direction: column;\n    gap: var(--space-3);\n}\n",
      "replace": ".lc-cl-bk {\n    display: flex;\n    flex-direction: column;\n    gap: var(--space-3);\n    border-radius: var(--lc-r-xl);\n    scroll-margin: var(--space-20);\n}\n\n.lc-cl-bk.is-focus,\n.lc-cl-past.is-focus {\n    outline: 2px solid var(--lc-info);\n    outline-offset: var(--space-2);\n}\n\n.lc-cl-past.is-focus {\n    outline-offset: -2px;\n    border-radius: var(--lc-r-lg);\n}\n"
    },
    {
      "file": "tests/harness/fakeSupabase.js",
      "find": "  support_tickets: [],\n}",
      "replace": "  support_tickets: [],\n  inbox: [\n    { id: 'i1', user_id: 'u1', audience: 'business', kind: 'booking_new', appointment_id: 'p1', business_id: 'b1', read_at: null, created_at: new Date(Date.now() - 5 * 60000).toISOString(), payload: { client_name: 'Jameson', service_name: 'Haircut', duration_minutes: 30, price: 18, country: 'PT', date: key, time: '10:00' } },\n    { id: 'i2', user_id: 'u1', audience: 'business', kind: 'booking_request', appointment_id: 'p2', business_id: 'b1', read_at: null, created_at: new Date(Date.now() - 50 * 60000).toISOString(), payload: { client_name: 'Rui', service_name: 'Beard trim', duration_minutes: 20, price: 12, country: 'PT', date: key, time: '15:00', moved_from: `${key}T11:30` } },\n    { id: 'i3', user_id: 'u1', audience: 'business', kind: 'booking_cancelled', appointment_id: null, business_id: 'b1', read_at: '2026-09-01T10:00:00Z', created_at: new Date(Date.now() - 30 * 3600000).toISOString(), payload: { client_name: 'Ana Maria dos Santos Ferreira', service_name: 'Haircut and beard trim with hot towel', duration_minutes: 75, price: 30, country: 'PT', date: key, time: '17:45' } },\n  ],\n}"
    },
    {
      "file": "tests/harness/main.jsx",
      "find": "import SettingsPage from '@src/pages/business/SettingsPage'\n",
      "replace": "import SettingsPage from '@src/pages/business/SettingsPage'\nimport InboxPage from '@src/components/inbox/InboxPage'\n"
    },
    {
      "file": "tests/harness/main.jsx",
      "find": "if (params.get('nohours') === '1') DATA.availability.length = 0\n",
      "replace": "if (params.get('nohours') === '1') DATA.availability.length = 0\nif (params.get('noinbox') === '1') DATA.inbox.length = 0\n"
    },
    {
      "file": "tests/harness/main.jsx",
      "find": "          <Route path=\"notifications\" element={<Planned section=\"notifications\" />} />",
      "replace": "          <Route path=\"notifications\" element={<InboxPage audience=\"business\" />} />"
    },
    {
      "file": "tests/run.mjs",
      "find": "import emails from './suites/emails.mjs'\n",
      "replace": "import emails from './suites/emails.mjs'\nimport notifications from './suites/notifications.mjs'\n"
    },
    {
      "file": "tests/run.mjs",
      "find": "['settings', settings]] }",
      "replace": "['settings', settings], ['notifications', notifications]] }"
    },
    {
      "file": "src/styles/client/client-shell.css",
      "find": "    .lc-cl-shell .lc-cl-topacts { display: none; }",
      "replace": "    .lc-cl-shell .lc-cl-me { display: none; }"
    }
  ],
  "retires": []
}

const here = path.dirname(fileURLToPath(import.meta.url))
const root = process.cwd()
const check = process.argv.includes('--check')
const problems = []
const plan = []

const abs = (rel) => path.join(root, ...rel.split('/'))
const source = (rel) => path.join(here, 'files', ...rel.split('/'))
const read = (p) => fs.readFileSync(p, 'utf8')
const eolOf = (text) => (text.includes('\r\n') ? '\r\n' : '\n')
const toEol = (text, eol) => text.replace(/\r\n/g, '\n').replace(/\n/g, eol)
const sha = (text) => crypto.createHash('sha256').update(text.replace(/\r\n/g, '\n')).digest('hex')
const count = (hay, needle) => (needle ? hay.split(needle).length - 1 : 0)

const pkg = JSON.parse(read(abs('package.json')))
if (pkg.name !== 'locappoint') {
    console.error('  [ABORT] This is not the locappoint repo.')
    process.exit(1)
}

for (const rel of SPEC.newFiles) {
    if (fs.existsSync(abs(rel))) problems.push(`${rel} already exists (patch already applied?)`)
    else if (!fs.existsSync(source(rel))) problems.push(`payload is missing ${rel}`)
    else plan.push(['NEW', rel])
}

for (const { file, sha: expected } of SPEC.replaceFiles) {
    if (!fs.existsSync(abs(file))) { problems.push(`${file} is missing`); continue }
    if (sha(read(abs(file))) !== expected) { problems.push(`${file} changed since this patch was built (or it is already applied)`); continue }
    plan.push(['REPLACE', file])
}

const srcFiles = () => {
    const out = []
    const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const full = path.join(dir, entry.name)
            if (entry.isDirectory()) { if (entry.name !== 'node_modules') walk(full) }
            else if (/\.(jsx?|css)$/.test(entry.name)) out.push(full)
        }
    }
    walk(abs('src'))
    return out
}

for (const prefix of SPEC.prefixes || []) {
    const owners = srcFiles().filter((full) => read(full).includes(prefix)).map((full) => path.relative(root, full))
    if (owners.length) problems.push(`class prefix ${prefix} is already used in ${owners.join(', ')}`)
}

const edits = new Map()
for (const p of SPEC.patches) {
    if (!fs.existsSync(abs(p.file))) { problems.push(`${p.file} is missing`); continue }
    if (!edits.has(p.file)) edits.set(p.file, read(abs(p.file)))
    const current = edits.get(p.file)
    const eol = eolOf(current)
    const find = toEol(p.find, eol)
    const hits = count(current, find)
    if (hits !== 1) { problems.push(`${p.file}: anchor matched ${hits} times, expected 1: ${JSON.stringify(p.find.slice(0, 60))}`); continue }
    edits.set(p.file, current.replace(find, () => toEol(p.replace, eol)))
}
for (const file of edits.keys()) plan.push(['EDIT', file])

for (const rel of SPEC.retires) {
    if (!fs.existsSync(abs(rel))) { problems.push(`${rel} is missing`); continue }
    const base = path.basename(rel)
    const stem = /\.(jsx?)$/.test(base) ? base.replace(/\.(jsx?)$/, '') : base
    const pattern = new RegExp(`[\\/'"]${stem.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\.jsx?)?['"]`)
    const planned = (full) => {
        const key = path.relative(root, full).split(path.sep).join('/')
        if (SPEC.replaceFiles.some((f) => f.file === key)) return read(source(key))
        return edits.has(key) ? edits.get(key) : read(full)
    }
    const users = srcFiles().filter((full) => full !== abs(rel) && pattern.test(planned(full))).map((full) => path.relative(root, full))
    if (users.length) problems.push(`${rel} is still imported by ${users.join(', ')}`)
    else plan.push(['RETIRE', rel])
}

if (problems.length) {
    console.error('  [ABORT] Nothing was written:')
    for (const p of problems) console.error(`    ${p}`)
    process.exit(1)
}

if (check) {
    for (const [kind, rel] of plan) console.log(`  [${kind}] ${rel}`)
    console.log('  Checks passed.')
    process.exit(0)
}

for (const [kind, rel] of plan) {
    const target = abs(rel)
    if (kind === 'NEW') {
        fs.mkdirSync(path.dirname(target), { recursive: true })
        fs.writeFileSync(target, read(source(rel)))
    } else if (kind === 'REPLACE') {
        const eol = eolOf(read(target))
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, toEol(read(source(rel)), eol))
    } else if (kind === 'EDIT') {
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, edits.get(rel))
    } else if (kind === 'RETIRE') {
        fs.renameSync(target, target + '.mistake')
    }
    console.log(`  [${kind}] ${rel}`)
}
console.log('  Patch applied.')
