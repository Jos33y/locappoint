import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const SPEC = {
  "name": "payments",
  "backup": ".backup-payments",
  "prefixes": [],
  "newFiles": [
    "src/pages/business/PaymentsPage.jsx"
  ],
  "replaceFiles": [
    {
      "file": "supabase/functions/payouts/providers.ts",
      "sha": "49cba34eb6f38eae79e3c3fb64444602f15784812f7d3cd44c844cd44485c029"
    },
    {
      "file": "supabase/functions/payouts/index.ts",
      "sha": "f59cab93e9b1f091c0a2bd1bab3413cd0fa46cb8edcb8579faf0e45104b20683"
    },
    {
      "file": "src/styles/business/payouts.css",
      "sha": "8be197162cd4c2ba4070f82028bc269d3d20d982cfa2e901984fefa677618c4e"
    },
    {
      "file": "src/pages/app/PayoutsDone.jsx",
      "sha": "a889e69131b2fc4059c43b88dacffe87be0f7b3e7b53d911450963f64a3149b8"
    },
    {
      "file": "tests/suites/payouts.mjs",
      "sha": "6d3a0a3ad2cfaaa2068eaade90d25609f9b991c131f85bbcec4ae9305a5d3e6d"
    },
    {
      "file": "src/components/business/HubNav.jsx",
      "sha": "d2713e2bae1bafdfecc0b5b82a3c32c27bd73f4c073c43d0d4593b05de146a31"
    }
  ],
  "patches": [
    {
      "file": "src/pages/business/SettingsPage.jsx",
      "find": "import { PayoutsSection } from '../../components/business/PayoutsSection'\n",
      "replace": ""
    },
    {
      "file": "src/pages/business/SettingsPage.jsx",
      "find": "    const { notify, isOwner } = useWorkspace()",
      "replace": "    const { notify } = useWorkspace()"
    },
    {
      "file": "src/pages/business/SettingsPage.jsx",
      "find": "                {isOwner && <PayoutsSection notify={notify} />}\n\n",
      "replace": ""
    },
    {
      "file": "src/pages/business/SettingsPage.jsx",
      "find": "<p className=\"biz-page__sub\">Your account, payouts, sign-in and security.</p>",
      "replace": "<p className=\"biz-page__sub\">Your account, sign-in and security.</p>"
    },
    {
      "file": "src/BookingApp.jsx",
      "find": "const SettingsPage = lazy(() => import('./pages/business/SettingsPage'))\n",
      "replace": "const SettingsPage = lazy(() => import('./pages/business/SettingsPage'))\nconst PaymentsPage = lazy(() => import('./pages/business/PaymentsPage'))\n"
    },
    {
      "file": "src/BookingApp.jsx",
      "find": "                        <Route path=\"settings\" element={inShell(<SettingsPage />)} />\n",
      "replace": "                        <Route path=\"settings\" element={inShell(<SettingsPage />)} />\n                        <Route path=\"payments\" element={inShell(<PaymentsPage />)} />\n"
    },
    {
      "file": "src/components/business/nav.js",
      "find": "Store, Sun, Users, UsersRound } from 'lucide-react'",
      "replace": "Store, Sun, Users, UsersRound, Wallet } from 'lucide-react'"
    },
    {
      "file": "src/components/business/nav.js",
      "find": "            { to: '/portal/team', label: 'Team', name: 'Team', icon: UsersRound, keywords: ['staff', 'barbers', 'people', 'login'] },\n",
      "replace": "            { to: '/portal/team', label: 'Team', name: 'Team', icon: UsersRound, keywords: ['staff', 'barbers', 'people', 'login'] },\n            { to: '/portal/payments', label: 'Payments', name: 'Payments', icon: Wallet, keywords: ['payouts', 'getting paid', 'bank', 'iban', 'stripe', 'paystack', 'money'] },\n"
    },
    {
      "file": "src/components/business/nav.js",
      "find": "body: 'Your page, services, hours and team, in one place. Clients book from what you set here.'",
      "replace": "body: 'Your page, services, hours, team and payments, in one place. Clients book from what you set here.'"
    },
    {
      "file": "src/styles/business/hubnav.css",
      "find": "@media (pointer: coarse) {\n    .biz-hubnav__tab {\n        min-height: 44px;\n    }\n}\n",
      "replace": "@media (pointer: coarse) {\n    .biz-hubnav__tab {\n        min-height: 44px;\n    }\n}\n\n/* Five tabs on a narrow phone: scroll sideways instead of cutting the labels. */\n@media (max-width: 639px) {\n    .biz-hubnav__track {\n        overflow-x: auto;\n        scrollbar-width: none;\n        overscroll-behavior-x: contain;\n    }\n\n    .biz-hubnav__track::-webkit-scrollbar {\n        display: none;\n    }\n\n    .biz-hubnav__tab {\n        flex: 1 0 auto;\n        padding: 0 var(--space-3);\n    }\n}\n"
    },
    {
      "file": "tests/harness/fakeSupabase.js",
      "find": "return { data: { url: `/?path=${encodeURIComponent('/portal/settings')}&payouts=return&payoutstate=active` }, error: null }",
      "replace": "return { data: { url: `/?path=${encodeURIComponent('/portal/payments')}&payouts=return&payoutstate=active` }, error: null }"
    }
  ],
  "retires": [
    "src/components/business/PayoutsSection.jsx"
  ]
}

const here = path.dirname(fileURLToPath(import.meta.url))
const root = process.cwd()
const check = process.argv.includes('--check')
const problems = []
const plan = []

const abs = (rel) => path.join(root, ...rel.split('/'))
const source = (rel) => path.join(here, 'files', ...rel.split('/'))
const read = (p) => fs.readFileSync(p, 'utf8')
const eolOf = (text) => (text.includes('\r\n') ? '\r\n' : '\n')
const toEol = (text, eol) => text.replace(/\r\n/g, '\n').replace(/\n/g, eol)
const sha = (text) => crypto.createHash('sha256').update(text.replace(/\r\n/g, '\n')).digest('hex')
const count = (hay, needle) => (needle ? hay.split(needle).length - 1 : 0)

const pkg = JSON.parse(read(abs('package.json')))
if (pkg.name !== 'locappoint') {
    console.error('  [ABORT] This is not the locappoint repo.')
    process.exit(1)
}

for (const rel of SPEC.newFiles) {
    if (fs.existsSync(abs(rel))) problems.push(`${rel} already exists (patch already applied?)`)
    else if (!fs.existsSync(source(rel))) problems.push(`payload is missing ${rel}`)
    else plan.push(['NEW', rel])
}

for (const { file, sha: expected } of SPEC.replaceFiles) {
    if (!fs.existsSync(abs(file))) { problems.push(`${file} is missing`); continue }
    if (sha(read(abs(file))) !== expected) { problems.push(`${file} changed since this patch was built (or it is already applied)`); continue }
    plan.push(['REPLACE', file])
}

const srcFiles = () => {
    const out = []
    const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const full = path.join(dir, entry.name)
            if (entry.isDirectory()) { if (entry.name !== 'node_modules') walk(full) }
            else if (/\.(jsx?|css)$/.test(entry.name)) out.push(full)
        }
    }
    walk(abs('src'))
    return out
}

for (const prefix of SPEC.prefixes || []) {
    const owners = srcFiles().filter((full) => read(full).includes(prefix)).map((full) => path.relative(root, full))
    if (owners.length) problems.push(`class prefix ${prefix} is already used in ${owners.join(', ')}`)
}

const edits = new Map()
for (const p of SPEC.patches) {
    if (!fs.existsSync(abs(p.file))) { problems.push(`${p.file} is missing`); continue }
    if (!edits.has(p.file)) edits.set(p.file, read(abs(p.file)))
    const current = edits.get(p.file)
    const eol = eolOf(current)
    const find = toEol(p.find, eol)
    const hits = count(current, find)
    if (hits !== 1) { problems.push(`${p.file}: anchor matched ${hits} times, expected 1: ${JSON.stringify(p.find.slice(0, 60))}`); continue }
    edits.set(p.file, current.replace(find, () => toEol(p.replace, eol)))
}
for (const file of edits.keys()) plan.push(['EDIT', file])

for (const rel of SPEC.retires) {
    if (!fs.existsSync(abs(rel))) { problems.push(`${rel} is missing`); continue }
    const base = path.basename(rel)
    const stem = /\.(jsx?)$/.test(base) ? base.replace(/\.(jsx?)$/, '') : base
    const pattern = new RegExp(`[\\/'"]${stem.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\.jsx?)?['"]`)
    const planned = (full) => {
        const key = path.relative(root, full).split(path.sep).join('/')
        if (SPEC.replaceFiles.some((f) => f.file === key)) return read(source(key))
        return edits.has(key) ? edits.get(key) : read(full)
    }
    const users = srcFiles().filter((full) => full !== abs(rel) && pattern.test(planned(full))).map((full) => path.relative(root, full))
    if (users.length) problems.push(`${rel} is still imported by ${users.join(', ')}`)
    else plan.push(['RETIRE', rel])
}

if (problems.length) {
    console.error('  [ABORT] Nothing was written:')
    for (const p of problems) console.error(`    ${p}`)
    process.exit(1)
}

if (check) {
    for (const [kind, rel] of plan) console.log(`  [${kind}] ${rel}`)
    console.log('  Checks passed.')
    process.exit(0)
}

for (const [kind, rel] of plan) {
    const target = abs(rel)
    if (kind === 'NEW') {
        fs.mkdirSync(path.dirname(target), { recursive: true })
        fs.copyFileSync(source(rel), target)
    } else if (kind === 'REPLACE') {
        const eol = eolOf(read(target))
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, toEol(read(source(rel)), eol))
    } else if (kind === 'EDIT') {
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, edits.get(rel))
    } else if (kind === 'RETIRE') {
        fs.renameSync(target, target + '.mistake')
    }
    console.log(`  [${kind}] ${rel}`)
}
console.log('  Patch applied.')
