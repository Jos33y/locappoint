import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const SPEC = {
  "name": "copy",
  "backup": ".backup-copy",
  "prefixes": [
    "pr__band"
  ],
  "newFiles": [
    "tests/suites/pricing.mjs"
  ],
  "replaceFiles": [
    {
      "file": "src/pages/app/home/Pricing.jsx",
      "sha": "5298f2eb46b051048a80e70df998609b51a956411ae8da0ab9841512c06ae9f6"
    },
    {
      "file": "src/pages/app/home/Pricing.css",
      "sha": "65b153b9ed579f91293f63b51b9b9f78a526def64b73f5e26dedda3b38358cb6"
    }
  ],
  "patches": [
    {
      "file": "src/pages/app/home/Hero.jsx",
      "find": "fill your calendar. Free for the first twelve months.",
      "replace": "fill your calendar. Free during the beta."
    },
    {
      "file": "src/pages/app/home/Hero.jsx",
      "find": "                                <div className=\"loca-hero__metric-num\">12 mo</div>\n                                <div className=\"loca-hero__metric-label\">Free trial</div>",
      "replace": "                                <div className=\"loca-hero__metric-num\">€0</div>\n                                <div className=\"loca-hero__metric-label\">During the beta</div>"
    },
    {
      "file": "src/pages/app/home/Hero.jsx",
      "find": "                                <div className=\"loca-hero__metric-num\">€19<span className=\"loca-hero__metric-sub\">/mo</span></div>\n                                <div className=\"loca-hero__metric-label\">Flat, after</div>",
      "replace": "                                <div className=\"loca-hero__metric-num\">10<span className=\"loca-hero__metric-sub\">min</span></div>\n                                <div className=\"loca-hero__metric-label\">To go live</div>"
    },
    {
      "file": "src/pages/app/home/Hero.jsx",
      "find": "                                <div className=\"loca-hero__metric-num\">0%</div>\n                                <div className=\"loca-hero__metric-label\">Commission</div>",
      "replace": "                                <div className=\"loca-hero__metric-num\">2</div>\n                                <div className=\"loca-hero__metric-label\">Reminders per booking</div>"
    },
    {
      "file": "src/pages/app/home/Cta.jsx",
      "find": "First cohort is open. Twelve months free. Nineteen euros a month flat after. Set up in ten minutes.",
      "replace": "First cohort is open. Free during the beta. Set up in ten minutes."
    },
    {
      "file": "src/components/common/Appfooter.jsx",
      "find": "in Porto, Lisbon, and Lagos. Twelve months free, then nineteen euros a month flat.",
      "replace": "in Porto, Lisbon, and Lagos. Free during the beta."
    },
    {
      "file": "src/components/common/Appfooter.jsx",
      "find": "<li><a href=\"tel:+351912345678\">+351 912 345 678</a></li>",
      "replace": "<li><a href=\"tel:+351934695914\">+351 934 695 914</a></li>"
    },
    {
      "file": "src/pages/app/Contact.jsx",
      "find": "const WHATSAPP_URL = 'https://wa.me/351912345678?text='",
      "replace": "const WHATSAPP_URL = 'https://wa.me/351934695914?text='"
    },
    {
      "file": "src/pages/app/Contact.jsx",
      "find": "<a href=\"tel:+351912345678\" className=\"info-card__value\">+351 912 345 678</a>\n                                        <div className=\"info-card__note\">Mon to Fri, 09:00 to 18:00 WET</div>",
      "replace": "<a href=\"tel:+351934695914\" className=\"info-card__value\">+351 934 695 914</a>\n                                        <div className=\"info-card__note\">Mon to Fri, 09:00 to 18:00 Portugal time</div>"
    },
    {
      "file": "src/pages/app/auth/AuthShell.jsx",
      "find": "brandSub = 'Local businesses in Porto, Lisbon, and Lagos. Free for the first twelve months.',",
      "replace": "brandSub = 'Local businesses in Porto, Lisbon, and Lagos. Free during the beta.',"
    },
    {
      "file": "src/pages/app/auth/AuthPage.jsx",
      "find": "'Local businesses in Porto, Lisbon, and Lagos. Free for the first twelve months.']",
      "replace": "'Local businesses in Porto, Lisbon, and Lagos. Free during the beta.']"
    },
    {
      "file": "src/pages/business/Setup.jsx",
      "find": "<span>Free for your first 12 months.</span>",
      "replace": "<span>Free during the beta.</span>"
    },
    {
      "file": "src/pages/business/Help.jsx",
      "find": "a: 'Your first twelve months are free. After that it is nineteen euros a month, flat, with no commission on your bookings.' },",
      "replace": "a: 'Nothing during the beta. When online payments arrive, a small fee applies only to bookings clients pay for on Locappoint, and your first month of it is free. Walk-ins and bookings you add yourself are always free. We tell you at least 30 days before any fee applies, and your weekly statement in Insights shows what it would be.' },"
    },
    {
      "file": "src/pages/app/Businesses.jsx",
      "find": "<span>Free for the first twelve months. Set up takes about ten minutes.</span>",
      "replace": "<span>Free during the beta. Set up takes about ten minutes.</span>"
    },
    {
      "file": "src/pages/app/Businesses.jsx",
      "find": "<p>Get your own booking page on Locappoint. Free for the first twelve months.</p>",
      "replace": "<p>Get your own booking page on Locappoint. Free during the beta.</p>"
    },
    {
      "file": "src/pages/app/AppDownload.jsx",
      "find": "'The app is free to download. Clients book for free. Businesses are on the same plan as the website: twelve months free, then nineteen euros a month, flat.'",
      "replace": "'The app is free to download. Clients book for free, and Locappoint is free for businesses during the beta.'"
    },
    {
      "file": "src/pages/app/AppDownload.jsx",
      "find": "<p>Clients book free. Businesses get twelve months free.</p>",
      "replace": "<p>Clients book free. Businesses are free during the beta.</p>"
    },
    {
      "file": "src/StatusApp.jsx",
      "find": "Pricing locked: 12 months free, then €19 a month</div>",
      "replace": "Pricing set: free during the beta, fees only on bookings paid online</div>"
    },
    {
      "file": "src/components/landing/WaitlistModal.jsx",
      "find": "t('waitlistModal.subtitle1', 'First 100 Porto businesses get 12 months free, then €19/mo. No commission.')",
      "replace": "t('waitlistModal.subtitle1', 'Free for businesses during the beta. Be first to hear when we open near you.')"
    },
    {
      "file": "src/pages/landing/WaitlistCTASection.jsx",
      "find": "t('cta.eyebrow', 'FIRST 100 LISBON BUSINESSES \\u00B7 12 MONTHS FREE \\u00B7 \\u20AC19/MO AFTER')",
      "replace": "t('cta.eyebrow', 'PORTO FIRST \\u00B7 FREE DURING THE BETA')"
    },
    {
      "file": "src/pages/landing/WaitlistCTASection.jsx",
      "find": "t('cta.trust1', 'Free for 12 months for first 100 Porto businesses')",
      "replace": "t('cta.trust1', 'Free for businesses during the beta')"
    },
    {
      "file": "src/pages/landing/WaitlistCTASection.jsx",
      "find": "t('cta.trust2', 'No credit card, no commission')",
      "replace": "t('cta.trust2', 'No credit card needed')"
    },
    {
      "file": "src/pages/landing/Faq.jsx",
      "find": "answer: 'The first 100 businesses in Porto get 12 months free. After that, it is 19 euro per month flat. No commission on bookings, ever.'",
      "replace": "answer: 'Nothing during the beta. When online payments arrive, clients pay a small service fee and businesses a small fee on bookings paid through Locappoint, and the first month of it is free. Walk-ins are always free, and there is no subscription.'"
    },
    {
      "file": "src/pages/app/Partnership.jsx",
      "find": "direct input on features, founder-tier pricing locked for life, and a co-marketing slot",
      "replace": "direct input on features, early access to what we build next, and a co-marketing slot"
    },
    {
      "file": "src/pages/app/legal/Terms.jsx",
      "find": "                <p><strong>Cohort 1 (current).</strong> Free for the first twelve (12) months from account creation, for the first 100 businesses in our launch cities (Porto, Lisbon, Lagos).</p>\n                <p><strong>After the free period.</strong> Nineteen euros (€19) per month per business, flat. We do not charge commission on bookings. Payment is processed monthly in advance. We will tell you before billing starts and confirm whether VAT applies.</p>\n                <p><strong>Cancellation.</strong> You can cancel your subscription at any time. Cancellation takes effect at the end of the current billing period. No refunds for partial months unless required by law.</p>\n                <p><strong>Price changes.</strong> We will notify you at least 30 days before any price changes take effect. You can cancel before the new price applies.</p>",
      "replace": "                <p><strong>During the beta.</strong> Locappoint is free for businesses. There is no subscription and nothing to pay.</p>\n                <p><strong>When online payments arrive.</strong> Clients will be able to pay for bookings on Locappoint. From then on, clients pay a small service fee on bookings they pay online, and businesses pay a small fee on each booking a client pays through Locappoint. The first month after online payments start for your account carries no business fee. Walk-ins and bookings you add yourself never carry a fee.</p>\n                <p><strong>Notice.</strong> We will tell you the exact fees, and whether VAT applies, at least 30 days before any fee applies to your account. You can stop using Locappoint before then at no cost.</p>\n                <p><strong>Weekly statement.</strong> Each week we send you a statement of the bookings made on Locappoint. During the beta it shows what a fee would have been and that nothing is owed. It is not an invoice.</p>\n                <p><strong>Fee changes.</strong> We will tell you at least 30 days before any fee changes take effect. You can stop using Locappoint before the new fee applies.</p>"
    },
    {
      "file": "tests/run.mjs",
      "find": "import cities from './suites/cities.mjs'\n",
      "replace": "import cities from './suites/cities.mjs'\nimport pricing from './suites/pricing.mjs'\n"
    },
    {
      "file": "tests/run.mjs",
      "find": "['cities', cities]] }",
      "replace": "['cities', cities], ['pricing', pricing]] }"
    },
    {
      "file": "tests/suites/cities.mjs",
      "find": "    /Lisbon time/,\n",
      "replace": "    /Lisbon time/,\n    /LISBON BUSINESSES|FIRST \\d+ LISBON/,\n"
    }
  ],
  "retires": []
}

const here = path.dirname(fileURLToPath(import.meta.url))
const root = process.cwd()
const check = process.argv.includes('--check')
const problems = []
const plan = []

const abs = (rel) => path.join(root, ...rel.split('/'))
const source = (rel) => path.join(here, 'files', ...rel.split('/'))
const read = (p) => fs.readFileSync(p, 'utf8')
const eolOf = (text) => (text.includes('\r\n') ? '\r\n' : '\n')
const toEol = (text, eol) => text.replace(/\r\n/g, '\n').replace(/\n/g, eol)
const sha = (text) => crypto.createHash('sha256').update(text.replace(/\r\n/g, '\n')).digest('hex')
const count = (hay, needle) => (needle ? hay.split(needle).length - 1 : 0)

const pkg = JSON.parse(read(abs('package.json')))
if (pkg.name !== 'locappoint') {
    console.error('  [ABORT] This is not the locappoint repo.')
    process.exit(1)
}

for (const rel of SPEC.newFiles) {
    if (fs.existsSync(abs(rel))) problems.push(`${rel} already exists (patch already applied?)`)
    else if (!fs.existsSync(source(rel))) problems.push(`payload is missing ${rel}`)
    else plan.push(['NEW', rel])
}

for (const { file, sha: expected } of SPEC.replaceFiles) {
    if (!fs.existsSync(abs(file))) { problems.push(`${file} is missing`); continue }
    if (sha(read(abs(file))) !== expected) { problems.push(`${file} changed since this patch was built (or it is already applied)`); continue }
    plan.push(['REPLACE', file])
}

const srcFiles = () => {
    const out = []
    const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const full = path.join(dir, entry.name)
            if (entry.isDirectory()) { if (entry.name !== 'node_modules') walk(full) }
            else if (/\.(jsx?|css)$/.test(entry.name)) out.push(full)
        }
    }
    walk(abs('src'))
    return out
}

for (const prefix of SPEC.prefixes || []) {
    const owners = srcFiles().filter((full) => read(full).includes(prefix)).map((full) => path.relative(root, full))
    if (owners.length) problems.push(`class prefix ${prefix} is already used in ${owners.join(', ')}`)
}

const edits = new Map()
for (const p of SPEC.patches) {
    if (!fs.existsSync(abs(p.file))) { problems.push(`${p.file} is missing`); continue }
    if (!edits.has(p.file)) edits.set(p.file, read(abs(p.file)))
    const current = edits.get(p.file)
    const eol = eolOf(current)
    const find = toEol(p.find, eol)
    const hits = count(current, find)
    if (hits !== 1) { problems.push(`${p.file}: anchor matched ${hits} times, expected 1: ${JSON.stringify(p.find.slice(0, 60))}`); continue }
    edits.set(p.file, current.replace(find, () => toEol(p.replace, eol)))
}
for (const file of edits.keys()) plan.push(['EDIT', file])

for (const rel of SPEC.retires) {
    if (!fs.existsSync(abs(rel))) { problems.push(`${rel} is missing`); continue }
    const base = path.basename(rel)
    const stem = /\.(jsx?)$/.test(base) ? base.replace(/\.(jsx?)$/, '') : base
    const pattern = new RegExp(`[\\/'"]${stem.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\.jsx?)?['"]`)
    const planned = (full) => {
        const key = path.relative(root, full).split(path.sep).join('/')
        if (SPEC.replaceFiles.some((f) => f.file === key)) return read(source(key))
        return edits.has(key) ? edits.get(key) : read(full)
    }
    const users = srcFiles().filter((full) => full !== abs(rel) && pattern.test(planned(full))).map((full) => path.relative(root, full))
    if (users.length) problems.push(`${rel} is still imported by ${users.join(', ')}`)
    else plan.push(['RETIRE', rel])
}

if (problems.length) {
    console.error('  [ABORT] Nothing was written:')
    for (const p of problems) console.error(`    ${p}`)
    process.exit(1)
}

if (check) {
    for (const [kind, rel] of plan) console.log(`  [${kind}] ${rel}`)
    console.log('  Checks passed.')
    process.exit(0)
}

for (const [kind, rel] of plan) {
    const target = abs(rel)
    if (kind === 'NEW') {
        fs.mkdirSync(path.dirname(target), { recursive: true })
        fs.copyFileSync(source(rel), target)
    } else if (kind === 'REPLACE') {
        const eol = eolOf(read(target))
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, toEol(read(source(rel)), eol))
    } else if (kind === 'EDIT') {
        fs.copyFileSync(target, target + SPEC.backup)
        fs.writeFileSync(target, edits.get(rel))
    } else if (kind === 'RETIRE') {
        fs.renameSync(target, target + '.mistake')
    }
    console.log(`  [${kind}] ${rel}`)
}
console.log('  Patch applied.')
